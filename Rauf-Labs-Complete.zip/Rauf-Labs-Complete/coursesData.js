/**
 * 🎓 RAUF LABS ACADEMY — OFFICIAL COURSE CURRICULUM CATALOG
 * 
 * Complete, original course curriculum covering:
 * - AI & Generative AI, Programming, Web Development, Android, Termux,
 * - Linux, Bash, PowerShell, Git & GitHub, APIs, Software Engineering,
 * - Open Source, Cybersecurity, Automation, Developer Tools, Creator Tech,
 * - Productivity, and Core Internet Technology.
 * 
 * Licensed under Creative Commons Attribution 4.0 International (CC BY 4.0)
 * Original educational material crafted for Rauf Labs Academy.
 */

window.COURSES_DATA = [
  // =========================================================================
  // 1. AI & GENERATIVE AI
  // =========================================================================
  {
    id: "gemini-llm-engineering",
    title: "Gemini 2.5 API & LLM Application Engineering",
    shortDescription: "Build real-world AI applications with Gemini 2.5 Flash and Pro. Master prompt engineering, structured JSON schemas, multimodal inputs, and streaming responses without third-party frameworks.",
    category: "AI & Generative AI",
    difficulty: "Intermediate",
    duration: "6 Hours",
    technology: ["Gemini 2.5", "Node.js", "Python", "REST API", "JSON Schema"],
    featured: true,
    whatYouWillLearn: [
      "Direct HTTP and SDK integration with Gemini 2.5 Flash and Pro endpoints",
      "System instructions, temperature tuning, and deterministic output control",
      "Enforcing strictly typed JSON schema responses for reliable backend pipelines",
      "Streaming tokens via Server-Sent Events (SSE) for low-latency chat UIs",
      "BYOK (Bring Your Own Key) architectural design protecting credentials"
    ],
    prerequisites: "Basic proficiency in JavaScript/Node.js or Python, and familiarity with REST APIs.",
    requiredTools: ["Node.js 18+ or Python 3.10+", "cURL or Postman", "Free Gemini API Key from Google AI Studio"],
    modules: [
      {
        moduleTitle: "Module 1: Authentication & First Inference Request",
        lessons: [
          {
            lessonTitle: "Gemini API Keys & Security Architecture",
            duration: "25 min",
            summary: "Obtaining and securing your Google AI Studio API key without leaking it to frontend clients.",
            content: "The Google Gemini API operates over standard HTTPS endpoints. An API key starting with 'AIzaSy...' authenticates requests. When building client-facing web apps, keys should either be proxied through a server or provided by the user using a BYOK pattern stored in the browser's localStorage.",
            codeLanguage: "bash",
            codeSnippet: `# Test Gemini 2.5 Flash connectivity via curl
curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$GEMINI_API_KEY" \\
  -H "Content-Type: application/json" \\
  -d '{
    "contents": [{
      "parts": [{"text": "Explain octal file permissions in Linux in 2 sentences."}]
    }]
  }'`,
            exercise: {
              task: "Execute the cURL request above using your own API key and parse the JSON response body to inspect 'candidates[0].content.parts[0].text'.",
              hint: "Pipe the curl output to jq: curl ... | jq '.candidates[0].content.parts[0].text'",
              solution: "curl -s \"https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$GEMINI_API_KEY\" -H 'Content-Type: application/json' -d '{\"contents\":[{\"parts\":[{\"text\":\"Ping\"}]}]}' | jq ."
            }
          },
          {
            lessonTitle: "System Instructions & Tone Framing",
            duration: "35 min",
            summary: "Enforcing strict developer personas, language constraints, and refusal guardrails.",
            content: "Gemini 2.5 supports top-level system instructions. This separates system guidelines from transient user prompts, preventing prompt injection attacks and guaranteeing consistent response formats.",
            codeLanguage: "javascript",
            codeSnippet: `// Node.js direct fetch integration with systemInstruction
const response = await fetch(\`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=\${apiKey}\`, {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({
    systemInstruction: {
      parts: [{ text: "You are a Linux Kernel and Terminal expert. Always respond with production-ready bash snippets and concise explanations." }]
    },
    contents: [{
      role: 'user',
      parts: [{ text: "How do I monitor live disk I/O in Ubuntu?" }]
    }]
  })
});
const data = await response.json();
console.log(data.candidates[0].content.parts[0].text);`,
            exercise: {
              task: "Modify the system instruction to force the model to output answers as Markdown bullet points with zero conversational filler.",
              hint: "Add 'Never include introductory or concluding phrases. Return only markdown bullets.'",
              solution: "systemInstruction: { parts: [{ text: 'Return only markdown bullet points. Zero fluff.' }] }"
            }
          }
        ]
      },
      {
        moduleTitle: "Module 2: Structured Outputs & Function Calling",
        lessons: [
          {
            lessonTitle: "Guaranteed JSON Schemas via responseSchema",
            duration: "45 min",
            summary: "Eliminating markdown regex parsing by enforcing strict RFC JSON output schemas.",
            content: "By setting 'responseMimeType: application/json' and specifying a 'responseSchema', Gemini is constrained at the decode layer to output strictly valid JSON conforming to your object schema.",
            codeLanguage: "json",
            codeSnippet: `{
  "generationConfig": {
    "responseMimeType": "application/json",
    "responseSchema": {
      "type": "OBJECT",
      "properties": {
        "command": { "type": "STRING" },
        "explanation": { "type": "STRING" },
        "riskLevel": { "type": "STRING", "enum": ["LOW", "MEDIUM", "HIGH"] }
      },
      "required": ["command", "explanation", "riskLevel"]
    }
  }
}`,
            exercise: {
              task: "Create a schema that extracts git commits, commit authors, and whether the commit is a breaking change.",
              hint: "Use an ARRAY type containing OBJECT items with string properties.",
              solution: "{\"type\":\"ARRAY\",\"items\":{\"type\":\"OBJECT\",\"properties\":{\"hash\":{\"type\":\"STRING\"},\"breaking\":{\"type\":\"BOOLEAN\"}}}}"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Terminal AI Copilot CLI Utility",
      description: "Build a standalone Node.js or Python CLI that accepts natural language instructions (e.g. 'find all files modified in the last 2 hours over 10MB'), queries Gemini 2.5 Flash, displays the command, asks for user confirmation, and safely executes it.",
      deliverables: ["Single executable CLI script", "BYOK configuration stored in ~/.config/rauf-ai", "Dry-run and safety validation for destructive commands (rm, dd, mkfs)"]
    },
    troubleshooting: [
      {
        problem: "HTTP 403: API key not valid. Please pass a valid API key.",
        cause: "The API key was copied with leading/trailing whitespace, or the Generative Language API is disabled in Google Cloud Console.",
        fix: "Verify the key starts with 'AIzaSy' and has no whitespace. Ensure you are using the AI Studio free tier key."
      },
      {
        problem: "HTTP 429: Resource exhausted / Quota exceeded.",
        cause: "Exceeded free tier RPM (requests per minute) limit.",
        fix: "Implement exponential backoff with jitter, or use Gemini 2.5 Flash which provides higher rate limits."
      }
    ],
    usefulResources: [
      "Google AI Studio API Key Manager",
      "Gemini REST API Reference & Parameter Guide",
      "Rauf Labs AI Copilot BYOK Guide"
    ],
    officialDocLinks: [
      { title: "Google AI Studio Official Documentation", url: "https://ai.google.dev/gemini-api/docs" },
      { title: "Gemini API Models & Tokens Specification", url: "https://ai.google.dev/gemini-api/docs/models/gemini" }
    ],
    licenseInfo: "Original Rauf Labs Academy Course Curriculum • Released under CC BY 4.0"
  },

  {
    id: "local-ai-ollama",
    title: "Local AI & LLMs with Ollama on Linux & Termux",
    shortDescription: "Deploy and run offline open-source models (Llama 3, DeepSeek, Qwen) on your personal laptop, Linux VPS, or Android device using Ollama and lightweight quantization.",
    category: "AI & Generative AI",
    difficulty: "Beginner",
    duration: "4.5 Hours",
    technology: ["Ollama", "Termux", "Linux", "GGUF", "Llama 3", "cURL"],
    featured: false,
    whatYouWillLearn: [
      "Installing and configuring the Ollama daemon on Linux and ARM64 environments",
      "Selecting the right quantization levels (Q4_K_M vs Q8) for available RAM",
      "Interacting with local models via terminal REPL and localhost REST API",
      "Creating custom Modelfiles with personalized system prompts and temperatures",
      "Building a private, offline terminal copilot without sending data to the cloud"
    ],
    prerequisites: "Basic Linux terminal navigation (cd, curl, cat) and at least 8GB RAM (or 4GB for 1B/3B parameter models).",
    requiredTools: ["Linux or Termux (proot-distro Ubuntu)", "Ollama binary", "4GB+ free disk space"],
    modules: [
      {
        moduleTitle: "Module 1: Installing Ollama & Pulling Quantized Models",
        lessons: [
          {
            lessonTitle: "Single-Command Installation & System Service",
            duration: "20 min",
            summary: "Installing Ollama and managing the background systemd service.",
            content: "Ollama compiles llama.cpp into a clean Go daemon. It automatically detects GPU acceleration (NVIDIA CUDA, AMD ROCm, Apple Metal) or falls back to optimized CPU AVX2 instructions.",
            codeLanguage: "bash",
            codeSnippet: `# Install Ollama on Linux
curl -fsSL https://ollama.com/install.sh | sh

# Verify systemd service status
systemctl status ollama

# Pull a fast 1.5B or 3B coding model
ollama run qwen2.5-coder:1.5b`,
            exercise: {
              task: "Start the Ollama daemon, run 'ollama list' to check downloaded models, and execute a one-line prompt.",
              hint: "Use 'ollama run <model> \"Your prompt\"'",
              solution: "ollama run qwen2.5-coder:1.5b \"Write a bash function to check if port 80 is open\""
            }
          }
        ]
      },
      {
        moduleTitle: "Module 2: Custom Modelfiles & Local API Integration",
        lessons: [
          {
            lessonTitle: "Writing a Custom Modelfile",
            duration: "30 min",
            summary: "Creating custom personas and setting generation temperatures via Modelfiles.",
            content: "Just like a Dockerfile builds container images, a Modelfile builds custom LLM images with baked-in system prompts, stop tokens, and context window sizes.",
            codeLanguage: "dockerfile",
            codeSnippet: `# Modelfile for Rauf Labs Local Bash Assistant
FROM qwen2.5-coder:1.5b

PARAMETER temperature 0.2
PARAMETER top_p 0.9
PARAMETER stop "<|endoftext|>"

SYSTEM """
You are Rauf Labs Local Assistant. You only output safe, verified POSIX bash commands.
Never explain obvious syntax. Always check exit codes with $?.
"""`,
            exercise: {
              task: "Create the Modelfile and build it using 'ollama create rauf-bash -f Modelfile'.",
              hint: "Run 'ollama list' to ensure rauf-bash appears in your local image registry.",
              solution: "ollama create rauf-bash -f ./Modelfile && ollama run rauf-bash \"How to list open sockets?\""
            }
          }
        ]
      }
    ],
    projects: {
      title: "Offline Terminal Translation & Explanation Tool",
      description: "Create a shell function in ~/.bashrc that pipes any command failure output directly to local Ollama for instant offline troubleshooting.",
      deliverables: ["Shell alias integration", "Zero internet dependency", "Sub-second inference using quantized 1.5B model"]
    },
    troubleshooting: [
      {
        problem: "Ollama: Out of memory (OOM) killed.",
        cause: "Model parameter size exceeds available system RAM/VRAM.",
        fix: "Switch to a smaller model (e.g. 1.5B or 3B with Q4 quantization) or increase system swap space."
      }
    ],
    usefulResources: ["Ollama Official Model Library", "GGUF Quantization Cheatsheet"],
    officialDocLinks: [
      { title: "Ollama Official GitHub Repository", url: "https://github.com/ollama/ollama" },
      { title: "Ollama REST API Docs", url: "https://github.com/ollama/ollama/blob/main/docs/api.md" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 2. PROGRAMMING
  // =========================================================================
  {
    id: "modern-python-automation",
    title: "Modern Python 3: From Syntax to Automation & APIs",
    shortDescription: "Master Python 3 from ground up with modern standards. Learn type hints, context managers, pathlib, httpx for async HTTP requests, and practical desktop/server automation.",
    category: "Programming",
    difficulty: "Beginner",
    duration: "8 Hours",
    technology: ["Python 3.12", "Pathlib", "HTTPX", "Virtualenv", "Pip", "JSON"],
    featured: true,
    whatYouWillLearn: [
      "Idiomatic Python 3 syntax, f-strings, list comprehensions, and dictionary unpacking",
      "Strict type hinting and static analysis with mypy",
      "Modern filesystem operations using pathlib instead of legacy os.path",
      "Building robust HTTP clients with httpx for REST APIs and rate-limited web scrapers",
      "Virtual environment isolation with venv and clean dependency management"
    ],
    prerequisites: "No prior programming experience required. Familiarity with typing commands in a terminal is helpful.",
    requiredTools: ["Python 3.10+", "VS Code, Neovim, or Termux nano", "Terminal / Bash"],
    modules: [
      {
        moduleTitle: "Module 1: Modern Syntax, Types & Pathlib",
        lessons: [
          {
            lessonTitle: "Type Annotations & Modern F-Strings",
            duration: "30 min",
            summary: "Writing clean, self-documenting code with native type hints and formatted string literals.",
            content: "Python 3.10+ introduced union types (int | str) and enhanced type annotations. Type hinting catches bugs before runtime when paired with linters and language servers.",
            codeLanguage: "python",
            codeSnippet: `from typing import List, Dict, Optional
from pathlib import Path

def get_disk_reports(directory: Path) -> List[Dict[str, int | str]]:
    """Scan directory and return file names and sizes in bytes."""
    if not directory.exists() or not directory.is_dir():
        raise FileNotFoundError(f"Directory {directory} does not exist.")

    reports = []
    for file_path in directory.iterdir():
        if file_path.is_file():
            reports.append({
                "name": file_path.name,
                "size_bytes": file_path.stat().st_size
            })
    return reports

if __name__ == "__main__":
    home_docs = Path.home() / "Documents"
    print(f"Scanning: {home_docs}")`,
            exercise: {
              task: "Enhance the get_disk_reports function to recursively find files with suffix '.log' using directory.rglob('*.log').",
              hint: "Use `for file_path in directory.rglob('*.log'):` instead of iterdir().",
              solution: "def find_logs(d: Path): return [f.name for f in d.rglob('*.log') if f.is_file()]"
            }
          }
        ]
      },
      {
        moduleTitle: "Module 2: Robust API Requests with HTTPX",
        lessons: [
          {
            lessonTitle: "Connecting to REST APIs with HTTPX",
            duration: "45 min",
            summary: "Replacing legacy requests library with modern HTTP/2 and async-capable HTTPX.",
            content: "HTTPX provides standard synchronous and asynchronous clients, automatic connection pooling, HTTP/2 support, and strict status code validation with raise_for_status().",
            codeLanguage: "python",
            codeSnippet: `import httpx
import json

def fetch_github_user(username: str) -> dict:
    url = f"https://api.github.com/users/{username}"
    headers = {"User-Agent": "RaufLabs-PythonCourse/1.0"}
    
    with httpx.Client(timeout=10.0) as client:
        response = client.get(url, headers=headers)
        response.raise_for_status()
        return response.json()

user = fetch_github_user("torvalds")
print(f"User: {user['login']} | Public Repos: {user['public_repos']}")`,
            exercise: {
              task: "Wrap the HTTP request in a try...except block catching httpx.HTTPStatusError and return None if user not found.",
              hint: "Catch `httpx.HTTPStatusError as exc:` and check `exc.response.status_code == 404`.",
              solution: "try:\n    r.raise_for_status()\nexcept httpx.HTTPStatusError as e:\n    if e.response.status_code == 404: return None\n    raise"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Automated Daily System Health Reporter",
      description: "Build a Python automation script that gathers CPU load, disk usage via pathlib, and public IP via an API, formats a markdown summary, and writes it to a timestamped file.",
      deliverables: ["Modular script with argparse CLI flags", "Zero third-party dependencies except httpx", "Clean systemd or cron configuration instructions"]
    },
    troubleshooting: [
      {
        problem: "ModuleNotFoundError: No module named 'httpx'",
        cause: "Script was executed in the global environment instead of the active virtual environment.",
        fix: "Create and activate a venv: python3 -m venv .venv && source .venv/bin/activate && pip install httpx"
      }
    ],
    usefulResources: ["Python 3 Official Docs", "HTTPX Quickstart Guide", "Real Python Pathlib Tutorial"],
    officialDocLinks: [
      { title: "Python Official Documentation", url: "https://docs.python.org/3/" },
      { title: "HTTPX Official Documentation", url: "https://www.python-httpx.org/" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  {
    id: "javascript-typescript-mastery",
    title: "Modern JavaScript & TypeScript for Backend & Tools",
    shortDescription: "Level up from JavaScript fundamentals to strong TypeScript type safety, async programming, ES Modules, and Node.js command-line utilities.",
    category: "Programming",
    difficulty: "Intermediate",
    duration: "7 Hours",
    technology: ["TypeScript 5", "Node.js", "ES Modules", "Async/Await", "Promises"],
    featured: false,
    whatYouWillLearn: [
      "ES Modules (import/export), top-level await, and modern syntax features",
      "TypeScript interfaces, generics, type narrowing, and utility types (Partial, Pick, Record)",
      "Asynchronous control flow: Promise.allSettled, async generators, and AbortController",
      "Building standalone Node.js executable scripts with chmod +x and hashbangs",
      "Strict compiler configurations (noImplicitAny, strictNullChecks) for bug-free code"
    ],
    prerequisites: "Basic familiarity with web development and variable declaration (let, const).",
    requiredTools: ["Node.js 18+ or Bun", "npm / npx", "TypeScript compiler (tsc)"],
    modules: [
      {
        moduleTitle: "Module 1: Modern ES Modules & TypeScript Types",
        lessons: [
          {
            lessonTitle: "Type Narrowing & Generic Interfaces",
            duration: "35 min",
            summary: "Writing reusable generic functions and narrowing types safely.",
            content: "TypeScript lets you declare strict schemas for data flowing through APIs. Using Discriminated Unions and Type Guards prevents undefined runtime errors.",
            codeLanguage: "typescript",
            codeSnippet: `type ApiResponse<T> = 
  | { success: true; data: T; timestamp: number }
  | { success: false; error: string; code: number };

interface ServerHealth {
  uptimeSeconds: number;
  memoryUsageMb: number;
  status: 'healthy' | 'degraded' | 'critical';
}

function handleResponse(res: ApiResponse<ServerHealth>): void {
  if (res.success) {
    // TypeScript automatically narrows res to the success branch
    console.log(\`Server status: \${res.data.status} (Uptime: \${res.data.uptimeSeconds}s)\`);
  } else {
    console.error(\`Error \${res.code}: \${res.error}\`);
  }
}`,
            exercise: {
              task: "Create a generic function 'wrapSuccess<T>(data: T): ApiResponse<T>' that returns a valid success payload.",
              hint: "Return { success: true, data, timestamp: Date.now() }",
              solution: "function wrapSuccess<T>(data: T): ApiResponse<T> { return { success: true, data, timestamp: Date.now() }; }"
            }
          }
        ]
      }
    ],
    projects: {
      title: "File Integrity & Hash Checker CLI",
      description: "Create a compiled TypeScript CLI utility that calculates SHA-256 hashes of files in a directory and outputs a JSON checksum manifest.",
      deliverables: ["CLI compiled with tsc", "Readable error handling", "Colorized terminal output using ANSI escape codes"]
    },
    troubleshooting: [
      {
        problem: "Cannot use import statement outside a module",
        cause: "package.json missing '\"type\": \"module\"' field.",
        fix: "Add '\"type\": \"module\"' to package.json or use .mjs file extensions."
      }
    ],
    usefulResources: ["TypeScript Handbook", "MDN JavaScript Reference"],
    officialDocLinks: [
      { title: "TypeScript Official Documentation", url: "https://www.typescriptlang.org/docs/" },
      { title: "Node.js API Documentation", url: "https://nodejs.org/docs/latest/api/" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 3. WEB DEVELOPMENT
  // =========================================================================
  {
    id: "fullstack-node-express",
    title: "Full-Stack Web Architecture with Node.js & Express",
    shortDescription: "Architect production REST APIs and web servers with Express. Learn routing, middleware pipelines, error handling, CORS, static file serving, and JWT authentication.",
    category: "Web Development",
    difficulty: "Intermediate",
    duration: "9 Hours",
    technology: ["Node.js", "Express 5", "REST API", "JWT", "CORS", "Middleware"],
    featured: true,
    whatYouWillLearn: [
      "Express request/response cycle, custom middlewares, and router modularization",
      "Safe body parsing, rate limiting, and security headers with Helmet",
      "RESTful resource design: GET, POST, PUT, PATCH, DELETE idempotency",
      "Centralized error handling middleware preventing uncaught server crashes",
      "Stateless authentication using JWT tokens and authorization headers"
    ],
    prerequisites: "Intermediate JavaScript/Node.js understanding.",
    requiredTools: ["Node.js 18+", "npm", "cURL or Postman"],
    modules: [
      {
        moduleTitle: "Module 1: Server Setup & Middleware Pipeline",
        lessons: [
          {
            lessonTitle: "The Express Middleware Pattern",
            duration: "40 min",
            summary: "Understanding req, res, and next() to build auth and logging pipelines.",
            content: "In Express, everything is a middleware function executed in sequential order. Intercepting requests early allows authentication verification, request logging, and rate limiting before hitting database endpoints.",
            codeLanguage: "javascript",
            codeSnippet: `import express from 'express';

const app = express();
const PORT = process.env.PORT || 3000;

// Body parser middleware
app.use(express.json());

// Request logger middleware
app.use((req, res, next) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(\`[\${req.method}] \${req.originalUrl} - \${res.statusCode} (\${duration}ms)\`);
  });
  next();
});

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(\`Server running on http://localhost:\${PORT}\`);
});`,
            exercise: {
              task: "Add an API key verification middleware that rejects requests without an 'x-api-key' header with a 401 Unauthorized status.",
              hint: "Check req.headers['x-api-key'] and return res.status(401).json({ error: 'Unauthorized' }) if missing.",
              solution: "app.use((req, res, next) => { if (req.headers['x-api-key'] !== 'my-secret') return res.status(401).json({error: 'Invalid API key'}); next(); });"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Self-Hosted Code Snippets & Notes REST API",
      description: "Build an Express REST API that allows users to create, search, and delete tagged markdown notes with in-memory or JSON file persistence.",
      deliverables: ["CRUD routes for /api/notes", "Filter by tag query parameter (?tag=termux)", "Comprehensive error handling middleware"]
    },
    troubleshooting: [
      {
        problem: "Error: listen EADDRINUSE: address already in use :::3000",
        cause: "Another process is already bound to port 3000.",
        fix: "Identify and kill the blocking process: lsof -i :3000 | awk 'NR>1 {print $2}' | xargs kill -9"
      }
    ],
    usefulResources: ["Express.js Documentation", "MDN HTTP Guide"],
    officialDocLinks: [
      { title: "Express.js Official Guide", url: "https://expressjs.com/" },
      { title: "MDN HTTP Overview", url: "https://developer.mozilla.org/en-US/docs/Web/HTTP" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  {
    id: "modern-css-responsive-ui",
    title: "Responsive UI Engineering with Semantic HTML & Modern CSS",
    shortDescription: "Build blazing fast, responsive, and accessible user interfaces without bloated frameworks. Master CSS Grid, Flexbox, CSS variables, and fluid typography.",
    category: "Web Development",
    difficulty: "Beginner",
    duration: "5 Hours",
    technology: ["HTML5", "CSS3", "CSS Grid", "Flexbox", "Responsive Design"],
    featured: false,
    whatYouWillLearn: [
      "Semantic HTML structures (nav, main, section, article) for optimal SEO and screen readers",
      "CSS Grid 2D layouts and auto-fit/auto-fill responsive patterns without media queries",
      "Flexbox alignment, gap properties, and flexible component layout",
      "Fluid typography using clamp() and modern CSS custom properties (variables)",
      "Mobile-first responsive design principles and touch target standards (minimum 44px)"
    ],
    prerequisites: "Basic computer literacy and text editing.",
    requiredTools: ["Any modern web browser (Chrome, Firefox)", "Code editor (VS Code, nano, vim)"],
    modules: [
      {
        moduleTitle: "Module 1: CSS Grid & Fluid Layouts",
        lessons: [
          {
            lessonTitle: "The Zero-Media-Query Responsive Card Grid",
            duration: "30 min",
            summary: "Building cards that automatically adjust to any screen size using repeat(auto-fill, minmax()).",
            content: "Modern CSS Grid solves responsive columns natively using auto-fill and minmax(). Instead of writing dozens of breakpoint media queries, the browser mathematically calculates column wraps.",
            codeLanguage: "css",
            codeSnippet: `/* Fluid Responsive Grid */
.course-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
  padding: 16px;
}

/* Card with mathematically calculated inner radius */
.card {
  --radius-outer: 16px;
  --padding-card: 20px;
  border-radius: var(--radius-outer);
  padding: var(--padding-card);
  background: rgba(14, 21, 37, 0.7);
  border: 1px solid rgba(255, 255, 255, 0.08);
  backdrop-filter: blur(12px);
}

.card-badge {
  /* Inner Radius = Outer Radius - Padding */
  border-radius: calc(var(--radius-outer) - var(--padding-card) + 10px);
}`,
            exercise: {
              task: "Create a container with 3 cards that stacks into 1 column on screens smaller than 300px and spreads to 3 columns on desktop.",
              hint: "Use grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)).",
              solution: ".grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1rem; }"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Responsive Developer Portfolio Page",
      description: "Build a single-page responsive portfolio showcasing projects, skills, and contact links with a dark cyberpunk aesthetic.",
      deliverables: ["Semantic HTML structure", "Pure modern CSS with custom variables", "100% Mobile responsive tested down to 320px"]
    },
    troubleshooting: [
      {
        problem: "Horizontal scrollbar appears on mobile screens.",
        cause: "An element has an explicit width: 100vw or fixed pixel width exceeding screen bounds.",
        fix: "Use max-width: 100% and box-sizing: border-box on all elements."
      }
    ],
    usefulResources: ["MDN Web Docs CSS Grid Guide", "CSS-Tricks Flexbox Guide"],
    officialDocLinks: [
      { title: "MDN Web Docs HTML & CSS", url: "https://developer.mozilla.org/en-US/docs/Learn" },
      { title: "W3C Web Accessibility Guidelines (WCAG)", url: "https://www.w3.org/WAI/standards-guidelines/wcag/" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 4. ANDROID
  // =========================================================================
  {
    id: "android-internals-adb",
    title: "Android Internals, ADB & Package Management Mastery",
    shortDescription: "Demystify Android operating system internals. Master Android Debug Bridge (ADB), Wireless debugging, package managers (pm), Logcat debugging, and system service introspection.",
    category: "Android",
    difficulty: "Intermediate",
    duration: "6.5 Hours",
    technology: ["Android ADB", "Fastboot", "Logcat", "Linux Kernel", "Android Services"],
    featured: true,
    whatYouWillLearn: [
      "Android architectural stack: Linux Kernel, HAL, ART runtime, and system services",
      "Connecting via ADB over USB and Wireless ADB over local Wi-Fi networks",
      "Inspecting, uninstalling bloatware, and granting runtime permissions with pm and am",
      "Advanced log filtering with logcat, regex matching, and crash diagnostics",
      "Capturing screen recordings, dumping battery stats, and inspecting network interfaces"
    ],
    prerequisites: "An Android phone with Developer Options enabled and a computer or Termux with adb installed.",
    requiredTools: ["Android device (Android 9+)", "Platform Tools (ADB/Fastboot) or Termux Android-tools"],
    modules: [
      {
        moduleTitle: "Module 1: ADB Wireless & Package Management",
        lessons: [
          {
            lessonTitle: "Wireless ADB Pairing & Device Shell",
            duration: "30 min",
            summary: "Pairing and connecting to Android devices over Wi-Fi without USB cables.",
            content: "Android 11+ supports native Wireless Debugging with TLS pairing. This allows developers to debug devices directly from Termux or a laptop over the same Wi-Fi network.",
            codeLanguage: "bash",
            codeSnippet: `# Pair device with pairing code from Developer Options -> Wireless Debugging
adb pair 192.168.1.50:37891

# Connect to the debug port
adb connect 192.168.1.50:41235

# Verify connection
adb devices -l

# Enter interactive Android shell
adb shell`,
            exercise: {
              task: "Open adb shell and list all installed third-party user applications using 'pm list packages -3'.",
              hint: "Run 'adb shell pm list packages -3' from your host terminal.",
              solution: "adb shell pm list packages -3 | cut -d: -f2 | sort"
            }
          },
          {
            lessonTitle: "Inspecting Logs & Diagnosing App Crashes with Logcat",
            duration: "35 min",
            summary: "Filtering noisy Android logs to catch specific stack traces and fatal exceptions.",
            content: "Android Logcat logs everything from system hardware events to app exceptions. Using priority filters (*:E for errors, *:W for warnings) and PID matching isolates crash reports instantly.",
            codeLanguage: "bash",
            codeSnippet: `# Stream fatal crashes in real-time
adb logcat -v time "*:E" | grep -iE "fatal|exception|crash"

# Clear logcat buffer
adb logcat -c

# Dump battery stats and charging profile
adb shell dumpsys battery`,
            exercise: {
              task: "Filter logcat to display messages from only one specific app package name.",
              hint: "Use `adb logcat --pid=$(adb shell pidof -s <package_name>)`.",
              solution: "pkg='com.example.app'; adb logcat --pid=$(adb shell pidof -s $pkg)"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Automated Device Bloatware Cleaner Script",
      description: "Create a safe shell script that lists OEM bloatware packages, asks user confirmation, and uninstalls them for user 0 (pm uninstall -k --user 0) without bricking device boot.",
      deliverables: ["Safe package whitelist/blacklist", "Dry-run execution mode", "Re-installation instructions via pm install-existing"]
    },
    troubleshooting: [
      {
        problem: "adb: device unauthorized. This adb server's $ADB_VENDOR_KEYS is not set",
        cause: "The Android phone screen has not accepted the 'Allow USB debugging?' RSA fingerprint prompt.",
        fix: "Unlock the Android device screen, check 'Always allow from this computer', and tap Allow."
      }
    ],
    usefulResources: ["Android Developer Platform Tools", "Android Open Source Project (AOSP) Docs"],
    officialDocLinks: [
      { title: "Android Developers ADB Guide", url: "https://developer.android.com/tools/adb" },
      { title: "Logcat Command-Line Tool", url: "https://developer.android.com/tools/logcat" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  {
    id: "android-kotlin-jetpack",
    title: "Modern Android App Architecture with Kotlin & Jetpack Compose",
    shortDescription: "Build native modern Android apps with Kotlin and Jetpack Compose. Learn declarative UI, State hoisting, ViewModels, Coroutines, and MVVM architecture.",
    category: "Android",
    difficulty: "Advanced",
    duration: "10 Hours",
    technology: ["Kotlin", "Jetpack Compose", "Coroutines", "Flow", "Android Studio", "Gradle"],
    featured: false,
    whatYouWillLearn: [
      "Modern Kotlin fundamentals: null-safety, data classes, extension functions, and lambdas",
      "Declarative UI programming with Jetpack Compose instead of legacy XML layouts",
      "State management: remember, mutableStateOf, and unidirectional data flow (UDF)",
      "Asynchronous background operations with Kotlin Coroutines and StateFlow",
      "MVVM (Model-View-ViewModel) architecture ensuring separation of concerns"
    ],
    prerequisites: "Familiarity with object-oriented programming concepts (classes, interfaces).",
    requiredTools: ["Android Studio Hedgehog/Iguana+", "JDK 17", "Android Device or Emulator"],
    modules: [
      {
        moduleTitle: "Module 1: Jetpack Compose UI & State",
        lessons: [
          {
            lessonTitle: "Declarative UI with Composable Functions",
            duration: "45 min",
            summary: "Building reactive UI components with Column, Row, Text, and Button.",
            content: "Compose completely replaces Android XML layouts with Kotlin code. When state changes, Compose intelligently recomposes only the affected UI nodes.",
            codeLanguage: "kotlin",
            codeSnippet: `package com.rauflabs.compose

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun DeveloperTerminalCounter() {
    var count by remember { mutableStateOf(0) }

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Column(
            modifier = Modifier.padding(24.dp),
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Terminal Tasks Run: $count",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(onClick = { count++ }) {
                Text("Execute Task (+1)")
            }
        }
    }
}`,
            exercise: {
              task: "Add a reset button that sets the counter back to 0 only when count is greater than 0.",
              hint: "Use an `if (count > 0)` check inside the Row.",
              solution: "if (count > 0) { Button(onClick = { count = 0 }) { Text(\"Reset\") } }"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Android Network Scanner & Ping Utility App",
      description: "Build an Android app in Jetpack Compose that discovers devices on the current Wi-Fi subnet and measures latency with visual status cards.",
      deliverables: ["Compose UI with dark mode support", "Coroutines for non-blocking ICMP ping requests", "ViewModel with StateFlow updates"]
    },
    troubleshooting: [
      {
        problem: "Compose compiler version incompatibility with Kotlin version.",
        cause: "Kotlin version in build.gradle does not match the Compose compiler extension version.",
        fix: "Check the official Kotlin/Compose compatibility matrix and pin matching versions in libs.versions.toml."
      }
    ],
    usefulResources: ["Android Developers Jetpack Compose Tutorial", "Kotlin Language Documentation"],
    officialDocLinks: [
      { title: "Android Developers Official Guide", url: "https://developer.android.com/" },
      { title: "Kotlin Official Documentation", url: "https://kotlinlang.org/docs/home.html" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 5. TERMUX
  // =========================================================================
  {
    id: "termux-complete-mastery",
    title: "Complete Termux Mastery: Linux Power Environment on Android",
    shortDescription: "Turn your Android phone into a high-powered Linux terminal workstation. Master storage permissions, pkg/apt package management, proot distros, and development stacks.",
    category: "Termux",
    difficulty: "Beginner",
    duration: "5 Hours",
    technology: ["Termux", "APT / PKG", "Bash", "SSH", "Android Storage", "proot"],
    featured: true,
    whatYouWillLearn: [
      "Installing Termux from F-Droid (avoiding deprecated Google Play Store builds)",
      "Configuring mirror repositories with termux-change-repo and maintaining packages",
      "Granting external storage permissions with termux-setup-storage to edit files in ~/storage",
      "Setting up OpenSSH server with public key authentication for remote access",
      "Installing Python, Node.js, Git, C compilers, and running local developer servers"
    ],
    prerequisites: "An Android device running Android 7.0 or higher.",
    requiredTools: ["Termux app (from F-Droid or GitHub Releases)", "Hacker's Keyboard (recommended)"],
    modules: [
      {
        moduleTitle: "Module 1: Installation, Repositories & Storage Setup",
        lessons: [
          {
            lessonTitle: "The Clean Termux Bootstrap",
            duration: "25 min",
            summary: "Setting up Termux correctly from official F-Droid builds and updating mirrors.",
            content: "Google Play Store Termux builds are deprecated and cannot receive package updates due to Android SDK target requirements. Always install Termux from F-Droid or the official GitHub releases.",
            codeLanguage: "bash",
            codeSnippet: `# 1. Update package database and upgrade existing core utilities
pkg update && pkg upgrade -y

# 2. Select the fastest mirror geographically
termux-change-repo

# 3. Grant access to shared internal Android storage (/sdcard)
termux-setup-storage

# 4. Install essential developer tools
pkg install -y git curl wget neovim tmux openssh python nodejs-lts`,
            exercise: {
              task: "Navigate to your phone's external shared Downloads folder from Termux and create a test markdown file.",
              hint: "Use 'cd ~/storage/downloads && echo \"# Hello from Termux\" > test.md'.",
              solution: "cd ~/storage/downloads && echo '# Termux Test' > test.md && ls -la test.md"
            }
          },
          {
            lessonTitle: "Running OpenSSH Server & Remote Access",
            duration: "30 min",
            summary: "Accessing your Android Termux shell from your PC or laptop over Wi-Fi.",
            content: "Termux runs OpenSSH on port 8022 (non-root standard). You can connect from any computer on your Wi-Fi network using standard SSH keys or passwords.",
            codeLanguage: "bash",
            codeSnippet: `# Set a password for your Termux user
passwd

# Start SSH daemon on port 8022
sshd

# Find your phone's Wi-Fi IP address
ip addr show wlan0 | grep "inet "

# From your PC terminal, connect via SSH:
# ssh -p 8022 <phone_ip_address>`,
            exercise: {
              task: "Add your PC's public SSH key (~/.ssh/id_rsa.pub) into Termux ~/.ssh/authorized_keys for passwordless login.",
              hint: "Append the key text into ~/.ssh/authorized_keys and run 'chmod 600 ~/.ssh/authorized_keys'.",
              solution: "mkdir -p ~/.ssh && chmod 700 ~/.ssh && echo 'ssh-rsa AAA...' >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys"
            }
          }
        ]
      }
    ],
    projects: {
      title: "All-in-One Termux Developer Quickstart Script",
      description: "Create an idempotent bash script that configures shell aliases, sets up a custom PS1 prompt, installs developer packages, and generates SSH keys automatically.",
      deliverables: ["Single-command bootstrap script", "Custom ~/.bashrc with helpful shortcuts", "Safe backup of existing configurations"]
    },
    troubleshooting: [
      {
        problem: "pkg install fails with 'Repository is under maintenance' or 404.",
        cause: "Outdated default mirror or temporary network block.",
        fix: "Run 'termux-change-repo', select 'Grimler' or 'Albatross' mirror, and run 'pkg update'."
      }
    ],
    usefulResources: ["Termux Official Wiki", "F-Droid Termux Package Page"],
    officialDocLinks: [
      { title: "Termux Official Wiki Documentation", url: "https://wiki.termux.com/wiki/Main_Page" },
      { title: "Termux GitHub Community", url: "https://github.com/termux/termux-app" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  {
    id: "termux-headless-server",
    title: "Headless Mobile Server & Microservices in Termux",
    shortDescription: "Turn an old Android phone into a 24/7 self-hosted microserver. Configure background execution, battery optimization exemptions, tmux sessions, and cron tasks.",
    category: "Termux",
    difficulty: "Intermediate",
    duration: "6 Hours",
    technology: ["Termux", "Node.js", "Python", "Tmux", "Cron", "Microservices"],
    featured: false,
    whatYouWillLearn: [
      "Preventing Android OS process killing with termux-wake-lock and battery whitelisting",
      "Running persistent terminal sessions with tmux that survive SSH disconnects",
      "Scheduling recurring tasks with cron (crond / crontab) inside Termux",
      "Deploying lightweight web servers (Express, Python HTTP) on local Wi-Fi",
      "Tunneling local phone endpoints to the public internet using Cloudflare Tunnels"
    ],
    prerequisites: "Completion of 'Complete Termux Mastery' or equivalent Linux command line knowledge.",
    requiredTools: ["Android device plugged into power", "Termux with Termux:API addon"],
    modules: [
      {
        moduleTitle: "Module 1: Background Persistence & Tmux",
        lessons: [
          {
            lessonTitle: "Acquiring Wake-Locks & Battery Exemption",
            duration: "25 min",
            summary: "Ensuring Termux processes stay running when phone screen locks.",
            content: "Android aggressively kills background apps to conserve battery. Using 'termux-wake-lock' and exempting Termux from system battery optimization keeps CPU cores active for continuous server operation.",
            codeLanguage: "bash",
            codeSnippet: `# Acquire CPU wake lock so server does not sleep when screen turns off
termux-wake-lock

# Verify wake lock is active in notification bar
# To release wake lock when done:
# termux-wake-unlock

# Launch a persistent tmux session named "server"
tmux new -s server

# Detach from tmux: Press Ctrl+B then D
# Re-attach anytime: tmux attach -t server`,
            exercise: {
              task: "Create a tmux session, launch a Python web server on port 8080, detach, close Termux, reopen, and reattach to verify the server is still running.",
              hint: "Run 'tmux new -s web', then 'python3 -m http.server 8080', press Ctrl+B then D.",
              solution: "tmux new -s web -d 'python3 -m http.server 8080' && tmux ls"
            }
          }
        ]
      }
    ],
    projects: {
      title: "24/7 Local Network File Sharing Hub",
      description: "Configure your phone with an external USB OTG or SD card to act as a local network file drop and webhook notification server using Node.js.",
      deliverables: ["Auto-start on boot using Termux:Boot", "Web UI for uploading and browsing files", "System stats monitoring dashboard"]
    },
    troubleshooting: [
      {
        problem: "Termux server stops responding 10 minutes after phone screen turns off.",
        cause: "Android OS Doze mode suspended Termux CPU execution.",
        fix: "Go to Android Settings -> Apps -> Termux -> Battery -> Set to 'Unrestricted' and run 'termux-wake-lock'."
      }
    ],
    usefulResources: ["Termux:Boot Addon Guide", "Tmux Cheat Sheet"],
    officialDocLinks: [
      { title: "Termux Background Work Documentation", url: "https://wiki.termux.com/wiki/Termux-wake-lock" },
      { title: "Tmux Official Documentation", url: "https://github.com/tmux/tmux/wiki" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 6. LINUX
  // =========================================================================
  {
    id: "linux-sysadmin-hardening",
    title: "Linux System Administration & Security Hardening",
    shortDescription: "Master Linux systems administration from the ground up. File hierarchy (FHS), POSIX permissions, user & group management, systemd services, and firewall hardening.",
    category: "Linux",
    difficulty: "Intermediate",
    duration: "8 Hours",
    technology: ["Linux", "Systemd", "UFW Firewall", "Chmod / Chown", "Journalctl", "SSH"],
    featured: true,
    whatYouWillLearn: [
      "The Filesystem Hierarchy Standard (FHS): /etc, /var, /opt, /usr, /proc, /dev",
      "POSIX file permissions, numeric octal modes (755 vs 644), and sticky/SUID bits",
      "Creating and managing custom systemd background service units with auto-restart",
      "Inspecting system logs, boot failures, and services with journalctl",
      "Hardening SSH (/etc/ssh/sshd_config) and configuring UFW firewall rules"
    ],
    prerequisites: "Basic command line navigation (cd, ls, cat, nano).",
    requiredTools: ["Any Linux distribution (Ubuntu, Debian, Fedora, Arch) or VM / VPS"],
    modules: [
      {
        moduleTitle: "Module 1: Permissions, Ownership & File Hierarchy",
        lessons: [
          {
            lessonTitle: "Octal Permissions & Symbolic Representation",
            duration: "35 min",
            summary: "Understanding read (4), write (2), execute (1) across User, Group, and Others.",
            content: "Linux permissions protect files at the kernel level. A permission mode like 755 grants the owner full control (4+2+1=7), while group and others can read and execute (4+1=5).",
            codeLanguage: "bash",
            codeSnippet: `# View detailed file permissions
ls -la /var/log/

# Set executable permission for owner, read-only for group/others (755)
chmod 755 deploy.sh

# Set standard data file permissions (644)
chmod 644 config.json

# Restrict sensitive private keys strictly to owner (600)
chmod 600 ~/.ssh/id_ed25519

# Change file ownership to developer user and devops group
sudo chown developer:devops /var/www/app -R`,
            exercise: {
              task: "Create a directory with sticky bit set so users can only delete their own files within it (like /tmp).",
              hint: "Use chmod +t or chmod 1777 <directory>.",
              solution: "mkdir /tmp/shared && chmod 1777 /tmp/shared && ls -ld /tmp/shared"
            }
          },
          {
            lessonTitle: "Writing Custom Systemd Service Units",
            duration: "45 min",
            summary: "Running production applications as managed daemon services.",
            content: "Systemd manages system initialization, background daemons, dependency ordering, and automatic crash restarts.",
            codeLanguage: "ini",
            codeSnippet: `# /etc/systemd/system/rauf-api.service
[Unit]
Description=Rauf Labs Background API Daemon
After=network.target

[Service]
Type=simple
User=developer
WorkingDirectory=/opt/rauf-api
ExecStart=/usr/bin/node server.js
Restart=always
RestartSec=5s
Environment=NODE_ENV=production PORT=8080

[Install]
WantedBy=multi-user.target`,
            exercise: {
              task: "Reload the systemd daemon, enable the service to start on boot, and check its status.",
              hint: "Run sudo systemctl daemon-reload, then sudo systemctl enable --now <service_name>.",
              solution: "sudo systemctl daemon-reload && sudo systemctl enable --now rauf-api && sudo systemctl status rauf-api"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Production VPS Hardening Automation",
      description: "Write an automated provisioning script that creates an unprivileged sudo user, disables SSH root login and password auth, configures UFW firewall, and enables unattended security upgrades.",
      deliverables: ["Zero-touch bash hardening script", "Tested on clean Ubuntu/Debian instance", "Verification checklist script"]
    },
    troubleshooting: [
      {
        problem: "Failed to start service: Unit not found.",
        cause: "Systemd daemon has not rescanned /etc/systemd/system after creating or modifying a .service file.",
        fix: "Run 'sudo systemctl daemon-reload' before starting or enabling the service."
      }
    ],
    usefulResources: ["Linux Foundation FHS Guide", "DigitalOcean Systemd Essentials"],
    officialDocLinks: [
      { title: "Systemd Documentation", url: "https://systemd.io/" },
      { title: "Ubuntu Server Security Guide", url: "https://ubuntu.com/server/docs/security" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  {
    id: "linux-networking-diagnostics",
    title: "Linux Networking, Diagnostics & Remote Administration",
    shortDescription: "Troubleshoot and configure Linux networks with confidence. Master IP routing, open ports (ss/netstat), DNS resolution (dig), cURL debugging, and Fail2ban brute-force defense.",
    category: "Linux",
    difficulty: "Advanced",
    duration: "7 Hours",
    technology: ["Linux Networking", "cURL", "ss / netstat", "Dig / DNS", "Fail2ban", "UFW"],
    featured: false,
    whatYouWillLearn: [
      "Inspecting active network interfaces, IP allocation, and routing tables with 'ip'",
      "Identifying listening ports, sockets, and associated process IDs with 'ss -tulpn'",
      "Debugging DNS lookup delays, authoritative nameservers, and records with 'dig'",
      "Diagnosing HTTP request lifecycles and timing metrics with cURL -w",
      "Automated IP ban protection against SSH brute-force attackers using Fail2ban"
    ],
    prerequisites: "Linux system administration fundamentals.",
    requiredTools: ["Linux machine or VM", "iproute2, bind9-dnsutils, curl, fail2ban"],
    modules: [
      {
        moduleTitle: "Module 1: Socket Inspection & DNS Diagnostics",
        lessons: [
          {
            lessonTitle: "Socket Statistics with ss",
            duration: "30 min",
            summary: "Replacing obsolete netstat with high-speed kernel socket statistics (ss).",
            content: "The 'ss' utility queries socket information directly from Linux kernel space, making it orders of magnitude faster than netstat on high-traffic servers.",
            codeLanguage: "bash",
            codeSnippet: `# List all TCP listening ports with process names and PIDs
sudo ss -tulpn

# Filter only sockets listening on port 80 or 443
sudo ss -tulpn | grep -E ":80|:443"

# Trace DNS resolution step-by-step
dig +trace +nodnssec google.com

# Measure exact HTTP connection phase latencies with curl
curl -so /dev/null -w "DNS: %{time_namelookup}s | Connect: %{time_connect}s | TTFB: %{time_starttransfer}s | Total: %{time_total}s\\n" https://rauflabs.ai.studio`,
            exercise: {
              task: "Use 'ss' to find which process is currently bound to port 22 (SSH).",
              hint: "Run 'sudo ss -tulpn | grep :22'.",
              solution: "sudo ss -tulpn | grep ':22 ' | awk '{print $NF}'"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Real-Time Network Health Monitoring Script",
      description: "Build an automated monitor that checks ping latency to primary DNS (1.1.1.1), verifies HTTP 200 on key endpoints, and alerts if port utilization spikes.",
      deliverables: ["Modular shell script", "Cron-ready execution", "Clean logging to /var/log/netmon.log"]
    },
    troubleshooting: [
      {
        problem: "Temporary failure in name resolution (DNS resolution fails).",
        cause: "/etc/resolv.conf is empty or pointed to an unreachable DNS nameserver.",
        fix: "Check /etc/resolv.conf and set a verified upstream nameserver like 'nameserver 1.1.1.1'."
      }
    ],
    usefulResources: ["Linux Advanced Routing & Traffic Control", "Cloudflare DNS Learning Center"],
    officialDocLinks: [
      { title: "IPRoute2 Linux Documentation", url: "https://wiki.linuxfoundation.org/networking/iproute2" },
      { title: "cURL Official Manual", url: "https://curl.se/docs/manual.html" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 7. BASH
  // =========================================================================
  {
    id: "production-bash-scripting",
    title: "Production Bash Scripting & Pipeline Automation",
    shortDescription: "Write robust, safe, and maintainable Bash scripts that never silently fail. Master 'set -euo pipefail', argument parsing, streams, regex, exit codes, and automated pipelines.",
    category: "Bash",
    difficulty: "Intermediate",
    duration: "6 Hours",
    technology: ["Bash", "Shell Scripts", "Pipes", "Grep / Sed / Awk", "Cron", "Linux"],
    featured: true,
    whatYouWillLearn: [
      "The Bash Strict Mode: 'set -euo pipefail' and IFS safety configurations",
      "Parsing CLI flags and arguments cleanly using getopts",
      "Input/Output redirection: stdin (0), stdout (1), stderr (2), and heredocs",
      "Text processing pipelines with grep, sed, awk, and cut",
      "Defensive trap handlers (EXIT, ERR, INT) for automatic cleanup of temp files"
    ],
    prerequisites: "Basic familiarity with Linux command line.",
    requiredTools: ["Bash 4.0+", "Any Linux/macOS terminal or Termux"],
    modules: [
      {
        moduleTitle: "Module 1: Defensive Script Architecture",
        lessons: [
          {
            lessonTitle: "The Unofficial Bash Strict Mode",
            duration: "30 min",
            summary: "Eliminating silent script bugs with set -euo pipefail and traps.",
            content: "By default, Bash continues executing even when a command fails or a variable is undefined. Strict mode forces scripts to halt immediately on errors and pipe failures.",
            codeLanguage: "bash",
            codeSnippet: `#!/usr/bin/env bash
# Unofficial Bash Strict Mode
set -euo pipefail
IFS=$'\\n\\t'

# Trap cleanup on exit or error
TEMP_DIR=$(mktemp -d)
cleanup() {
  echo "Cleaning temporary files in \${TEMP_DIR}..."
  rm -rf "\${TEMP_DIR}"
}
trap cleanup EXIT

echo "Created temp workspace: \${TEMP_DIR}"

# Safe variable access (fails immediately if UNSET_VAR is not passed)
TARGET="\${1:-default_value}"
echo "Target set to: \${TARGET}"`,
            exercise: {
              task: "Add an ERR trap that prints the exact line number where any command in the script failed.",
              hint: "Use `trap 'echo \"Error on line $LINENO\"' ERR`.",
              solution: "trap 'echo \"[ERROR] Script failed at line \${LINENO}\"' ERR"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Automated Rotating Backup Pipeline with Integrity Check",
      description: "Build a production-ready backup script that compresses a target directory into a tar.gz archive, verifies sha256 checksums, and purges archives older than 7 days.",
      deliverables: ["Compliant with set -euo pipefail", "CLI flags with getopts (-s source, -d destination, -k keep_days)", "Zero orphaned temp files on failure"]
    },
    troubleshooting: [
      {
        problem: "Syntax error: '(' unexpected (when running bash script).",
        cause: "Script was executed with sh (dash/posix) instead of bash: sh script.sh.",
        fix: "Ensure proper shebang #!/usr/bin/env bash and run with bash script.sh or ./script.sh."
      }
    ],
    usefulResources: ["Google Shell Style Guide", "ShellCheck Static Analysis Tool"],
    officialDocLinks: [
      { title: "GNU Bash Reference Manual", url: "https://www.gnu.org/software/bash/manual/" },
      { title: "ShellCheck Wiki", url: "https://www.shellcheck.net/" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 8. POWERSHELL
  // =========================================================================
  {
    id: "powershell-core-crossplatform",
    title: "Cross-Platform PowerShell Core for Systems & DevOps",
    shortDescription: "Harness the power of PowerShell 7+ on Linux, macOS, and Windows. Learn object pipelines, structured data parsing (JSON/CSV), cmdlets, and DevOps automation.",
    category: "PowerShell",
    difficulty: "Beginner",
    duration: "5 Hours",
    technology: ["PowerShell 7", "Cmdlets", "JSON Parsing", "DevOps", "Cross-Platform"],
    featured: false,
    whatYouWillLearn: [
      "The fundamental difference: Object pipelines vs traditional text streams",
      "Essential cmdlets: Get-Command, Get-Help, Get-Member, and Where-Object",
      "Parsing and manipulating JSON, CSV, and XML payloads without external tools",
      "Cross-platform file manipulation and background jobs",
      "Writing reusable PowerShell script modules (.psm1) with parameter validation"
    ],
    prerequisites: "Basic command line understanding.",
    requiredTools: ["PowerShell 7 (pwsh) installed on Windows, macOS, or Linux"],
    modules: [
      {
        moduleTitle: "Module 1: The Object Pipeline & Structured Cmdlets",
        lessons: [
          {
            lessonTitle: "Objects Over Plain Text",
            duration: "30 min",
            summary: "Why objects eliminate tedious grep/awk parsing in shell pipelines.",
            content: "In traditional Unix shells, outputs are streams of characters requiring awk/sed parsing. In PowerShell, every pipeline item is a typed .NET object with accessible properties and methods.",
            codeLanguage: "powershell",
            codeSnippet: `# Filter running processes consuming over 100MB of working set memory
Get-Process | Where-Object WorkingSet64 -gt 100MB | 
  Sort-Object WorkingSet64 -Descending | 
  Select-Object -First 5 ProcessName, @{Name="RAM_MB"; Expression={[math]::Round($_.WorkingSet64 / 1MB, 2)}}

# Query REST API and parse JSON directly into native objects
$response = Invoke-RestMethod -Uri "https://api.github.com/repos/powershell/powershell"
Write-Host "Stars: $($response.stargazers_count) | Open Issues: $($response.open_issues_count)"`,
            exercise: {
              task: "Export the top 5 memory-heavy processes directly to a CSV file on your desktop using Export-Csv.",
              hint: "Pipe the Select-Object output to Export-Csv -Path ./top_procs.csv -NoTypeInformation.",
              solution: "Get-Process | Sort-Object WorkingSet64 -Descending | Select-Object -First 5 Name, WorkingSet64 | Export-Csv -Path ./procs.csv -NoTypeInformation"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Multi-Platform System Audit Report Generator",
      description: "Build a cross-platform PowerShell script that inspects CPU, disk volume free space, and active network adapters, exporting an HTML executive audit report.",
      deliverables: ["Tested on pwsh Linux & Windows", "Formatted HTML report with colorized status badges", "Clean error handling with try/catch blocks"]
    },
    troubleshooting: [
      {
        problem: "File cannot be loaded because running scripts is disabled on this system.",
        cause: "Windows execution policy is set to Restricted.",
        fix: "Run 'Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser' in an elevated session."
      }
    ],
    usefulResources: ["Microsoft PowerShell Official Documentation", "PowerShell Gallery"],
    officialDocLinks: [
      { title: "Microsoft Learn PowerShell Docs", url: "https://learn.microsoft.com/en-us/powershell/" },
      { title: "PowerShell GitHub Repository", url: "https://github.com/PowerShell/PowerShell" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 9. GIT & GITHUB
  // =========================================================================
  {
    id: "git-workflows-conflict-resolution",
    title: "Professional Git Workflows & Conflict Resolution",
    shortDescription: "Master Git like a senior software engineer. Understand the Git object model, feature branching strategies, interactive rebasing, cherry-picking, and resolving complex merge conflicts.",
    category: "Git & GitHub",
    difficulty: "Beginner",
    duration: "4.5 Hours",
    technology: ["Git", "GitHub", "Rebase", "Merge Conflicts", "Cherry-Pick", "Bisect"],
    featured: true,
    whatYouWillLearn: [
      "The Git internal object database: Blobs, Trees, Commits, and Annotated Tags",
      "Clean feature branching, pull request etiquette, and conventional commits",
      "Interactive rebase (git rebase -i) for squashing, rewording, and reordering history",
      "Diagnosing and resolving merge and rebase conflicts without panic",
      "Advanced forensic tools: git bisect for bug hunting and git reflog for undoing mistakes"
    ],
    prerequisites: "None. Suitable for complete beginners and intermediate developers.",
    requiredTools: ["Git 2.30+", "GitHub account", "Text editor with diff viewing (VS Code / Neovim)"],
    modules: [
      {
        moduleTitle: "Module 1: Branching, Rebasing & Conflict Solving",
        lessons: [
          {
            lessonTitle: "Rebase vs. Merge & Conflict Anatomy",
            duration: "35 min",
            summary: "When to use rebase for a linear history vs. merge commits for traceability.",
            content: "Git conflicts occur when two branches modify the same lines of code. Understanding the <<<<<<< HEAD, =======, and >>>>>>> markers makes resolving conflicts straightforward.",
            codeLanguage: "bash",
            codeSnippet: `# Fetch upstream updates without altering working tree
git fetch origin

# Rebase current branch on top of main for a clean linear history
git rebase origin/main

# If a conflict occurs, check affected files
git status

# Inspect the conflict markers:
# <<<<<<< HEAD (Current branch code)
# =======
# >>>>>>> incoming (Code being integrated)

# After editing file to keep the correct lines:
git add conflicting_file.py
git rebase --continue

# Emergency abort if rebase goes wrong:
# git rebase --abort`,
            exercise: {
              task: "Use git reflog to locate a deleted commit hash and restore it to a new branch.",
              hint: "Run git reflog, identify the commit SHA, and run git checkout -b recovery-branch <SHA>.",
              solution: "git reflog | head -n 5\ngit checkout -b recover HEAD@{1}"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Interactive Open Source Contribution Simulation",
      description: "Simulate a real-world multi-developer collaboration: fork a mock repo, rebase feature branches, resolve simulated merge conflicts, and generate a clean pull request.",
      deliverables: ["Single squashed feature commit", "Linear git log verified with git log --oneline --graph", "Proper signed-off commit message"]
    },
    troubleshooting: [
      {
        problem: "fatal: refusing to merge unrelated histories.",
        cause: "Attempting to merge two repositories that do not share a common root commit.",
        fix: "Pass '--allow-unrelated-histories': git pull origin main --allow-unrelated-histories"
      }
    ],
    usefulResources: ["Pro Git Book (Free Online)", "Visualizing Git Interactive Guide"],
    officialDocLinks: [
      { title: "Git Official Documentation", url: "https://git-scm.com/doc" },
      { title: "GitHub Docs", url: "https://docs.github.com/" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 10. APIS
  // =========================================================================
  {
    id: "rest-api-design-security",
    title: "RESTful API Design, Testing & Security",
    shortDescription: "Design, build, document, and test resilient RESTful APIs. Master HTTP semantics, pagination, Bearer authentication, rate limiting, and automated cURL testing.",
    category: "APIs",
    difficulty: "Intermediate",
    duration: "6 Hours",
    technology: ["REST", "cURL", "Postman", "JWT", "OAuth 2.0", "HTTP Status Codes"],
    featured: true,
    whatYouWillLearn: [
      "Strict HTTP status code discipline: 200 vs 201, 400 vs 422, 401 vs 403, 500 vs 503",
      "Resource naming conventions, plurals, nested resources, and filtering query params",
      "Securing endpoints with Bearer tokens, API keys, and CORS origin policies",
      "Pagination patterns: Offset/Limit vs Cursor-based pagination for high-volume endpoints",
      "Writing automated test scripts using cURL and Postman/Newman in CI pipelines"
    ],
    prerequisites: "Basic web and programming familiarity.",
    requiredTools: ["cURL", "Postman or HTTPie", "Code editor"],
    modules: [
      {
        moduleTitle: "Module 1: REST Semantics & Authentication",
        lessons: [
          {
            lessonTitle: "Idempotency & HTTP Verbs in Practice",
            duration: "35 min",
            summary: "Designing safe and idempotent endpoints across GET, POST, PUT, PATCH, and DELETE.",
            content: "An idempotent request produces the identical system state whether called once or ten times. GET, PUT, and DELETE are idempotent; POST is not.",
            codeLanguage: "bash",
            codeSnippet: `# Authenticated POST request with Bearer token and JSON body
curl -X POST "https://api.example.com/v1/projects" \\
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{
    "name": "Rauf Labs Terminal Hub",
    "visibility": "public",
    "tags": ["termux", "linux"]
  }' -v

# Idempotent PUT replacing entire resource
curl -X PUT "https://api.example.com/v1/projects/101" \\
  -H "Authorization: Bearer YOUR_ACCESS_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"name": "Updated Name", "visibility": "private"}'`,
            exercise: {
              task: "Write a cURL command that tests pagination with query parameters 'page=2&limit=10' and prints only response headers.",
              hint: "Use `curl -I \"https://api.example.com/items?page=2&limit=10\"`.",
              solution: "curl -s -I \"https://jsonplaceholder.typicode.com/posts?_page=2&_limit=10\" | grep -iE \"http|content-type\""
            }
          }
        ]
      }
    ],
    projects: {
      title: "API Test Suite & Automated Smoke Tester",
      description: "Build a standalone Bash/cURL script that executes end-to-end integration tests against a mock API, validating HTTP status codes, JSON keys, and latency limits.",
      deliverables: ["Executable test runner script", "Detailed terminal test summary with green pass / red fail output", "CI/CD exit code compatibility (exit 0 on success, exit 1 on failure)"]
    },
    troubleshooting: [
      {
        problem: "CORS error: 'No 'Access-Control-Allow-Origin' header is present on the requested resource'.",
        cause: "Browser blocked cross-origin request because the API backend did not return the required CORS headers.",
        fix: "Configure the API server to return 'Access-Control-Allow-Origin: *' or whitelist the client domain."
      }
    ],
    usefulResources: ["REST API Tutorial", "HTTP Status Dogs / Cats Visualizer"],
    officialDocLinks: [
      { title: "MDN HTTP Reference", url: "https://developer.mozilla.org/en-US/docs/Web/HTTP/Methods" },
      { title: "RFC 9110 HTTP Semantics", url: "https://www.rfc-editor.org/rfc/rfc9110" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 11. SOFTWARE ENGINEERING
  // =========================================================================
  {
    id: "clean-code-software-architecture",
    title: "Clean Code, Refactoring & Architectural Patterns",
    shortDescription: "Level up from a code writer to a software craftsman. Master SOLID principles, DRY, separation of concerns, test-driven mindsets, and managing technical debt.",
    category: "Software Engineering",
    difficulty: "Intermediate",
    duration: "7 Hours",
    technology: ["SOLID", "Design Patterns", "Clean Code", "Refactoring", "Testing"],
    featured: false,
    whatYouWillLearn: [
      "The 5 SOLID principles applied to modern TypeScript and Python codebases",
      "Identifying code smells: God objects, shotgun surgery, and primitive obsession",
      "Writing readable code: Meaningful naming, small single-responsibility functions, and minimal nesting",
      "The Testing Pyramid: Unit tests, integration tests, and end-to-end verification",
      "Safe refactoring workflows backed by automated regression tests"
    ],
    prerequisites: "Proficiency in at least one modern programming language (Python, JavaScript, Go, etc.).",
    requiredTools: ["Code editor", "Linter and test runner of your choice"],
    modules: [
      {
        moduleTitle: "Module 1: SOLID Principles & Code Smells",
        lessons: [
          {
            lessonTitle: "Single Responsibility & Dependency Inversion",
            duration: "40 min",
            summary: "Decoupling business logic from storage and network implementations.",
            content: "High-level modules should not depend on low-level modules; both should depend on abstractions. By passing interfaces instead of concrete classes, code becomes modular and easily testable.",
            codeLanguage: "typescript",
            codeSnippet: `// Abstraction interface
interface NotificationService {
  send(recipient: string, message: string): Promise<void>;
}

// Low-level email implementation
class EmailNotificationService implements NotificationService {
  async send(recipient: string, message: string): Promise<void> {
    console.log(\`Sending Email to \${recipient}: \${message}\`);
  }
}

// High-level business logic depends only on the abstraction
class UserManager {
  constructor(private notifier: NotificationService) {}

  async registerUser(email: string): Promise<void> {
    // Register user in database...
    await this.notifier.send(email, "Welcome to Rauf Labs Academy!");
  }
}`,
            exercise: {
              task: "Create a MockNotificationService for unit tests that records sent messages without calling external services.",
              hint: "Store messages in an in-memory array.",
              solution: "class MockNotifier implements NotificationService { public sent: string[] = []; async send(r: string, m: string) { this.sent.push(m); } }"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Legacy Codebase Refactoring Challenge",
      description: "Take a monolithic 500-line spaghetti script, write unit tests to establish baseline behavior, and refactor it into clean, decoupled modules conforming to SOLID.",
      deliverables: ["Clean modular directory structure", "100% test pass rate with zero regressions", "Before and after architectural explanation"]
    },
    troubleshooting: [
      {
        problem: "Refactoring introduces silent regressions in production.",
        cause: "Refactoring was attempted before comprehensive unit tests were in place.",
        fix: "Always write characterization tests verifying current input/output behavior before modifying implementation code."
      }
    ],
    usefulResources: ["Martin Fowler Refactoring Catalog", "Clean Code Principles Summary"],
    officialDocLinks: [
      { title: "Refactoring Guru Design Patterns", url: "https://refactoring.guru/design-patterns" },
      { title: "Agile Alliance Engineering Practices", url: "https://www.agilealliance.org/" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 12. OPEN SOURCE
  // =========================================================================
  {
    id: "open-source-contribution-guide",
    title: "Contributing to Open Source & Repository Management",
    shortDescription: "Make meaningful contributions to open-source software. Master GitHub fork-and-pull workflows, open source licensing (MIT, Apache, GPL), issue triaging, and documentation craft.",
    category: "Open Source",
    difficulty: "Beginner",
    duration: "3.5 Hours",
    technology: ["Open Source", "Markdown", "Git Fork", "Pull Requests", "Licenses"],
    featured: false,
    whatYouWillLearn: [
      "Open source license fundamentals: Permissive (MIT, Apache 2.0) vs Copyleft (GPL v3)",
      "The complete fork, branch, upstream sync, and pull request workflow",
      "Writing clear, actionable bug reports and feature requests that maintainers appreciate",
      "Crafting professional README.md files, contributing guidelines (CONTRIBUTING.md), and code of conducts",
      "Navigating open source etiquette, code reviews, and addressing feedback gracefully"
    ],
    prerequisites: "Basic Git familiarity (clone, commit, push).",
    requiredTools: ["GitHub account", "Git CLI"],
    modules: [
      {
        moduleTitle: "Module 1: Upstream Sync & PR Etiquette",
        lessons: [
          {
            lessonTitle: "The Fork & Upstream Workflow",
            duration: "30 min",
            summary: "Keeping your fork synchronized with the original repository.",
            content: "When contributing to open-source projects, you work on your personal fork while maintaining an upstream remote pointing to the main project repository.",
            codeLanguage: "bash",
            codeSnippet: `# Clone your personal fork
git clone https://github.com/your-username/open-project.git
cd open-project

# Add official upstream repository remote
git remote add upstream https://github.com/original-creator/open-project.git

# Verify remotes
git remote -v

# Sync main branch with latest upstream changes
git checkout main
git fetch upstream
git merge upstream/main

# Create a dedicated feature branch for your PR
git checkout -b fix-terminal-cursor-bug`,
            exercise: {
              task: "Create a branch, make a typo fix in a markdown file, and format a commit following Conventional Commits (e.g. docs: fix typo in README).",
              hint: "Use git commit -m \"docs(readme): correct spelling of Termux\".",
              solution: "git commit -m 'docs: fix typo in quickstart instructions'"
            }
          }
        ]
      }
    ],
    projects: {
      title: "First Open Source Pull Request",
      description: "Find an active open source repository with a 'good-first-issue' tag, draft a solution, submit a pull request adhering to repository guidelines, and respond to reviewer feedback.",
      deliverables: ["Merged or reviewed pull request link", "Signed CLA (if required)", "Clean single-commit history"]
    },
    troubleshooting: [
      {
        problem: "Pull request has merge conflicts with the target branch.",
        cause: "Other commits were merged into main after you created your feature branch.",
        fix: "Rebase onto upstream/main: git fetch upstream && git rebase upstream/main, resolve conflicts, and git push --force-with-lease."
      }
    ],
    usefulResources: ["First Contributions Guide", "Choose A License (GitHub)"],
    officialDocLinks: [
      { title: "Open Source Guides by GitHub", url: "https://opensource.guide/" },
      { title: "Choose an Open Source License", url: "https://choosealicense.com/" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 13. CYBERSECURITY FUNDAMENTALS
  // =========================================================================
  {
    id: "cybersecurity-developer-defense",
    title: "Developer Security Essentials: SSH Keys, Secrets & App Defense",
    shortDescription: "Secure your development workflow and applications. Master modern public-key cryptography (Ed25519), secrets management (.env leakage prevention), OWASP Top 10 web vulnerabilities, and secure coding.",
    category: "Cybersecurity Fundamentals",
    difficulty: "Intermediate",
    duration: "8 Hours",
    technology: ["SSH Cryptography", "OWASP Top 10", "Input Sanitization", "Secrets Vault", "GPG"],
    featured: true,
    whatYouWillLearn: [
      "Modern asymmetric cryptography: Why Ed25519 is superior to legacy RSA 2048",
      "Preventing credential leakage: Git hooks, .gitignore discipline, and git-secrets scanning",
      "OWASP Top 10 vulnerabilities: SQL Injection, Cross-Site Scripting (XSS), and Broken Access Control",
      "Safe password hashing: bcrypt and Argon2id vs obsolete MD5/SHA-256",
      "Secure headers: Content Security Policy (CSP), Strict-Transport-Security (HSTS), and X-Frame-Options"
    ],
    prerequisites: "Basic programming and web architecture knowledge.",
    requiredTools: ["OpenSSH", "Browser Developer Tools", "Node.js or Python"],
    modules: [
      {
        moduleTitle: "Module 1: SSH Cryptography & Secrets Sanitation",
        lessons: [
          {
            lessonTitle: "Generating High-Security Ed25519 SSH Keys",
            duration: "30 min",
            summary: "Generating and configuring Edwards-curve Digital Signature Algorithm keys.",
            content: "Ed25519 keys offer superior security and faster signature generation compared to RSA, with a compact 68-character public key format.",
            codeLanguage: "bash",
            codeSnippet: `# Generate modern Ed25519 key with 100 KDF rounds
ssh-keygen -t ed25519 -a 100 -C "developer@rauflabs" -f ~/.ssh/id_ed25519_rauf

# Verify correct file permissions
chmod 700 ~/.ssh
chmod 600 ~/.ssh/id_ed25519_rauf
chmod 644 ~/.ssh/id_ed25519_rauf.pub

# Add key to SSH agent
eval "$(ssh-agent -s)"
ssh-add ~/.ssh/id_ed25519_rauf`,
            exercise: {
              task: "Configure ~/.ssh/config so typing 'ssh myserver' automatically uses your specific Ed25519 key and port 8022.",
              hint: "Use Host myserver / HostName <ip> / Port 8022 / IdentityFile ~/.ssh/id_ed25519_rauf.",
              solution: "echo -e 'Host myserver\\n  HostName 127.0.0.1\\n  Port 8022\\n  IdentityFile ~/.ssh/id_ed25519_rauf' >> ~/.ssh/config"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Automated Secret Scanner & Security Audit Tool",
      description: "Build a pre-commit Git hook that scans staged files for accidentally included API keys (AIzaSy, sk-, ghp_), private keys, and unencrypted .env files.",
      deliverables: ["Bash pre-commit hook script", "Regex pattern library for popular cloud keys", "Emergency un-stage and warning alerts"]
    },
    troubleshooting: [
      {
        problem: "Permissions 0644 for '~/.ssh/id_rsa' are too open (UNPROTECTED PRIVATE KEY FILE!).",
        cause: "SSH client refuses to use private keys that can be read by other system users.",
        fix: "Run 'chmod 600 ~/.ssh/id_ed25519' to restrict read/write exclusively to the owner."
      }
    ],
    usefulResources: ["OWASP Top Ten Web Application Security Risks", "Mozilla OpenSSH Security Guidelines"],
    officialDocLinks: [
      { title: "OWASP Official Foundation", url: "https://owasp.org/" },
      { title: "OpenSSH Security Project", url: "https://www.openssh.com/" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 14. AUTOMATION
  // =========================================================================
  {
    id: "system-task-automation",
    title: "System & Task Automation: Cron, Systemd Timers & Webhooks",
    shortDescription: "Automate repetitive tasks across servers and local machines. Master crontab syntax, systemd timer units, disk cleanup scripts, and automated webhook notifications.",
    category: "Automation",
    difficulty: "Intermediate",
    duration: "5.5 Hours",
    technology: ["Crontab", "Systemd Timers", "Bash", "Webhooks", "Backup Pipelines"],
    featured: false,
    whatYouWillLearn: [
      "The 5-field cron expression syntax (minute, hour, day-of-month, month, day-of-week)",
      "Why systemd timers are superior to legacy cron for modern servers (logging, dependencies, randomized delays)",
      "Automating directory pruning, cache flushing, and log rotation",
      "Triggering external alert webhooks (Discord, Telegram, Slack) on pipeline completion or failure",
      "Preventing overlapping execution using flock (file locks)"
    ],
    prerequisites: "Basic Linux terminal commands.",
    requiredTools: ["Linux or Termux", "cronie / cron or systemd"],
    modules: [
      {
        moduleTitle: "Module 1: Cron & Systemd Timers",
        lessons: [
          {
            lessonTitle: "Mastering Crontab & Preventing Overlaps",
            duration: "30 min",
            summary: "Writing reliable cron schedules and locking jobs with flock.",
            content: "Cron runs tasks in a minimal environment missing your standard user $PATH. Using absolute paths and flock guarantees that slow tasks never spawn duplicate parallel processes.",
            codeLanguage: "bash",
            codeSnippet: `# Edit user crontab
# crontab -e

# Format:
# m   h   dom mon dow   command
# ─── ─── ─── ─── ───   ───────
# 0   3   *   *   *     /usr/bin/bash /opt/backup.sh >> /var/log/backup.log 2>&1

# Run every Monday at 4:30 AM with flock to prevent overlapping runs:
# 30  4   *   *   1     /usr/bin/flock -n /tmp/backup.lock /opt/scripts/weekly_backup.sh`,
            exercise: {
              task: "Write a cron expression that runs every 15 minutes between 9 AM and 5 PM on weekdays (Mon-Fri).",
              hint: "Use */15 for minutes, 9-17 for hours, and 1-5 for day-of-week.",
              solution: "*/15 9-17 * * 1-5 /path/to/command"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Automated Website Uptime Monitor & Telegram Alert Bot",
      description: "Build an automated monitor running every 5 minutes that sends an HTTP request to your sites and dispatches a Telegram/Discord webhook message if any site goes down.",
      deliverables: ["Shell script using cURL", "JSON payload formatting for Discord/Telegram webhooks", "Cron or systemd timer setup instructions"]
    },
    troubleshooting: [
      {
        problem: "Cron job runs manually in terminal but fails when scheduled.",
        cause: "Cron runs with a stripped environment where $PATH only includes /usr/bin:/bin.",
        fix: "Always use absolute paths for commands (/usr/bin/node instead of node) or define PATH at the top of the crontab."
      }
    ],
    usefulResources: ["Crontab.guru Expression Visualizer", "ArchWiki Systemd Timers Guide"],
    officialDocLinks: [
      { title: "Systemd.timer Manual", url: "https://www.freedesktop.org/software/systemd/man/systemd.timer.html" },
      { title: "Cronie Linux Project", url: "https://pagure.io/cronie" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 15. DEVELOPER TOOLS
  // =========================================================================
  {
    id: "terminal-mastery-vim-tmux",
    title: "Developer Tooling & Terminal Mastery: Vim, Tmux & Modern CLI",
    shortDescription: "Transform your terminal into a lightning-fast IDE. Master modal text editing in Vim/Neovim, workspace multiplexing with Tmux, and modern CLI tools (fzf, ripgrep, jq, bat).",
    category: "Developer Tools",
    difficulty: "Intermediate",
    duration: "6 Hours",
    technology: ["Vim", "Neovim", "Tmux", "fzf", "ripgrep", "jq"],
    featured: true,
    whatYouWillLearn: [
      "Vim modal editing: Normal, Insert, Visual, and Command modes without touching the mouse",
      "Essential Vim motions: hjkl, w/b, f/t, ciw, da{, and global search/replace (%s/foo/bar/g)",
      "Tmux session management, split windows, synchronized panes, and detached workflows",
      "High-speed fuzzy finding with fzf for files and shell history",
      "Lightning-fast codebase search with ripgrep (rg) and JSON querying with jq"
    ],
    prerequisites: "Basic command line literacy.",
    requiredTools: ["Vim or Neovim", "Tmux", "fzf, ripgrep, jq"],
    modules: [
      {
        moduleTitle: "Module 1: Modal Editing & Modern Utilities",
        lessons: [
          {
            lessonTitle: "Core Vim Motions & Text Objects",
            duration: "35 min",
            summary: "Editing code at the speed of thought using verbs and nouns.",
            content: "Vim treats text editing like a language. Combine an operator (c for change, d for delete, y for yank) with a motion or text object (iw for inner word, i\" for inside quotes, a{ for around braces).",
            codeLanguage: "text",
            codeSnippet: `Key Vim Motion Combinations:
ci"    -> Change inside quotes: "hello world" becomes "" in insert mode
di(    -> Delete inside parentheses: (foo, bar) becomes ()
yip    -> Yank (copy) inner paragraph
Vyp    -> Duplicate current line downwards
:%s/old/new/gc -> Replace "old" with "new" across entire file with confirmation

Modern CLI Shortcuts:
rg "search_term" src/        # Search code 10x faster than grep
cat data.json | jq '.users[] | .name' # Filter JSON arrays instantly
fzf                          # Interactive fuzzy file finder`,
            exercise: {
              task: "Open a file in Vim and replace every occurrence of 'TODO' with 'DONE' using ex command mode.",
              hint: "Type :%s/TODO/DONE/g and press Enter.",
              solution: ":%s/TODO/DONE/g"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Ultimate Terminal Dotfiles Configuration",
      description: "Create your personal, portable terminal setup containing customized ~/.vimrc and ~/.tmux.conf files with modern status bars, ergonomic keybindings, and fzf integrations.",
      deliverables: ["Clean .vimrc with sensible defaults", "Intuitive Tmux prefix (Ctrl+A or Ctrl+Space)", "Cross-platform installation instructions"]
    },
    troubleshooting: [
      {
        problem: "Vim colors look washed out or inverted in terminal.",
        cause: "Terminal emulator does not report truecolor (24-bit color) support.",
        fix: "Add 'set termguicolors' in ~/.vimrc and set 'export TERM=xterm-256color' in ~/.bashrc."
      }
    ],
    usefulResources: ["Vim Adventures Game", "Neovim Official Getting Started Guide"],
    officialDocLinks: [
      { title: "Vim Official Documentation", url: "https://www.vim.org/docs.php" },
      { title: "Neovim Official Site", url: "https://neovim.io/" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 16. CREATOR TECHNOLOGY
  // =========================================================================
  {
    id: "ffmpeg-media-engineering",
    title: "FFmpeg for Developers & Media Creators",
    shortDescription: "Process audio and video programmatically with the industry standard multimedia framework. Master video transcoding, resizing, audio extraction, lossless cutting, and automated batch encoding.",
    category: "Creator Technology",
    difficulty: "Intermediate",
    duration: "5 Hours",
    technology: ["FFmpeg", "H.264 / AV1", "Lossless Audio", "CLI Transcoding", "OBS"],
    featured: true,
    whatYouWillLearn: [
      "The FFmpeg architecture: Demuxers, Decoders, Filtergraphs, Encoders, and Muxers",
      "Lossless video cutting and trimming with stream copying (-c copy)",
      "High-efficiency video compression using libx264, libx265, and modern AV1 with CRF tuning",
      "Audio extraction, volume normalization, and sample rate conversion",
      "Automating batch video transcoding pipelines across entire directories using Bash"
    ],
    prerequisites: "Familiarity with terminal commands.",
    requiredTools: ["FFmpeg 5.0+ installed (via apt, brew, or pkg)"],
    modules: [
      {
        moduleTitle: "Module 1: Transcoding, Compression & Cutting",
        lessons: [
          {
            lessonTitle: "Lossless Trimming & Modern Video Encoding",
            duration: "35 min",
            summary: "Cutting clips without re-encoding and tuning Constant Rate Factor (CRF).",
            content: "Using '-c copy' cuts videos at keyframes in milliseconds without losing quality or re-encoding. When compression is needed, CRF values balance visual quality against filesize.",
            codeLanguage: "bash",
            codeSnippet: `# 1. Lossless trim video from 00:01:30 to 00:02:45 (instant, zero quality loss)
ffmpeg -ss 00:01:30 -to 00:02:45 -i input.mp4 -c copy trimmed.mp4

# 2. Extract high quality MP3 audio from video
ffmpeg -i video.mp4 -vn -c:a libmp3lame -q:a 2 audio.mp3

# 3. Compress 4K video to high quality 1080p web format using H.264
ffmpeg -i input_4k.mp4 -vf "scale=1920:1080" -c:v libx264 -crf 22 -preset slow -c:a aac -b:a 192k web_output.mp4`,
            exercise: {
              task: "Use FFmpeg to convert a 5-second video clip into a lightweight looping GIF with a custom palette.",
              hint: "Use -vf 'fps=15,scale=480:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse'.",
              solution: "ffmpeg -i clip.mp4 -t 5 -vf 'fps=12,scale=480:-1' output.gif"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Batch Video Compressor & Watermark Pipeline",
      description: "Build a shell script that monitors a folder for uploaded videos, automatically scales them to 1080p, overlays a subtle logo watermark in the corner, and compresses them for web sharing.",
      deliverables: ["Bash script with directory traversal", "Lossless audio preservation", "Tested with MP4, MKV, and MOV inputs"]
    },
    troubleshooting: [
      {
        problem: "Trimmed video audio is out of sync or starts with black frames.",
        cause: "Cutting with -c copy before a keyframe (I-frame).",
        fix: "Place '-ss' before '-i' for fast keyframe seeking: 'ffmpeg -ss 00:00:10 -i input.mp4 -c copy output.mp4'."
      }
    ],
    usefulResources: ["FFmpeg Official Documentation", "Trillke FFmpeg Cheatsheet"],
    officialDocLinks: [
      { title: "FFmpeg Official Documentation", url: "https://ffmpeg.org/documentation.html" },
      { title: "FFmpeg Wiki & Encoders Guide", url: "https://trac.ffmpeg.org/wiki" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 17. PRODUCTIVITY
  // =========================================================================
  {
    id: "dotfiles-terminal-productivity",
    title: "Developer Workflow & Dotfiles Mastery",
    shortDescription: "Build a portable, replicated developer environment across all your machines. Master Git bare repositories for dotfiles, custom shell aliases, prompts, and ergonomic keybindings.",
    category: "Productivity",
    difficulty: "Beginner",
    duration: "3.5 Hours",
    technology: ["Dotfiles", "Git Bare Repo", "Zsh / Bash", "Aliases", "Productivity"],
    featured: false,
    whatYouWillLearn: [
      "Managing ~/.config and dotfiles with a Git bare repository without symlinks",
      "Writing powerful shell aliases and functions that shave hours off daily typing",
      "Customizing minimal, fast prompts (Starship or native PS1) with zero latency",
      "Synchronizing settings seamlessly between Linux, macOS, and Android Termux",
      "Keeping private tokens out of public dotfiles using environment variables"
    ],
    prerequisites: "Basic Git and command line familiarity.",
    requiredTools: ["Git", "Bash or Zsh"],
    modules: [
      {
        moduleTitle: "Module 1: The Git Bare Repository Pattern",
        lessons: [
          {
            lessonTitle: "Dotfiles without Symlink Clutter",
            duration: "30 min",
            summary: "Tracking home directory configuration files directly with Git bare repos.",
            content: "Instead of creating complex symlink trees, a Git bare repository tracks files directly in your $HOME directory while storing git objects in a separate ~/.dotfiles folder.",
            codeLanguage: "bash",
            codeSnippet: `# 1. Initialize bare repository in ~/.cfg
git init --bare $HOME/.cfg

# 2. Define alias for interacting with dotfiles
alias dotfiles='/usr/bin/git --git-dir=$HOME/.cfg/ --work-tree=$HOME'

# 3. Prevent untracked home files from cluttering status
dotfiles config --local status.showUntrackedFiles no

# 4. Add your bashrc or config files
dotfiles add ~/.bashrc ~/.tmux.conf
dotfiles commit -m "feat: setup terminal aliases and tmux config"
dotfiles push origin main`,
            exercise: {
              task: "Create an alias 'mkcd' in your ~/.bashrc that creates a directory and immediately changes into it.",
              hint: "Use `mkcd() { mkdir -p \"$1\" && cd \"$1\"; }`.",
              solution: "mkcd() { mkdir -p \"$1\" && cd \"$1\"; }"
            }
          }
        ]
      }
    ],
    projects: {
      title: "One-Line Machine Provisioning Script",
      description: "Create a bootstrap script hosted on GitHub that clones your bare dotfiles repository, installs key packages, and sets up your terminal environment on any new server in 60 seconds.",
      deliverables: ["curl | bash compatible bootstrap script", "Tested on fresh Linux / Termux installation", "Safe handling of existing configuration collisions"]
    },
    troubleshooting: [
      {
        problem: "'dotfiles checkout' reports error: 'The following untracked working tree files would be overwritten'.",
        cause: "Default files (like .bashrc) already exist on the new machine.",
        fix: "Back up existing files to a temporary folder: mkdir -p ~/.config-backup && dotfiles checkout 2>&1 | egrep \"\\s+\\.\" | awk {'print $1'} | xargs -I{} mv {} ~/.config-backup/{}"
      }
    ],
    usefulResources: ["Atlassian Dotfiles Tutorial", "Starship Cross-Shell Prompt"],
    officialDocLinks: [
      { title: "Dotfiles Community Documentation", url: "https://dotfiles.github.io/" },
      { title: "Starship Prompt Documentation", url: "https://starship.rs/" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  },

  // =========================================================================
  // 18. OTHER TECHNOLOGY
  // =========================================================================
  {
    id: "internet-protocols-web-infra",
    title: "Internet Protocols, DNS & Web Infrastructure",
    shortDescription: "Understand the invisible plumbing of the global internet. Master TCP/IP handshakes, UDP, DNS record types (A, CNAME, MX, TXT), TLS/SSL certificates, and HTTP/2 vs HTTP/3.",
    category: "Other Technology",
    difficulty: "Beginner",
    duration: "6 Hours",
    technology: ["TCP/IP", "DNS", "TLS / SSL", "HTTP/2 & HTTP/3", "Sockets", "Networking"],
    featured: false,
    whatYouWillLearn: [
      "The 7-layer OSI model mapped to practical real-world internet architecture",
      "TCP 3-way handshake (SYN, SYN-ACK, ACK) and reliable connection guarantees vs UDP",
      "DNS hierarchy: Root servers, TLDs, Authoritative nameservers, and TTL caching",
      "TLS 1.3 cryptographic handshakes, certificate authorities (Let's Encrypt), and SNI",
      "The evolution of HTTP: HTTP/1.1 head-of-line blocking, HTTP/2 multiplexing, and HTTP/3 QUIC"
    ],
    prerequisites: "Curiosity about how networks and the internet work.",
    requiredTools: ["Terminal with dig, traceroute, curl, openssl"],
    modules: [
      {
        moduleTitle: "Module 1: DNS Mechanics & TLS Handshakes",
        lessons: [
          {
            lessonTitle: "DNS Lookup Chains & Record Types",
            duration: "35 min",
            summary: "Tracing domain name resolution from root servers to authoritative records.",
            content: "When you type a URL, your system checks local cache, resolver, TLD nameserver, and authoritative nameserver. DNS records define server IPs (A/AAAA), aliases (CNAME), mail routes (MX), and verification keys (TXT).",
            codeLanguage: "bash",
            codeSnippet: `# Query IPv4 A record for a domain
dig A rauflabs.ai.studio +short

# Query authoritative nameservers for a domain
dig NS google.com +short

# Inspect SSL/TLS certificate chain and expiration directly via OpenSSL
openssl s_client -connect rauflabs.ai.studio:443 -servername rauflabs.ai.studio </dev/null 2>/dev/null | openssl x509 -noout -dates -subject`,
            exercise: {
              task: "Use dig to query the TXT records of google.com to view SPF security policies.",
              hint: "Run 'dig TXT google.com +short'.",
              solution: "dig TXT google.com +short | grep v=spf"
            }
          }
        ]
      }
    ],
    projects: {
      title: "Custom Domain DNS & SSL Diagnostic Report",
      description: "Build a command-line utility that takes any domain name as input, audits its DNS records, tests TLS certificate validity, checks response times from multiple global resolvers, and generates an infrastructure report.",
      deliverables: ["Bash or Node.js diagnostic script", "Clear visual reporting of DNS health", "TLS certificate expiry warning alerts"]
    },
    troubleshooting: [
      {
        problem: "SSL certificate verify failed: certificate has expired or self-signed.",
        cause: "System root CA certificates are outdated, or the server certificate chain is incomplete.",
        fix: "Update system CA certificates: 'sudo apt install --reinstall ca-certificates' and verify server sends full chain."
      }
    ],
    usefulResources: ["Cloudflare How DNS Works", "Let's Encrypt Documentation"],
    officialDocLinks: [
      { title: "Internet Engineering Task Force (IETF) RFCs", url: "https://www.ietf.org/" },
      { title: "Let's Encrypt How It Works", url: "https://letsencrypt.org/howitworks/" }
    ],
    licenseInfo: "Original Rauf Labs Academy Curriculum • Released under CC BY 4.0"
  }
];

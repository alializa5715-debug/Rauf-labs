/**
 * 📚 RAUF LABS ACADEMY — OFFICIAL PDF CATALOG
 * 
 * Centralized catalog containing the 5 official Rauf Labs Academy publications.
 */

window.PDFS_DATA = [
  {
    id: "ai-businesses-rauf-labs-academy",
    title: "50 Ready-Made AI Businesses You Can Launch",
    subtitle: "60 Ready-to-Launch AI Business Ideas You Can Start This Weekend - Rauf Labs Academy",
    description: "Sixty open-source, fully working AI SaaS products with authentication, Stripe billing, and AI pipelines already wired up. Fork one, put your brand on it, and start charging.",
    category: "AI SaaS",
    file: "/pdfs/ai-businesses-rauf-labs-academy.pdf",
    author: "Rauf Labs Academy",
    pageCount: 22,
    fileSize: "37 KB",
    tags: ["AI SaaS", "Startup Ideas", "Open Source", "Next.js", "Stripe", "Rauf Labs Academy"],
    featured: true,
    date: "2026-09-08",
    source: "/courses/ai",
    about: "Unlike hypothetical lists, this playbook details working open-source repositories you can fork, rebrand, and deploy to Vercel in one weekend. Every business model includes the paid competitor it disrupts, unit economics, and 95%+ gross software margin calculations.",
    learn: [
      "10 high-demand categories: Open Platforms, Video Gen, Image Studios, AI Agents, Beauty & Real Estate",
      "Unit economics: reselling compute at $29/pack with ~$1.40 raw cost for 95% gross margins",
      "Standard tech stack: Next.js 14, Tailwind CSS, Prisma ORM, Supabase, and Stripe Webhooks",
      "Step-by-step distribution strategies using short-form video and programmatic SEO"
    ],
    requirements: "Basic JavaScript/TypeScript familiarity, GitHub account, and Vercel/Supabase free accounts."
  },
  {
    id: "free-ai-gateway-rauf-labs-academy",
    title: "The Free AI Gateway Setup Most People Still Don't Know About",
    subtitle: "Free AI Gateway Setup Guide - Practical Setup Playbook - Rauf Labs",
    description: "A complete 25-page DevOps playbook on connecting FreeLLMAPI and OmniRoute with Claude Code, Codex, and OpenClaw without token lockouts.",
    category: "AI Gateway",
    file: "/pdfs/free-ai-gateway-rauf-labs-academy.pdf",
    author: "Rauf Labs Academy",
    pageCount: 25,
    fileSize: "46 KB",
    tags: ["AI Gateway", "Claude Code", "Codex", "OpenClaw", "FreeLLMAPI", "OmniRoute", "DevOps"],
    featured: true,
    date: "2026-09-07",
    source: "/courses/ai",
    about: "This comprehensive guide teaches software engineers and students how to unify legitimate free-tier LLM providers behind a single local proxy gateway. It covers architecture switchboards, port setups (3001 vs 20128), and Anthropic vs OpenAI wire protocol translation.",
    learn: [
      "How to set up FreeLLMAPI via Docker or native Node.js on port 3001",
      "Configuring OmniRoute as an advanced multi-client local routing control plane on port 20128",
      "Integrating Claude Code without duplicate /v1 path 404 errors",
      "Writing ~/.codex/config.toml and OpenClaw JSON5 custom provider settings",
      "Diagnosing 401 Unauthorized and Docker host networking connection issues"
    ],
    requirements: "Node.js 20+, terminal access, and at least one free or paid provider API key (Gemini, Groq, Mistral, OpenRouter)."
  },
  {
    id: "chatgpt-slash-commands-rauf-labs-academy",
    title: "100 Powerful ChatGPT Slash Commands",
    subtitle: "The Ultimate AI Command Playbook - Rauf Labs Academy",
    description: "A practical visual index of 100 prompt shortcuts across visual diagrams, system architectures, decision making, and consulting frameworks.",
    category: "Prompts",
    file: "/pdfs/chatgpt-slash-commands-rauf-labs-academy.pdf",
    author: "Rauf Labs Academy",
    pageCount: 4,
    fileSize: "13 KB",
    tags: ["ChatGPT", "Slash Commands", "Prompt Engineering", "Playbook", "Cheatsheet"],
    featured: true,
    date: "2026-09-06",
    source: "/courses/ai",
    about: "A visual reference index transforming conversational AI into a structured software productivity engine. It provides categorized slash command shortcuts for diagrams, infographics, mental models, code architecture, and executive management briefs.",
    learn: [
      "Visual & Image prompts: /visualize, /explodedview, /xray, /blueprint, /flowchart",
      "System visualization: /architecture, /wireframe, /isometric, /dashboard, /network",
      "Critical thinking: /devilsadvocate, /firstprinciples, /fivewhys, /decisionmatrix",
      "Business strategy: /consultant, /premortem, /redteam, /reverseengineer"
    ],
    requirements: "Any modern LLM interface (ChatGPT, Claude, Gemini, or DeepSeek)."
  },
  {
    id: "free-ai-tools-rauf-labs-academy",
    title: "Free AI Tools for Students in South Asia",
    subtitle: "India + Pakistan | 2026 Student Edition - Rauf Labs Academy",
    description: "25+ verified free student offers covering AI credits, coding tools, cloud hosting, 3D suites, video editors, and university campus perks.",
    category: "Education",
    file: "/pdfs/free-ai-tools-rauf-labs-academy.pdf",
    author: "Rauf Labs Academy",
    pageCount: 5,
    fileSize: "10 KB",
    tags: ["Student Pack", "Free Credits", "India", "Pakistan", "GitHub Student", "Azure", "Figma"],
    featured: true,
    date: "2026-09-05",
    source: "/courses/productivity",
    about: "Curated guide specifically compiled for students in India and Pakistan. Every offer is verified for eligibility, detailing what software is free, who can claim it, and exact verification steps.",
    learn: [
      "Core AI & Coding: Google AI Plus 12 months free, GitHub Copilot, Azure for Students ($100 credit)",
      "Creative Stack: Figma Education, Autodesk Maya & 3ds Max, Adobe Substance 3D, Unity Pro",
      "Study & Voice: Notion Education, ElevenReader Ultra 1-year free, Miro Education",
      "Campus Access & Telco: Jio Google AI Pro (18 months), Airtel Adobe Express (12 months)"
    ],
    requirements: "Active student status or institutional email (.edu, .ac.in, .edu.pk)."
  },
  {
    id: "google-gemini-omni-rauf-labs-academy",
    title: "How to Use Google Gemini Omni for Video Editing",
    subtitle: "Step-by-Step Guide - Rauf Labs Academy",
    description: "Master multimodal video transformation: analyze reference videos, extract scene prompts, transform footage with Gemini Omni, and assemble in CapCut.",
    category: "Video AI",
    file: "/pdfs/google-gemini-omni-rauf-labs-academy.pdf",
    author: "Rauf Labs Academy",
    pageCount: 4,
    fileSize: "9 KB",
    tags: ["Google Gemini Omni", "Video Editing", "Multimodal AI", "CapCut", "Prompt Templates"],
    featured: true,
    date: "2026-09-04",
    source: "/courses/creator",
    about: "Complete step-by-step masterclass on breaking down viral reference videos from Instagram or TikTok, writing copy-ready scene prompts, iterative chat refinement, and seamless final assembly.",
    learn: [
      "The 6-stage multimodal workflow: Reference -> Script -> Prompts -> Omni Edit -> Refine -> CapCut",
      "Exact copy-ready prompt template for multimodal style, lighting, and camera motion extraction",
      "Controlling scene consistency, characters, background aesthetics, and pacing",
      "Refining video generations inside chat with precise, single-variable instructions"
    ],
    requirements: "Multimodal AI access (Gemini/ChatGPT/Claude) and a video editor (CapCut, Premiere, or DaVinci)."
  }
];

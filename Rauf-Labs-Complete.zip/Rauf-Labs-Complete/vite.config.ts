import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import fs from 'fs';
import path from 'path';
import {defineConfig, Plugin} from 'vite';

// LINT.IfChange(aistudio_media_plugin)
function aistudioMediaPlugin(): Plugin {
  return {
    name: 'vite-plugin-aistudio-media',
    configureServer(server) {
      server.middlewares.use((req, res, next) => {
        if (req.url && req.url.startsWith('/assets/aistudio/')) {
          const rawPath = req.url.split('?')[0].split('#')[0];
          try {
            const decodedPath = decodeURIComponent(rawPath);
            const relativePath = decodedPath.replace(/^\//, '');
            const aistudioDir = path.resolve(
              __dirname,
              'public',
              'assets',
              'aistudio',
            );
            const filePath = path.resolve(__dirname, 'public', relativePath);
            if (
              filePath.startsWith(aistudioDir + path.sep) &&
              fs.existsSync(filePath) &&
              fs.statSync(filePath).isFile()
            ) {
              const ext = path.extname(filePath).toLowerCase();
              const mimeMap: Record<string, string> = {
                '.jpg': 'image/jpeg',
                '.jpeg': 'image/jpeg',
                '.png': 'image/png',
                '.gif': 'image/gif',
                '.webp': 'image/webp',
                '.svg': 'image/svg+xml',
                '.bmp': 'image/bmp',
                '.ico': 'image/x-icon',
                '.mp4': 'video/mp4',
                '.webm': 'video/webm',
                '.ogv': 'video/ogg',
                '.mp3': 'audio/mpeg',
                '.wav': 'audio/wav',
                '.ogg': 'audio/ogg',
                '.pdf': 'application/pdf',
              };
              res.setHeader(
                'Content-Type',
                mimeMap[ext] || 'application/octet-stream',
              );
              res.setHeader('Cache-Control', 'no-cache');
              fs.createReadStream(filePath).pipe(res);
              return;
            }
          } catch {
            // Fall through if URI decoding or file access fails
          }
        }
        next();
      });
    },
  };
}
// LINT.ThenChange(//depot/google3/java/com/google/alkali/boq/makersuite/applet_dev_service/templates/initializers/react_theme/vite.config.ts:aistudio_media_plugin)

function spaMultiPagePlugin(): Plugin {
  const routes = [
    'developer',
    'android',
    'roadmap',
    'creator',
    'tools',
    'resources',
    'ai',
    'login',
    'about',
    'skills',
    'projects',
    'blog',
    'contact',
    'termux',
    'linux',
    'powershell',
    'bash',
    'git',
    'programming',
    'apis',
    'opensource',
    'pdfs',
    'courses',
    'qr',
    '404',
  ];

  return {
    name: 'vite-plugin-spa-multi-page',
    closeBundle() {
      const distDir = path.resolve(__dirname, 'dist');
      if (!fs.existsSync(distDir)) return;

      // Copy standalone scripts & stylesheets to dist
      const assetsToCopy = [
        'routesData.js',
        'script.js',
        'style.css',
        'pdfsData.js',
        'pdfLibrary.js',
        'coursesData.js',
        'coursesEngine.js',
      ];
      for (const asset of assetsToCopy) {
        const src = path.resolve(__dirname, asset);
        if (fs.existsSync(src)) {
          fs.copyFileSync(src, path.resolve(distDir, asset));
        }
      }

      // Ensure PDF assets exist in dist/pdfs and dist/public/pdfs
      const distPdfsDir = path.resolve(distDir, 'pdfs');
      const distPublicPdfsDir = path.resolve(distDir, 'public', 'pdfs');
      if (!fs.existsSync(distPdfsDir)) fs.mkdirSync(distPdfsDir, { recursive: true });
      if (!fs.existsSync(distPublicPdfsDir)) fs.mkdirSync(distPublicPdfsDir, { recursive: true });

      const pdfSourceDirs = [
        path.resolve(__dirname, 'public', 'pdfs'),
        path.resolve(__dirname, 'pdfs'),
      ];

      for (const sourceDir of pdfSourceDirs) {
        if (fs.existsSync(sourceDir)) {
          const files = fs.readdirSync(sourceDir);
          for (const file of files) {
            if (file.toLowerCase().endsWith('.pdf')) {
              const srcFile = path.resolve(sourceDir, file);
              const dest1 = path.resolve(distPdfsDir, file);
              const dest2 = path.resolve(distPublicPdfsDir, file);
              if (!fs.existsSync(dest1)) fs.copyFileSync(srcFile, dest1);
              if (!fs.existsSync(dest2)) fs.copyFileSync(srcFile, dest2);
            }
          }
        }
      }

      // Copy vendor directory (pdfjs etc.)
      const vendorSrc = path.resolve(__dirname, 'vendor');
      const vendorDist = path.resolve(distDir, 'vendor');
      if (fs.existsSync(vendorSrc)) {
        fs.cpSync(vendorSrc, vendorDist, { recursive: true });
      }

      // Generate static directories with index.html for standard routes
      for (const route of routes) {
        const routeDir = path.resolve(distDir, route);
        if (!fs.existsSync(routeDir)) {
          fs.mkdirSync(routeDir, { recursive: true });
        }

        const compiledRouteHtml = path.resolve(distDir, `${route}.html`);
        const targetIndexHtml = path.resolve(routeDir, 'index.html');

        if (fs.existsSync(compiledRouteHtml)) {
          fs.copyFileSync(compiledRouteHtml, targetIndexHtml);
        } else {
          const mainIndex = path.resolve(distDir, 'index.html');
          if (fs.existsSync(mainIndex)) {
            fs.copyFileSync(mainIndex, targetIndexHtml);
          }
        }
      }

      // Dynamic subroutes for PDF reader: /pdfs/read and /pdfs/read/:id
      const compiledPdfsHtml = path.resolve(distDir, 'pdfs.html');
      if (fs.existsSync(compiledPdfsHtml)) {
        const pdfReadDir = path.resolve(distDir, 'pdfs', 'read');
        if (!fs.existsSync(pdfReadDir)) fs.mkdirSync(pdfReadDir, { recursive: true });
        fs.copyFileSync(compiledPdfsHtml, path.resolve(pdfReadDir, 'index.html'));

        // Known PDF IDs for pre-rendered directory routing
        const knownPdfIds = [
          'ai-businesses-rauf-labs-academy',
          'free-ai-gateway-rauf-labs-academy',
          'chatgpt-slash-commands-rauf-labs-academy',
          'free-ai-tools-rauf-labs-academy',
          'google-gemini-omni-rauf-labs-academy',
          'termux-basics-handbook',
          'linux-command-mastery',
          'git-github-team-workflow',
          'python-zero-to-production',
          'cybersecurity-recon-defense',
          'web-development-modern-stack',
          'software-engineering-design-patterns',
          'viral-creator-algorithm-handbook'
        ];
        for (const pid of knownPdfIds) {
          const pidDir = path.resolve(pdfReadDir, pid);
          if (!fs.existsSync(pidDir)) fs.mkdirSync(pidDir, { recursive: true });
          fs.copyFileSync(compiledPdfsHtml, path.resolve(pidDir, 'index.html'));
        }
      }

      // Dynamic subroutes for Courses: /courses/:courseId and categories
      const compiledCoursesHtml = path.resolve(distDir, 'courses.html');
      if (fs.existsSync(compiledCoursesHtml)) {
        const knownCourseSlugs = [
          'gemini-llm-engineering',
          'local-ai-ollama',
          'modern-python-automation',
          'javascript-typescript-mastery',
          'fullstack-node-express',
          'modern-css-responsive-ui',
          'android-internals-adb',
          'android-kotlin-jetpack',
          'termux-complete-mastery',
          'termux-headless-server',
          'linux-sysadmin-hardening',
          'linux-networking-diagnostics',
          'production-bash-scripting',
          'powershell-core-crossplatform',
          'git-workflows-conflict-resolution',
          'rest-api-design-security',
          'clean-code-software-architecture',
          'open-source-contribution-guide',
          'cybersecurity-developer-defense',
          'system-task-automation',
          'terminal-mastery-vim-tmux',
          'ffmpeg-media-engineering',
          'dotfiles-terminal-productivity',
          'internet-protocols-web-infra',
          'ai',
          'programming',
          'web-development',
          'android',
          'termux',
          'linux',
          'bash',
          'powershell',
          'git',
          'apis',
          'software-engineering',
          'open-source',
          'cybersecurity',
          'automation',
          'developer-tools',
          'creator',
          'productivity'
        ];
        for (const slug of knownCourseSlugs) {
          const slugDir = path.resolve(distDir, 'courses', slug);
          if (!fs.existsSync(slugDir)) fs.mkdirSync(slugDir, { recursive: true });
          fs.copyFileSync(compiledCoursesHtml, path.resolve(slugDir, 'index.html'));
        }
      }

      // Static host fallback files (_redirects, 200.html, 404.html)
      const compiled404 = path.resolve(distDir, '404.html');
      const root404 = path.resolve(__dirname, '404.html');
      if (!fs.existsSync(compiled404) && fs.existsSync(root404)) {
        fs.copyFileSync(root404, compiled404);
      }

      const mainIndex = path.resolve(distDir, 'index.html');
      if (fs.existsSync(mainIndex)) {
        fs.copyFileSync(mainIndex, path.resolve(distDir, '200.html'));
      }

      const redirectsContent = `/pdfs/read/* /pdfs.html 200\n/courses/* /courses.html 200\n/* /index.html 200\n`;
      fs.writeFileSync(path.resolve(distDir, '_redirects'), redirectsContent, 'utf-8');
    },
  };
}

export default defineConfig(() => {
  return {
    appType: 'mpa' as const,
    plugins: [react(), tailwindcss(), aistudioMediaPlugin(), spaMultiPagePlugin()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    build: {
      rollupOptions: {
        input: {
          main: path.resolve(__dirname, 'index.html'),
          developer: path.resolve(__dirname, 'developer.html'),
          android: path.resolve(__dirname, 'android.html'),
          roadmap: path.resolve(__dirname, 'roadmap.html'),
          creator: path.resolve(__dirname, 'creator.html'),
          tools: path.resolve(__dirname, 'tools.html'),
          resources: path.resolve(__dirname, 'resources.html'),
          ai: path.resolve(__dirname, 'ai.html'),
          login: path.resolve(__dirname, 'login.html'),
          about: path.resolve(__dirname, 'about.html'),
          skills: path.resolve(__dirname, 'skills.html'),
          projects: path.resolve(__dirname, 'projects.html'),
          blog: path.resolve(__dirname, 'blog.html'),
          contact: path.resolve(__dirname, 'contact.html'),
          termux: path.resolve(__dirname, 'termux.html'),
          linux: path.resolve(__dirname, 'linux.html'),
          powershell: path.resolve(__dirname, 'powershell.html'),
          bash: path.resolve(__dirname, 'bash.html'),
          git: path.resolve(__dirname, 'git.html'),
          programming: path.resolve(__dirname, 'programming.html'),
          apis: path.resolve(__dirname, 'apis.html'),
          opensource: path.resolve(__dirname, 'opensource.html'),
          pdfs: path.resolve(__dirname, 'pdfs.html'),
          courses: path.resolve(__dirname, 'courses.html'),
          qr: path.resolve(__dirname, 'qr.html'),
          notFound: path.resolve(__dirname, '404.html'),
        },
      },
    },
    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});

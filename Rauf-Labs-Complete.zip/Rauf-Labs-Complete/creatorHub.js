/**
 * 🔥 VIRAL CREATOR HUB ENGINE
 * Search, Voice, Real-Time Meme Feed, Editing Academy,
 * Content Generator, Hashtag Tool, Posting Clock & Modals
 */

function initViralCreatorHub() {
  const container = document.getElementById('creator-hero');
  if (!container && !document.getElementById('viral-memes-grid')) return;

  // Initialize all subsystems
  initCreatorTimestamp();
  initCreatorSearch();
  initViralMemes();
  initInstagramGuides();
  initYouTubeGuides();
  initYtChecklist();
  initBestTimeToPost();
  initEditingAcademy();
  initSoftwareGuides();
  initWorkflowPipeline();
  initIdeaGenerator();
  initHashtagFinder();
  initAiCreatorTools();
  initStickyFilterBar();
  initCreatorModalClose();
}

/**
 * 1. Timestamp & Real-Time Pulse
 */
function initCreatorTimestamp() {
  const tsEl = document.getElementById('creator-live-timestamp');
  if (tsEl) {
    const now = new Date();
    const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const dateStr = now.toLocaleDateString([], { month: 'short', day: 'numeric' });
    tsEl.textContent = `Updated just now (${dateStr}, ${timeStr})`;
  }
}

/**
 * 2. Search Bar with Voice Interaction & Instant Filtering
 */
function initCreatorSearch() {
  const input = document.getElementById('creator-search-input');
  const resultsDropdown = document.getElementById('creator-search-results');
  const voiceBtn = document.getElementById('creator-voice-btn');
  if (!input || !resultsDropdown) return;

  // Build searchable index from all data modules
  const searchIndex = [];

  // Index Memes
  if (window.VIRAL_MEMES_DATA) {
    window.VIRAL_MEMES_DATA.forEach(m => {
      searchIndex.push({
        title: m.title,
        category: 'Viral Meme / Trend',
        badge: m.platform,
        snippet: m.explanation,
        action: () => openTrendModal(m.id)
      });
    });
  }

  // Index IG Guides
  if (window.IG_GUIDES_DATA) {
    Object.keys(window.IG_GUIDES_DATA).forEach(k => {
      const g = window.IG_GUIDES_DATA[k];
      searchIndex.push({
        title: g.title,
        category: 'Instagram Guide',
        badge: g.badge,
        snippet: 'Instagram growth strategies, algorithm insights, and Reels retention formulas.',
        action: () => openGuideModal(g.title, g.badge, g.content)
      });
    });
  }

  // Index YT Guides
  if (window.YT_GUIDES_DATA) {
    Object.keys(window.YT_GUIDES_DATA).forEach(k => {
      const g = window.YT_GUIDES_DATA[k];
      searchIndex.push({
        title: g.title,
        category: 'YouTube Guide',
        badge: g.badge,
        snippet: 'YouTube channel launch, video SEO, click-through rate, and retention curves.',
        action: () => openGuideModal(g.title, g.badge, g.content)
      });
    });
  }

  // Index Editing Academy Lessons
  if (window.EDITING_ACADEMY_LESSONS) {
    ['beginner', 'intermediate', 'advanced'].forEach(lvl => {
      window.EDITING_ACADEMY_LESSONS[lvl].forEach(l => {
        searchIndex.push({
          title: l.title,
          category: `Editing Academy (${l.diff})`,
          badge: l.time,
          snippet: l.desc,
          action: () => openLessonModal(l)
        });
      });
    });
  }

  // Index Software Guides
  if (window.EDITING_SOFTWARE_DATA) {
    Object.keys(window.EDITING_SOFTWARE_DATA).forEach(k => {
      const s = window.EDITING_SOFTWARE_DATA[k];
      searchIndex.push({
        title: s.title,
        category: 'Editing Software / App',
        badge: s.badge,
        snippet: s.overview,
        action: () => openSoftwareModal(k)
      });
    });
  }

  // Index AI Tools
  if (window.AI_CREATOR_TOOLS_DATA) {
    window.AI_CREATOR_TOOLS_DATA.forEach(a => {
      searchIndex.push({
        title: a.name,
        category: 'AI Creator Tool',
        badge: a.category,
        snippet: a.what,
        action: () => {
          resultsDropdown.classList.remove('open');
          const el = document.getElementById('ai-tools');
          if (el) el.scrollIntoView({ behavior: 'smooth' });
        }
      });
    });
  }

  function handleSearch(q) {
    const term = q.trim().toLowerCase();
    if (!term) {
      resultsDropdown.classList.remove('open');
      resultsDropdown.innerHTML = '';
      return;
    }

    const matches = searchIndex.filter(item => {
      return item.title.toLowerCase().includes(term) ||
             item.category.toLowerCase().includes(term) ||
             item.snippet.toLowerCase().includes(term) ||
             item.badge.toLowerCase().includes(term);
    }).slice(0, 7);

    if (matches.length === 0) {
      resultsDropdown.innerHTML = `
        <div style="padding: 18px; text-align: center; color: var(--text-secondary);">
          <div style="margin-bottom: 6px; font-weight: 700; color: #fff;">No matching creator items found for "${q}"</div>
          <div style="font-size: 0.85rem; margin-bottom: 12px;">Try searching for:</div>
          <div style="display: flex; gap: 6px; justify-content: center; flex-wrap: wrap;">
            <button class="btn btn-secondary btn-sm search-suggest-btn" data-s="CapCut">CapCut</button>
            <button class="btn btn-secondary btn-sm search-suggest-btn" data-s="Hooks">Hooks</button>
            <button class="btn btn-secondary btn-sm search-suggest-btn" data-s="Hashtags">Hashtags</button>
            <button class="btn btn-secondary btn-sm search-suggest-btn" data-s="Shorts">Shorts</button>
            <button class="btn btn-secondary btn-sm search-suggest-btn" data-s="Keyframes">Keyframes</button>
          </div>
        </div>
      `;
      resultsDropdown.classList.add('open');

      resultsDropdown.querySelectorAll('.search-suggest-btn').forEach(btn => {
        btn.onclick = () => {
          input.value = btn.dataset.s;
          handleSearch(btn.dataset.s);
        };
      });
      return;
    }

    let html = '';
    matches.forEach(item => {
      html += `
        <div class="creator-search-item" style="padding: 12px 16px; border-bottom: 1px solid var(--border-subtle); cursor: pointer; display: flex; justify-content: space-between; align-items: center; gap: 12px;">
          <div>
            <div style="font-size: 0.75rem; font-weight: 700; color: var(--accent-cyan); text-transform: uppercase; margin-bottom: 2px;">
              ${item.category} • <span style="color: #94a3b8;">${item.badge}</span>
            </div>
            <div style="font-weight: 700; color: #fff; font-size: 0.95rem;">${item.title}</div>
            <div style="font-size: 0.82rem; color: var(--text-secondary); max-width: 500px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;">${item.snippet}</div>
          </div>
          <span style="color: var(--accent-cyan); font-weight: 700; font-size: 0.9rem;">View ↗</span>
        </div>
      `;
    });

    resultsDropdown.innerHTML = html;
    resultsDropdown.classList.add('open');

    // Attach click handlers
    const itemEls = resultsDropdown.querySelectorAll('.creator-search-item');
    itemEls.forEach((el, idx) => {
      el.onclick = () => {
        resultsDropdown.classList.remove('open');
        input.value = '';
        matches[idx].action();
      };
    });
  }

  input.addEventListener('input', (e) => handleSearch(e.target.value));

  // Close search dropdown on click outside
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.creator-search-wrapper')) {
      resultsDropdown.classList.remove('open');
    }
  });

  // Voice Search setup
  if (voiceBtn) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      let isListening = false;

      voiceBtn.onclick = () => {
        if (isListening) {
          recognition.stop();
          return;
        }
        try {
          recognition.start();
          isListening = true;
          voiceBtn.style.color = '#ef4444';
          voiceBtn.style.background = 'rgba(239, 68, 68, 0.2)';
          input.placeholder = 'Listening... Speak now!';
        } catch (err) {
          console.warn('SpeechRecognition start error:', err);
        }
      };

      recognition.onresult = (evt) => {
        const transcript = evt.results[0][0].transcript;
        input.value = transcript;
        handleSearch(transcript);
      };

      recognition.onerror = () => {
        isListening = false;
        voiceBtn.style.color = '';
        voiceBtn.style.background = '';
        input.placeholder = 'Search memes, hashtags, Reels ideas, editing tutorials...';
      };

      recognition.onend = () => {
        isListening = false;
        voiceBtn.style.color = '';
        voiceBtn.style.background = '';
        input.placeholder = 'Search memes, hashtags, Reels ideas, editing tutorials...';
      };
    } else {
      voiceBtn.onclick = () => {
        if (typeof showToast === 'function') {
          showToast('Voice search is not supported in this browser. Please type your search query.');
        } else {
          alert('Voice search is not supported in this browser.');
        }
      };
    }
  }
}

/**
 * 3. Real-Time Viral Memes & Trends Fetcher + Fallback
 */
function initViralMemes() {
  const grid = document.getElementById('viral-memes-grid');
  const filterWrap = document.getElementById('meme-platform-filter');
  const sourceBadge = document.getElementById('meme-data-source-badge');
  const noticeBanner = document.getElementById('meme-live-status-notice');
  if (!grid) return;

  let activeFilter = 'all';

  // Render trending cards
  function renderMemes(data, isLive = true) {
    let filtered = data;
    if (activeFilter !== 'all') {
      filtered = data.filter(d => d.platform.toLowerCase().includes(activeFilter) || activeFilter.includes(d.platform.toLowerCase()));
    }

    if (filtered.length === 0) {
      grid.innerHTML = `<div style="grid-column: 1 / -1; padding: 40px; text-align: center; color: var(--text-secondary);">No trending memes in the "${activeFilter}" category right now. Select "All" to view active trends.</div>`;
      return;
    }

    let html = '';
    filtered.forEach(item => {
      html += `
        <div class="card" data-trend-id="${item.id}">
          <div class="card-top">
            <span class="card-badge" style="background: rgba(244, 63, 94, 0.15); color: #fb7185;">${item.platform}</span>
            <span style="font-size: 0.78rem; color: #34d399; font-weight: 600;">${item.velocity}</span>
          </div>
          <h3 class="card-title">${item.title}</h3>
          <p class="card-desc">${item.explanation}</p>
          <div style="background: rgba(0,0,0,0.25); padding: 10px 14px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle); margin: 12px 0; font-size: 0.84rem; color: #cbd5e1;">
            <strong style="color: var(--accent-cyan); display: block; margin-bottom: 2px;">Real-World Example:</strong>
            ${item.example}
          </div>
          <div class="card-footer" style="display: flex; justify-content: space-between; align-items: center;">
            <span style="font-size: 0.75rem; color: var(--text-muted);">${item.updated}</span>
            <button class="btn btn-primary btn-sm view-trend-usage-btn" data-id="${item.id}">
              How to use this trend ✦
            </button>
          </div>
        </div>
      `;
    });

    grid.innerHTML = html;

    // Attach click events
    grid.querySelectorAll('.view-trend-usage-btn').forEach(btn => {
      btn.onclick = () => openTrendModal(btn.dataset.id);
    });
  }

  // Live fetch attempt with timeout and fallback
  async function fetchLiveTrends() {
    // Check session cache first
    const cached = sessionStorage.getItem('rauf_viral_memes_cache');
    if (cached) {
      try {
        const parsed = JSON.parse(cached);
        if (sourceBadge) {
          sourceBadge.textContent = '🟢 LIVE TREND FEED';
          sourceBadge.style.color = '#34d399';
        }
        renderMemes(parsed, true);
        return;
      } catch (e) {}
    }

    try {
      // Attempt fetching public trending data with 4s timeout
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      const resp = await fetch('https://api.allorigins.win/raw?url=' + encodeURIComponent('https://www.reddit.com/r/memes/top.json?limit=6&t=day'), {
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
      const json = await resp.json();

      if (json && json.data && json.data.children && json.data.children.length > 0) {
        // Transform live Reddit trends into creator hub format
        const liveItems = json.data.children.slice(0, 6).map((child, idx) => {
          const p = child.data;
          return {
            id: `live_${idx}`,
            title: p.title || 'Trending Public Meme',
            platform: idx % 2 === 0 ? 'Reels / Shorts' : 'Instagram Meme',
            velocity: `🔥 +${Math.round(p.ups / 100) || 150}% Upvotes`,
            updated: 'Live Verified API Stream',
            explanation: `Peaking on global social feeds with over ${p.ups ? p.ups.toLocaleString() : '15,000'} community reactions and high engagement velocity.`,
            example: p.selftext ? p.selftext.slice(0, 100) + '...' : `Viral concept trending around modern tech culture, work habits, and creator relatable moments.`,
            nicheTips: {
              hook: `First 2s: Showcase the core concept of "${p.title.slice(0, 40)}..." with immediate text on screen.`,
              audio: 'Trending background riser or upbeat lo-fi loop.',
              niche: 'Adapts to Tech, Coding, Fitness, and Everyday Creator Situations.'
            }
          };
        });

        sessionStorage.setItem('rauf_viral_memes_cache', JSON.stringify(liveItems));
        if (sourceBadge) {
          sourceBadge.textContent = '🟢 LIVE TREND FEED';
          sourceBadge.style.color = '#34d399';
        }
        if (noticeBanner) noticeBanner.style.display = 'none';
        renderMemes(liveItems, true);
        return;
      }
      throw new Error('Empty payload');
    } catch (err) {
      console.log('Live public trend API stream fallback triggered:', err.message);
      // Graceful verified fallback according to requirement 2 & 15
      if (sourceBadge) {
        sourceBadge.textContent = '🟡 RECENT VERIFIED DATA (Offline Mode)';
        sourceBadge.style.color = '#fbbf24';
      }
      if (noticeBanner) noticeBanner.style.display = 'flex';
      renderMemes(window.VIRAL_MEMES_DATA || [], false);
    }
  }

  // Handle sub-filters
  if (filterWrap) {
    filterWrap.querySelectorAll('button').forEach(btn => {
      btn.onclick = () => {
        filterWrap.querySelectorAll('button').forEach(b => b.classList.remove('active-subfilter'));
        btn.classList.add('active-subfilter');
        activeFilter = btn.dataset.mfilter;
        const cached = sessionStorage.getItem('rauf_viral_memes_cache');
        const data = cached ? JSON.parse(cached) : window.VIRAL_MEMES_DATA;
        renderMemes(data || window.VIRAL_MEMES_DATA);
      };
    });
  }

  fetchLiveTrends();
}

/**
 * 4. Instagram Growth Guide Modals
 */
function initInstagramGuides() {
  document.querySelectorAll('.view-ig-guide-btn').forEach(btn => {
    btn.onclick = () => {
      const guideKey = btn.dataset.guide;
      const g = window.IG_GUIDES_DATA && window.IG_GUIDES_DATA[guideKey];
      if (g) {
        openGuideModal(g.title, g.badge, g.content);
      }
    };
  });
}

/**
 * 5. YouTube Creator Guide Modals & Checklist
 */
function initYouTubeGuides() {
  document.querySelectorAll('.view-yt-guide-btn').forEach(btn => {
    btn.onclick = () => {
      const guideKey = btn.dataset.guide;
      const g = window.YT_GUIDES_DATA && window.YT_GUIDES_DATA[guideKey];
      if (g) {
        openGuideModal(g.title, g.badge, g.content);
      }
    };
  });
}

function initYtChecklist() {
  const container = document.getElementById('yt-checklist-items');
  const scoreEl = document.getElementById('yt-checklist-score');
  if (!container || !scoreEl) return;

  const saved = JSON.parse(localStorage.getItem('yt_publish_checklist') || '[]');
  const checkboxes = container.querySelectorAll('.yt-chk');

  checkboxes.forEach(chk => {
    if (saved.includes(chk.dataset.item)) {
      chk.checked = true;
    }
    chk.onchange = () => {
      const checkedIds = Array.from(container.querySelectorAll('.yt-chk:checked')).map(c => c.dataset.item);
      localStorage.setItem('yt_publish_checklist', JSON.stringify(checkedIds));
      updateScore();
    };
  });

  function updateScore() {
    const checkedCount = container.querySelectorAll('.yt-chk:checked').length;
    const total = checkboxes.length;
    const pct = Math.round((checkedCount / total) * 100);
    scoreEl.textContent = `${checkedCount} / ${total} Completed (${pct}%)`;
    scoreEl.style.color = pct === 100 ? '#34d399' : '#38bdf8';
  }

  updateScore();
}

/**
 * 6. When Should I Post? Interactive Posting Time Matrix
 */
function initBestTimeToPost() {
  const container = document.getElementById('posting-slots-container');
  const tabsWrap = document.getElementById('posting-platform-tabs');
  const tzSelect = document.getElementById('timezone-selector');
  const detectedTzEl = document.getElementById('detected-tz-name');
  if (!container) return;

  let currentPlatform = 'instagram';
  const detectedZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC';
  if (detectedTzEl) detectedTzEl.textContent = detectedZone;

  const SLOTS_DATA = {
    instagram: [
      {
        title: 'Morning Transit Slot',
        time: '7:30 AM – 9:00 AM',
        rating: '⭐ High (88% Engagement)',
        reason: 'Commuters and students check Reels and Stories during travel and morning coffee.',
        bestDays: 'Tuesday, Wednesday, Thursday'
      },
      {
        title: 'Midday Lunch Break',
        time: '12:00 PM – 1:30 PM',
        rating: '🔥 Peak Window (96% Engagement)',
        reason: 'Global office workers and students taking lunch breaks. High save and share velocity.',
        bestDays: 'Wednesday, Friday, Sunday'
      },
      {
        title: 'Evening Prime Time',
        time: '6:30 PM – 9:00 PM',
        rating: '🔥 Highest Total Reach (98%)',
        reason: 'Peak relaxation window. Average watch time and full completion rates reach highest levels.',
        bestDays: 'Monday through Sunday'
      },
      {
        title: 'Late Night Wind-Down',
        time: '10:00 PM – 11:30 PM',
        rating: '⭐ Moderate (82% Engagement)',
        reason: 'Pre-sleep bedside scrolling. High comment and discussion depth on thoughtful content.',
        bestDays: 'Thursday, Friday, Saturday'
      }
    ],
    youtube: [
      {
        title: 'Afternoon Upload Window',
        time: '2:00 PM – 4:00 PM',
        rating: '🔥 Prime Indexing Window',
        reason: 'Allows YouTube 2 hours to index HD/4K tiers and verify captions before evening traffic.',
        bestDays: 'Thursday, Friday, Saturday'
      },
      {
        title: 'Weekend Morning Release',
        time: '9:00 AM – 11:00 AM',
        rating: '⭐ High Long-Form Watch Time',
        reason: 'Viewers have extended time on weekend mornings to watch 10+ minute tutorials.',
        bestDays: 'Saturday, Sunday'
      },
      {
        title: 'Evening Browse Window',
        time: '5:00 PM – 8:00 PM',
        rating: '🔥 Peak Concurrent Viewers',
        reason: 'Matches desktop and smart TV viewing habits for educational and entertainment videos.',
        bestDays: 'Wednesday, Thursday, Friday'
      }
    ],
    shorts: [
      {
        title: 'Early Morning Micro-Dose',
        time: '7:00 AM – 8:30 AM',
        rating: '⭐ Fast Algorithm Test Pool',
        reason: 'Rapid initial test pool gives YouTube algorithm early signals to scale throughout day.',
        bestDays: 'Monday through Friday'
      },
      {
        title: 'Lunchtime Shorts Spurt',
        time: '12:00 PM – 1:30 PM',
        rating: '🔥 High Velocity Pool',
        reason: 'Quick 30-second bites are ideal for mobile snacking during afternoon lulls.',
        bestDays: 'Tuesday, Wednesday, Thursday'
      },
      {
        title: 'Nighttime Shorts Spurt',
        time: '7:00 PM – 10:00 PM',
        rating: '🔥 Peak Algorithmic Distribution',
        reason: 'Shorts shelf recommendation engine prioritizes recently uploaded high-retention clips.',
        bestDays: 'Daily (Consistent cadence)'
      }
    ]
  };

  function renderSlots() {
    const slots = SLOTS_DATA[currentPlatform] || [];
    let html = '';
    slots.forEach(s => {
      html += `
        <div class="posting-slot-card">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
            <span style="font-size: 0.8rem; font-weight: 700; color: var(--accent-cyan); text-transform: uppercase;">${s.title}</span>
            <span style="font-size: 0.78rem; color: #34d399; font-weight: 700;">${s.rating}</span>
          </div>
          <div class="posting-slot-time">${s.time}</div>
          <div class="posting-slot-reason">${s.reason}</div>
          <div class="posting-slot-days">Best days: <strong>${s.bestDays}</strong></div>
        </div>
      `;
    });
    container.innerHTML = html;
  }

  if (tabsWrap) {
    tabsWrap.querySelectorAll('.posting-platform-tab').forEach(tab => {
      tab.onclick = () => {
        tabsWrap.querySelectorAll('.posting-platform-tab').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        currentPlatform = tab.dataset.platform;
        renderSlots();
      };
    });
  }

  if (tzSelect) {
    tzSelect.onchange = (e) => {
      if (detectedTzEl) {
        detectedTzEl.textContent = e.target.value === 'local' ? detectedZone : e.target.value;
      }
      renderSlots();
    };
  }

  renderSlots();
}

/**
 * 7. Editing Academy (29 Lessons with Local Progress Tracking)
 */
function initEditingAcademy() {
  const container = document.getElementById('academy-lessons-container');
  const levelNav = document.getElementById('academy-level-nav');
  const progressFill = document.getElementById('academy-progress-fill');
  const progressLabel = document.getElementById('academy-progress-label');
  const resetBtn = document.getElementById('academy-reset-progress-btn');
  if (!container || !window.EDITING_ACADEMY_LESSONS) return;

  let currentLevel = 'beginner';

  function getCompleted() {
    return JSON.parse(localStorage.getItem('creator_academy_completed') || '[]');
  }

  function toggleCompleted(id) {
    let list = getCompleted();
    if (list.includes(id)) {
      list = list.filter(i => i !== id);
    } else {
      list.push(id);
    }
    localStorage.setItem('creator_academy_completed', JSON.stringify(list));
    updateProgress();
    renderLessons();
  }

  function updateProgress() {
    const list = getCompleted();
    const allCount = 29;
    const completedCount = list.length;
    const pct = Math.round((completedCount / allCount) * 100);

    if (progressFill) progressFill.style.width = `${pct}%`;
    if (progressLabel) progressLabel.textContent = `${completedCount} of ${allCount} Lessons Mastered (${pct}%)`;

    // Update level badges
    const bCount = list.filter(id => id.startsWith('b')).length;
    const iCount = list.filter(id => id.startsWith('i')).length;
    const aCount = list.filter(id => id.startsWith('a')).length;

    const bEl = document.getElementById('badge-count-beginner');
    const iEl = document.getElementById('badge-count-intermediate');
    const aEl = document.getElementById('badge-count-advanced');

    if (bEl) bEl.textContent = `${bCount}/9 Done`;
    if (iEl) iEl.textContent = `${iCount}/10 Done`;
    if (aEl) aEl.textContent = `${aCount}/10 Done`;
  }

  function renderLessons() {
    const lessons = window.EDITING_ACADEMY_LESSONS[currentLevel] || [];
    const completed = getCompleted();

    let html = '';
    lessons.forEach((l, index) => {
      const isDone = completed.includes(l.id);
      html += `
        <div class="card ${isDone ? 'lesson-done-card' : ''}" style="${isDone ? 'border-color: rgba(16, 185, 129, 0.4); background: rgba(16, 185, 129, 0.05);' : ''}">
          <div class="card-top">
            <span class="card-badge ${currentLevel === 'beginner' ? '' : currentLevel === 'intermediate' ? 'cyan' : ''}">
              Lesson #${index + 1} • ${l.diff}
            </span>
            <span style="font-size: 0.78rem; color: #94a3b8; font-family: var(--font-mono);">${l.time}</span>
          </div>
          <h3 class="card-title">${l.title}</h3>
          <p class="card-desc">${l.desc}</p>

          <div style="margin: 14px 0; padding: 12px; background: rgba(0,0,0,0.3); border-radius: var(--radius-sm); border: 1px solid var(--border-subtle); font-size: 0.84rem;">
            <strong style="color: var(--accent-cyan); display: block; margin-bottom: 4px;">Practice Task:</strong>
            <span style="color: #cbd5e1;">${l.task}</span>
          </div>

          <div class="card-footer" style="display: flex; gap: 8px; flex-wrap: wrap; justify-content: space-between; align-items: center;">
            <button class="btn btn-secondary btn-sm read-lesson-btn" data-id="${l.id}">
              Read Full Lesson ↗
            </button>
            <button class="btn ${isDone ? 'btn-primary' : 'btn-secondary'} btn-sm toggle-lesson-btn" data-id="${l.id}" style="${isDone ? 'background: #10b981; border-color: #10b981;' : ''}">
              ${isDone ? '✓ Mastered' : 'Mark as Done'}
            </button>
          </div>
        </div>
      `;
    });

    container.innerHTML = html;

    // Attach click events
    container.querySelectorAll('.read-lesson-btn').forEach(btn => {
      btn.onclick = () => {
        const found = lessons.find(x => x.id === btn.dataset.id);
        if (found) openLessonModal(found);
      };
    });

    container.querySelectorAll('.toggle-lesson-btn').forEach(btn => {
      btn.onclick = () => toggleCompleted(btn.dataset.id);
    });
  }

  if (levelNav) {
    levelNav.querySelectorAll('.academy-tab-btn').forEach(tab => {
      tab.onclick = () => {
        levelNav.querySelectorAll('.academy-tab-btn').forEach(t => t.classList.remove('active'));
        tab.classList.add('active');
        currentLevel = tab.dataset.level;
        renderLessons();
      };
    });
  }

  if (resetBtn) {
    resetBtn.onclick = () => {
      if (confirm('Are you sure you want to reset your Editing Academy progress?')) {
        localStorage.removeItem('creator_academy_completed');
        updateProgress();
        renderLessons();
      }
    };
  }

  updateProgress();
  renderLessons();
}

/**
 * 8. Editing Software & Mobile Apps Guides
 */
function initSoftwareGuides() {
  document.querySelectorAll('.view-app-guide-btn').forEach(btn => {
    btn.onclick = () => {
      openSoftwareModal(btn.dataset.app);
    };
  });
}

/**
 * 9. Viral Content Workflow Pipeline (10 Steps)
 */
function initWorkflowPipeline() {
  const buttons = document.querySelectorAll('.workflow-step-node');
  const display = document.getElementById('workflow-step-display');
  if (!buttons.length || !display || !window.WORKFLOW_STEPS_DATA) return;

  function showStep(stepNum) {
    buttons.forEach(b => {
      if (b.dataset.step === String(stepNum)) {
        b.classList.add('active');
      } else {
        b.classList.remove('active');
      }
    });

    const step = window.WORKFLOW_STEPS_DATA[stepNum];
    if (!step) return;

    let checkHtml = '';
    step.checklist.forEach(item => {
      checkHtml += `<li style="margin-bottom: 6px;">✓ ${item}</li>`;
    });

    display.innerHTML = `
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; flex-wrap: wrap; gap: 8px;">
        <div>
          <span class="card-badge cyan">${step.badge}</span>
          <h3 style="font-size: 1.4rem; color: #fff; margin-top: 6px;">${step.title}</h3>
        </div>
        <div style="font-size: 0.85rem; color: var(--text-secondary);">Interactive Workflow Guide</div>
      </div>
      <p style="color: var(--text-secondary); font-size: 0.95rem; line-height: 1.6; margin-bottom: 16px;">${step.desc}</p>
      
      <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 16px; margin-bottom: 16px;">
        <div style="background: rgba(0,0,0,0.3); padding: 16px; border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
          <strong style="color: var(--accent-cyan); display: block; margin-bottom: 10px;">📋 Action Checklist:</strong>
          <ul style="list-style: none; padding: 0; margin: 0; font-size: 0.88rem; color: #cbd5e1;">
            ${checkHtml}
          </ul>
        </div>
        <div style="display: flex; flex-direction: column; gap: 12px;">
          <div style="background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.25); border-radius: var(--radius-md); padding: 14px;">
            <strong style="color: #34d399; font-size: 0.85rem; display: block; margin-bottom: 4px;">💡 Pro Creator Secret:</strong>
            <span style="font-size: 0.88rem; color: #cbd5e1;">${step.proTip}</span>
          </div>
          <div style="background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.25); border-radius: var(--radius-md); padding: 14px;">
            <strong style="color: #f87171; font-size: 0.85rem; display: block; margin-bottom: 4px;">⚠️ Pitfall to Avoid:</strong>
            <span style="font-size: 0.88rem; color: #94a3b8;">${step.pitfall}</span>
          </div>
        </div>
      </div>
    `;
  }

  buttons.forEach(btn => {
    btn.onclick = () => showStep(Number(btn.dataset.step));
  });

  // Default to step 1
  showStep(1);
}

/**
 * 10. Content Idea & Hook Generator
 */
function initIdeaGenerator() {
  const btn = document.getElementById('gen-ideas-btn');
  const out = document.getElementById('gen-output-container');
  if (!btn || !out) return;

  btn.onclick = () => {
    const platform = document.getElementById('gen-platform').value;
    const niche = document.getElementById('gen-niche').value;
    const type = document.getElementById('gen-type').value;
    const audience = document.getElementById('gen-audience').value;

    const titles = {
      tech: [
        'How to Run Linux Tools Directly on Android (Zero Root Required)',
        '3 Critical Git Mistakes That Ruin Your Repository History',
        'Stop Writing Raw Bash Scripts Until You Master This One Command'
      ],
      ai: [
        'I Replaced 4 Paid SaaS Apps with Free Local AI Prompts',
        'The Prompt Engineering Trick Nobody Talks About in 2026',
        '3 Automation Workflows Every Solo Developer Must Set Up'
      ],
      productivity: [
        'Why Your Notion Setup is Secretly Killing Your Focus',
        'The 15-Minute Terminal Routine I Run Before Writing Any Code',
        'How to Organize 10,000 Files with One Single Python Command'
      ],
      finance: [
        'How Developers Turn Side Projects into $1,000/Month Passive Income',
        '3 Freelance Pricing Mistakes I Made in My First Year',
        'Stop Selling Your Time: How to Package Your Code as Micro-Services'
      ],
      fitness: [
        'How Software Engineers Fix Desk Posture in 3 Daily Minutes',
        '3 Ergonomic Workspace Upgrades That Actually Prevent Wrist Pain',
        'The 20-20-20 Rule for Programmers Spending 10 Hours at Screens'
      ],
      gaming: [
        'How to Optimize OBS Studio for Zero Dropped Frames in 2026',
        '3 Audio Filters That Make Budget Microphones Sound Like Shure SM7B',
        'The Secret to High-Bitrate Gameplay Recordings on Budget Laptops'
      ],
      lifestyle: [
        'A Realistic Day in the Life of a Self-Taught Engineer from Kashmir',
        'How I Built 20+ Practical Tech Projects While Working from Home',
        'The Minimalist Tech Desk Setup that Keeps Me Shipping Code Daily'
      ]
    };

    const nicheTitles = titles[niche] || titles.tech;

    let html = `
      <div style="margin-top: 14px;">
        <div style="font-size: 0.88rem; font-weight: 700; color: #34d399; margin-bottom: 12px;">
          ✦ Generated 3 High-Retention Packages for ${platform.toUpperCase()} (${niche.toUpperCase()}):
        </div>
        <div style="display: flex; flex-direction: column; gap: 16px;">
    `;

    nicheTitles.forEach((t, i) => {
      const hook = i === 0 
        ? `"Stop scrolling. If you are still doing this manually in 2026, here is the 1-click fix."`
        : i === 1 
        ? `"Nobody is talking about this hidden setting, but it saves 3 hours every week."`
        : `"I tested this exact workflow for 30 days. Here is what actually happened."`;

      html += `
        <div style="background: rgba(0,0,0,0.3); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 18px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; flex-wrap: wrap; gap: 8px;">
            <span class="card-badge ${i === 0 ? 'cyan' : ''}">Package #${i + 1} • High Engagement</span>
            <button class="btn btn-secondary btn-sm copy-package-btn" data-title="${t}" data-hook="${hook}">
              Copy Full Package 📋
            </button>
          </div>
          <h4 style="font-size: 1.1rem; color: #fff; margin-bottom: 8px;">"${t}"</h4>
          <div style="font-size: 0.86rem; color: var(--accent-cyan); margin-bottom: 6px;">
            <strong>Opening Verbal Hook (First 2.5s):</strong> ${hook}
          </div>
          <div style="font-size: 0.84rem; color: var(--text-secondary); line-height: 1.5;">
            <strong>Caption Template:</strong> "Save this so you don't lose the commands later! 📌 Here is the step-by-step breakdown of how to execute this in under 60 seconds... [drop 3 key steps]. Drop a comment if you want the link to the full GitHub code!"
          </div>
        </div>
      `;
    });

    html += `</div></div>`;
    out.innerHTML = html;

    out.querySelectorAll('.copy-package-btn').forEach(b => {
      b.onclick = () => {
        const text = `Title: ${b.dataset.title}\nHook: ${b.dataset.hook}\nFormat: ${platform} | Audience: ${audience}`;
        navigator.clipboard.writeText(text).then(() => {
          if (typeof showToast === 'function') showToast('Copied content package to clipboard!');
          b.textContent = '✓ Copied!';
          setTimeout(() => { b.textContent = 'Copy Full Package 📋'; }, 2000);
        });
      };
    });
  };
}

/**
 * 11. Multi-Tier Hashtag Finder
 */
function initHashtagFinder() {
  const btn = document.getElementById('find-hashtags-btn');
  const input = document.getElementById('hashtag-query');
  const platformSelect = document.getElementById('hashtag-platform');
  const box = document.getElementById('hashtag-results-box');
  if (!btn || !input || !box) return;

  btn.onclick = () => {
    const q = input.value.trim() || 'Tech & Coding';
    const plat = platformSelect ? platformSelect.value : 'instagram';
    const cleanWord = q.toLowerCase().replace(/[^a-z0-9]/g, '');

    const broad = [`#${cleanWord}`, `#${cleanWord}life`, `#learn${cleanWord}`, `#${cleanWord}tips`];
    const niche = [`#${cleanWord}community`, `#daily${cleanWord}`, `#${cleanWord}guide`, `#${cleanWord}developer`];
    const context = [`#${cleanWord}2026`, `#buildwith${cleanWord}`, `#${cleanWord}setup`];

    const allTags = plat === 'youtube' 
      ? [`#${cleanWord}`, `#shorts`, `#tech`] 
      : [...broad.slice(0, 1), ...niche.slice(0, 2), ...context.slice(0, 2)];

    box.innerHTML = `
      <div style="background: rgba(0,0,0,0.3); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 18px; margin-top: 14px;">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; flex-wrap: wrap; gap: 8px;">
          <div style="font-size: 0.95rem; font-weight: 700; color: #fff;">
            Recommended Tags for "${q}" on ${plat === 'youtube' ? 'YouTube' : 'Instagram'}:
          </div>
          <button id="copy-all-tags-btn" class="btn btn-primary btn-sm">
            Copy Recommended Tags 📋
          </button>
        </div>

        <div style="display: flex; gap: 8px; flex-wrap: wrap; margin-bottom: 16px;">
          ${allTags.map(t => `<span class="tag-pill" style="background: rgba(56, 189, 248, 0.15); color: #38bdf8; border: 1px solid rgba(56, 189, 248, 0.3); padding: 4px 10px; border-radius: 9999px; font-size: 0.85rem; font-family: var(--font-mono); font-weight: 600;">${t}</span>`).join('')}
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px; font-size: 0.82rem; color: var(--text-secondary); border-top: 1px solid var(--border-subtle); padding-top: 12px;">
          <div><strong style="color: #34d399;">Broad Tier:</strong> 1 Tag (High search volume)</div>
          <div><strong style="color: #38bdf8;">Niche Community:</strong> 2 Tags (Targeted audience)</div>
          <div><strong style="color: #fb7185;">Context Tier:</strong> 1–2 Tags (Exact video topic)</div>
        </div>
      </div>
    `;

    box.style.display = 'block';

    const copyBtn = document.getElementById('copy-all-tags-btn');
    if (copyBtn) {
      copyBtn.onclick = () => {
        navigator.clipboard.writeText(allTags.join(' ')).then(() => {
          if (typeof showToast === 'function') showToast('Hashtags copied to clipboard!');
          copyBtn.textContent = '✓ Copied All!';
          setTimeout(() => { copyBtn.textContent = 'Copy Recommended Tags 📋'; }, 2000);
        });
      };
    }
  };
}

/**
 * 12. AI Creator Tools Directory
 */
function initAiCreatorTools() {
  const grid = document.getElementById('ai-creator-tools-grid');
  if (!grid || !window.AI_CREATOR_TOOLS_DATA) return;

  let html = '';
  window.AI_CREATOR_TOOLS_DATA.forEach(tool => {
    html += `
      <div class="card">
        <div class="card-top">
          <span class="card-badge" style="background: rgba(168, 85, 247, 0.15); color: #c084fc;">${tool.category}</span>
          <span style="font-size: 0.78rem; color: #34d399;">AI Engine</span>
        </div>
        <h3 class="card-title">${tool.name}</h3>
        <p class="card-desc">${tool.what}</p>

        <div style="background: rgba(0,0,0,0.25); padding: 10px 14px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle); margin: 12px 0; font-size: 0.82rem; color: #cbd5e1;">
          <strong style="color: var(--accent-cyan); display: block; margin-bottom: 2px;">Who it is for:</strong>
          ${tool.who}
        </div>

        <div class="card-footer" style="display: flex; justify-content: space-between; align-items: center;">
          <button class="btn btn-secondary btn-sm copy-prompt-btn" data-prompt="${encodeURIComponent(tool.prompt)}">
            Copy Prompt Template 📋
          </button>
          <a href="/ai" class="btn btn-primary btn-sm">Launch in AI ✦</a>
        </div>
      </div>
    `;
  });

  grid.innerHTML = html;

  grid.querySelectorAll('.copy-prompt-btn').forEach(btn => {
    btn.onclick = () => {
      const prompt = decodeURIComponent(btn.dataset.prompt);
      navigator.clipboard.writeText(prompt).then(() => {
        if (typeof showToast === 'function') showToast('AI Prompt copied to clipboard!');
        btn.textContent = '✓ Copied!';
        setTimeout(() => { btn.textContent = 'Copy Prompt Template 📋'; }, 2000);
      });
    };
  });
}

/**
 * 13. Sticky Filter System
 */
function initStickyFilterBar() {
  const tabs = document.querySelectorAll('.sticky-filter-btn');
  if (!tabs.length) return;

  tabs.forEach(tab => {
    tab.onclick = () => {
      tabs.forEach(t => t.classList.remove('active'));
      tab.classList.add('active');

      const filter = tab.dataset.filter;
      const targetMap = {
        'all': 'creator-hero',
        'memes': 'viral-memes',
        'instagram': 'instagram-guide',
        'youtube': 'youtube-guide',
        'reels': 'instagram-guide',
        'shorts': 'youtube-guide',
        'editing': 'editing-academy',
        'hashtags': 'hashtag-tool',
        'ai-tools': 'ai-tools',
        'workflow': 'content-workflow'
      };

      const targetId = targetMap[filter];
      if (targetId) {
        const el = document.getElementById(targetId);
        if (el) {
          el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }
      }
    };
  });
}

/**
 * 14. Modals Engine
 */
function openGuideModal(title, badge, htmlContent) {
  const modal = document.getElementById('creator-hub-modal');
  const titleEl = document.getElementById('creator-modal-title');
  const bodyEl = document.getElementById('creator-modal-content');
  if (!modal || !titleEl || !bodyEl) return;

  titleEl.innerHTML = `<span class="card-badge cyan" style="margin-right: 8px;">${badge}</span> ${title}`;
  bodyEl.innerHTML = htmlContent;
  modal.classList.add('open');
}

function openLessonModal(lesson) {
  const modal = document.getElementById('creator-hub-modal');
  const titleEl = document.getElementById('creator-modal-title');
  const bodyEl = document.getElementById('creator-modal-content');
  if (!modal || !titleEl || !bodyEl) return;

  let stepsHtml = '';
  lesson.steps.forEach((s, idx) => {
    stepsHtml += `
      <li style="margin-bottom: 8px;">
        <strong style="color: var(--accent-cyan);">Step ${idx + 1}:</strong> ${s}
      </li>
    `;
  });

  titleEl.innerHTML = `<span class="card-badge" style="margin-right: 8px;">${lesson.diff} (${lesson.time})</span> ${lesson.title}`;
  bodyEl.innerHTML = `
    <p style="font-size: 1.05rem; color: var(--text-secondary); line-height: 1.6; margin-bottom: 20px;">
      ${lesson.desc}
    </p>

    <h4 style="color: #fff; margin-bottom: 12px; font-size: 1.1rem;">Step-by-Step Instructions:</h4>
    <ol style="list-style: none; padding: 0; margin-bottom: 20px;">
      ${stepsHtml}
    </ol>

    <div style="background: rgba(16, 185, 129, 0.08); border: 1px solid rgba(16, 185, 129, 0.25); border-radius: var(--radius-md); padding: 16px; margin-bottom: 16px;">
      <strong style="color: #34d399; font-size: 0.9rem; display: block; margin-bottom: 6px;">🎯 Practice Exercise:</strong>
      <p style="margin: 0; color: #cbd5e1; font-size: 0.9rem;">${lesson.task}</p>
    </div>

    <div style="background: rgba(239, 68, 68, 0.08); border: 1px solid rgba(239, 68, 68, 0.25); border-radius: var(--radius-md); padding: 16px;">
      <strong style="color: #f87171; font-size: 0.9rem; display: block; margin-bottom: 6px;">⚠️ Common Amateur Mistake:</strong>
      <p style="margin: 0; color: #94a3b8; font-size: 0.9rem;">${lesson.mistake}</p>
    </div>
  `;

  modal.classList.add('open');
}

function openSoftwareModal(key) {
  const s = window.EDITING_SOFTWARE_DATA && window.EDITING_SOFTWARE_DATA[key];
  if (!s) return;

  const modal = document.getElementById('creator-hub-modal');
  const titleEl = document.getElementById('creator-modal-title');
  const bodyEl = document.getElementById('creator-modal-content');
  if (!modal || !titleEl || !bodyEl) return;

  titleEl.innerHTML = `<span class="card-badge cyan" style="margin-right: 8px;">${s.badge}</span> ${s.title}`;
  bodyEl.innerHTML = `
    <p style="font-size: 1.05rem; color: var(--text-secondary); line-height: 1.6; margin-bottom: 18px;">
      ${s.overview}
    </p>

    <div style="background: rgba(56, 189, 248, 0.08); border: 1px solid rgba(56, 189, 248, 0.25); border-radius: var(--radius-md); padding: 14px; margin-bottom: 20px;">
      <strong style="color: #38bdf8; font-size: 0.85rem; display: block; margin-bottom: 4px;">📱 Mobile vs Desktop Notice:</strong>
      <span style="font-size: 0.88rem; color: #cbd5e1;">${s.parityNotice}</span>
    </div>

    <h4 style="color: #fff; margin-bottom: 8px;">Tutorial Progression:</h4>
    <div style="display: flex; flex-direction: column; gap: 10px; margin-bottom: 20px;">
      <div style="background: rgba(0,0,0,0.3); padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
        <strong style="color: #34d399; font-size: 0.85rem;">🌱 Beginner Quickstart:</strong>
        <p style="margin: 4px 0 0; font-size: 0.88rem; color: #cbd5e1;">${s.beginnerTutorial}</p>
      </div>
      <div style="background: rgba(0,0,0,0.3); padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
        <strong style="color: #38bdf8; font-size: 0.85rem;">⚡ Intermediate Workflow:</strong>
        <p style="margin: 4px 0 0; font-size: 0.88rem; color: #cbd5e1;">${s.intermediateTutorial}</p>
      </div>
      <div style="background: rgba(0,0,0,0.3); padding: 12px; border-radius: var(--radius-sm); border: 1px solid var(--border-subtle);">
        <strong style="color: #fb7185; font-size: 0.85rem;">🔥 Advanced Techniques:</strong>
        <p style="margin: 4px 0 0; font-size: 0.88rem; color: #cbd5e1;">${s.advancedTutorial}</p>
      </div>
    </div>

    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 14px;">
      <div style="background: rgba(0,0,0,0.25); padding: 14px; border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
        <strong style="color: var(--accent-cyan); display: block; margin-bottom: 4px;">🎯 Practice Project:</strong>
        <p style="margin: 0; font-size: 0.86rem; color: #cbd5e1;">${s.project}</p>
      </div>
      <div style="background: rgba(0,0,0,0.25); padding: 14px; border-radius: var(--radius-md); border: 1px solid var(--border-subtle);">
        <strong style="color: var(--accent-cyan); display: block; margin-bottom: 4px;">🚀 Export Tips:</strong>
        <p style="margin: 0; font-size: 0.86rem; color: #cbd5e1;">${s.exportTips}</p>
      </div>
    </div>
  `;

  modal.classList.add('open');
}

function openTrendModal(id) {
  const cached = sessionStorage.getItem('rauf_viral_memes_cache');
  const allTrends = cached ? JSON.parse(cached) : window.VIRAL_MEMES_DATA;
  const item = (allTrends || []).find(t => t.id === id) || (window.VIRAL_MEMES_DATA || []).find(t => t.id === id);
  if (!item) return;

  const modal = document.getElementById('creator-hub-modal');
  const titleEl = document.getElementById('creator-modal-title');
  const bodyEl = document.getElementById('creator-modal-content');
  if (!modal || !titleEl || !bodyEl) return;

  titleEl.innerHTML = `<span class="card-badge" style="margin-right: 8px;">${item.platform}</span> Trend Execution Blueprint`;
  bodyEl.innerHTML = `
    <h3 style="font-size: 1.3rem; color: #fff; margin-bottom: 8px;">"${item.title}"</h3>
    <div style="color: #34d399; font-weight: 700; font-size: 0.88rem; margin-bottom: 16px;">${item.velocity} • ${item.updated}</div>
    <p style="color: var(--text-secondary); font-size: 0.95rem; line-height: 1.6; margin-bottom: 20px;">
      ${item.explanation}
    </p>

    <div style="background: rgba(0,0,0,0.3); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 16px; margin-bottom: 16px;">
      <h4 style="color: var(--accent-cyan); margin-bottom: 10px; font-size: 1rem;">Actionable Trend Execution:</h4>
      <div style="display: flex; flex-direction: column; gap: 12px; font-size: 0.9rem;">
        <div>
          <strong style="color: #fff; display: block; margin-bottom: 2px;">🎣 Recommended Hook (First 2s):</strong>
          <span style="color: #38bdf8;">${item.nicheTips ? item.nicheTips.hook : 'Deliver the punchline or core problem statement in frame 1.'}</span>
        </div>
        <div>
          <strong style="color: #fff; display: block; margin-bottom: 2px;">🎵 Audio Selection:</strong>
          <span style="color: #cbd5e1;">${item.nicheTips ? item.nicheTips.audio : 'Search the exact audio title inside Instagram or YouTube Shorts audio library.'}</span>
        </div>
        <div>
          <strong style="color: #fff; display: block; margin-bottom: 2px;">💡 Niche Adaptability:</strong>
          <span style="color: #cbd5e1;">${item.nicheTips ? item.nicheTips.niche : 'Universal format suitable for tech, coding, fitness, and career topics.'}</span>
        </div>
      </div>
    </div>
  `;

  modal.classList.add('open');
}

function initCreatorModalClose() {
  const modal = document.getElementById('creator-hub-modal');
  const closeBtn = document.getElementById('creator-modal-close');
  if (!modal) return;

  if (closeBtn) {
    closeBtn.onclick = () => modal.classList.remove('open');
  }

  modal.onclick = (e) => {
    if (e.target === modal) modal.classList.remove('open');
  };

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('open')) {
      modal.classList.remove('open');
    }
  });
}

// Global hook for script.js
window.initViralCreatorHub = initViralCreatorHub;

/**
 * 🎓 RAUF LABS ACADEMY — INTERACTIVE COURSE ENGINE
 * 
 * Handles course catalog filtering, category tabs, real-time search,
 * URL route synchronization, and the comprehensive course reader view.
 */

(function () {
  'use strict';

  // Category slug-to-name mapping
  const CATEGORY_MAP = {
    'all': 'All Categories',
    'ai': 'AI & Generative AI',
    'generative-ai': 'AI & Generative AI',
    'programming': 'Programming',
    'web-development': 'Web Development',
    'web': 'Web Development',
    'android': 'Android',
    'termux': 'Termux',
    'linux': 'Linux',
    'bash': 'Bash',
    'powershell': 'PowerShell',
    'git': 'Git & GitHub',
    'github': 'Git & GitHub',
    'apis': 'APIs',
    'software-engineering': 'Software Engineering',
    'open-source': 'Open Source',
    'cybersecurity': 'Cybersecurity Fundamentals',
    'cybersecurity-fundamentals': 'Cybersecurity Fundamentals',
    'automation': 'Automation',
    'developer-tools': 'Developer Tools',
    'tools': 'Developer Tools',
    'creator': 'Creator Technology',
    'creator-technology': 'Creator Technology',
    'productivity': 'Productivity',
    'other': 'Other Technology',
    'other-technology': 'Other Technology'
  };

  function getSlugFromCategory(category) {
    if (!category) return 'all';
    const clean = category.toLowerCase().trim();
    if (clean.includes('ai') || clean.includes('generative')) return 'ai';
    if (clean.includes('program')) return 'programming';
    if (clean.includes('web')) return 'web-development';
    if (clean.includes('android')) return 'android';
    if (clean.includes('termux')) return 'termux';
    if (clean.includes('linux')) return 'linux';
    if (clean.includes('bash')) return 'bash';
    if (clean.includes('powershell')) return 'powershell';
    if (clean.includes('git')) return 'git';
    if (clean.includes('api')) return 'apis';
    if (clean.includes('software')) return 'software-engineering';
    if (clean.includes('open source') || clean.includes('opensource')) return 'open-source';
    if (clean.includes('cyber') || clean.includes('security')) return 'cybersecurity';
    if (clean.includes('automat')) return 'automation';
    if (clean.includes('developer tools') || clean.includes('tool')) return 'developer-tools';
    if (clean.includes('creator')) return 'creator';
    if (clean.includes('productiv')) return 'productivity';
    return 'other';
  }

  // Parse state from current URL
  function getRouteParams() {
    const pathname = window.location.pathname.replace(/\/$/, '') || '/';
    const searchParams = new URLSearchParams(window.location.search);

    let activeCategory = 'all';
    let activeCourseId = searchParams.get('id') || '';

    // Check pathname like /courses/ai or /courses/termux
    const parts = pathname.split('/').filter(Boolean);
    if (parts[0] === 'courses') {
      if (parts[1]) {
        const potentialSlug = parts[1].toLowerCase();
        // Check if parts[1] is a course ID
        const matchCourse = (window.COURSES_DATA || []).find(c => c.id === potentialSlug);
        if (matchCourse) {
          activeCourseId = matchCourse.id;
          activeCategory = getSlugFromCategory(matchCourse.category);
        } else if (CATEGORY_MAP[potentialSlug]) {
          activeCategory = potentialSlug;
          if (parts[2]) {
            activeCourseId = parts[2];
          }
        }
      }
    }

    if (searchParams.get('category')) {
      activeCategory = searchParams.get('category').toLowerCase();
    }

    return {
      category: activeCategory,
      courseId: activeCourseId,
      search: searchParams.get('q') || '',
      difficulty: searchParams.get('difficulty') || 'all',
      duration: searchParams.get('duration') || 'all'
    };
  }

  window.initCoursesEngine = function () {
    const container = document.getElementById('courses-engine-root');
    if (!container) return;

    const courses = window.COURSES_DATA || [];
    const params = getRouteParams();

    let state = {
      searchQuery: params.search,
      selectedCategory: params.category,
      selectedDifficulty: params.difficulty,
      selectedDuration: params.duration,
      selectedCourseId: params.courseId,
      activeLessonMap: {} // courseId -> { moduleIndex, lessonIndex }
    };

    function render() {
      // If a specific course is selected, render the detailed Course Reader
      if (state.selectedCourseId) {
        const currentCourse = courses.find(c => c.id === state.selectedCourseId);
        if (currentCourse) {
          renderCourseDetail(currentCourse);
          return;
        }
      }

      // Otherwise, render Course Catalog with Filters
      renderCatalog();
    }

    // -----------------------------------------------------------------------
    // Course Detail View Render
    // -----------------------------------------------------------------------
    function renderCourseDetail(course) {
      const activeState = state.activeLessonMap[course.id] || { modIdx: 0, lesIdx: 0 };
      const currentModule = course.modules[activeState.modIdx] || course.modules[0];
      const currentLesson = currentModule ? (currentModule.lessons[activeState.lesIdx] || currentModule.lessons[0]) : null;

      const categorySlug = getSlugFromCategory(course.category);
      const isBookmarked = (typeof window.getBookmarks === 'function' && window.getBookmarks().includes(course.title));

      container.innerHTML = `
        <div class="course-reader-view animate-fade-in">
          <!-- Navigation Breadcrumb Bar -->
          <div class="reader-top-bar">
            <button id="reader-back-btn" class="btn btn-secondary btn-sm">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>
              Back to Courses
            </button>
            <div class="reader-breadcrumbs">
              <a href="/courses" class="reader-crumb-link">Academy</a>
              <span class="reader-crumb-sep">/</span>
              <a href="/courses/${categorySlug}" class="reader-crumb-link">${escapeHtml(course.category)}</a>
              <span class="reader-crumb-sep">/</span>
              <span class="reader-crumb-active">${escapeHtml(course.title)}</span>
            </div>
            <div class="reader-actions">
              <button id="reader-bookmark-btn" class="btn-icon-subtle ${isBookmarked ? 'bookmarked' : ''}" title="Bookmark Course">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="${isBookmarked ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg>
              </button>
              <button id="reader-share-btn" class="btn-icon-subtle" title="Share Course">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="18" cy="5" r="3"></circle><circle cx="6" cy="12" r="3"></circle><circle cx="18" cy="19" r="3"></circle><line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line><line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line></svg>
              </button>
            </div>
          </div>

          <!-- Course Header Card -->
          <div class="course-detail-header card">
            <div class="course-header-meta">
              <span class="card-badge ${getBadgeClass(course.category)}">${escapeHtml(course.category)}</span>
              <span class="badge-difficulty ${course.difficulty.toLowerCase()}">${escapeHtml(course.difficulty)}</span>
              <span class="badge-duration">⏱ ${escapeHtml(course.duration)}</span>
              <span class="badge-license">⚖️ ${escapeHtml(course.licenseInfo.split('•')[0] || 'CC BY 4.0')}</span>
            </div>
            <h1 class="course-detail-title">${escapeHtml(course.title)}</h1>
            <p class="course-detail-desc">${escapeHtml(course.shortDescription)}</p>

            <div class="course-tech-row">
              <span class="tech-row-label">Technologies:</span>
              <div class="tech-tags">
                ${course.technology.map(t => `<span class="tech-tag">${escapeHtml(t)}</span>`).join('')}
              </div>
            </div>

            <!-- What you will learn checklist -->
            <div class="learn-checklist-box">
              <h3 class="learn-box-title">What You'll Learn &amp; Master:</h3>
              <div class="learn-grid">
                ${course.whatYouWillLearn.map(item => `
                  <div class="learn-item">
                    <svg class="check-icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2.5"><polyline points="20 6 9 17 4 12"></polyline></svg>
                    <span>${escapeHtml(item)}</span>
                  </div>
                `).join('')}
              </div>
            </div>

            <!-- Prerequisites & Tools -->
            <div class="course-prereq-grid">
              <div class="prereq-card">
                <strong>Prerequisites</strong>
                <p>${escapeHtml(course.prerequisites)}</p>
              </div>
              <div class="prereq-card">
                <strong>Required Tools &amp; Environment</strong>
                <div class="tools-pills">
                  ${course.requiredTools.map(tool => `<span class="tool-pill">⚙️ ${escapeHtml(tool)}</span>`).join('')}
                </div>
              </div>
            </div>
          </div>

          <!-- Interactive Learning Workspace: Sidebar + Lesson Viewer -->
          <div class="course-workspace-layout">
            <!-- Sidebar: Modules & Lessons -->
            <aside class="workspace-sidebar card">
              <div class="sidebar-header">
                <h3>Course Curriculum</h3>
                <span class="modules-count">${course.modules.length} Modules</span>
              </div>
              <div class="modules-accordion">
                ${course.modules.map((mod, mIdx) => `
                  <div class="module-group ${mIdx === activeState.modIdx ? 'active-module' : ''}">
                    <div class="module-group-title" data-mod-idx="${mIdx}">
                      <span>${escapeHtml(mod.moduleTitle)}</span>
                      <span class="module-chevron">${mIdx === activeState.modIdx ? '▾' : '▸'}</span>
                    </div>
                    <div class="module-lessons-list">
                      ${mod.lessons.map((les, lIdx) => {
                        const isCurrent = (mIdx === activeState.modIdx && lIdx === activeState.lesIdx);
                        return `
                          <button class="lesson-tab-btn ${isCurrent ? 'active' : ''}" data-mod-idx="${mIdx}" data-les-idx="${lIdx}">
                            <span class="lesson-num">${mIdx + 1}.${lIdx + 1}</span>
                            <span class="lesson-name">${escapeHtml(les.lessonTitle)}</span>
                            <span class="lesson-time">${escapeHtml(les.duration)}</span>
                          </button>
                        `;
                      }).join('')}
                    </div>
                  </div>
                `).join('')}
              </div>
            </aside>

            <!-- Main Lesson Reader -->
            <section class="workspace-lesson-panel">
              ${currentLesson ? `
                <div class="lesson-content-card card">
                  <div class="lesson-meta-bar">
                    <span class="lesson-badge">Module ${activeState.modIdx + 1} • Lesson ${activeState.lesIdx + 1}</span>
                    <span class="lesson-read-time">⏱ ${escapeHtml(currentLesson.duration)}</span>
                  </div>

                  <h2 class="lesson-headline">${escapeHtml(currentLesson.lessonTitle)}</h2>
                  <p class="lesson-summary-lead">${escapeHtml(currentLesson.summary)}</p>

                  <div class="lesson-body-text">
                    <p>${escapeHtml(currentLesson.content)}</p>
                  </div>

                  <!-- Code block with copy button -->
                  <div class="lesson-code-wrapper">
                    <div class="code-header">
                      <div class="code-dots">
                        <span class="dot red"></span>
                        <span class="dot yellow"></span>
                        <span class="dot green"></span>
                        <span class="code-lang-tag">${escapeHtml(currentLesson.codeLanguage || 'bash')}</span>
                      </div>
                      <button class="copy-btn" data-code="${encodeURIComponent(currentLesson.codeSnippet)}">
                        Copy Code
                      </button>
                    </div>
                    <pre><code class="language-${escapeHtml(currentLesson.codeLanguage || 'bash')}">${escapeHtml(currentLesson.codeSnippet)}</code></pre>
                  </div>

                  <!-- Hands-on Exercise -->
                  <div class="lesson-exercise-box">
                    <div class="exercise-header">
                      <span class="exercise-badge">⚡ Hands-on Practice Task</span>
                    </div>
                    <p class="exercise-task">${escapeHtml(currentLesson.exercise.task)}</p>
                    <div class="exercise-hint-row">
                      <span class="hint-label">💡 Hint:</span>
                      <span class="hint-text">${escapeHtml(currentLesson.exercise.hint)}</span>
                    </div>
                    <button class="btn btn-secondary btn-sm solution-toggle" style="margin-top: 14px;">
                      Reveal Solution &amp; Answer ↓
                    </button>
                    <div class="solution-dropdown hidden">
                      <div class="code-header" style="background: rgba(0,0,0,0.4); margin-top: 10px;">
                        <span style="font-size: 0.8rem; color: var(--text-muted);">Verified Solution</span>
                        <button class="copy-btn" data-code="${encodeURIComponent(currentLesson.exercise.solution)}">Copy</button>
                      </div>
                      <pre><code>${escapeHtml(currentLesson.exercise.solution)}</code></pre>
                    </div>
                  </div>

                  <!-- Next / Previous Lesson Navigation -->
                  <div class="lesson-pager-row">
                    ${getPrevLesson(course, activeState.modIdx, activeState.lesIdx) ? `
                      <button id="prev-lesson-btn" class="btn btn-secondary btn-sm">
                        ← Previous Lesson
                      </button>
                    ` : '<div></div>'}
                    ${getNextLesson(course, activeState.modIdx, activeState.lesIdx) ? `
                      <button id="next-lesson-btn" class="btn btn-primary btn-sm">
                        Next Lesson →
                      </button>
                    ` : `
                      <span class="curriculum-complete-badge">🎉 Module Completed!</span>
                    `}
                  </div>
                </div>
              ` : '<div class="card"><p>Select a lesson from the curriculum sidebar to begin.</p></div>'}

              <!-- Real-World Project Section -->
              ${course.projects ? `
                <div class="course-project-card card" style="margin-top: 24px;">
                  <div class="project-header">
                    <span class="project-badge">🛠️ Capstone Project</span>
                    <h3 class="project-title">${escapeHtml(course.projects.title)}</h3>
                  </div>
                  <p class="project-desc">${escapeHtml(course.projects.description)}</p>
                  <div class="deliverables-box">
                    <strong>Project Deliverables:</strong>
                    <ul>
                      ${course.projects.deliverables.map(d => `<li>${escapeHtml(d)}</li>`).join('')}
                    </ul>
                  </div>
                </div>
              ` : ''}

              <!-- Troubleshooting & Common Gotchas -->
              ${course.troubleshooting && course.troubleshooting.length ? `
                <div class="course-troubleshoot-card card" style="margin-top: 24px;">
                  <div class="troubleshoot-header">
                    <span class="troubleshoot-badge">🔧 Troubleshooting &amp; Gotchas</span>
                    <h3>Common Developer Errors &amp; Fixes</h3>
                  </div>
                  <div class="troubleshoot-list">
                    ${course.troubleshooting.map(t => `
                      <div class="troubleshoot-item">
                        <div class="troubleshoot-problem">⚠️ ${escapeHtml(t.problem)}</div>
                        <div class="troubleshoot-cause"><strong>Root Cause:</strong> ${escapeHtml(t.cause)}</div>
                        <div class="troubleshoot-fix"><strong>Exact Fix:</strong> <code>${escapeHtml(t.fix)}</code></div>
                      </div>
                    `).join('')}
                  </div>
                </div>
              ` : ''}

              <!-- Official Documentation & Resources -->
              <div class="course-docs-card card" style="margin-top: 24px;">
                <h3>Official Documentation &amp; Reference Links</h3>
                <p style="color: var(--text-muted); font-size: 0.9rem; margin-bottom: 16px;">
                  Ground your technical knowledge in primary sources and authoritative documentation:
                </p>
                <div class="docs-links-grid">
                  ${course.officialDocLinks.map(doc => `
                    <a href="${escapeHtml(doc.url)}" target="_blank" rel="noopener noreferrer" class="doc-link-item">
                      <span>${escapeHtml(doc.title)}</span>
                      <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" y1="14" x2="21" y2="3"></line></svg>
                    </a>
                  `).join('')}
                </div>
                <div class="license-notice-box">
                  <span>📜 <strong>Curriculum License:</strong> ${escapeHtml(course.licenseInfo)}</span>
                </div>
              </div>
            </section>
          </div>
        </div>
      `;

      // Hook up Course Detail Event Listeners
      const backBtn = document.getElementById('reader-back-btn');
      if (backBtn) {
        backBtn.onclick = () => {
          state.selectedCourseId = '';
          updateUrl();
          render();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        };
      }

      // Bookmark Button
      const bmBtn = document.getElementById('reader-bookmark-btn');
      if (bmBtn) {
        bmBtn.onclick = () => {
          if (typeof window.toggleBookmark === 'function') {
            const added = window.toggleBookmark(course.title, `/courses?id=${course.id}`, course.category);
            bmBtn.classList.toggle('bookmarked', added);
            bmBtn.querySelector('svg').setAttribute('fill', added ? 'currentColor' : 'none');
          } else {
            showToast('Course bookmarked!', 'success');
          }
        };
      }

      // Share Button
      const shareBtn = document.getElementById('reader-share-btn');
      if (shareBtn) {
        shareBtn.onclick = () => {
          const url = window.location.href;
          if (navigator.clipboard) {
            navigator.clipboard.writeText(url).then(() => {
              showToast('Course link copied to clipboard!', 'success');
            }).catch(() => {
              showToast(`Link: ${url}`, 'info');
            });
          }
        };
      }

      // Lesson Tab Switching
      container.querySelectorAll('.lesson-tab-btn').forEach(btn => {
        btn.onclick = () => {
          const mIdx = parseInt(btn.dataset.modIdx, 10);
          const lIdx = parseInt(btn.dataset.lesIdx, 10);
          state.activeLessonMap[course.id] = { modIdx: mIdx, lesIdx: lIdx };
          renderCourseDetail(course);
          const lessonCard = container.querySelector('.workspace-lesson-panel');
          if (lessonCard) {
            lessonCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
          }
        };
      });

      // Module Accordion Toggle
      container.querySelectorAll('.module-group-title').forEach(hdr => {
        hdr.onclick = () => {
          const group = hdr.closest('.module-group');
          group.classList.toggle('active-module');
          const chevron = hdr.querySelector('.module-chevron');
          if (chevron) {
            chevron.textContent = group.classList.contains('active-module') ? '▾' : '▸';
          }
        };
      });

      // Solution toggle
      container.querySelectorAll('.solution-toggle').forEach(btn => {
        btn.onclick = () => {
          const solBox = btn.nextElementSibling;
          if (solBox) {
            const isHidden = solBox.classList.toggle('hidden');
            btn.textContent = isHidden ? 'Reveal Solution & Answer ↓' : 'Hide Solution ↑';
          }
        };
      });

      // Copy buttons in lesson
      container.querySelectorAll('.copy-btn').forEach(btn => {
        btn.onclick = () => {
          const code = decodeURIComponent(btn.dataset.code || '');
          if (code && navigator.clipboard) {
            navigator.clipboard.writeText(code).then(() => {
              const prev = btn.textContent;
              btn.textContent = 'Copied!';
              setTimeout(() => { btn.textContent = prev; }, 1500);
              showToast('Code copied to clipboard!', 'success');
            });
          }
        };
      });

      // Previous & Next Lesson Buttons
      const prevBtn = document.getElementById('prev-lesson-btn');
      if (prevBtn) {
        prevBtn.onclick = () => {
          const prev = getPrevLesson(course, activeState.modIdx, activeState.lesIdx);
          if (prev) {
            state.activeLessonMap[course.id] = prev;
            renderCourseDetail(course);
            window.scrollTo({ top: 120, behavior: 'smooth' });
          }
        };
      }

      const nextBtn = document.getElementById('next-lesson-btn');
      if (nextBtn) {
        nextBtn.onclick = () => {
          const next = getNextLesson(course, activeState.modIdx, activeState.lesIdx);
          if (next) {
            state.activeLessonMap[course.id] = next;
            renderCourseDetail(course);
            window.scrollTo({ top: 120, behavior: 'smooth' });
          }
        };
      }
    }

    function getNextLesson(course, modIdx, lesIdx) {
      const currentMod = course.modules[modIdx];
      if (!currentMod) return null;
      if (lesIdx + 1 < currentMod.lessons.length) {
        return { modIdx, lesIdx: lesIdx + 1 };
      }
      if (modIdx + 1 < course.modules.length) {
        return { modIdx: modIdx + 1, lesIdx: 0 };
      }
      return null;
    }

    function getPrevLesson(course, modIdx, lesIdx) {
      if (lesIdx - 1 >= 0) {
        return { modIdx, lesIdx: lesIdx - 1 };
      }
      if (modIdx - 1 >= 0) {
        const prevMod = course.modules[modIdx - 1];
        return { modIdx: modIdx - 1, lesIdx: prevMod.lessons.length - 1 };
      }
      return null;
    }

    // -----------------------------------------------------------------------
    // Course Catalog & Filter Engine Render
    // -----------------------------------------------------------------------
    function renderCatalog() {
      const filtered = courses.filter(c => {
        // Category filter
        if (state.selectedCategory !== 'all') {
          const slug = getSlugFromCategory(c.category);
          if (slug !== state.selectedCategory) return false;
        }

        // Difficulty filter
        if (state.selectedDifficulty !== 'all') {
          if (c.difficulty.toLowerCase() !== state.selectedDifficulty.toLowerCase()) {
            return false;
          }
        }

        // Duration filter
        if (state.selectedDuration !== 'all') {
          const hours = parseFloat(c.duration) || 5;
          if (state.selectedDuration === 'short' && hours >= 5) return false;
          if (state.selectedDuration === 'medium' && (hours < 5 || hours > 8)) return false;
          if (state.selectedDuration === 'long' && hours < 8) return false;
        }

        // Search text
        if (state.searchQuery.trim()) {
          const q = state.searchQuery.toLowerCase().trim();
          const matchTitle = c.title.toLowerCase().includes(q);
          const matchDesc = c.shortDescription.toLowerCase().includes(q);
          const matchCat = c.category.toLowerCase().includes(q);
          const matchTech = (c.technology || []).some(t => t.toLowerCase().includes(q));
          const matchTools = (c.requiredTools || []).some(t => t.toLowerCase().includes(q));
          if (!matchTitle && !matchDesc && !matchCat && !matchTech && !matchTools) {
            return false;
          }
        }

        return true;
      });

      // Categories array for pills
      const categoriesList = [
        { slug: 'all', label: 'All Courses' },
        { slug: 'ai', label: 'AI & Generative AI' },
        { slug: 'programming', label: 'Programming' },
        { slug: 'web-development', label: 'Web Development' },
        { slug: 'android', label: 'Android' },
        { slug: 'termux', label: 'Termux' },
        { slug: 'linux', label: 'Linux' },
        { slug: 'bash', label: 'Bash' },
        { slug: 'powershell', label: 'PowerShell' },
        { slug: 'git', label: 'Git & GitHub' },
        { slug: 'apis', label: 'APIs' },
        { slug: 'software-engineering', label: 'Software Engineering' },
        { slug: 'open-source', label: 'Open Source' },
        { slug: 'cybersecurity', label: 'Cybersecurity' },
        { slug: 'automation', label: 'Automation' },
        { slug: 'developer-tools', label: 'Developer Tools' },
        { slug: 'creator', label: 'Creator Tech' },
        { slug: 'productivity', label: 'Productivity' },
        { slug: 'other', label: 'Other Tech' }
      ];

      container.innerHTML = `
        <div class="courses-catalog-view animate-fade-in">
          <!-- Search & Filter Controls Card -->
          <div class="catalog-controls-card card">
            <div class="catalog-search-row">
              <div class="search-input-wrapper">
                <svg class="search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                <input 
                  type="text" 
                  id="courses-search-input" 
                  class="courses-search-field" 
                  placeholder="Search courses by topic, language, tool, or keyword (e.g. Gemini, Termux, Python, Docker)..."
                  value="${escapeHtml(state.searchQuery)}"
                  autocomplete="off"
                />
                ${state.searchQuery ? `<button id="search-clear-btn" class="search-clear-btn" title="Clear search">✕</button>` : ''}
              </div>

              <!-- Secondary Filters: Difficulty & Duration -->
              <div class="filter-selects-row">
                <select id="filter-difficulty" class="filter-dropdown">
                  <option value="all" ${state.selectedDifficulty === 'all' ? 'selected' : ''}>All Difficulties</option>
                  <option value="beginner" ${state.selectedDifficulty === 'beginner' ? 'selected' : ''}>Beginner</option>
                  <option value="intermediate" ${state.selectedDifficulty === 'intermediate' ? 'selected' : ''}>Intermediate</option>
                  <option value="advanced" ${state.selectedDifficulty === 'advanced' ? 'selected' : ''}>Advanced</option>
                </select>

                <select id="filter-duration" class="filter-dropdown">
                  <option value="all" ${state.selectedDuration === 'all' ? 'selected' : ''}>All Durations</option>
                  <option value="short" ${state.selectedDuration === 'short' ? 'selected' : ''}>&lt; 5 Hours</option>
                  <option value="medium" ${state.selectedDuration === 'medium' ? 'selected' : ''}>5 – 8 Hours</option>
                  <option value="long" ${state.selectedDuration === 'long' ? 'selected' : ''}>8+ Hours</option>
                </select>
              </div>
            </div>

            <!-- Category Pills Bar -->
            <div class="category-pills-bar">
              ${categoriesList.map(cat => `
                <button class="category-pill-btn ${cat.slug === state.selectedCategory ? 'active' : ''}" data-cat-slug="${cat.slug}">
                  ${escapeHtml(cat.label)}
                </button>
              `).join('')}
            </div>

            <!-- Status Indicator / Reset -->
            <div class="catalog-status-bar">
              <span class="results-counter">
                Showing <strong>${filtered.length}</strong> of ${courses.length} courses
                ${state.selectedCategory !== 'all' ? ` in <em>${escapeHtml(CATEGORY_MAP[state.selectedCategory] || state.selectedCategory)}</em>` : ''}
              </span>
              ${(state.searchQuery || state.selectedCategory !== 'all' || state.selectedDifficulty !== 'all' || state.selectedDuration !== 'all') ? `
                <button id="reset-filters-btn" class="btn-reset-filters">
                  ↺ Reset Filters
                </button>
              ` : ''}
            </div>
          </div>

          <!-- Courses Grid -->
          ${filtered.length > 0 ? `
            <div class="courses-cards-grid">
              ${filtered.map(c => renderCourseCard(c)).join('')}
            </div>
          ` : `
            <div class="courses-empty-state card">
              <div class="empty-icon">🔍</div>
              <h3>No courses matched your filter criteria</h3>
              <p>Try adjusting your search keywords or switching category filters.</p>
              <button id="empty-reset-btn" class="btn btn-primary btn-sm" style="margin-top: 16px;">
                Reset All Filters
              </button>
            </div>
          `}
        </div>
      `;

      // Event Listeners for Search & Filters
      const searchInput = document.getElementById('courses-search-input');
      if (searchInput) {
        let debounceTimer;
        searchInput.oninput = (e) => {
          clearTimeout(debounceTimer);
          debounceTimer = setTimeout(() => {
            state.searchQuery = e.target.value;
            updateUrl();
            renderCatalog();
          }, 250);
        };
      }

      const clearBtn = document.getElementById('search-clear-btn');
      if (clearBtn) {
        clearBtn.onclick = () => {
          state.searchQuery = '';
          updateUrl();
          renderCatalog();
        };
      }

      const diffSelect = document.getElementById('filter-difficulty');
      if (diffSelect) {
        diffSelect.onchange = (e) => {
          state.selectedDifficulty = e.target.value;
          updateUrl();
          renderCatalog();
        };
      }

      const durSelect = document.getElementById('filter-duration');
      if (durSelect) {
        durSelect.onchange = (e) => {
          state.selectedDuration = e.target.value;
          updateUrl();
          renderCatalog();
        };
      }

      container.querySelectorAll('.category-pill-btn').forEach(btn => {
        btn.onclick = () => {
          state.selectedCategory = btn.dataset.catSlug;
          updateUrl();
          renderCatalog();
        };
      });

      const resetBtn = document.getElementById('reset-filters-btn');
      if (resetBtn) {
        resetBtn.onclick = resetAllFilters;
      }

      const emptyResetBtn = document.getElementById('empty-reset-btn');
      if (emptyResetBtn) {
        emptyResetBtn.onclick = resetAllFilters;
      }

      // "Start Learning" Button Click on Cards
      container.querySelectorAll('.btn-start-course').forEach(btn => {
        btn.onclick = () => {
          const courseId = btn.dataset.courseId;
          if (courseId) {
            state.selectedCourseId = courseId;
            updateUrl();
            render();
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }
        };
      });

      // Bookmark button on cards
      container.querySelectorAll('.card-bookmark-btn').forEach(btn => {
        btn.onclick = (e) => {
          e.stopPropagation();
          const title = btn.dataset.courseTitle;
          const id = btn.dataset.courseId;
          const cat = btn.dataset.courseCat;
          if (typeof window.toggleBookmark === 'function') {
            const added = window.toggleBookmark(title, `/courses?id=${id}`, cat);
            btn.classList.toggle('bookmarked', added);
            btn.querySelector('svg').setAttribute('fill', added ? 'currentColor' : 'none');
          }
        };
      });
    }

    function renderCourseCard(c) {
      const isBookmarked = (typeof window.getBookmarks === 'function' && window.getBookmarks().includes(c.title));

      return `
        <div class="course-card card ${c.featured ? 'featured-course-card' : ''}">
          <div class="course-card-top">
            <div class="course-card-badges">
              <span class="card-badge ${getBadgeClass(c.category)}">${escapeHtml(c.category)}</span>
              <span class="badge-difficulty ${c.difficulty.toLowerCase()}">${escapeHtml(c.difficulty)}</span>
            </div>
            <button class="card-bookmark-btn ${isBookmarked ? 'bookmarked' : ''}" data-course-id="${c.id}" data-course-title="${escapeHtml(c.title)}" data-course-cat="${escapeHtml(c.category)}" title="Bookmark Course">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="${isBookmarked ? 'currentColor' : 'none'}" stroke="currentColor" stroke-width="2"><path d="M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"></path></svg>
            </button>
          </div>

          <h3 class="course-card-title">${escapeHtml(c.title)}</h3>
          <p class="course-card-desc">${escapeHtml(c.shortDescription)}</p>

          <div class="course-card-tech">
            ${c.technology.slice(0, 4).map(t => `<span class="tech-pill">${escapeHtml(t)}</span>`).join('')}
            ${c.technology.length > 4 ? `<span class="tech-pill more">+${c.technology.length - 4}</span>` : ''}
          </div>

          <div class="course-card-footer">
            <span class="footer-duration">⏱ ${escapeHtml(c.duration)}</span>
            <button class="btn btn-primary btn-sm btn-start-course" data-course-id="${c.id}">
              Start Learning →
            </button>
          </div>
        </div>
      `;
    }

    function resetAllFilters() {
      state.searchQuery = '';
      state.selectedCategory = 'all';
      state.selectedDifficulty = 'all';
      state.selectedDuration = 'all';
      updateUrl();
      renderCatalog();
    }

    function updateUrl() {
      const url = new URL(window.location);
      if (state.selectedCourseId) {
        url.pathname = '/courses';
        url.searchParams.set('id', state.selectedCourseId);
        url.searchParams.delete('category');
        url.searchParams.delete('q');
        url.searchParams.delete('difficulty');
        url.searchParams.delete('duration');
      } else {
        url.searchParams.delete('id');
        if (state.selectedCategory !== 'all') {
          url.pathname = `/courses/${state.selectedCategory}`;
          url.searchParams.delete('category');
        } else {
          url.pathname = '/courses';
          url.searchParams.delete('category');
        }

        if (state.searchQuery) {
          url.searchParams.set('q', state.searchQuery);
        } else {
          url.searchParams.delete('q');
        }

        if (state.selectedDifficulty !== 'all') {
          url.searchParams.set('difficulty', state.selectedDifficulty);
        } else {
          url.searchParams.delete('difficulty');
        }

        if (state.selectedDuration !== 'all') {
          url.searchParams.set('duration', state.selectedDuration);
        } else {
          url.searchParams.delete('duration');
        }
      }

      window.history.pushState({}, '', url.toString());
    }

    // Handle browser back/forward buttons
    window.addEventListener('popstate', () => {
      const newParams = getRouteParams();
      state.selectedCategory = newParams.category;
      state.selectedCourseId = newParams.courseId;
      state.searchQuery = newParams.search;
      state.selectedDifficulty = newParams.difficulty;
      state.selectedDuration = newParams.duration;
      render();
    });

    // Initial render
    render();
  };

  function getBadgeClass(category) {
    if (!category) return 'cyan';
    const c = category.toLowerCase();
    if (c.includes('ai') || c.includes('generative')) return 'purple';
    if (c.includes('termux') || c.includes('android')) return 'emerald';
    if (c.includes('linux') || c.includes('bash')) return 'cyan';
    if (c.includes('security')) return 'red';
    if (c.includes('creator')) return 'pink';
    return 'blue';
  }

  function escapeHtml(str) {
    if (!str) return '';
    return String(str)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  // Auto-init on page load if container exists
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      if (document.getElementById('courses-engine-root')) {
        window.initCoursesEngine();
      }
    });
  } else {
    if (document.getElementById('courses-engine-root')) {
      window.initCoursesEngine();
    }
  }

})();

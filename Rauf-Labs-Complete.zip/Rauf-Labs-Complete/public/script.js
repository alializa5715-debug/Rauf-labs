/**
 * Rauf Labs — Global Script & Interactive Engine
 * Handles Navigation, Mobile Drawer, Copy Actions, Toasts, Filter Tabs,
 * and the Dynamic Public APIs Parser & Directory Engine.
 */

// ==========================================================================
// 1. SPA Client-Side Router & Navigation Engine
// ==========================================================================

function normalizeRoute(path) {
  if (!path || path === '' || path === '/' || path === '/index.html' || path === 'index.html') {
    return '/';
  }
  let clean = path.split('?')[0].split('#')[0];
  clean = clean.replace(/\.html$/, '');
  if (clean.length > 1 && clean.endsWith('/')) {
    clean = clean.slice(0, -1);
  }
  if (!clean.startsWith('/')) {
    clean = '/' + clean;
  }
  return clean;
}

function getRouteData(route) {
  const norm = normalizeRoute(route);
  if (window.RAUF_ROUTES && window.RAUF_ROUTES[norm]) {
    return { route: norm, data: window.RAUF_ROUTES[norm] };
  }
  if (norm.startsWith('/courses/') || norm === '/courses') {
    if (window.RAUF_ROUTES && window.RAUF_ROUTES['/courses']) {
      return { route: norm, data: window.RAUF_ROUTES['/courses'] };
    }
  }
  if (norm.startsWith('/pdfs/read/') || norm.startsWith('/pdfs/')) {
    if (window.RAUF_ROUTES && window.RAUF_ROUTES['/pdfs']) {
      return { route: norm, data: window.RAUF_ROUTES['/pdfs'] };
    }
  }
  if (window.RAUF_ROUTES && window.RAUF_ROUTES['/404']) {
    return { route: '/404', data: window.RAUF_ROUTES['/404'], is404: true };
  }
  return null;
}

function updateActiveNav(activeRoute) {
  const norm = normalizeRoute(activeRoute);

  const navLinks = document.querySelectorAll('.nav-link, .dropdown-link, .mobile-nav-link');
  navLinks.forEach((link) => {
    const href = link.getAttribute('href');
    if (!href) return;
    const linkNorm = normalizeRoute(href);
    if (linkNorm === norm) {
      link.classList.add('active');
    } else {
      link.classList.remove('active');
    }
  });

  // Highlight Learning dropdown trigger if any learning route is active
  const learningRoutes = ['/termux', '/linux', '/powershell', '/bash', '/git', '/programming'];
  const dropdownTrigger = document.querySelector('.dropdown-trigger');
  if (dropdownTrigger) {
    if (learningRoutes.includes(norm)) {
      dropdownTrigger.classList.add('active');
    } else {
      dropdownTrigger.classList.remove('active');
    }
  }
}

function closeMobileDrawer() {
  const drawer = document.querySelector('.mobile-drawer');
  const toggleBtn = document.querySelector('.mobile-toggle');
  if (drawer && drawer.classList.contains('open')) {
    drawer.classList.remove('open');
    if (toggleBtn) {
      toggleBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>';
      toggleBtn.setAttribute('aria-expanded', 'false');
    }
  }
}

function initPageInteractions(route) {
  initCopyButtons();
  initSkillsTabs();
  initBlogModals();
  initContactForm();
  initBookmarksButtons();
  initDevTools();
  initAiCopilot();
  initAuthView();
  initQrPage();
  initLearningTrackInteractions();

  if (route === '/apis' || document.getElementById('api-directory-container')) {
    initApiDirectory();
  }

  if (route === '/creator' || document.getElementById('creator-hero') || document.getElementById('viral-memes-grid')) {
    if (typeof window.initViralCreatorHub === 'function') {
      window.initViralCreatorHub();
    }
  }

  if (route === '/pdfs' || route.startsWith('/pdfs') || document.getElementById('pdf-library-container')) {
    if (typeof window.initPdfLibrary === 'function') {
      window.initPdfLibrary();
    }
  }

  if (route === '/courses' || route.startsWith('/courses') || document.getElementById('courses-engine-root')) {
    if (typeof window.initCoursesEngine === 'function') {
      window.initCoursesEngine();
    }
  }
}

function navigateTo(route, pushState = true) {
  const norm = normalizeRoute(route);
  const mainEl = document.querySelector('main.main-content');

  if (!mainEl || !document.querySelector('.navbar')) {
    if (window.location.pathname !== norm) {
      window.location.href = norm === '/' ? '/' : norm;
    }
    return;
  }

  const routeObj = getRouteData(norm);

  if (routeObj && routeObj.data) {
    if (pushState) {
      window.history.pushState({ route: norm }, '', norm === '/' ? '/' : norm);
    }

    if (routeObj.data.title) {
      document.title = routeObj.data.title;
    }
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc && routeObj.data.description) {
      metaDesc.setAttribute('content', routeObj.data.description);
    }

    if (mainEl && mainEl.innerHTML !== routeObj.data.content) {
      mainEl.innerHTML = routeObj.data.content;
      window.scrollTo({ top: 0, behavior: 'instant' });
    }

    updateActiveNav(norm);
    closeMobileDrawer();
    initPageInteractions(norm);
  } else {
    // Fallback 404
    if (pushState) {
      window.history.pushState({ route: norm }, '', norm);
    }
    if (mainEl) {
      mainEl.innerHTML = `
        <div class="container" style="padding: 100px 20px; text-align: center;">
          <span class="card-badge" style="background: rgba(239, 68, 68, 0.15); color: #f87171; border: 1px solid rgba(239, 68, 68, 0.3); margin-bottom: 16px;">
            Error 404
          </span>
          <h1 style="font-size: clamp(2rem, 4vw, 3rem); font-weight: 800; color: #fff; margin-bottom: 16px;">
            Page Not Found
          </h1>
          <p style="color: var(--text-secondary); max-width: 500px; margin: 0 auto 28px; line-height: 1.6;">
            The requested page does not exist or has moved. Return home to continue exploring Rauf Labs.
          </p>
          <a href="/" class="btn btn-primary">Go Back Home ↗</a>
        </div>
      `;
      window.scrollTo({ top: 0, behavior: 'instant' });
    }
    updateActiveNav('/404');
    closeMobileDrawer();
  }
}

function initRouter() {
  // Intercept all internal navigation clicks
  document.addEventListener('click', (e) => {
    const link = e.target.closest('a');
    if (!link) return;

    const href = link.getAttribute('href');
    if (!href) return;

    // Skip external links, new tabs, anchors, tel/mailto
    if (
      link.target === '_blank' ||
      href.startsWith('http://') ||
      href.startsWith('https://') ||
      href.startsWith('//') ||
      href.startsWith('mailto:') ||
      href.startsWith('tel:') ||
      (href.startsWith('#') && !href.startsWith('#/'))
    ) {
      return;
    }

    // Skip modified clicks (Ctrl, Cmd, Shift, Alt)
    if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

    e.preventDefault();
    navigateTo(href, true);
  });

  // Handle browser Back / Forward buttons
  window.addEventListener('popstate', (e) => {
    const path = window.location.pathname;
    navigateTo(path, false);
  });

  // Sticky navbar shadow on scroll
  const navbar = document.querySelector('.navbar');
  if (navbar) {
    window.addEventListener('scroll', () => {
      if (window.scrollY > 20) {
        navbar.classList.add('scrolled');
      } else {
        navbar.classList.remove('scrolled');
      }
    }, { passive: true });
  }

  // Handle initial page load
  const initialPath = window.location.pathname;
  const initialNorm = normalizeRoute(initialPath);

  // If path is deep link (e.g., /projects, /apis), render that route immediately
  if (initialNorm !== '/') {
    navigateTo(initialNorm, false);
  } else {
    updateActiveNav('/');
    initPageInteractions('/');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  initMobileDrawer();
  initBackToTop();
  initRouter();
  initGlobalSearch();
  initBookmarksDrawer();
  initAuthState();
});

// ==========================================================================
// 2. Mobile Drawer Toggle
// ==========================================================================
function initMobileDrawer() {
  const toggleBtn = document.querySelector('.mobile-toggle');
  const drawer = document.querySelector('.mobile-drawer');

  if (!toggleBtn || !drawer) return;

  toggleBtn.addEventListener('click', () => {
    const isOpen = drawer.classList.toggle('open');
    toggleBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
    toggleBtn.innerHTML = isOpen
      ? '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>'
      : '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>';
  });

  // Close drawer when any mobile link is clicked
  const mobileLinks = drawer.querySelectorAll('a');
  mobileLinks.forEach((link) => {
    link.addEventListener('click', () => {
      drawer.classList.remove('open');
      toggleBtn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>';
    });
  });
}

// ==========================================================================
// 3. Toast Notification System
// ==========================================================================
function showToast(message, type = 'info') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';

  const icon = type === 'success'
    ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>'
    : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>';

  toast.innerHTML = `${icon}<span>${escapeHtml(message)}</span>`;
  container.appendChild(toast);

  // Trigger animation
  requestAnimationFrame(() => {
    toast.classList.add('show');
  });

  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => {
      if (toast.parentNode) toast.parentNode.removeChild(toast);
    }, 300);
  }, 2800);
}

// ==========================================================================
// 4. Copy Code Snippet Buttons
// ==========================================================================
function initCopyButtons() {
  document.querySelectorAll('.code-copy-btn').forEach((btn) => {
    if (btn.dataset.bound === 'true') return;
    btn.dataset.bound = 'true';

    btn.addEventListener('click', async () => {
      const codeBox = btn.closest('.code-box') || btn.closest('.card') || btn.parentElement;
      const pre = codeBox.querySelector('pre') || codeBox.querySelector('code');
      if (!pre) return;

      const codeText = pre.innerText || pre.textContent || '';
      try {
        await navigator.clipboard.writeText(codeText.trim());
        const originalHtml = btn.innerHTML;
        btn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg> Copied!';
        showToast('Command copied to clipboard!', 'success');
        setTimeout(() => {
          btn.innerHTML = originalHtml;
        }, 2000);
      } catch (err) {
        showToast('Could not copy automatically.', 'info');
      }
    });
  });
}

// ==========================================================================
// 5. Back To Top Button
// ==========================================================================
function initBackToTop() {
  let backBtn = document.querySelector('.back-to-top');
  if (!backBtn) {
    backBtn = document.createElement('button');
    backBtn.className = 'back-to-top';
    backBtn.setAttribute('title', 'Back to top');
    backBtn.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="18 15 12 9 6 15"></polyline></svg>';
    document.body.appendChild(backBtn);
  }

  window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
      backBtn.classList.add('show');
    } else {
      backBtn.classList.remove('show');
    }
  }, { passive: true });

  backBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

// ==========================================================================
// 6. Skills Page Category Tabs
// ==========================================================================
function initSkillsTabs() {
  const tabs = document.querySelectorAll('.tab-btn[data-category]');
  if (!tabs.length) return;

  tabs.forEach((tab) => {
    if (tab.dataset.bound === 'true') return;
    tab.dataset.bound = 'true';

    tab.addEventListener('click', () => {
      tabs.forEach((t) => t.classList.remove('active'));
      tab.classList.add('active');

      const targetCategory = tab.getAttribute('data-category');
      const skillCards = document.querySelectorAll('.skill-bar-card');

      skillCards.forEach((card) => {
        const cat = card.getAttribute('data-skill-cat');
        if (targetCategory === 'all' || cat === targetCategory) {
          card.style.display = 'block';
        } else {
          card.style.display = 'none';
        }
      });
    });
  });
}

// ==========================================================================
// 7. Blog / Guide Modal Viewer
// ==========================================================================
const BLOG_GUIDES = {
  'termux-dev-setup': {
    title: 'Complete Mobile Development Environment in Termux',
    category: 'Termux Guide',
    date: 'February 2026',
    readTime: '6 min read',
    content: `
      <p>Termux transforms any Android device into a genuine Linux terminal environment. In this tutorial, you will configure a rock-solid developer setup with Node.js, Python 3, Git, and Neovim.</p>
      
      <h3>Step 1: Update Mirrors & Packages</h3>
      <p>Always run repository updates immediately after a fresh Termux install:</p>
      <div class="code-box">
        <div class="code-box-header"><span>BASH</span><button class="code-copy-btn">Copy</button></div>
        <pre>pkg update && pkg upgrade -y</pre>
      </div>

      <h3>Step 2: Grant Storage Permissions</h3>
      <p>This links your phone's internal storage directly to <code>~/storage/shared</code>:</p>
      <div class="code-box">
        <div class="code-box-header"><span>BASH</span><button class="code-copy-btn">Copy</button></div>
        <pre>termux-setup-storage</pre>
      </div>

      <h3>Step 3: Install Developer Essentials</h3>
      <p>Install Git, Python, Node.js, and curl with one package command:</p>
      <div class="code-box">
        <div class="code-box-header"><span>BASH</span><button class="code-copy-btn">Copy</button></div>
        <pre>pkg install git nodejs python curl neovim zsh -y</pre>
      </div>

      <h3>Pro Tip: Keep Sessions Alive</h3>
      <p>Android battery savers often kill background terminals. Run <code>termux-wake-lock</code> to keep server daemons active indefinitely.</p>
    `
  },
  'linux-permissions-guide': {
    title: 'Demystifying Linux File Permissions and Ownership',
    category: 'Linux Guide',
    date: 'January 2026',
    readTime: '8 min read',
    content: `
      <p>Linux security is built upon file permissions and user ownership. Mastering <code>chmod</code>, <code>chown</code>, and numeric octal notation is crucial for server safety.</p>

      <h3>Understanding the Permission Matrix</h3>
      <p>When you run <code>ls -l</code>, the first column shows 10 characters: <code>-rwxr-xr--</code>. Here is how they break down:</p>
      <ul>
        <li><strong>Read (r):</strong> Value 4</li>
        <li><strong>Write (w):</strong> Value 2</li>
        <li><strong>Execute (x):</strong> Value 1</li>
      </ul>

      <h3>Common Octal Patterns</h3>
      <div class="code-box">
        <div class="code-box-header"><span>BASH</span><button class="code-copy-btn">Copy</button></div>
        <pre># Read, write, execute for user; read & execute for group & others
chmod 755 script.sh

# Read & write for user only (recommended for SSH keys)
chmod 600 ~/.ssh/id_rsa

# Full directory ownership assignment
sudo chown -R $USER:$USER /var/www/html</pre>
      </div>
    `
  },
  'git-branching-strategy': {
    title: 'Modern Git Branching & Merge Conflict Resolution',
    category: 'Git & GitHub',
    date: 'January 2026',
    readTime: '5 min read',
    content: `
      <p>Merge conflicts occur when two branches modify the same lines in a file. Here is how to cleanly resolve conflicts without losing work.</p>

      <h3>Creating Clean Feature Branches</h3>
      <div class="code-box">
        <div class="code-box-header"><span>GIT</span><button class="code-copy-btn">Copy</button></div>
        <pre>git checkout -b feature/api-cache
git status
git add .
git commit -m "feat: implement memory cache for public APIs"
git push -u origin feature/api-cache</pre>
      </div>

      <h3>Safe Rebase Workflow</h3>
      <p>Keep your commit history linear before submitting a pull request:</p>
      <div class="code-box">
        <div class="code-box-header"><span>GIT</span><button class="code-copy-btn">Copy</button></div>
        <pre>git fetch origin
git rebase origin/main</pre>
      </div>
    `
  }
};

function initBlogModals() {
  const readButtons = document.querySelectorAll('.read-guide-btn');
  if (!readButtons.length) return;

  // Create reader modal overlay if not exists
  let modal = document.getElementById('guide-modal');
  if (!modal) {
    modal = document.createElement('div');
    modal.id = 'guide-modal';
    modal.className = 'guide-modal-overlay';
    modal.style.cssText = `
      display: none; position: fixed; inset: 0; background: rgba(5,8,17,0.88);
      backdrop-filter: blur(20px); z-index: 2500; align-items: center; justify-content: center; padding: 20px;
    `;
    modal.innerHTML = `
      <div class="guide-modal-box" style="
        background: #0d1222; border: 1px solid rgba(255,255,255,0.12); border-radius: 20px;
        max-width: 760px; width: 100%; max-height: 85vh; overflow-y: auto; padding: 32px; position: relative; box-shadow: 0 20px 60px rgba(0,0,0,0.8);
      ">
        <button id="close-modal-btn" style="
          position: absolute; top: 20px; right: 20px; background: rgba(255,255,255,0.06); border: 1px solid rgba(255,255,255,0.1);
          color: #fff; border-radius: 8px; width: 36px; height: 36px; cursor: pointer; display: flex; align-items: center; justify-content: center;
        ">✕</button>
        <div id="modal-content-target"></div>
      </div>
    `;
    document.body.appendChild(modal);

    modal.querySelector('#close-modal-btn').addEventListener('click', () => {
      modal.style.display = 'none';
    });

    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.style.display = 'none';
    });
  }

  readButtons.forEach((btn) => {
    if (btn.dataset.bound === 'true') return;
    btn.dataset.bound = 'true';

    btn.addEventListener('click', (e) => {
      e.preventDefault();
      const guideKey = btn.getAttribute('data-guide');
      const guide = BLOG_GUIDES[guideKey];
      if (!guide) return;

      const target = document.getElementById('modal-content-target');
      target.innerHTML = `
        <span class="card-badge cyan" style="margin-bottom: 12px;">${escapeHtml(guide.category)}</span>
        <h2 style="font-size: 1.8rem; font-weight: 800; color: #fff; margin-bottom: 8px;">${escapeHtml(guide.title)}</h2>
        <div style="font-size: 0.85rem; color: #94a3b8; margin-bottom: 24px;">By Rauf • ${guide.date} • ${guide.readTime}</div>
        <div class="guide-body" style="color: #cbd5e1; line-height: 1.7; font-size: 0.95rem;">${guide.content}</div>
      `;

      initCopyButtons();
      modal.style.display = 'flex';
    });
  });
}

// ==========================================================================
// 8. Contact Form Handler
// ==========================================================================
function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form || form.dataset.bound === 'true') return;
  form.dataset.bound = 'true';

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const nameInput = document.getElementById('name');
    const emailInput = document.getElementById('email');
    const subjectInput = document.getElementById('subject');
    const messageInput = document.getElementById('message');

    const name = nameInput ? nameInput.value.trim() : '';
    const email = emailInput ? emailInput.value.trim() : '';
    const subject = subjectInput ? subjectInput.value.trim() : '';
    const message = messageInput ? messageInput.value.trim() : '';

    if (!name || !email || !message) {
      showToast('Please fill out all required fields.', 'info');
      return;
    }

    // Interactive success confirmation
    showToast(`Thank you, ${name}! Your message has been sent. Rauf will respond soon.`, 'success');
    form.reset();
  });
}

// ==========================================================================
// 9. Public APIs Dynamic Explorer Engine (apis.html)
// ==========================================================================
const FALLBACK_PUBLIC_APIS = [
  {
    name: 'Open-Meteo',
    description: 'Free open-source weather API with solar, temperature, wind, and forecast models. No API key required.',
    category: 'Weather',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://open-meteo.com/'
  },
  {
    name: 'Open Library',
    description: 'Millions of book records, authors, ISBNs, book covers, and full-text search.',
    category: 'Books',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://openlibrary.org/developers/api'
  },
  {
    name: 'REST Countries',
    description: 'Comprehensive world countries directory with borders, currencies, capitals, flags and ISO codes.',
    category: 'Geocoding',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://restcountries.com/'
  },
  {
    name: 'PokeAPI',
    description: 'All the Pokémon data you will ever need: species, moves, abilities, types, sprites and evolutions.',
    category: 'Games & Comics',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://pokeapi.co/'
  },
  {
    name: 'JSONPlaceholder',
    description: 'Free fake REST API for prototyping frontend applications with fake posts, users, albums, and comments.',
    category: 'Development',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://jsonplaceholder.typicode.com/'
  },
  {
    name: 'Dog CEO',
    description: 'Crowdsourced collection of open-source dog images with breed categorization and random queries.',
    category: 'Animals',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://dog.ceo/dog-api/'
  },
  {
    name: 'Cat Facts',
    description: 'Random and daily cat facts powered by ninja endpoints.',
    category: 'Animals',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://catfact.ninja/'
  },
  {
    name: 'GitHub REST API',
    description: 'Interact with public repositories, user profiles, commits, releases, issues, and gists.',
    category: 'Development',
    auth: 'apiKey (optional)',
    https: true,
    cors: 'Yes',
    link: 'https://docs.github.com/en/rest'
  },
  {
    name: 'CoinGecko Public API',
    description: 'Real-time cryptocurrency prices, market capitalization, trading volumes, and exchange stats.',
    category: 'Cryptocurrency',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://www.coingecko.com/en/api'
  },
  {
    name: 'NASA Open APIs',
    description: 'Astronomy Picture of the Day (APOD), Mars Rover photos, asteroid tracking, and Earth imagery.',
    category: 'Science & Math',
    auth: 'apiKey',
    https: true,
    cors: 'Yes',
    link: 'https://api.nasa.gov/'
  },
  {
    name: 'Frankfurter',
    description: 'Free foreign exchange currency converter and historical currency rates published by the European Central Bank.',
    category: 'Finance',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://www.frankfurter.app/docs/'
  },
  {
    name: 'Wikipedia REST API',
    description: 'Read and search Wikipedia articles, summaries, page views, and featured daily contents.',
    category: 'Open Data',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://en.wikipedia.org/api/rest_v1/'
  },
  {
    name: 'Chuck Norris Jokes',
    description: 'Curated database of funny Chuck Norris jokes with category filtering and random retrieval.',
    category: 'Entertainment',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://api.chucknorris.io/'
  },
  {
    name: 'Advice Slip',
    description: 'Simple advice generator API giving pieces of advice for daily wisdom and motivation.',
    category: 'Personality',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://api.adviceslip.com/'
  },
  {
    name: 'Free Dictionary API',
    description: 'English dictionary API with phonetics, pronunciations, definitions, examples, and synonyms.',
    category: 'Dictionaries',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://dictionaryapi.dev/'
  },
  {
    name: 'IPify',
    description: 'A simple and resilient public IP address lookup API that returns IPv4 and IPv6 addresses.',
    category: 'Development',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://www.ipify.org/'
  },
  {
    name: 'ReqRes',
    description: 'A hosted REST-API ready to respond to AJAX requests with simulated users, status codes, and latency.',
    category: 'Development',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://reqres.in/'
  },
  {
    name: 'Sunrise and Sunset',
    description: 'Free REST API providing sunrise, sunset, dawn, and dusk times for any latitude and longitude.',
    category: 'Weather',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://sunrise-sunset.org/api'
  },
  {
    name: 'RandomUser.me',
    description: 'Free API for generating realistic random user placeholder data with photos, addresses, and bios.',
    category: 'Test Data',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://randomuser.me/'
  }
];

let allApisList = [];
let allApis = allApisList;
if (typeof window !== 'undefined') {
  window.allApis = allApisList;
  window.allApisList = allApisList;
}
let visibleApiCount = 48;
const GITHUB_README_URL = 'https://raw.githubusercontent.com/public-apis/public-apis/master/README.md';
const FALLBACK_API_URL = 'https://api.publicapis.org/entries';

function sanitizeText(str) {
  if (!str) return '';
  return str
    .replace(/<[^>]*>/g, '')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/\*([^*]+)\*/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1')
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

function extractSafeUrl(str) {
  if (!str) return '';
  const mdMatch = str.match(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/i);
  if (mdMatch && mdMatch[2]) return mdMatch[2].trim();
  const rawMatch = str.match(/(https?:\/\/[^\s)]+)/i);
  if (rawMatch && rawMatch[1]) return rawMatch[1].trim();
  return '';
}

function parseMarkdownReadme(markdown) {
  if (!markdown || typeof markdown !== 'string') return [];

  const lines = markdown.split(/\r?\n/);
  const out = [];
  const ignoreHeadings = new Set([
    'apis covered under apilayer suite!',
    'apilayer apis',
    'learn more about public apis',
    'index',
    'license',
    'try public apis for free',
    'table of contents',
    'contributing'
  ]);

  let currentCategory = '';
  const seenKeys = new Set();

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    const headingMatch = line.match(/^#{2,4}\s+(.+)$/);
    if (headingMatch) {
      const heading = headingMatch[1].replace(/^\d+\.\s*/, '').trim();
      if (!ignoreHeadings.has(heading.toLowerCase())) {
        currentCategory = heading;
      }
      continue;
    }

    if (!currentCategory) continue;

    const pipeCount = (line.match(/\|/g) || []).length;
    if (pipeCount >= 2) {
      let trimmed = line;
      if (trimmed.startsWith('|')) trimmed = trimmed.slice(1);
      if (trimmed.endsWith('|')) trimmed = trimmed.slice(0, -1);
      const cells = trimmed.split('|').map((c) => c.trim());

      if (cells.length < 3) continue;

      // Skip separator rows (:--- | :---)
      const isSep = cells.every((c) => /^:?-{2,}:?$/.test(c.trim()) || c.trim() === '');
      if (isSep) continue;

      const rawName = cells[0];
      const name = sanitizeText(rawName);
      if (
        !name ||
        /^api$/i.test(name) ||
        /^name$/i.test(name) ||
        name.includes('---') ||
        name.startsWith(':')
      ) {
        continue;
      }

      const rawDesc = cells[1];
      const description = sanitizeText(rawDesc);
      if (
        !description ||
        /^description$/i.test(description) ||
        description.includes('---') ||
        description.startsWith(':')
      ) {
        continue;
      }

      const rawAuth = cells[2] || 'No';
      let auth = sanitizeText(rawAuth);
      if (/^auth$/i.test(auth) || auth.includes('---')) continue;
      if (!auth || auth.toLowerCase() === 'no' || auth.toLowerCase() === 'none') {
        auth = 'No';
      }

      const rawHttps = cells[3] || 'No';
      const httpsStr = sanitizeText(rawHttps).toLowerCase();
      const https = httpsStr === 'yes' || httpsStr === 'true';

      const link = extractSafeUrl(rawName) || (rawDesc ? extractSafeUrl(rawDesc) : '');

      const key = `${name.toLowerCase()}:::${currentCategory.toLowerCase()}`;
      if (seenKeys.has(key)) continue;
      seenKeys.add(key);

      out.push({
        name,
        description,
        category: currentCategory,
        auth,
        https,
        link: link || '#'
      });
    }
  }

  out.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));
  return out;
}

async function fetchPublicApis(isManualRefresh = false) {
  const statusIndicator = document.getElementById('api-status-indicator');
  const statusText = document.getElementById('api-status-text');
  const refreshBtn = document.getElementById('refresh-apis-btn');

  if (statusIndicator) statusIndicator.className = 'api-status-indicator loading';
  if (statusText) statusText.textContent = 'Refreshing API directory…';
  if (refreshBtn) refreshBtn.classList.add('loading');

  let loadedApis = [];
  let isLive = false;

  try {
    // 1. Primary: GitHub README Markdown with cache-busting
    const cacheBuster = `?t=${Date.now()}`;
    const res = await fetch(GITHUB_README_URL + cacheBuster, {
      cache: 'no-store',
      headers: { Accept: 'text/plain, text/markdown, */*' }
    });

    if (res.ok) {
      const text = await res.text();
      const parsed = parseMarkdownReadme(text);
      if (parsed.length > 0) {
        loadedApis = parsed;
        isLive = true;
      }
    }
  } catch (err) {
    console.warn('GitHub README fetch failed:', err);
  }

  // 2. Fallback: JSON endpoint
  if (!loadedApis.length) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 5000);
      const res2 = await fetch(FALLBACK_API_URL, {
        cache: 'no-store',
        signal: controller.signal
      });
      clearTimeout(timeout);

      if (res2.ok) {
        const data = await res2.json();
        if (data && Array.isArray(data.entries) && data.entries.length > 0) {
          loadedApis = data.entries.map((x) => ({
            name: sanitizeText(x.API || x.name),
            description: sanitizeText(x.Description || x.description),
            category: sanitizeText(x.Category || x.category || 'General'),
            auth: sanitizeText(x.Auth) || 'No',
            https: x.HTTPS === true || x.HTTPS === 'Yes',
            link: extractSafeUrl(x.Link || x.link) || '#'
          })).filter((x) => x.name && !x.name.includes('---'));
          isLive = true;
        }
      }
    } catch (err2) {
      console.warn('Fallback JSON API failed:', err2);
    }
  }

  // 3. Fallback: Curated Built-in Catalog
  if (!loadedApis.length) {
    loadedApis = FALLBACK_PUBLIC_APIS;
    isLive = false;
  }

  loadedApis.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));
  allApisList = loadedApis;
  allApis = loadedApis;
  if (typeof window !== 'undefined') {
    window.allApis = loadedApis;
    window.allApisList = loadedApis;
  }

  // Update Status
  if (statusIndicator) statusIndicator.className = 'api-status-indicator';
  if (statusText) {
    if (isLive) {
      statusText.textContent = `Loaded ${loadedApis.length.toLocaleString()} APIs from the Public APIs directory.`;
    } else {
      statusText.textContent = `Live directory unavailable — showing cached/fallback data (${loadedApis.length} APIs).`;
    }
  }

  if (refreshBtn) refreshBtn.classList.remove('loading');

  // Populate categories dropdown
  populateCategoryDropdown(loadedApis);

  // Render cards
  visibleApiCount = 48;
  renderApiCards();

  if (isManualRefresh) {
    showToast(`Directory refreshed! Loaded ${loadedApis.length.toLocaleString()} APIs.`, 'success');
  }
}

function populateCategoryDropdown(apis) {
  const select = document.getElementById('api-category-select');
  if (!select) return;

  const currentVal = select.value;
  const categories = Array.from(new Set(apis.map((a) => a.category).filter(Boolean))).sort();

  select.innerHTML = '<option value="">All Categories</option>';
  categories.forEach((cat) => {
    const opt = document.createElement('option');
    opt.value = cat;
    opt.textContent = cat;
    select.appendChild(opt);
  });

  if (categories.includes(currentVal)) {
    select.value = currentVal;
  }
}

function populateCategories(apis = allApisList) {
  populateCategoryDropdown(apis);
}

function renderApiCards() {
  const container = document.getElementById('api-directory-container');
  if (!container) return;

  const searchInput = document.getElementById('api-search-input');
  const categorySelect = document.getElementById('api-category-select');

  const query = searchInput ? searchInput.value.toLowerCase().trim() : '';
  const selectedCat = categorySelect ? categorySelect.value : '';

  const filtered = allApisList.filter((api) => {
    if (selectedCat && api.category !== selectedCat) return false;
    if (query) {
      const matchName = api.name.toLowerCase().includes(query);
      const matchDesc = api.description.toLowerCase().includes(query);
      const matchCat = (api.category || '').toLowerCase().includes(query);
      const matchAuth = (api.auth || '').toLowerCase().includes(query);
      return matchName || matchDesc || matchCat || matchAuth;
    }
    return true;
  });

  if (filtered.length === 0) {
    container.innerHTML = `
      <div style="grid-column: 1 / -1; text-align: center; padding: 60px 20px; background: rgba(14,21,37,0.5); border: 1px dashed rgba(255,255,255,0.1); border-radius: 16px;">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="1.5" style="margin: 0 auto 16px;"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
        <h3 style="font-size: 1.25rem; font-weight: 700; color: #fff; margin-bottom: 8px;">No APIs found. Try another search.</h3>
        <p style="color: #94a3b8; font-size: 0.9rem; max-width: 440px; margin: 0 auto 16px;">We couldn't find any API matching your filters. Try resetting the search or category.</p>
        <button id="reset-filter-btn" class="btn btn-secondary btn-sm">Reset Filters</button>
      </div>
    `;
    const resetBtn = document.getElementById('reset-filter-btn');
    if (resetBtn) {
      resetBtn.addEventListener('click', () => {
        if (searchInput) searchInput.value = '';
        if (categorySelect) categorySelect.value = '';
        renderApiCards();
      });
    }
    return;
  }

  const toShow = filtered.slice(0, visibleApiCount);
  let html = '';

  toShow.forEach((api) => {
    const hasValidLink = Boolean(api.link) && api.link !== '#' && /^https?:\/\//i.test(api.link);
    const authText = api.auth && api.auth !== 'No' ? api.auth : 'No';

    html += `
      <article class="card api-card">
        <div class="card-top">
          <span class="card-badge cyan">${escapeHtml(api.category || 'General')}</span>
          <span style="font-size: 0.75rem; display: flex; align-items: center; gap: 4px; color: ${api.https ? '#34d399' : '#f59e0b'}; font-weight: 600;">
            ${api.https ? '✓ HTTPS' : '✕ HTTP'}
          </span>
        </div>
        <h3 class="card-title">${escapeHtml(api.name)}</h3>
        <p class="card-desc">${escapeHtml(api.description)}</p>
        <div class="card-footer">
          <span style="font-size: 0.75rem; color: #94a3b8; background: rgba(255,255,255,0.04); padding: 4px 8px; border-radius: 6px; border: 1px solid rgba(255,255,255,0.06);">
            Auth: ${escapeHtml(authText)}
          </span>
          ${
            hasValidLink
              ? `<a href="${escapeHtml(api.link)}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary btn-sm" style="color: #38bdf8; border-color: rgba(56,189,248,0.3);">Official Docs ↗</a>`
              : `<span style="font-size: 0.75rem; color: #64748b;">No link listed</span>`
          }
        </div>
      </article>
    `;
  });

  if (filtered.length > visibleApiCount) {
    html += `
      <div style="grid-column: 1 / -1; text-align: center; margin-top: 24px;">
        <button id="load-more-apis-btn" class="btn btn-primary">
          Load More APIs (${Math.min(48, filtered.length - visibleApiCount)} more)
        </button>
        <p style="font-size: 0.8rem; color: #64748b; margin-top: 8px;">
          Showing ${Math.min(visibleApiCount, filtered.length).toLocaleString()} of ${filtered.length.toLocaleString()} matching APIs
        </p>
      </div>
    `;
  }

  container.innerHTML = html;

  const loadMoreBtn = document.getElementById('load-more-apis-btn');
  if (loadMoreBtn) {
    loadMoreBtn.addEventListener('click', () => {
      visibleApiCount += 48;
      renderApiCards();
    });
  }
}

function initApiDirectory() {
  const container = document.getElementById('api-directory-container');
  if (!container) return;

  const searchInput = document.getElementById('api-search-input');
  const categorySelect = document.getElementById('api-category-select');
  const refreshBtn = document.getElementById('refresh-apis-btn');

  if (searchInput && searchInput.dataset.bound !== 'true') {
    searchInput.dataset.bound = 'true';
    searchInput.addEventListener('input', () => {
      visibleApiCount = 48;
      renderApiCards();
    });
  }

  if (categorySelect && categorySelect.dataset.bound !== 'true') {
    categorySelect.dataset.bound = 'true';
    categorySelect.addEventListener('change', () => {
      visibleApiCount = 48;
      renderApiCards();
    });
  }

  if (refreshBtn && refreshBtn.dataset.bound !== 'true') {
    refreshBtn.dataset.bound = 'true';
    refreshBtn.addEventListener('click', () => {
      fetchPublicApis(true);
    });
  }

  // If we already have APIs in memory, render immediately; otherwise fetch
  if (allApisList && allApisList.length > 0) {
    populateCategoryDropdown(allApisList);
    renderApiCards();
  } else {
    fetchPublicApis(false);
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

// ==========================================================================
// 7. Global Search Modal Engine (Cmd+K / Search Button)
// ==========================================================================

const SEARCH_INDEX = [
  { title: "Home — Rauf Labs Developer Platform", route: "/", category: "Platform", tags: "developer portfolio terminal kashmir tools overview" },
  { title: "Developer Hub — Command Center", route: "/developer", category: "Hub", tags: "developer tracks android termux linux powershell bash git" },
  { title: "Android Hub — Deep OS & Architecture", route: "/android", category: "Guide", tags: "android apk adb rooting recovery zygote jni frida smali bootloader selinux kernel" },
  { title: "Termux Android — Mobile Terminal Masterclass", route: "/termux", category: "Guide", tags: "termux android pkg mobile python nodejs ssh wake lock debian proot" },
  { title: "Linux Systems — Administration & Permissions", route: "/linux", category: "Guide", tags: "linux chmod chown permissions systemd htop grep find ssh security users" },
  { title: "PowerShell — Automation & Object Pipelines", route: "/powershell", category: "Guide", tags: "powershell windows cmdlets automation scripts wmi registry pipelines" },
  { title: "Bash Scripting — Shell Mastery & Automation", route: "/bash", category: "Guide", tags: "bash shell scripting sed awk regex loops cron automation functions" },
  { title: "Git & GitHub — Branching & Conflict Resolution", route: "/git", category: "Guide", tags: "git github rebase merge conflict pull request cherry-pick stash branches" },
  { title: "Programming — Modern TypeScript & Web Systems", route: "/programming", category: "Guide", tags: "programming typescript javascript python rest api async await web dom" },
  { title: "Developer Roadmap — 10 Stages to Senior", route: "/roadmap", category: "Roadmap", tags: "roadmap career junior senior stages software engineer architecture milestones" },
  { title: "Projects Directory — 20+ Production Applications", route: "/projects", category: "Projects", tags: "projects portfolio apps code terminal cli apis live tools" },
  { title: "Public APIs Live Explorer (1,700+ APIs)", route: "/apis", category: "APIs", tags: "apis public rest free endpoints weather crypto news finance directory" },
  { title: "Open Source CLI Tools & Terminal Utilities", route: "/opensource", category: "Tools", tags: "opensource cli fzf ripgrep bat tmux neovim starship terminal tools" },
  { title: "Developer Utilities — 8 Browser DevTools", route: "/tools", category: "Tools", tags: "utilities devtools json base64 hash sha256 regex chmod uuid qr code" },
  { title: "JSON Formatter & Validator", route: "/tools#tool-json", category: "Utility", tags: "json format minify validate prettify parse lint" },
  { title: "Base64 Encoder & Decoder", route: "/tools#tool-base64", category: "Utility", tags: "base64 encode decode utf8 string binary" },
  { title: "Cryptographic Hash (SHA-256 / SHA-1)", route: "/tools#tool-hash", category: "Utility", tags: "hash sha256 sha1 checksum crypto digest" },
  { title: "Regex Pattern Tester & Matcher", route: "/tools#tool-regex", category: "Utility", tags: "regex regular expression pattern match test flags groups" },
  { title: "Linux Chmod Calculator (Octal & Symbolic)", route: "/tools#tool-chmod", category: "Utility", tags: "chmod 755 644 permissions rwx octal calculator" },
  { title: "UUID v4 Cryptographic Generator", route: "/tools#tool-uuid", category: "Utility", tags: "uuid guid random v4 generator identifier" },
  { title: "QR Code Instant Generator", route: "/tools#tool-qr", category: "Utility", tags: "qr code generator barcode url text mobile" },
  { title: "Official QR Code & Quick Connect", route: "/qr", category: "Connect", tags: "qr code scan mobile connect share download svg png" },
  { title: "Developer PDF Library & Books", route: "/pdfs", category: "Resources", tags: "pdf reader books guides documentation downloads" },
  { title: "Rauf Labs Academy — 24+ Developer & AI Courses", route: "/courses", category: "Academy", tags: "courses academy gemini api python termux linux docker git rust bash cybersecurity kubernetes sql" },
  { title: "Course: Gemini API & Multimodal AI Engineering", route: "/courses?id=gemini-api-mastery", category: "Academy", tags: "gemini ai llm api python rest function calling multimodal prompts vision" },
  { title: "Course: Termux Mobile Linux Masterclass", route: "/courses?id=termux-mobile-masterclass", category: "Academy", tags: "termux android linux mobile cli python bash server pkg" },
  { title: "Course: Defensive Shell Scripting & Automation", route: "/courses?id=bash-automation-mastery", category: "Academy", tags: "bash shell scripting sed awk automation cron pipefail" },
  { title: "Course: Linux Kernel, Systemd & Networking", route: "/courses?id=linux-systems-administration", category: "Academy", tags: "linux systemd permissions networking chmod chown ssh iptables" },
  { title: "Course: Practical Cybersecurity & Ethical Hacking", route: "/courses?id=ethical-hacking-fundamentals", category: "Academy", tags: "cybersecurity ethical hacking security nmap wireshark owasp cryptography" },
  { title: "Course: Modern Python 3 Systems & Automation", route: "/courses?id=python-systems-automation", category: "Academy", tags: "python automation scripting api async backend sysadmin" },
  { title: "Resources Hub — Cheat Sheets & Documentation", route: "/resources", category: "Resources", tags: "resources cheat sheets docs books repositories guides downloads" },
  { title: "Creator Hub — Media & Trending Projects", route: "/creator", category: "Creator", tags: "creator youtube instagram media trending videos community" },
  { title: "Rauf Labs AI — Developer Copilot & BYOK", route: "/ai", category: "AI", tags: "ai copilot gemini byok assistant terminal code debug prompt" },
  { title: "Developer Account & Bookmarks", route: "/login", category: "Account", tags: "login signup auth account bookmarks profile preferences" },
  { title: "About Rauf — Background & Credentials", route: "/about", category: "Profile", tags: "about rauf bio btech education kashmir software engineer" },
  { title: "Contact Rauf — Direct Inquiries", route: "/contact", category: "Contact", tags: "contact email hire collaborate message project support" }
];

let searchModalOverlay = null;

function ensureSearchModal() {
  if (searchModalOverlay) return searchModalOverlay;

  searchModalOverlay = document.createElement('div');
  searchModalOverlay.id = 'search-modal-overlay';
  searchModalOverlay.className = 'search-modal-overlay';
  searchModalOverlay.setAttribute('role', 'dialog');
  searchModalOverlay.setAttribute('aria-modal', 'true');
  searchModalOverlay.innerHTML = `
    <div class="search-modal" id="search-modal-box">
      <div class="search-modal-header">
        <div class="search-input-wrapper">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
          <input type="text" id="global-search-input" class="search-modal-input" placeholder="Search guides, tools, tracks, APIs, commands..." autocomplete="off" spellcheck="false">
        </div>
        <button class="search-modal-close" id="search-modal-close-btn" aria-label="Close search">✕</button>
      </div>
      <div class="search-modal-quick">
        <span class="search-quick-label">Quick:</span>
        <button class="search-quick-chip" data-q="courses">Academy</button>
        <button class="search-quick-chip" data-q="android">Android</button>
        <button class="search-quick-chip" data-q="termux">Termux</button>
        <button class="search-quick-chip" data-q="chmod">chmod</button>
        <button class="search-quick-chip" data-q="git">Git</button>
        <button class="search-quick-chip" data-q="apis">APIs</button>
        <button class="search-quick-chip" data-q="tools">Tools</button>
        <button class="search-quick-chip" data-q="ai">AI Copilot</button>
      </div>
      <div class="search-results-list" id="search-results-list"></div>
      <div class="search-modal-footer">
        <span><kbd>↑</kbd> <kbd>↓</kbd> to navigate</span>
        <span><kbd>ESC</kbd> to close</span>
        <span><kbd>↵</kbd> to select</span>
      </div>
    </div>
  `;
  document.body.appendChild(searchModalOverlay);

  const closeBtn = searchModalOverlay.querySelector('#search-modal-close-btn');
  closeBtn.addEventListener('click', closeSearchModal);

  searchModalOverlay.addEventListener('click', (e) => {
    if (e.target === searchModalOverlay) {
      closeSearchModal();
    }
  });

  const input = searchModalOverlay.querySelector('#global-search-input');
  input.addEventListener('input', () => {
    renderSearchResults(input.value.trim());
  });

  input.addEventListener('keydown', (e) => {
    const items = searchModalOverlay.querySelectorAll('.search-result-item');
    let activeIndex = Array.from(items).findIndex(el => el.classList.contains('active'));

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (items.length === 0) return;
      if (activeIndex >= 0) items[activeIndex].classList.remove('active');
      activeIndex = (activeIndex + 1) % items.length;
      items[activeIndex].classList.add('active');
      items[activeIndex].scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (items.length === 0) return;
      if (activeIndex >= 0) items[activeIndex].classList.remove('active');
      activeIndex = (activeIndex - 1 + items.length) % items.length;
      items[activeIndex].classList.add('active');
      items[activeIndex].scrollIntoView({ block: 'nearest' });
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (activeIndex >= 0 && items[activeIndex]) {
        const route = items[activeIndex].getAttribute('data-route');
        if (route) {
          closeSearchModal();
          navigateTo(route, true);
        }
      } else if (items.length > 0) {
        const route = items[0].getAttribute('data-route');
        if (route) {
          closeSearchModal();
          navigateTo(route, true);
        }
      }
    } else if (e.key === 'Escape') {
      closeSearchModal();
    }
  });

  const quickChips = searchModalOverlay.querySelectorAll('.search-quick-chip');
  quickChips.forEach((chip) => {
    chip.addEventListener('click', () => {
      const q = chip.getAttribute('data-q') || '';
      input.value = q;
      renderSearchResults(q);
      input.focus();
    });
  });

  return searchModalOverlay;
}

function openSearchModal(initialQuery = '') {
  const modal = ensureSearchModal();
  modal.classList.add('open');
  document.body.style.overflow = 'hidden';

  const input = modal.querySelector('#global-search-input');
  if (input) {
    input.value = initialQuery;
    renderSearchResults(initialQuery);
    setTimeout(() => input.focus(), 50);
  }
}

function closeSearchModal() {
  if (searchModalOverlay) {
    searchModalOverlay.classList.remove('open');
    document.body.style.overflow = '';
  }
}

function renderSearchResults(query) {
  const container = document.getElementById('search-results-list');
  if (!container) return;

  const q = query.toLowerCase();
  let matches = SEARCH_INDEX;
  if (q.length > 0) {
    matches = SEARCH_INDEX.filter(item => {
      return item.title.toLowerCase().includes(q) ||
        item.category.toLowerCase().includes(q) ||
        item.tags.toLowerCase().includes(q) ||
        item.route.toLowerCase().includes(q);
    });
  }

  if (matches.length === 0) {
    container.innerHTML = `
      <div style="padding: 36px 20px; text-align: center; color: var(--text-muted);">
        <p style="font-size: 1rem; color: #fff; margin-bottom: 6px;">No matching guides or tools found</p>
        <p style="font-size: 0.85rem;">Try searching for "Android", "chmod", "Termux", "Git", or "APIs"</p>
      </div>
    `;
    return;
  }

  let html = '';
  matches.forEach((item, index) => {
    const isFirst = index === 0 ? 'active' : '';
    html += `
      <div class="search-result-item ${isFirst}" data-route="${item.route}">
        <div style="display: flex; align-items: center; justify-content: space-between; gap: 12px;">
          <div style="font-weight: 600; color: #fff; font-size: 0.95rem;">${escapeHtml(item.title)}</div>
          <span class="card-badge" style="font-size: 0.7rem; padding: 2px 8px; flex-shrink: 0;">${escapeHtml(item.category)}</span>
        </div>
        <div style="display: flex; align-items: center; gap: 8px; margin-top: 4px; font-size: 0.75rem; color: var(--text-muted);">
          <span style="font-family: var(--font-mono); color: var(--accent-cyan);">${escapeHtml(item.route)}</span>
          <span>•</span>
          <span style="overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${escapeHtml(item.tags)}</span>
        </div>
      </div>
    `;
  });

  container.innerHTML = html;

  const resultEls = container.querySelectorAll('.search-result-item');
  resultEls.forEach((el) => {
    el.addEventListener('click', () => {
      const route = el.getAttribute('data-route');
      if (route) {
        closeSearchModal();
        navigateTo(route, true);
      }
    });
  });
}

function initGlobalSearch() {
  // Delegate click for search button in navbar
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('#nav-search-btn');
    if (btn) {
      e.preventDefault();
      openSearchModal();
    }
  });

  // Global keyboard shortcut: Cmd+K / Ctrl+K or /
  window.addEventListener('keydown', (e) => {
    if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
      e.preventDefault();
      if (searchModalOverlay && searchModalOverlay.classList.contains('open')) {
        closeSearchModal();
      } else {
        openSearchModal();
      }
    } else if (e.key === '/' && !['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) {
      e.preventDefault();
      openSearchModal();
    }
  });
}

// ==========================================================================
// 8. Bookmarks Drawer System
// ==========================================================================

const BOOKMARKS_STORAGE_KEY = 'rauf_bookmarks';
let bookmarksDrawerOverlay = null;

function getBookmarks() {
  try {
    const raw = localStorage.getItem(BOOKMARKS_STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (err) {
    console.error('Failed to load bookmarks', err);
    return [];
  }
}

function saveBookmarks(list) {
  try {
    localStorage.setItem(BOOKMARKS_STORAGE_KEY, JSON.stringify(list));
    updateBookmarkIndicators();
  } catch (err) {
    console.error('Failed to save bookmarks', err);
  }
}

function toggleBookmark(item) {
  const list = getBookmarks();
  const index = list.findIndex(b => b.route === item.route);

  if (index >= 0) {
    list.splice(index, 1);
    saveBookmarks(list);
    showToast('Removed from bookmarks');
    return false;
  } else {
    list.unshift({
      title: item.title || 'Untitled',
      route: item.route,
      category: item.category || 'Learning Track',
      date: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })
    });
    saveBookmarks(list);
    showToast('Saved to your bookmarks! ★');
    return true;
  }
}

function isBookmarked(route) {
  const list = getBookmarks();
  return list.some(b => b.route === route);
}

function updateBookmarkIndicators() {
  const list = getBookmarks();
  const count = list.length;

  const countBadge = document.getElementById('nav-bookmarks-count');
  if (countBadge) {
    countBadge.textContent = count;
    countBadge.style.display = count > 0 ? 'inline-flex' : 'none';
  }

  const drawerBadge = document.getElementById('drawer-bookmarks-badge');
  if (drawerBadge) {
    drawerBadge.textContent = count;
  }

  const profileCount = document.getElementById('profile-bookmarks-count');
  if (profileCount) {
    profileCount.textContent = count;
  }

  // Update button active state on page
  const bookmarkButtons = document.querySelectorAll('.btn-bookmark');
  bookmarkButtons.forEach(btn => {
    const targetRoute = btn.getAttribute('data-route') || window.location.pathname;
    if (isBookmarked(targetRoute)) {
      btn.classList.add('bookmarked');
      btn.innerHTML = '★ Bookmarked';
    } else {
      btn.classList.remove('bookmarked');
      btn.innerHTML = '☆ Bookmark';
    }
  });

  renderBookmarksInDrawer();
}

function ensureBookmarksDrawer() {
  if (bookmarksDrawerOverlay) return bookmarksDrawerOverlay;

  bookmarksDrawerOverlay = document.createElement('div');
  bookmarksDrawerOverlay.id = 'bookmarks-drawer-overlay';
  bookmarksDrawerOverlay.className = 'bookmarks-drawer-overlay';
  bookmarksDrawerOverlay.innerHTML = `
    <div class="bookmarks-drawer" id="bookmarks-drawer">
      <div class="bookmarks-drawer-header">
        <div style="display: flex; align-items: center; gap: 8px;">
          <span style="color: var(--accent-purple-light); font-size: 1.15rem;">★</span>
          <h3 style="font-size: 1.1rem; font-weight: 700; color: #fff; margin: 0;">My Bookmarks</h3>
          <span id="drawer-bookmarks-badge" class="badge" style="background: rgba(139,92,246,0.2); color: var(--accent-purple-light); font-size: 0.75rem; padding: 2px 8px; border-radius: 9999px;">0</span>
        </div>
        <div style="display: flex; align-items: center; gap: 8px;">
          <button id="clear-bookmarks-btn" class="btn btn-secondary btn-sm" style="font-size: 0.75rem; padding: 4px 8px;">Clear All</button>
          <button id="bookmarks-drawer-close" class="close-btn" style="background: transparent; border: none; color: var(--text-secondary); cursor: pointer; font-size: 1.2rem;">✕</button>
        </div>
      </div>
      <div id="bookmarks-list-container" class="bookmarks-list" style="padding: 16px; overflow-y: auto; flex: 1;"></div>
    </div>
  `;
  document.body.appendChild(bookmarksDrawerOverlay);

  const closeBtn = bookmarksDrawerOverlay.querySelector('#bookmarks-drawer-close');
  closeBtn.addEventListener('click', closeBookmarksDrawer);

  bookmarksDrawerOverlay.addEventListener('click', (e) => {
    if (e.target === bookmarksDrawerOverlay) {
      closeBookmarksDrawer();
    }
  });

  const clearBtn = bookmarksDrawerOverlay.querySelector('#clear-bookmarks-btn');
  clearBtn.addEventListener('click', () => {
    if (confirm('Clear all saved bookmarks?')) {
      saveBookmarks([]);
      showToast('Bookmarks cleared');
    }
  });

  return bookmarksDrawerOverlay;
}

function openBookmarksDrawer() {
  const drawer = ensureBookmarksDrawer();
  drawer.classList.add('open');
  document.body.style.overflow = 'hidden';
  updateBookmarkIndicators();
}

function closeBookmarksDrawer() {
  if (bookmarksDrawerOverlay) {
    bookmarksDrawerOverlay.classList.remove('open');
    document.body.style.overflow = '';
  }
}

function renderBookmarksInDrawer() {
  const container = document.getElementById('bookmarks-list-container');
  if (!container) return;

  const list = getBookmarks();
  if (list.length === 0) {
    container.innerHTML = `
      <div style="padding: 40px 16px; text-align: center; color: var(--text-muted);">
        <div style="font-size: 2.5rem; margin-bottom: 12px; opacity: 0.6;">★</div>
        <h4 style="font-size: 1rem; color: #fff; margin-bottom: 6px;">No Bookmarks Saved Yet</h4>
        <p style="font-size: 0.85rem; line-height: 1.5; max-width: 260px; margin: 0 auto;">
          Click the "☆ Bookmark" button on any track or guide to save it here for quick access.
        </p>
      </div>
    `;
    return;
  }

  let html = '';
  list.forEach((item) => {
    html += `
      <div class="bookmark-card" style="background: rgba(255,255,255,0.02); border: 1px solid var(--border-subtle); border-radius: var(--radius-md); padding: 14px; margin-bottom: 10px; display: flex; align-items: center; justify-content: space-between; gap: 12px; transition: border-color 0.2s;">
        <div style="flex: 1; cursor: pointer;" class="bookmark-click-target" data-route="${item.route}">
          <div style="font-size: 0.9rem; font-weight: 600; color: #fff; margin-bottom: 2px;">${escapeHtml(item.title)}</div>
          <div style="display: flex; align-items: center; gap: 6px; font-size: 0.75rem; color: var(--text-muted);">
            <span style="color: var(--accent-cyan); font-family: var(--font-mono);">${escapeHtml(item.route)}</span>
            <span>•</span>
            <span>${escapeHtml(item.date)}</span>
          </div>
        </div>
        <button class="bookmark-remove-btn" data-route="${item.route}" title="Remove bookmark" style="background: transparent; border: none; color: var(--text-muted); cursor: pointer; padding: 4px 6px; font-size: 1rem; border-radius: 4px;">✕</button>
      </div>
    `;
  });

  container.innerHTML = html;

  container.querySelectorAll('.bookmark-click-target').forEach(el => {
    el.addEventListener('click', () => {
      const route = el.getAttribute('data-route');
      if (route) {
        closeBookmarksDrawer();
        navigateTo(route, true);
      }
    });
  });

  container.querySelectorAll('.bookmark-remove-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const route = btn.getAttribute('data-route');
      if (route) {
        toggleBookmark({ route });
      }
    });
  });
}

function initBookmarksButtons() {
  const bookmarkButtons = document.querySelectorAll('.btn-bookmark');
  bookmarkButtons.forEach(btn => {
    const route = btn.getAttribute('data-route') || window.location.pathname;
    const title = btn.getAttribute('data-title') || document.title.split('—')[0].trim();
    const category = btn.getAttribute('data-category') || 'Guide';

    if (isBookmarked(route)) {
      btn.classList.add('bookmarked');
      btn.innerHTML = '★ Bookmarked';
    } else {
      btn.classList.remove('bookmarked');
      btn.innerHTML = '☆ Bookmark';
    }

    btn.onclick = (e) => {
      e.preventDefault();
      toggleBookmark({ route, title, category });
    };
  });
}

function initBookmarksDrawer() {
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('#nav-bookmarks-btn');
    if (btn) {
      e.preventDefault();
      openBookmarksDrawer();
    }
  });

  updateBookmarkIndicators();
}

// ==========================================================================
// 9. Developer Utilities Engine (/tools)
// ==========================================================================

function initDevTools() {
  // 1. JSON Formatter
  const jsonInput = document.getElementById('json-input');
  const jsonOutput = document.getElementById('json-output');
  const jsonStatus = document.getElementById('json-status');
  const jsonFormatBtn = document.getElementById('json-format-btn');
  const jsonMinifyBtn = document.getElementById('json-minify-btn');
  const jsonClearBtn = document.getElementById('json-clear-btn');
  const jsonCopyBtn = document.getElementById('json-copy-btn');

  if (jsonInput && jsonOutput) {
    const validateAndProcess = (minify = false) => {
      const raw = jsonInput.value.trim();
      if (!raw) {
        jsonOutput.value = '';
        if (jsonStatus) jsonStatus.textContent = '';
        return;
      }
      try {
        const parsed = JSON.parse(raw);
        jsonOutput.value = minify ? JSON.stringify(parsed) : JSON.stringify(parsed, null, 2);
        if (jsonStatus) {
          jsonStatus.textContent = '✓ Valid JSON';
          jsonStatus.style.color = '#34d399';
        }
      } catch (err) {
        if (jsonStatus) {
          jsonStatus.textContent = `⚠ ${err.message}`;
          jsonStatus.style.color = '#f87171';
        }
      }
    };

    if (jsonFormatBtn) jsonFormatBtn.onclick = () => validateAndProcess(false);
    if (jsonMinifyBtn) jsonMinifyBtn.onclick = () => validateAndProcess(true);
    if (jsonClearBtn) {
      jsonClearBtn.onclick = () => {
        jsonInput.value = '';
        jsonOutput.value = '';
        if (jsonStatus) jsonStatus.textContent = '';
      };
    }
    if (jsonCopyBtn) {
      jsonCopyBtn.onclick = () => {
        if (!jsonOutput.value) return;
        navigator.clipboard.writeText(jsonOutput.value).then(() => showToast('Formatted JSON copied!'));
      };
    }
  }

  // 2. Base64 Encoder / Decoder
  const b64Input = document.getElementById('b64-input');
  const b64Output = document.getElementById('b64-output');
  const b64EncodeBtn = document.getElementById('b64-encode-btn');
  const b64DecodeBtn = document.getElementById('b64-decode-btn');
  const b64CopyBtn = document.getElementById('b64-copy-btn');

  if (b64Input && b64Output) {
    if (b64EncodeBtn) {
      b64EncodeBtn.onclick = () => {
        try {
          const encoded = btoa(unescape(encodeURIComponent(b64Input.value)));
          b64Output.value = encoded;
        } catch (e) {
          b64Output.value = 'Error: Failed to encode string';
        }
      };
    }
    if (b64DecodeBtn) {
      b64DecodeBtn.onclick = () => {
        try {
          const decoded = decodeURIComponent(escape(atob(b64Input.value.trim())));
          b64Output.value = decoded;
        } catch (e) {
          b64Output.value = 'Error: Invalid Base64 string';
        }
      };
    }
    if (b64CopyBtn) {
      b64CopyBtn.onclick = () => {
        if (!b64Output.value) return;
        navigator.clipboard.writeText(b64Output.value).then(() => showToast('Base64 result copied!'));
      };
    }
  }

  // 3. URL Encoder / Decoder
  const urlInput = document.getElementById('url-input');
  const urlOutput = document.getElementById('url-output');
  const urlEncodeBtn = document.getElementById('url-encode-btn');
  const urlDecodeBtn = document.getElementById('url-decode-btn');
  const urlCopyBtn = document.getElementById('url-copy-btn');

  if (urlInput && urlOutput) {
    if (urlEncodeBtn) {
      urlEncodeBtn.onclick = () => {
        urlOutput.value = encodeURIComponent(urlInput.value);
      };
    }
    if (urlDecodeBtn) {
      urlDecodeBtn.onclick = () => {
        try {
          urlOutput.value = decodeURIComponent(urlInput.value);
        } catch (e) {
          urlOutput.value = 'Error: Malformed URI sequence';
        }
      };
    }
    if (urlCopyBtn) {
      urlCopyBtn.onclick = () => {
        if (!urlOutput.value) return;
        navigator.clipboard.writeText(urlOutput.value).then(() => showToast('URL result copied!'));
      };
    }
  }

  // 4. Cryptographic Hash Generator (SHA-256 / SHA-1)
  const hashInput = document.getElementById('hash-input');
  const hashSha256 = document.getElementById('hash-sha256');
  const hashSha1 = document.getElementById('hash-sha1');
  const copySha256Btn = document.getElementById('copy-sha256-btn');
  const copySha1Btn = document.getElementById('copy-sha1-btn');

  if (hashInput && hashSha256) {
    const computeHashes = async () => {
      const text = hashInput.value;
      if (!text) {
        hashSha256.value = '';
        if (hashSha1) hashSha1.value = '';
        return;
      }
      const enc = new TextEncoder().encode(text);
      try {
        const buf256 = await crypto.subtle.digest('SHA-256', enc);
        hashSha256.value = Array.from(new Uint8Array(buf256)).map(b => b.toString(16).padStart(2, '0')).join('');

        if (hashSha1) {
          const buf1 = await crypto.subtle.digest('SHA-1', enc);
          hashSha1.value = Array.from(new Uint8Array(buf1)).map(b => b.toString(16).padStart(2, '0')).join('');
        }
      } catch (e) {
        console.error('Hash calculation error', e);
      }
    };

    hashInput.addEventListener('input', computeHashes);
    if (hashInput.value) computeHashes();

    if (copySha256Btn) {
      copySha256Btn.onclick = () => {
        if (!hashSha256.value) return;
        navigator.clipboard.writeText(hashSha256.value).then(() => showToast('SHA-256 hash copied!'));
      };
    }
    if (copySha1Btn && hashSha1) {
      copySha1Btn.onclick = () => {
        if (!hashSha1.value) return;
        navigator.clipboard.writeText(hashSha1.value).then(() => showToast('SHA-1 hash copied!'));
      };
    }
  }

  // 5. Regex Tester
  const regexPattern = document.getElementById('regex-pattern');
  const regexFlags = document.getElementById('regex-flags');
  const regexTestStr = document.getElementById('regex-test-string');
  const regexResults = document.getElementById('regex-results');

  if (regexPattern && regexTestStr && regexResults) {
    const runRegex = () => {
      const p = regexPattern.value;
      const f = (regexFlags ? regexFlags.value : 'g') || 'g';
      const text = regexTestStr.value;

      if (!p) {
        regexResults.innerHTML = '<span style="color: var(--text-muted);">Enter a regex pattern and test string</span>';
        return;
      }

      try {
        const rx = new RegExp(p, f);
        const matches = [...text.matchAll(rx)];
        if (matches.length === 0) {
          regexResults.innerHTML = '<span style="color: #f87171;">No matches found</span>';
        } else {
          let list = `<div style="color: #34d399; margin-bottom: 8px; font-weight: 600;">Found ${matches.length} match(es):</div>`;
          matches.forEach((m, i) => {
            list += `<div style="font-family: var(--font-mono); font-size: 0.8rem; background: rgba(0,0,0,0.3); padding: 4px 8px; border-radius: 4px; margin-bottom: 4px; border: 1px solid var(--border-subtle);">
              #${i + 1}: <strong style="color: #fff;">${escapeHtml(m[0])}</strong> at index ${m.index}
            </div>`;
          });
          regexResults.innerHTML = list;
        }
      } catch (err) {
        regexResults.innerHTML = `<span style="color: #f87171;">Regex Error: ${escapeHtml(err.message)}</span>`;
      }
    };

    regexPattern.addEventListener('input', runRegex);
    if (regexFlags) regexFlags.addEventListener('input', runRegex);
    regexTestStr.addEventListener('input', runRegex);
  }

  // 6. Linux Chmod Calculator
  const chmodBoxes = document.querySelectorAll('.chmod-checkbox');
  const chmodOctal = document.getElementById('chmod-octal');
  const chmodSymbolic = document.getElementById('chmod-symbolic');
  const chmodCmd = document.getElementById('chmod-cmd');
  const copyChmodBtn = document.getElementById('copy-chmod-btn');

  if (chmodBoxes.length > 0 && chmodOctal) {
    const updateChmod = () => {
      let u = 0, g = 0, o = 0;
      if (document.getElementById('chmod-u-r')?.checked) u += 4;
      if (document.getElementById('chmod-u-w')?.checked) u += 2;
      if (document.getElementById('chmod-u-x')?.checked) u += 1;

      if (document.getElementById('chmod-g-r')?.checked) g += 4;
      if (document.getElementById('chmod-g-w')?.checked) g += 2;
      if (document.getElementById('chmod-g-x')?.checked) g += 1;

      if (document.getElementById('chmod-o-r')?.checked) o += 4;
      if (document.getElementById('chmod-o-w')?.checked) o += 2;
      if (document.getElementById('chmod-o-x')?.checked) o += 1;

      const octal = `${u}${g}${o}`;
      chmodOctal.textContent = octal;

      const sym =
        (document.getElementById('chmod-u-r')?.checked ? 'r' : '-') +
        (document.getElementById('chmod-u-w')?.checked ? 'w' : '-') +
        (document.getElementById('chmod-u-x')?.checked ? 'x' : '-') +
        (document.getElementById('chmod-g-r')?.checked ? 'r' : '-') +
        (document.getElementById('chmod-g-w')?.checked ? 'w' : '-') +
        (document.getElementById('chmod-g-x')?.checked ? 'x' : '-') +
        (document.getElementById('chmod-o-r')?.checked ? 'r' : '-') +
        (document.getElementById('chmod-o-w')?.checked ? 'w' : '-') +
        (document.getElementById('chmod-o-x')?.checked ? 'x' : '-');

      if (chmodSymbolic) chmodSymbolic.textContent = sym;
      if (chmodCmd) chmodCmd.value = `chmod ${octal} <file_or_directory>`;
    };

    chmodBoxes.forEach(b => b.addEventListener('change', updateChmod));
    updateChmod();

    if (copyChmodBtn && chmodCmd) {
      copyChmodBtn.onclick = () => {
        navigator.clipboard.writeText(chmodCmd.value).then(() => showToast('Chmod command copied!'));
      };
    }
  }

  // 7. UUID v4 Generator
  const uuidOutput = document.getElementById('uuid-output');
  const uuidCount = document.getElementById('uuid-count');
  const uuidGenerateBtn = document.getElementById('uuid-generate-btn');
  const uuidCopyBtn = document.getElementById('uuid-copy-btn');

  if (uuidOutput && uuidGenerateBtn) {
    const genUuid = () => {
      const count = uuidCount ? parseInt(uuidCount.value, 10) || 1 : 1;
      const ids = [];
      for (let i = 0; i < count; i++) {
        ids.push(crypto.randomUUID ? crypto.randomUUID() : '10000000-1000-4000-8000-100000000000'.replace(/[018]/g, c =>
          (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
        ));
      }
      uuidOutput.value = ids.join('\n');
    };

    uuidGenerateBtn.onclick = genUuid;
    if (!uuidOutput.value) genUuid();

    if (uuidCopyBtn) {
      uuidCopyBtn.onclick = () => {
        if (!uuidOutput.value) return;
        navigator.clipboard.writeText(uuidOutput.value).then(() => showToast('UUID(s) copied!'));
      };
    }
  }

  // 8. QR Code Generator
  const qrInput = document.getElementById('qr-input');
  const qrImg = document.getElementById('qr-img');
  const qrGenerateBtn = document.getElementById('qr-generate-btn');

  if (qrInput && qrImg) {
    const generateQr = () => {
      const val = qrInput.value.trim();
      if (!val) return;
      const url = `https://api.qrserver.com/v1/create-qr-code/?size=160x160&data=${encodeURIComponent(val)}`;
      qrImg.src = url;
    };

    if (qrGenerateBtn) qrGenerateBtn.onclick = generateQr;
    qrInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') generateQr();
    });
  }
}

// ==========================================================================
// 10. Rauf Labs AI Copilot (BYOK Gemini API & Built-in Engine)
// ==========================================================================

const AI_API_STORAGE_KEY = 'rauf_gemini_api_key';

const AI_KNOWLEDGE_BASE = [
  {
    keywords: ['android', 'apk', 'adb', 'zygote', 'art', 'dalvik', 'root', 'frida', 'magisk'],
    reply: `### Android Internals & Architecture Guide

Android is a multi-tier operating system built on top of a modified Linux LTS kernel.

**Core Stack Components:**
1. **Linux Kernel**: Handles hardware abstraction, memory paging, Binder IPC drivers, and process scheduling.
2. **HAL (Hardware Abstraction Layer)**: Exposes device hardware interfaces (camera, audio, sensors) to higher levels.
3. **Android Runtime (ART)**: Executes DEX bytecode via AOT (Ahead-of-Time) & JIT (Just-in-Time) compilation.
4. **Zygote Process**: Preloads Android core framework classes and forks every new application process with copy-on-write RAM savings.

**Essential ADB Commands:**
\`\`\`bash
# List connected devices
adb devices

# Inspect running process PIDs and top memory consumers
adb shell top -m 10

# Capture live logcat system log filtered by tag
adb logcat -v time *:E

# Install split APKs or test packages
adb install -r -d app-release.apk
\`\`\`
`
  },
  {
    keywords: ['termux', 'pkg', 'apt', 'mobile', 'storage', 'ssh', 'proot', 'python'],
    reply: `### Termux Mobile Workstation Masterclass

Termux creates a fully functional non-root Linux environment directly on Android.

**Recommended Setup Commands:**
\`\`\`bash
# 1. Update package lists and base binaries
pkg update &amp;&amp; pkg upgrade -y

# 2. Grant shared storage permissions (/sdcard)
termux-setup-storage

# 3. Install core dev tools
pkg install git nodejs-lts python clang neovim tmux openssh -y

# 4. Acquire CPU wake-lock so background servers do not sleep
termux-wake-lock
\`\`\`

*Tip: For running heavy full Linux distributions like Ubuntu or Debian inside Termux, install \`proot-distro\`.*
`
  },
  {
    keywords: ['chmod', 'chown', 'permission', '755', '644', '600', 'linux permissions'],
    reply: `### Linux Permissions & Chmod Demystified

Linux file permissions are grouped into three distinct octal tiers: **User (u)**, **Group (g)**, and **Others (o)**.

| Permission | Octal Value | Meaning |
|---|---|---|
| **Read (r)** | 4 | View file contents or list directory |
| **Write (w)** | 2 | Modify file or create/delete files in directory |
| **Execute (x)** | 1 | Run binary/script or \`cd\` into directory |

**Standard Production Permission Sets:**
\`\`\`bash
# Web root files: Owner read/write, everyone else read-only
chmod 644 index.html

# Executable scripts: Owner read/write/exec, others read/exec
chmod 755 deploy.sh

# Private SSH keys: Strict owner read/write only (required by ssh client)
chmod 600 ~/.ssh/id_rsa
\`\`\`
`
  },
  {
    keywords: ['git', 'conflict', 'rebase', 'merge', 'cherry-pick', 'stash'],
    reply: `### Modern Git Workflow & Conflict Resolution

Clean team development relies on atomic commits and linear history through rebasing.

**Clean Feature Branch Workflow:**
\`\`\`bash
# 1. Start from latest main
git checkout main
git pull origin main

# 2. Create feature branch
git checkout -b feature/auth-redesign

# 3. Pull upstream changes cleanly onto your feature branch
git fetch origin
git rebase origin/main

# 4. If conflicts occur, inspect and resolve:
git status
# Edit conflicting markers (<<<<<<< HEAD), then:
git add .
git rebase --continue
\`\`\`
`
  },
  {
    keywords: ['bash', 'script', 'cron', 'sed', 'awk', 'loop'],
    reply: `### Bash Automation Scripting Template

Here is a resilient production bash script skeleton with strict error trapping (\`set -euo pipefail\`):

\`\`\`bash
#!/usr/bin/env bash
set -euo pipefail
IFS=$'\\n\\t'

echo "==> Starting Rauf Labs Build Process..."
TARGET_DIR="./dist"

if [[ ! -d "$TARGET_DIR" ]]; then
  echo "Creating build target: $TARGET_DIR"
  mkdir -p "$TARGET_DIR"
fi

echo "✓ Build complete at $(date '+%Y-%m-%d %H:%M:%S')"
\`\`\`
`
  }
];

function initAiCopilot() {
  const chatFeed = document.getElementById('ai-chat-feed');
  const chatInput = document.getElementById('ai-input-box') || document.getElementById('ai-chat-input');
  const sendBtn = document.getElementById('ai-send-btn');
  const clearBtn = document.getElementById('ai-clear-btn');
  const exportBtn = document.getElementById('ai-export-btn');
  const settingsToggle = document.getElementById('ai-settings-toggle-btn');
  const byokBanner = document.getElementById('ai-byok-banner');
  const byokClose = document.getElementById('ai-byok-close');
  const apiKeyInput = document.getElementById('ai-api-key-input') || document.getElementById('ai-key-input');
  const saveKeyBtn = document.getElementById('ai-key-save-btn');
  const removeKeyBtn = document.getElementById('ai-key-remove-btn');
  const testConnBtn = document.getElementById('ai-test-connection-btn');
  const bannerTestBtn = document.getElementById('ai-banner-test-btn');
  const connDot = document.getElementById('ai-status-dot');
  const connText = document.getElementById('ai-status-text');
  const bannerStatus = document.getElementById('ai-banner-status-display');
  const diagnosticFeedback = document.getElementById('ai-diagnostic-feedback');
  const modelSelect = document.getElementById('ai-model-select');
  const modelSelectBanner = document.getElementById('ai-model-select-banner');
  const micBtn = document.getElementById('ai-mic-btn');
  const stopVoiceBtn = document.getElementById('ai-stop-voice-btn');
  const v2vToggle = document.getElementById('ai-v2v-toggle-btn');
  const v2vLabel = document.getElementById('v2v-state-label');

  if (!chatFeed || !chatInput) return;

  let voiceToVoiceEnabled = false;
  let isGeminiConnected = false;
  let serverHasKey = false;

  const getSelectedModel = () => {
    return (modelSelect && modelSelect.value) || (modelSelectBanner && modelSelectBanner.value) || 'gemini-3.8-flash';
  };

  const syncModelSelects = (val) => {
    if (modelSelect) modelSelect.value = val;
    if (modelSelectBanner) modelSelectBanner.value = val;
  };

  const getCustomKey = () => {
    const k = localStorage.getItem(AI_API_STORAGE_KEY);
    return (k && k.trim().length > 10) ? k.trim() : null;
  };

  const showDiagnostic = (message, isError = false) => {
    if (!diagnosticFeedback) return;
    diagnosticFeedback.style.display = 'block';
    diagnosticFeedback.style.background = isError ? 'rgba(239, 68, 68, 0.15)' : 'rgba(34, 197, 94, 0.15)';
    diagnosticFeedback.style.border = isError ? '1px solid rgba(239, 68, 68, 0.4)' : '1px solid rgba(34, 197, 94, 0.4)';
    diagnosticFeedback.style.color = isError ? '#fca5a5' : '#86efac';
    diagnosticFeedback.innerHTML = message;
  };

  const setStatus = (status, label, detailMsg = '') => {
    if (connDot) {
      if (status === 'connected') connDot.style.background = '#34d399';
      else if (status === 'error') connDot.style.background = '#f87171';
      else if (status === 'checking') connDot.style.background = '#60a5fa';
      else connDot.style.background = '#fbbf24';
    }

    if (connText) {
      connText.textContent = label;
    }

    if (bannerStatus) {
      if (status === 'connected') {
        bannerStatus.style.color = '#34d399';
        bannerStatus.textContent = `🟢 ${label}`;
      } else if (status === 'error') {
        bannerStatus.style.color = '#f87171';
        bannerStatus.textContent = `🔴 ${label}`;
      } else if (status === 'checking') {
        bannerStatus.style.color = '#60a5fa';
        bannerStatus.textContent = `🔵 ${label}`;
      } else {
        bannerStatus.style.color = '#fbbf24';
        bannerStatus.textContent = `🟡 ${label}`;
      }
    }

    if (detailMsg) {
      showDiagnostic(detailMsg, status === 'error');
    }
  };

  const testGeminiConnection = async (explicitUserClick = false) => {
    const model = getSelectedModel();
    const customKey = getCustomKey();

    setStatus('checking', `Testing connection (${model})...`);
    if (testConnBtn) {
      testConnBtn.disabled = true;
      testConnBtn.textContent = '⚡ Testing...';
    }
    if (bannerTestBtn) {
      bannerTestBtn.disabled = true;
      bannerTestBtn.textContent = '⚡ Testing...';
    }

    try {
      const headers = { 'Content-Type': 'application/json' };
      if (customKey) {
        headers['x-gemini-api-key'] = customKey;
      }

      const res = await fetch('/api/gemini/test-connection', {
        method: 'POST',
        headers,
        body: JSON.stringify({ model })
      });

      const data = await res.json().catch(() => ({}));

      if (res.ok && data.ok) {
        isGeminiConnected = true;
        setStatus('connected', `Connected: ${data.model}`, `<strong>Success:</strong> Verified live connection to <code>${escapeHtml(data.model)}</code> via secure backend proxy (Latency: ${data.latencyMs || 0}ms).`);
        if (explicitUserClick) {
          showToast(`Successfully connected to ${data.model}!`, 'success');
        }
      } else {
        isGeminiConnected = false;
        const errCode = data.code || 'REQUEST_FAILED';
        let errMsg = data.error || 'Connection failed';

        if (errCode === 'KEY_MISSING') {
          errMsg = 'Server configuration missing: GEMINI_API_KEY is not configured on the server. You can provide a custom API key in the configuration panel.';
          setStatus('idle', 'Configuration Required', `<strong>Notice:</strong> ${errMsg}`);
          if (explicitUserClick) showToast('Server configuration missing: Please configure an API key.', 'info');
        } else if (errCode === 'AUTH_FAILED') {
          setStatus('error', 'Authentication failed: Invalid API key', `<strong>Error:</strong> Authentication failed — the supplied Gemini API key is invalid.`);
          if (explicitUserClick) showToast('Authentication failed: Invalid API key', 'error');
        } else if (errCode === 'MODEL_UNAVAILABLE') {
          setStatus('error', 'Configured Gemini model is unavailable', `<strong>Error:</strong> Configured Gemini model is unavailable.`);
          if (explicitUserClick) showToast('Configured Gemini model is unavailable.', 'error');
        } else if (errCode === 'RATE_LIMIT') {
          setStatus('error', 'Rate limit reached', `<strong>Error:</strong> Rate limit reached or quota exceeded.`);
          if (explicitUserClick) showToast('Rate limit reached.', 'error');
        } else {
          setStatus('error', 'Connection failed', `<strong>Error:</strong> ${escapeHtml(errMsg)}`);
          if (explicitUserClick) showToast(`Gemini error: ${errMsg}`, 'error');
        }
      }
    } catch (err) {
      isGeminiConnected = false;
      setStatus('error', 'Backend Request Failed', `<strong>Error:</strong> Unable to communicate with Rauf Labs server proxy (${escapeHtml(err.message)}).`);
      if (explicitUserClick) showToast(`Connection error: ${err.message}`, 'error');
    } finally {
      if (testConnBtn) {
        testConnBtn.disabled = false;
        testConnBtn.textContent = '⚡ Test Connection';
      }
      if (bannerTestBtn) {
        bannerTestBtn.disabled = false;
        bannerTestBtn.textContent = '⚡ Test Connection';
      }
    }
  };

  // Check initial backend status
  const initBackendStatus = async () => {
    try {
      const customKey = getCustomKey();
      if (apiKeyInput && customKey) {
        apiKeyInput.value = customKey;
        if (removeKeyBtn) removeKeyBtn.style.display = 'inline-flex';
      }

      const res = await fetch('/api/gemini/status', {
        headers: customKey ? { 'x-gemini-api-key': customKey } : {}
      });

      if (res.ok) {
        const data = await res.json();
        serverHasKey = data.isServerConfigured;
        if (data.configured) {
          // Perform real test to verify connection status
          await testGeminiConnection(false);
        } else {
          setStatus('idle', 'Gemini Not Configured', '<strong>Server configuration missing:</strong> GEMINI_API_KEY is not set on the server. You can add one below or configure it in AI Studio Secrets.');
        }
      } else {
        setStatus('idle', 'Using Built-in Knowledge Base');
      }
    } catch {
      setStatus('idle', 'Using Built-in Knowledge Base');
    }
  };

  initBackendStatus();

  // Model changes
  if (modelSelect) {
    modelSelect.onchange = () => {
      syncModelSelects(modelSelect.value);
      testGeminiConnection(false);
    };
  }
  if (modelSelectBanner) {
    modelSelectBanner.onchange = () => {
      syncModelSelects(modelSelectBanner.value);
      testGeminiConnection(false);
    };
  }

  // Banner toggling
  if (settingsToggle && byokBanner) {
    settingsToggle.onclick = () => {
      byokBanner.classList.toggle('hidden');
    };
  }

  if (byokClose && byokBanner) {
    byokClose.onclick = () => {
      byokBanner.classList.add('hidden');
    };
  }

  // Save custom key
  if (saveKeyBtn && apiKeyInput) {
    saveKeyBtn.onclick = async () => {
      const key = apiKeyInput.value.trim();
      if (!key) {
        showToast('Please paste a valid Gemini API key.');
        return;
      }
      localStorage.setItem(AI_API_STORAGE_KEY, key);
      if (removeKeyBtn) removeKeyBtn.style.display = 'inline-flex';
      showToast('Custom Gemini key saved. Testing connection...', 'info');
      await testGeminiConnection(true);
    };
  }

  // Remove/disconnect key
  if (removeKeyBtn) {
    removeKeyBtn.onclick = () => {
      localStorage.removeItem(AI_API_STORAGE_KEY);
      if (apiKeyInput) apiKeyInput.value = '';
      removeKeyBtn.style.display = 'none';
      isGeminiConnected = false;
      setStatus('idle', serverHasKey ? 'Using Server Key' : 'Disconnected / Built-in Knowledge Base', 'Custom API key removed.');
      showToast('API key removed. Connection reset.');
      if (serverHasKey) {
        testGeminiConnection(false);
      }
    };
  }

  // Test connection button clicks
  if (testConnBtn) {
    testConnBtn.onclick = () => testGeminiConnection(true);
  }
  if (bannerTestBtn) {
    bannerTestBtn.onclick = () => testGeminiConnection(true);
  }

  // Quick prompt chips
  const chips = document.querySelectorAll('.prompt-chip');
  chips.forEach(chip => {
    chip.onclick = () => {
      const q = chip.getAttribute('data-prompt') || chip.textContent.trim();
      chatInput.value = q;
      handleSendMessage();
    };
  });

  // Speech-to-Text Microphone
  const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
  if (micBtn && SpeechRecognition) {
    let recognition = new SpeechRecognition();
    let isListening = false;
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = 'en-US';

    recognition.onstart = () => {
      isListening = true;
      micBtn.classList.add('recording');
      micBtn.title = 'Listening... Speak your coding query';
      showToast('Microphone active. Listening...', 'info');
    };

    recognition.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      if (chatInput) {
        chatInput.value = (chatInput.value ? chatInput.value + ' ' : '') + transcript;
        chatInput.focus();
      }
    };

    recognition.onerror = (event) => {
      isListening = false;
      micBtn.classList.remove('recording');
      micBtn.title = 'Voice Input (Speech-to-Text)';
      if (event.error !== 'no-speech') {
        showToast(`Microphone notification: ${event.error}`, 'info');
      }
    };

    recognition.onend = () => {
      isListening = false;
      micBtn.classList.remove('recording');
      micBtn.title = 'Voice Input (Speech-to-Text)';
    };

    micBtn.onclick = () => {
      if (!isListening) {
        try {
          recognition.start();
        } catch (err) {
          console.error('Speech recognition error', err);
        }
      } else {
        recognition.stop();
      }
    };
  } else if (micBtn) {
    micBtn.onclick = () => {
      showToast('Speech recognition not supported in this browser. Please type below.', 'info');
    };
  }

  // Text-to-Speech Output
  const speakText = (rawText) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();

    const clean = rawText
      .replace(/```[\s\S]*?```/g, 'Code block omitted from voice.')
      .replace(/`([^`]+)`/g, '$1')
      .replace(/[*#_~>]/g, '')
      .trim();

    if (!clean) return;

    const utterance = new SpeechSynthesisUtterance(clean);
    utterance.rate = 1.05;
    utterance.pitch = 1.0;

    utterance.onstart = () => {
      if (stopVoiceBtn) stopVoiceBtn.style.display = 'inline-flex';
    };
    utterance.onend = () => {
      if (stopVoiceBtn) stopVoiceBtn.style.display = 'none';
    };
    utterance.onerror = () => {
      if (stopVoiceBtn) stopVoiceBtn.style.display = 'none';
    };

    window.speechSynthesis.speak(utterance);
  };

  if (stopVoiceBtn) {
    stopVoiceBtn.onclick = () => {
      if (window.speechSynthesis) {
        window.speechSynthesis.cancel();
        stopVoiceBtn.style.display = 'none';
        showToast('Voice readout stopped.');
      }
    };
  }

  if (v2vToggle && v2vLabel) {
    v2vToggle.onclick = () => {
      voiceToVoiceEnabled = !voiceToVoiceEnabled;
      v2vLabel.textContent = voiceToVoiceEnabled ? 'ON' : 'OFF';
      v2vLabel.style.color = voiceToVoiceEnabled ? '#34d399' : 'var(--text-muted)';
      showToast(`Voice-to-Voice auto-readout is now ${voiceToVoiceEnabled ? 'ON' : 'OFF'}`);
      if (!voiceToVoiceEnabled && window.speechSynthesis) {
        window.speechSynthesis.cancel();
        if (stopVoiceBtn) stopVoiceBtn.style.display = 'none';
      }
    };
  }

  const appendMessage = (sender, contentHtml, rawPlainText = '') => {
    const msgDiv = document.createElement('div');
    msgDiv.className = `ai-message ${sender === 'user' ? 'user-msg' : 'bot-msg'}`;
    const avatar = sender === 'user' ? '👤' : '🤖';
    const name = sender === 'user' ? 'You' : 'Rauf Labs AI';

    msgDiv.innerHTML = `
      <div class="msg-avatar">${avatar}</div>
      <div class="msg-content">
        <div class="msg-header" style="display: flex; justify-content: space-between; align-items: center;">
          <div style="display: flex; align-items: center; gap: 8px;">
            <strong>${name}</strong>
            <span style="font-size: 0.75rem; color: var(--text-muted);">${new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
          </div>
          ${sender === 'bot' ? `<button class="listen-msg-btn" title="Listen to response" style="background: none; border: 1px solid var(--border-subtle); color: var(--text-muted); font-size: 0.75rem; padding: 2px 8px; border-radius: 4px; cursor: pointer;">🔊 Listen</button>` : ''}
        </div>
        <div class="msg-body">${contentHtml}</div>
      </div>
    `;

    chatFeed.appendChild(msgDiv);
    chatFeed.scrollTop = chatFeed.scrollHeight;

    // Attach copy listeners to any code blocks inside message
    msgDiv.querySelectorAll('pre').forEach(pre => {
      if (!pre.querySelector('.code-copy-btn')) {
        const copyBtn = document.createElement('button');
        copyBtn.className = 'code-copy-btn';
        copyBtn.textContent = 'Copy';
        copyBtn.onclick = () => {
          const code = pre.querySelector('code')?.innerText || pre.innerText;
          navigator.clipboard.writeText(code).then(() => {
            copyBtn.textContent = 'Copied!';
            setTimeout(() => copyBtn.textContent = 'Copy', 2000);
          });
        };
        pre.style.position = 'relative';
        pre.appendChild(copyBtn);
      }
    });

    // Voice replay button
    const listenBtn = msgDiv.querySelector('.listen-msg-btn');
    if (listenBtn) {
      listenBtn.onclick = () => {
        const textToSpeak = rawPlainText || msgDiv.querySelector('.msg-body')?.innerText || '';
        speakText(textToSpeak);
      };
    }

    return msgDiv;
  };

  const handleSendMessage = async () => {
    const text = chatInput.value.trim();
    if (!text) return;

    appendMessage('user', `<p>${escapeHtml(text)}</p>`);
    chatInput.value = '';

    // Temporary loading indicator
    const loadingDiv = appendMessage('bot', `
      <div style="display: flex; align-items: center; gap: 8px; color: var(--text-muted); font-size: 0.85rem;">
        <span class="loading-spinner" style="display: inline-block; width: 14px; height: 14px; border: 2px solid var(--accent-purple-light); border-top-color: transparent; border-radius: 50%; animation: spin 0.8s linear infinite;"></span>
        Rauf Labs AI is synthesizing response...
      </div>
    `);

    const customKey = getCustomKey();
    const selectedModel = getSelectedModel();

    try {
      const headers = { 'Content-Type': 'application/json' };
      if (customKey) {
        headers['x-gemini-api-key'] = customKey;
      }

      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          message: text,
          model: selectedModel
        })
      });

      const data = await response.json().catch(() => ({}));

      if (response.ok && data.ok && data.reply) {
        const candidate = data.reply;
        const formatted = candidate
          .replace(/```([a-z]*)\n([\s\S]*?)```/g, (m, lang, code) => {
            return `<pre><code class="language-${lang}">${escapeHtml(code.trim())}</code></pre>`;
          })
          .replace(/\n\n/g, '</p><p>')
          .replace(/\n/g, '<br>');

        loadingDiv.querySelector('.msg-body').innerHTML = `<p>${formatted}</p>`;

        const listenBtn = loadingDiv.querySelector('.listen-msg-btn');
        if (listenBtn) {
          listenBtn.onclick = () => speakText(candidate);
        }

        if (voiceToVoiceEnabled) {
          speakText(candidate);
        }
      } else {
        const errCode = data.code || 'REQUEST_FAILED';
        let errMsg = data.error || 'Unable to generate response from Gemini API';

        if (errCode === 'KEY_MISSING') {
          errMsg = 'Server configuration missing: GEMINI_API_KEY is not configured on the server. Please add your key in the AI Studio Secrets panel or configure a custom API key.';
        } else if (errCode === 'AUTH_FAILED') {
          errMsg = 'Authentication failed: Invalid API key.';
        } else if (errCode === 'MODEL_UNAVAILABLE') {
          errMsg = 'Configured Gemini model is unavailable.';
        } else if (errCode === 'RATE_LIMIT') {
          errMsg = 'Rate limit reached or quota exceeded.';
        }

        const localReply = getLocalReply(text);
        loadingDiv.querySelector('.msg-body').innerHTML = `
          <div style="color: #f87171; font-size: 0.85rem; margin-bottom: 8px; padding: 8px 12px; background: rgba(248, 113, 113, 0.1); border: 1px solid rgba(248, 113, 113, 0.3); border-radius: 6px;">
            ⚠️ <strong>${escapeHtml(errMsg)}</strong><br>
            <span style="font-size: 0.8rem; color: var(--text-secondary);">Displaying answer from built-in developer knowledge base:</span>
          </div>
          ${localReply}
        `;
        if (voiceToVoiceEnabled) {
          speakText(loadingDiv.querySelector('.msg-body')?.innerText || '');
        }
      }
    } catch (err) {
      const localReply = getLocalReply(text);
      loadingDiv.querySelector('.msg-body').innerHTML = `
        <div style="color: #f87171; font-size: 0.85rem; margin-bottom: 8px; padding: 8px 12px; background: rgba(248, 113, 113, 0.1); border: 1px solid rgba(248, 113, 113, 0.3); border-radius: 6px;">
          ⚠️ <strong>Backend communication error (${escapeHtml(err.message)})</strong><br>
          <span style="font-size: 0.8rem; color: var(--text-secondary);">Displaying answer from built-in developer knowledge base:</span>
        </div>
        ${localReply}
      `;
      if (voiceToVoiceEnabled) {
        speakText(loadingDiv.querySelector('.msg-body')?.innerText || '');
      }
    }
  };

  const getLocalReply = (query) => {
    const q = query.toLowerCase();
    for (const item of AI_KNOWLEDGE_BASE) {
      if (item.keywords.some(k => q.includes(k))) {
        return item.reply
          .replace(/```([a-z]*)\n([\s\S]*?)```/g, (m, lang, code) => `<pre><code class="language-${lang}">${code.trim()}</code></pre>`)
          .replace(/\n\n/g, '</p><p>')
          .replace(/\n/g, '<br>');
      }
    }

    return `
      <p>I can help you build, debug, and automate this technical task!</p>
      <p>Here is the recommended workflow in <strong>Rauf Labs</strong>:</p>
      <pre><code># Explore the relevant track or tool directly:
$ curl -s https://rauflabs.ai.studio/apis
$ cd ~/rauf-labs && ./build.sh</code></pre>
      <p>For custom codebase analysis, add your free <strong>Gemini API key</strong> using the <em>Configure Gemini API Key</em> button above for unlimited dynamic generation!</p>
    `;
  };

  if (sendBtn) sendBtn.onclick = handleSendMessage;
  chatInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  });

  if (clearBtn) {
    clearBtn.onclick = () => {
      chatFeed.innerHTML = `
        <div class="ai-message bot-msg">
          <div class="msg-avatar">🤖</div>
          <div class="msg-content">
            <div class="msg-header">
              <strong>Rauf Labs AI</strong>
              <span style="font-size: 0.75rem; color: var(--text-muted);">Ready</span>
            </div>
            <div class="msg-body">
              <p>Chat history cleared. Ask me anything about Android, Termux, Linux system administration, Bash scripts, or Git workflows!</p>
            </div>
          </div>
        </div>
      `;
      if (window.speechSynthesis) window.speechSynthesis.cancel();
      if (stopVoiceBtn) stopVoiceBtn.style.display = 'none';
    };
  }

  if (exportBtn) {
    exportBtn.onclick = () => {
      const messages = chatFeed.querySelectorAll('.ai-message');
      let markdown = `# Rauf Labs AI Chat Export\nExported on: ${new Date().toLocaleString()}\n\n---\n\n`;
      messages.forEach(m => {
        const isUser = m.classList.contains('user-msg');
        const text = m.querySelector('.msg-body')?.innerText || '';
        markdown += `### ${isUser ? 'You' : 'Rauf Labs AI'}\n\n${text}\n\n`;
      });

      const blob = new Blob([markdown], { type: 'text/markdown;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `rauf-labs-chat-${Date.now()}.md`;
      a.click();
      URL.revokeObjectURL(url);
      showToast('Chat transcript exported as Markdown!');
    };
  }
}

// ==========================================================================
// 11. Official QR Code Page Engine (/qr)
// ==========================================================================

function initQrPage() {
  const qrSvg = document.getElementById('official-qr-image');
  if (!qrSvg) return;

  const downloadPngBtn = document.getElementById('qr-download-png');
  const downloadSvgBtn = document.getElementById('qr-download-svg');
  const copyBtn = document.getElementById('qr-copy-btn');
  const quickCopyBtn = document.getElementById('quick-copy-link-btn');
  const shareBtn = document.getElementById('qr-share-btn');
  const printBtn = document.getElementById('qr-print-btn');

  // PNG Download
  if (downloadPngBtn && downloadPngBtn.dataset.bound !== 'true') {
    downloadPngBtn.dataset.bound = 'true';
    downloadPngBtn.addEventListener('click', () => {
      const svg = document.getElementById('official-qr-image');
      if (!svg) return;
      const svgData = new XMLSerializer().serializeToString(svg);
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      const img = new Image();
      canvas.width = 1000;
      canvas.height = 1000;

      img.onload = () => {
        ctx.fillStyle = '#0a101d';
        ctx.fillRect(0, 0, 1000, 1000);
        ctx.drawImage(img, 100, 100, 800, 800);
        const pngUrl = canvas.toDataURL('image/png');
        const a = document.createElement('a');
        a.download = 'rauf-labs-official-qr.png';
        a.href = pngUrl;
        a.click();
        showToast('High-resolution PNG QR Code downloaded!', 'success');
      };
      img.src = 'data:image/svg+xml;base64,' + btoa(unescape(encodeURIComponent(svgData)));
    });
  }

  // SVG Download
  if (downloadSvgBtn && downloadSvgBtn.dataset.bound !== 'true') {
    downloadSvgBtn.dataset.bound = 'true';
    downloadSvgBtn.addEventListener('click', () => {
      const svg = document.getElementById('official-qr-image');
      if (!svg) return;
      const svgData = new XMLSerializer().serializeToString(svg);
      const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.download = 'rauf-labs-official-qr.svg';
      a.href = url;
      a.click();
      URL.revokeObjectURL(url);
      showToast('Vector SVG QR Code downloaded!', 'success');
    });
  }

  // Copy Link
  const handleCopyLink = () => {
    navigator.clipboard.writeText('https://rauflabs.ai.studio/').then(() => {
      showToast('Official platform link copied to clipboard!', 'success');
    }).catch(() => {
      showToast('Copied: https://rauflabs.ai.studio/', 'info');
    });
  };

  if (copyBtn && copyBtn.dataset.bound !== 'true') {
    copyBtn.dataset.bound = 'true';
    copyBtn.addEventListener('click', handleCopyLink);
  }

  if (quickCopyBtn && quickCopyBtn.dataset.bound !== 'true') {
    quickCopyBtn.dataset.bound = 'true';
    quickCopyBtn.addEventListener('click', handleCopyLink);
  }

  // Share Link
  if (shareBtn && shareBtn.dataset.bound !== 'true') {
    shareBtn.dataset.bound = 'true';
    shareBtn.addEventListener('click', () => {
      if (navigator.share) {
        navigator.share({
          title: 'Rauf Labs — Developer Platform',
          text: 'Explore open-source Android, Termux, Linux, and programming tracks on Rauf Labs:',
          url: 'https://rauflabs.ai.studio/'
        }).catch(() => {});
      } else {
        handleCopyLink();
      }
    });
  }

  // Print QR Sheet
  if (printBtn && printBtn.dataset.bound !== 'true') {
    printBtn.dataset.bound = 'true';
    printBtn.addEventListener('click', () => {
      window.print();
    });
  }
}

// ==========================================================================
// 12. Learning Track Navigation & Practice Solutions
// ==========================================================================

function initLearningTrackInteractions() {
  // Mobile learning sidebar drawer toggle
  const toggleBtn = document.getElementById('mobile-learning-nav-toggle');
  const sidebar = document.querySelector('.learning-sidebar');
  if (toggleBtn && sidebar && toggleBtn.dataset.bound !== 'true') {
    toggleBtn.dataset.bound = 'true';
    toggleBtn.addEventListener('click', () => {
      const isOpen = sidebar.classList.toggle('open-mobile');
      toggleBtn.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      toggleBtn.innerHTML = isOpen
        ? '<span>✕ Close Track Index</span>'
        : '<span>📖 Jump to Module / Topic ↓</span>';
    });
  }

  // Smooth scroll and active link highlight
  const navLinks = document.querySelectorAll('.learning-nav-item a');
  navLinks.forEach(link => {
    if (link.dataset.bound === 'true') return;
    link.dataset.bound = 'true';
    link.addEventListener('click', (e) => {
      const href = link.getAttribute('href');
      if (href && href.startsWith('#')) {
        const target = document.querySelector(href);
        if (target) {
          e.preventDefault();
          navLinks.forEach(l => l.classList.remove('active'));
          link.classList.add('active');
          target.scrollIntoView({ behavior: 'smooth', block: 'start' });
          if (sidebar && sidebar.classList.contains('open-mobile')) {
            sidebar.classList.remove('open-mobile');
            if (toggleBtn) toggleBtn.innerHTML = '<span>📖 Jump to Module / Topic ↓</span>';
          }
        }
      }
    });
  });

  // Practice task solution reveal toggles
  document.querySelectorAll('.solution-toggle-btn').forEach(btn => {
    if (btn.dataset.bound === 'true') return;
    btn.dataset.bound = 'true';
    btn.addEventListener('click', () => {
      const solutionBox = btn.closest('.practice-task-card')?.querySelector('.solution-box') || btn.nextElementSibling;
      if (!solutionBox) return;
      const isOpen = solutionBox.classList.toggle('open');
      btn.textContent = isOpen ? 'Hide Solution ↑' : 'Show Solution ↓';
    });
  });
}

/// ==========================================================================
// 13. Auth & Account Management (Rauf Labs Developer Profile)
// ==========================================================================

const USER_STORAGE_KEY = 'rauf_user';

function getStoredUser() {
  try {
    const raw = localStorage.getItem(USER_STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (err) {
    return null;
  }
}

function initAuthState() {
  const user = getStoredUser();
  const navLoginBtn = document.getElementById('nav-login-btn');
  if (navLoginBtn) {
    if (user && user.signedIn) {
      const roleBadge = (user.role === 'admin' || user.role === 'superadmin')
        ? `<span style="display:inline-block; padding:1px 5px; font-size:0.65rem; font-weight:800; border-radius:4px; background:rgba(56,189,248,0.25); color:var(--accent-cyan); border:1px solid rgba(56,189,248,0.4); margin-left:4px; text-transform:uppercase;">${user.role}</span>`
        : '';

      const avatarMarkup = user.dpUrl
        ? `<img src="${user.dpUrl}" alt="" style="width:18px; height:18px; border-radius:50%; object-fit:cover; border:1px solid rgba(52,211,153,0.6);" />`
        : `<span style="display:inline-flex; align-items:center; justify-content:center; width:18px; height:18px; border-radius:50%; background:linear-gradient(135deg, #10b981 0%, #059669 100%); color:#fff; font-size:0.65rem; font-weight:700;">${(user.name || 'D').charAt(0).toUpperCase()}</span>`;

      navLoginBtn.innerHTML = `
        <span style="display: inline-flex; align-items: center; gap: 6px;">
          ${avatarMarkup}
          <span style="max-width: 110px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${user.name || 'Account'}</span>
          ${roleBadge}
        </span>
      `;
      navLoginBtn.title = `Logged in as ${user.email} (${user.role || 'developer'})`;
      navLoginBtn.classList.add('logged-in');
    } else {
      navLoginBtn.innerHTML = 'Login';
      navLoginBtn.title = 'Sign In to Rauf Labs';
      navLoginBtn.classList.remove('logged-in');
    }
  }

  // Also update mobile drawer link
  const mobileLoginLinks = document.querySelectorAll('a[href="/login"].mobile-nav-link');
  mobileLoginLinks.forEach((link) => {
    if (user && user.signedIn) {
      link.innerHTML = `👤 ${user.name || 'Account'} <span>→</span>`;
    } else {
      link.innerHTML = `Login / Account <span>→</span>`;
    }
  });
}

function initAuthView() {
  const loginView = document.getElementById('auth-logged-out-view');
  const profileView = document.getElementById('auth-logged-in-view');
  if (!loginView && !profileView) return;

  const updateViews = () => {
    const currentUser = getStoredUser();
    if (currentUser && currentUser.signedIn) {
      if (loginView) loginView.classList.add('hidden');
      if (profileView) {
        profileView.classList.remove('hidden');

        // Display Name & Email
        const nameEl = document.getElementById('profile-name');
        const emailEl = document.getElementById('profile-email');
        if (nameEl) nameEl.textContent = currentUser.name || 'Developer';
        if (emailEl) emailEl.textContent = currentUser.email || 'developer@rauflabs.io';

        // Avatar
        const avatarInitial = document.getElementById('profile-avatar');
        const avatarImgContainer = document.getElementById('profile-avatar-img-container');
        const avatarImg = document.getElementById('profile-avatar-img');

        if (currentUser.dpUrl && avatarImg && avatarImgContainer) {
          avatarImg.src = currentUser.dpUrl;
          avatarImgContainer.style.display = 'block';
        } else if (avatarInitial) {
          if (avatarImgContainer) avatarImgContainer.style.display = 'none';
          const initial = (currentUser.name || currentUser.email || 'D').charAt(0).toUpperCase();
          avatarInitial.textContent = initial;
        }

        // Role Badge
        const roleBadge = document.getElementById('profile-role-badge');
        if (roleBadge) {
          const role = (currentUser.role || 'developer').toLowerCase();
          if (role === 'superadmin') {
            roleBadge.textContent = '⚡ SUPER ADMIN';
            roleBadge.className = 'card-badge gold';
            roleBadge.style.background = 'rgba(234, 179, 8, 0.2)';
            roleBadge.style.color = '#eab308';
            roleBadge.style.borderColor = 'rgba(234, 179, 8, 0.5)';
          } else if (role === 'admin') {
            roleBadge.textContent = '⚡ ADMIN';
            roleBadge.className = 'card-badge amber';
            roleBadge.style.background = 'rgba(245, 158, 11, 0.2)';
            roleBadge.style.color = '#f59e0b';
            roleBadge.style.borderColor = 'rgba(245, 158, 11, 0.5)';
          } else {
            roleBadge.textContent = 'DEVELOPER';
            roleBadge.className = 'card-badge emerald';
            roleBadge.style.background = 'rgba(16, 185, 129, 0.15)';
            roleBadge.style.color = '#34d399';
            roleBadge.style.borderColor = 'rgba(52, 211, 153, 0.3)';
          }
        }

        // Bookmarks count
        const bCount = document.getElementById('profile-bookmarks-count');
        if (bCount) bCount.textContent = `${getBookmarks().length} items`;
      }
    } else {
      if (loginView) loginView.classList.remove('hidden');
      if (profileView) profileView.classList.add('hidden');
    }
    initAuthState();
  };

  updateViews();

  // Tabs toggle (Sign In vs Create Account)
  const tabLogin = document.getElementById('tab-login');
  const tabSignup = document.getElementById('tab-signup');
  const authSubmitBtn = document.getElementById('auth-submit-btn');
  const authNameField = document.getElementById('auth-name-field');
  const authCardDesc = document.getElementById('auth-card-desc');
  const errorMsg = document.getElementById('auth-error-msg');
  const successMsg = document.getElementById('auth-success-msg');

  let mode = 'login';
  if (tabLogin && tabSignup) {
    tabLogin.onclick = () => {
      mode = 'login';
      tabLogin.classList.add('active');
      tabSignup.classList.remove('active');
      if (authNameField) authNameField.style.display = 'none';
      if (authSubmitBtn) authSubmitBtn.textContent = 'Sign In to Account';
      if (authCardDesc) authCardDesc.textContent = 'Sign in to your developer profile to sync bookmarks, track course certifications, and manage your learning progress.';
      if (errorMsg) errorMsg.style.display = 'none';
      if (successMsg) successMsg.style.display = 'none';
    };
    tabSignup.onclick = () => {
      mode = 'signup';
      tabSignup.classList.add('active');
      tabLogin.classList.remove('active');
      if (authNameField) authNameField.style.display = 'block';
      if (authSubmitBtn) authSubmitBtn.textContent = 'Create Developer Account';
      if (authCardDesc) authCardDesc.textContent = 'Create your developer profile to track learning tracks, save project bookmarks, and unlock interactive certifications.';
      if (errorMsg) errorMsg.style.display = 'none';
      if (successMsg) successMsg.style.display = 'none';
    };
  }

  // Password visibility toggle
  const pwdToggle = document.getElementById('password-toggle-btn');
  const pwdInput = document.getElementById('auth-password');
  if (pwdToggle && pwdInput) {
    pwdToggle.onclick = () => {
      const isPwd = pwdInput.type === 'password';
      pwdInput.type = isPwd ? 'text' : 'password';
      pwdToggle.innerHTML = isPwd
        ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>'
        : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>';
    };
  }

  // Forgot Password Flow
  const forgotToggle = document.getElementById('forgot-password-toggle');
  const forgotPanel = document.getElementById('forgot-password-panel');
  const resetEmailInput = document.getElementById('reset-email-input');
  const sendResetBtn = document.getElementById('send-reset-btn');
  const resetStatusMsg = document.getElementById('reset-status-msg');

  if (forgotToggle && forgotPanel) {
    forgotToggle.onclick = () => {
      const isHidden = forgotPanel.style.display === 'none';
      forgotPanel.style.display = isHidden ? 'block' : 'none';
      if (isHidden && resetEmailInput) {
        const currentEmail = document.getElementById('auth-email')?.value.trim();
        if (currentEmail) resetEmailInput.value = currentEmail;
        resetEmailInput.focus();
      }
    };
  }

  if (sendResetBtn && resetEmailInput && resetStatusMsg) {
    sendResetBtn.onclick = async () => {
      const email = resetEmailInput.value.trim();
      if (!email || !email.includes('@')) {
        resetStatusMsg.textContent = 'Please enter a valid email address.';
        resetStatusMsg.style.color = '#f87171';
        resetStatusMsg.style.display = 'block';
        return;
      }

      sendResetBtn.disabled = true;
      sendResetBtn.textContent = 'Sending...';
      resetStatusMsg.style.display = 'none';

      setTimeout(() => {
        resetStatusMsg.textContent = `Password reset instructions sent to ${email}. Check your inbox!`;
        resetStatusMsg.style.color = '#34d399';
        resetStatusMsg.style.display = 'block';
        sendResetBtn.disabled = false;
        sendResetBtn.textContent = 'Send Link';
      }, 600);
    };
  }

  // Form submit (Developer Authentication)
  const authForm = document.getElementById('auth-form');
  if (authForm) {
    authForm.onsubmit = async (e) => {
      e.preventDefault();
      const email = document.getElementById('auth-email')?.value.trim();
      const password = document.getElementById('auth-password')?.value;
      const name = document.getElementById('auth-name')?.value.trim();

      if (errorMsg) errorMsg.style.display = 'none';
      if (successMsg) successMsg.style.display = 'none';

      if (!email || !email.includes('@')) {
        if (errorMsg) {
          errorMsg.textContent = 'Please enter a valid email address.';
          errorMsg.style.display = 'block';
        }
        return;
      }

      if (!password || password.length < 6) {
        if (errorMsg) {
          errorMsg.textContent = 'Password must be at least 6 characters long.';
          errorMsg.style.display = 'block';
        }
        return;
      }

      const originalText = authSubmitBtn ? authSubmitBtn.textContent : '';
      if (authSubmitBtn) {
        authSubmitBtn.disabled = true;
        authSubmitBtn.textContent = mode === 'login' ? 'Signing in...' : 'Creating account...';
      }

      setTimeout(() => {
        const displayName = name || email.split('@')[0];
        const userObj = {
          signedIn: true,
          name: displayName,
          email: email,
          role: 'developer',
          dpUrl: ''
        };
        try {
          localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(userObj));
        } catch (err) {
          console.error(err);
        }

        if (mode === 'login') {
          showToast(`Welcome back, ${displayName}!`, 'success');
        } else {
          showToast(`Account created successfully!`, 'success');
        }

        if (authSubmitBtn) {
          authSubmitBtn.disabled = false;
          authSubmitBtn.textContent = originalText;
        }

        updateViews();
      }, 500);
    };
  }

  // Edit Profile Drawer
  const editProfileToggleBtn = document.getElementById('edit-profile-toggle-btn');
  const editProfilePanel = document.getElementById('edit-profile-panel');
  const editNameInput = document.getElementById('edit-profile-name');
  const editDpInput = document.getElementById('edit-profile-dp');
  const saveProfileBtn = document.getElementById('save-profile-btn');
  const cancelProfileBtn = document.getElementById('cancel-profile-btn');
  const editStatusMsg = document.getElementById('edit-profile-status');

  if (editProfileToggleBtn && editProfilePanel) {
    editProfileToggleBtn.onclick = () => {
      const isHidden = editProfilePanel.style.display === 'none';
      editProfilePanel.style.display = isHidden ? 'block' : 'none';
      if (isHidden) {
        const u = getStoredUser();
        if (u) {
          if (editNameInput) editNameInput.value = u.name || '';
          if (editDpInput) editDpInput.value = u.dpUrl || '';
        }
        if (editStatusMsg) editStatusMsg.style.display = 'none';
      }
    };
  }

  if (cancelProfileBtn && editProfilePanel) {
    cancelProfileBtn.onclick = () => {
      editProfilePanel.style.display = 'none';
    };
  }

  if (saveProfileBtn && editNameInput && editProfilePanel) {
    saveProfileBtn.onclick = () => {
      const newName = editNameInput.value.trim();
      const newDp = editDpInput ? editDpInput.value.trim() : '';

      if (!newName) {
        if (editStatusMsg) {
          editStatusMsg.textContent = 'Display name cannot be empty.';
          editStatusMsg.style.color = '#f87171';
          editStatusMsg.style.display = 'block';
        }
        return;
      }

      saveProfileBtn.disabled = true;
      saveProfileBtn.textContent = 'Saving...';

      setTimeout(() => {
        const u = getStoredUser() || {};
        u.name = newName;
        u.dpUrl = newDp;
        u.signedIn = true;
        try {
          localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(u));
        } catch (err) {
          console.error(err);
        }

        if (editStatusMsg) {
          editStatusMsg.textContent = 'Profile updated successfully!';
          editStatusMsg.style.color = '#34d399';
          editStatusMsg.style.display = 'block';
        }
        showToast('Profile saved successfully', 'success');
        updateViews();
        setTimeout(() => {
          editProfilePanel.style.display = 'none';
          saveProfileBtn.disabled = false;
          saveProfileBtn.textContent = 'Save Changes';
        }, 800);
      }, 400);
    };
  }

  // Sign out button
  const signOutBtn = document.getElementById('auth-signout-btn');
  if (signOutBtn) {
    signOutBtn.onclick = () => {
      signOutBtn.disabled = true;
      signOutBtn.textContent = 'Signing out...';
      setTimeout(() => {
        localStorage.removeItem(USER_STORAGE_KEY);
        showToast('Signed out successfully');
        updateViews();
        signOutBtn.disabled = false;
        signOutBtn.textContent = 'Sign Out';
      }, 400);
    };
  }
}


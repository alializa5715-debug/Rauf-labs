import fs from 'node:fs';
import path from 'node:path';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';
import { buildSlashCommandsPdf } from './build-slash-commands.mjs';
import { buildStudentToolsPdf } from './build-student-tools.mjs';
import { buildAiBusinessPdf } from './build-ai-business.mjs';
import { buildGatewayPdf } from './build-gateway.mjs';

const ROOT_DIR = process.cwd();
const PUBLIC_PDF_DIR = path.join(ROOT_DIR, 'public', 'pdfs');
const ROOT_PDF_DIR = path.join(ROOT_DIR, 'pdfs');

for (const dir of [PUBLIC_PDF_DIR, ROOT_PDF_DIR]) {
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
}

// Re-embed builder for Gemini Omni
async function buildGeminiOmniPdf() {
  const doc = await PDFDocument.create();
  const fontBold = await doc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await doc.embedFont(StandardFonts.Helvetica);

  const PAGE_W = 595.28;
  const PAGE_H = 841.89;

  function drawCard(page, x, y, width, height, bg, border, borderWidth = 1) {
    page.drawRectangle({ x, y, width, height, color: bg, borderColor: border, borderWidth });
  }

  // Page 1
  {
    const page = doc.addPage([PAGE_W, PAGE_H]);
    page.drawRectangle({ x: 0, y: 0, width: PAGE_W, height: PAGE_H, color: rgb(1, 1, 1) });

    drawCard(page, 28, PAGE_H - 170, PAGE_W - 56, 140, rgb(0.94, 0.96, 1.0), rgb(0.80, 0.88, 0.98), 1);
    page.drawText('Google Omni', { x: 50, y: PAGE_H - 75, size: 30, font: fontBold, color: rgb(0.10, 0.40, 0.90) });
    page.drawText('Step by Step', { x: 50, y: PAGE_H - 110, size: 30, font: fontBold, color: rgb(0.12, 0.15, 0.22) });
    page.drawText('Editing Guide', { x: 50, y: PAGE_H - 145, size: 30, font: fontBold, color: rgb(0.10, 0.40, 0.90) });

    page.drawText('Analyze. Edit. Refine. Create.', { x: 50, y: PAGE_H - 162, size: 10, font: fontBold, color: rgb(0.40, 0.44, 0.52) });
    page.drawText('Professional videos with Google Omni.', { x: 205, y: PAGE_H - 162, size: 10, font: fontRegular, color: rgb(0.10, 0.40, 0.90) });

    const steps = ['1 Find Reference', '2 Write Script', '3 Create Prompts', '4 Edit in Omni', '5 Refine in Chat', '6 Assemble CapCut'];
    let sx = 28;
    const sw = (PAGE_W - 56 - 5 * 6) / 6;
    steps.forEach((st) => {
      drawCard(page, sx, PAGE_H - 220, sw, 36, rgb(0.96, 0.97, 0.99), rgb(0.85, 0.88, 0.93));
      const parts = st.split(' ');
      page.drawText(parts[0], { x: sx + 6, y: PAGE_H - 200, size: 8, font: fontBold, color: rgb(0.10, 0.40, 0.90) });
      page.drawText(parts.slice(1).join(' '), { x: sx + 6, y: PAGE_H - 212, size: 7.5, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });
      sx += sw + 6;
    });

    drawCard(page, 28, PAGE_H - 325, PAGE_W - 56, 90, rgb(0.98, 0.98, 1.0), rgb(0.85, 0.89, 0.96));
    page.drawText('Edit Videos with Google Gemini Omni', { x: 120, y: PAGE_H - 255, size: 16, font: fontBold, color: rgb(0.10, 0.12, 0.16) });
    page.drawText('Use any multimodal AI to analyse a reference video and prepare scene prompts. Then use Google', { x: 45, y: PAGE_H - 275, size: 9.5, font: fontRegular, color: rgb(0.40, 0.44, 0.52) });
    page.drawText('Gemini Omni to edit, transform, and recreate that visual style with your own script, visuals, or footage.', { x: 45, y: PAGE_H - 290, size: 9.5, font: fontRegular, color: rgb(0.40, 0.44, 0.52) });
    page.drawText('REFERENCE  ->  SCRIPT  ->  AI PROMPTS  ->  OMNI EDIT  ->  REFINE  ->  CAPCUT', { x: 75, y: PAGE_H - 312, size: 8.5, font: fontBold, color: rgb(0.12, 0.42, 0.88) });

    drawCard(page, 28, PAGE_H - 490, PAGE_W - 56, 150, rgb(1, 1, 1), rgb(0.86, 0.90, 0.96));
    drawCard(page, 28, PAGE_H - 380, 48, 40, rgb(0.15, 0.45, 0.92), rgb(0.15, 0.45, 0.92));
    page.drawText('1', { x: 46, y: PAGE_H - 360, size: 20, font: fontBold, color: rgb(1, 1, 1) });
    page.drawText('Find a Reference Video', { x: 88, y: PAGE_H - 360, size: 14, font: fontBold, color: rgb(0.10, 0.12, 0.16) });
    page.drawText('Choose the style before you start generating.', { x: 88, y: PAGE_H - 374, size: 9.5, font: fontRegular, color: rgb(0.40, 0.44, 0.52) });

    const s1Bullets = [
      '• Choose a video from Instagram, TikTok, Pinterest, or YouTube with the exact pacing and aesthetic you want.',
      '• Save the video or take clear screenshots from key scenes.',
      '• Prepare your final written script before generating any visual prompts.',
      '• Collect product or character images you plan to feature.',
      '• Keep your logo, brand assets, and raw footage ready if available.'
    ];
    let by = PAGE_H - 402;
    s1Bullets.forEach(b => {
      page.drawText(b, { x: 42, y: by, size: 8.5, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });
      by -= 16;
    });

    drawCard(page, 28, PAGE_H - 640, PAGE_W - 56, 135, rgb(1, 1, 1), rgb(0.86, 0.90, 0.96));
    drawCard(page, 28, PAGE_H - 550, 48, 40, rgb(0.15, 0.45, 0.92), rgb(0.15, 0.45, 0.92));
    page.drawText('2', { x: 46, y: PAGE_H - 530, size: 20, font: fontBold, color: rgb(1, 1, 1) });
    page.drawText('Create the Prompts in Any AI Model', { x: 88, y: PAGE_H - 530, size: 14, font: fontBold, color: rgb(0.10, 0.12, 0.16) });
    page.drawText('Use ChatGPT, Claude, Gemini, or another multimodal AI.', { x: 88, y: PAGE_H - 544, size: 9.5, font: fontRegular, color: rgb(0.40, 0.44, 0.52) });

    const s2Bullets = [
      '• Upload your reference footage/screenshots into the multimodal AI session.',
      '• Attach your target script and specify target aspect ratio (9:16 vertical or 16:9 widescreen).',
      '• Request an exact scene-by-scene prompt breakdown covering camera movement, lighting, and transitions.',
      '• Enforce visual consistency across characters, colors, and background environments.'
    ];
    by = PAGE_H - 570;
    s2Bullets.forEach(b => {
      page.drawText(b, { x: 42, y: by, size: 8.5, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });
      by -= 16;
    });

    page.drawText('RAUF LABS ACADEMY', { x: 230, y: 30, size: 9, font: fontBold, color: rgb(0.15, 0.45, 0.92) });
  }

  // Page 2
  {
    const page = doc.addPage([PAGE_W, PAGE_H]);
    page.drawRectangle({ x: 0, y: 0, width: PAGE_W, height: PAGE_H, color: rgb(1, 1, 1) });

    drawCard(page, 28, 80, PAGE_W - 56, PAGE_H - 145, rgb(0.99, 0.99, 1.0), rgb(0.82, 0.88, 0.96));
    page.drawText('COPY THIS PROMPT', { x: 45, y: PAGE_H - 85, size: 12, font: fontBold, color: rgb(0.15, 0.45, 0.92) });

    const promptLines = [
      'I am attaching a reference video and my own script.',
      '',
      'Analyse the reference video and identify:',
      '- Visual and editing style',
      '- Camera movement and angles',
      '- Animation and motion dynamics',
      '- Transitions between shots',
      '- Colours and background palette',
      '- Typography and on-screen overlays',
      '- Pacing and cuts per second',
      '- Music and sound effects rhythm',
      '- Opening hook structure (first 3 seconds)',
      '- Ending call-to-action style',
      '',
      'Then divide my script into short scenes suitable for Google Gemini Omni.',
      '',
      'For each scene, write one copy-ready editing prompt that includes:',
      '- What should appear on screen',
      '- What should change from my uploaded footage or reference',
      '- Character, product, or object movement',
      '- Camera movement and focal length',
      '- Background and lighting conditions',
      '- Animation and transitions',
      '- Sound effects and music direction',
      '- Short on-screen text, only when needed',
      '- How the scene should connect to the next one',
      '',
      'Keep the visual style consistent across all scenes.',
      'Do not copy the original brand, logo, people, wording, or exact scene. Create an original version for my content.',
      '',
      'My script: [PASTE YOUR SCRIPT HERE]',
      'My required format: [9:16 OR 16:9]',
      'My preferred total duration: [ENTER DURATION, e.g. 30 SECONDS]'
    ];

    let py = PAGE_H - 110;
    promptLines.forEach(l => {
      const isHeader = l.startsWith('Analyse') || l.startsWith('For each') || l.startsWith('Keep') || l.startsWith('My ');
      page.drawText(l, {
        x: 45,
        y: py,
        size: 8.5,
        font: isHeader ? fontBold : fontRegular,
        color: l.startsWith('My ') ? rgb(0.12, 0.40, 0.90) : rgb(0.10, 0.12, 0.16)
      });
      py -= 15;
    });

    page.drawText('RAUF LABS ACADEMY', { x: 230, y: 30, size: 9, font: fontBold, color: rgb(0.15, 0.45, 0.92) });
  }

  // Page 3
  {
    const page = doc.addPage([PAGE_W, PAGE_H]);
    page.drawRectangle({ x: 0, y: 0, width: PAGE_W, height: PAGE_H, color: rgb(1, 1, 1) });

    drawCard(page, 28, PAGE_H - 150, PAGE_W - 56, 110, rgb(1, 1, 1), rgb(0.86, 0.90, 0.96));
    drawCard(page, 28, PAGE_H - 85, 48, 40, rgb(0.15, 0.45, 0.92), rgb(0.15, 0.45, 0.92));
    page.drawText('3', { x: 46, y: PAGE_H - 65, size: 20, font: fontBold, color: rgb(1, 1, 1) });
    page.drawText('Review the Scene Prompts', { x: 88, y: PAGE_H - 65, size: 14, font: fontBold, color: rgb(0.10, 0.12, 0.16) });
    page.drawText('Fix the plan before moving into Omni.', { x: 88, y: PAGE_H - 79, size: 9.5, font: fontRegular, color: rgb(0.40, 0.44, 0.52) });

    const s3Items = [
      '• Does every scene match the script? | • Is the opening hook strong in the first 2 seconds?',
      '• Are the visuals clearly connected across shots? | • Is the text short and readable on phones?',
      '• Is the character/product consistent? | • Is the final CTA prompt explicit?'
    ];
    let s3y = PAGE_H - 105;
    s3Items.forEach(it => {
      page.drawText(it, { x: 42, y: s3y, size: 8.5, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });
      s3y -= 15;
    });

    drawCard(page, 28, PAGE_H - 420, PAGE_W - 56, 255, rgb(1, 1, 1), rgb(0.86, 0.90, 0.96));
    drawCard(page, 28, PAGE_H - 200, 48, 40, rgb(0.15, 0.45, 0.92), rgb(0.15, 0.45, 0.92));
    page.drawText('4', { x: 46, y: PAGE_H - 180, size: 20, font: fontBold, color: rgb(1, 1, 1) });
    page.drawText('Edit in Google Gemini Omni', { x: 88, y: PAGE_H - 180, size: 14, font: fontBold, color: rgb(0.10, 0.12, 0.16) });
    page.drawText('Work scene by scene for maximum creative control.', { x: 88, y: PAGE_H - 194, size: 9.5, font: fontRegular, color: rgb(0.40, 0.44, 0.52) });

    const omniTable = [
      ['1', 'Upload the reference video, your raw footage, or your images.'],
      ['2', 'Paste the matching scene prompt.'],
      ['3', 'Ask Omni to transform or edit the uploaded content.'],
      ['4', 'Keep the best version and note generation seeds.'],
      ['5', 'Repeat for the remaining scenes to complete the storyline.']
    ];
    let ty = PAGE_H - 235;
    omniTable.forEach(row => {
      drawCard(page, 38, ty - 8, PAGE_W - 76, 24, rgb(0.96, 0.98, 1.0), rgb(0.88, 0.92, 0.98));
      drawCard(page, 38, ty - 8, 30, 24, rgb(0.90, 0.94, 1.0), rgb(0.84, 0.89, 0.96));
      page.drawText(row[0], { x: 50, y: ty, size: 10, font: fontBold, color: rgb(0.15, 0.45, 0.92) });
      page.drawText(row[1], { x: 78, y: ty, size: 9, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });
      ty -= 30;
    });

    drawCard(page, 28, PAGE_H - 670, PAGE_W - 56, 235, rgb(1, 1, 1), rgb(0.86, 0.90, 0.96));
    drawCard(page, 28, PAGE_H - 460, 48, 40, rgb(0.15, 0.45, 0.92), rgb(0.15, 0.45, 0.92));
    page.drawText('5', { x: 46, y: PAGE_H - 440, size: 20, font: fontBold, color: rgb(1, 1, 1) });
    page.drawText('Improve the Result in Chat', { x: 88, y: PAGE_H - 440, size: 14, font: fontBold, color: rgb(0.10, 0.12, 0.16) });
    page.drawText('Make one clear change at a time.', { x: 88, y: PAGE_H - 454, size: 9.5, font: fontRegular, color: rgb(0.40, 0.44, 0.52) });

    const chatGrid = [
      ['"Keep the video the same but make the text bigger."', '"Slow down the transition."'],
      ['"Change the background to red."', '"Keep the same person and clothing."'],
      ['"Replace the product with my product."', '"Add more camera movement."'],
      ['"Remove the extra objects."', '"Make the animation more energetic."'],
      ['"Keep the first part and change only the ending."', '"Remove all on-screen text."']
    ];
    let cgy = PAGE_H - 490;
    chatGrid.forEach(pair => {
      drawCard(page, 38, cgy - 6, (PAGE_W - 86) / 2, 22, rgb(0.98, 0.98, 1.0), rgb(0.88, 0.92, 0.98));
      drawCard(page, 38 + (PAGE_W - 86) / 2 + 10, cgy - 6, (PAGE_W - 86) / 2, 22, rgb(0.98, 0.98, 1.0), rgb(0.88, 0.92, 0.98));
      page.drawText(pair[0], { x: 46, y: cgy + 1, size: 8, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });
      page.drawText(pair[1], { x: 46 + (PAGE_W - 86) / 2 + 10, y: cgy + 1, size: 8, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });
      cgy -= 28;
    });

    page.drawText('RAUF LABS ACADEMY', { x: 230, y: 30, size: 9, font: fontBold, color: rgb(0.15, 0.45, 0.92) });
  }

  // Page 4
  {
    const page = doc.addPage([PAGE_W, PAGE_H]);
    page.drawRectangle({ x: 0, y: 0, width: PAGE_W, height: PAGE_H, color: rgb(1, 1, 1) });

    drawCard(page, 28, PAGE_H - 330, PAGE_W - 56, 300, rgb(1, 1, 1), rgb(0.86, 0.90, 0.96));
    drawCard(page, 28, PAGE_H - 85, 48, 40, rgb(0.15, 0.45, 0.92), rgb(0.15, 0.45, 0.92));
    page.drawText('6', { x: 46, y: PAGE_H - 65, size: 20, font: fontBold, color: rgb(1, 1, 1) });
    page.drawText('Assemble the Final Video', { x: 88, y: PAGE_H - 65, size: 14, font: fontBold, color: rgb(0.10, 0.12, 0.16) });
    page.drawText('Finish the edit in CapCut, Premiere, or another editor.', { x: 88, y: PAGE_H - 79, size: 9.5, font: fontRegular, color: rgb(0.40, 0.44, 0.52) });

    const s6Checklist = [
      '• Put the generated scenes in timeline order.',
      '• Add clear, high-energy voice-over (ElevenLabs or native recording).',
      '• Add background music and targeted Foley sound effects.',
      '• Add dynamic captions with word-by-word highlights.',
      '• Fix any misspelled AI-generated text with overlay titles.',
      '• Add your logo, brand watermark, and end card call-to-action.',
      '• Export at 1080x1920 (9:16) at 60fps for crisp mobile feeds.'
    ];
    let s6y = PAGE_H - 115;
    s6Checklist.forEach(chk => {
      page.drawText(chk, { x: 45, y: s6y, size: 9.5, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });
      s6y -= 22;
    });

    drawCard(page, 28, PAGE_H - 490, PAGE_W - 56, 120, rgb(0.06, 0.10, 0.18), rgb(0.12, 0.20, 0.35));
    page.drawText('SIMPLE WORKFLOW', { x: 230, y: PAGE_H - 400, size: 11, font: fontBold, color: rgb(0.40, 0.65, 0.98) });
    page.drawText('Reference video  ->  Script  ->  Prompts in any AI  ->  Edit in Gemini Omni  ->  Refine in chat  ->  CapCut', {
      x: 45, y: PAGE_H - 430, size: 8.5, font: fontBold, color: rgb(1, 1, 1)
    });
    page.drawText('The prompts can be created anywhere. The actual video editing and transformation happens in Google Gemini Omni.', {
      x: 48, y: PAGE_H - 455, size: 8.5, font: fontRegular, color: rgb(0.70, 0.78, 0.90)
    });

    drawCard(page, 28, PAGE_H - 650, PAGE_W - 56, 130, rgb(0.97, 0.99, 1.0), rgb(0.85, 0.90, 0.98));
    page.drawText('PRO-CREATOR TIP FOR VIRAL RETENTION', { x: 45, y: PAGE_H - 530, size: 11, font: fontBold, color: rgb(0.15, 0.45, 0.92) });
    page.drawText('1. Keep your cuts under 2.2 seconds during the first 6 seconds to prevent swiping.', { x: 45, y: PAGE_H - 555, size: 9, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });
    page.drawText('2. Use contrasting typography colors (yellow + white on dark backgrounds) for mobile legibility.', { x: 45, y: PAGE_H - 575, size: 9, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });
    page.drawText('3. Use Omni to change backgrounds while preserving consistent actor facial identity.', { x: 45, y: PAGE_H - 595, size: 9, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });
    page.drawText('4. Export with proper bitrate to avoid compression banding on TikTok and Instagram Reels.', { x: 45, y: PAGE_H - 615, size: 9, font: fontRegular, color: rgb(0.10, 0.12, 0.16) });

    page.drawText('RAUF LABS ACADEMY', { x: 230, y: 30, size: 9, font: fontBold, color: rgb(0.15, 0.45, 0.92) });
  }

  return await doc.save();
}

async function run() {
  console.log('Generating all 5 Rauf Labs Academy PDFs...');

  const pdfDefs = [
    {
      slug: 'google-gemini-omni-rauf-labs-academy.pdf',
      fullName: 'How to Use Google Gemini Omni for Video Editing Step-by-Step Guide - Rauf Labs Academy.pdf',
      builder: buildGeminiOmniPdf,
      pages: 4
    },
    {
      slug: 'ai-businesses-rauf-labs-academy.pdf',
      fullName: '50 Ready-Made AI Businesses You Can Launch - Rauf Labs Academy.pdf',
      builder: buildAiBusinessPdf,
      pages: 22
    },
    {
      slug: 'chatgpt-slash-commands-rauf-labs-academy.pdf',
      fullName: '100 Powerful ChatGPT Slash Commands - The Ultimate AI Command Playbook - Rauf Labs Academy.pdf',
      builder: buildSlashCommandsPdf,
      pages: 4
    },
    {
      slug: 'free-ai-tools-rauf-labs-academy.pdf',
      fullName: 'Free AI Tools for Students in South Asia - Rauf Labs Academy.pdf',
      builder: buildStudentToolsPdf,
      pages: 5
    },
    {
      slug: 'free-ai-gateway-rauf-labs-academy.pdf',
      fullName: 'The Free AI Gateway Setup Most People Still Dont Know About - Rauf Labs Academy.pdf',
      builder: buildGatewayPdf,
      pages: 25
    }
  ];

  for (const def of pdfDefs) {
    console.log(`Building ${def.slug} (${def.pages} pages)...`);
    const buffer = await def.builder();

    // Write to public/pdfs/ with slug
    fs.writeFileSync(path.join(PUBLIC_PDF_DIR, def.slug), buffer);
    // Write to public/pdfs/ with full name
    fs.writeFileSync(path.join(PUBLIC_PDF_DIR, def.fullName), buffer);

    // Also write to root /pdfs/ for direct static serving fallback
    fs.writeFileSync(path.join(ROOT_PDF_DIR, def.slug), buffer);
    fs.writeFileSync(path.join(ROOT_PDF_DIR, def.fullName), buffer);

    console.log(`✓ Saved ${def.slug} (${(buffer.length / 1024).toFixed(1)} KB)`);
  }

  console.log('All 5 Rauf Labs Academy PDFs successfully generated and saved!');
}

run().catch(err => {
  console.error('Build error:', err);
  process.exit(1);
});

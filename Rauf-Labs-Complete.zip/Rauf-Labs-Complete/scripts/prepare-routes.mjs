import fs from 'node:fs';
import path from 'node:path';

const ROOT_DIR = process.cwd();

const ROUTE_FILES = [
  { file: 'index.html', route: '/' },
  { file: 'developer.html', route: '/developer' },
  { file: 'android.html', route: '/android' },
  { file: 'roadmap.html', route: '/roadmap' },
  { file: 'creator.html', route: '/creator' },
  { file: 'tools.html', route: '/tools' },
  { file: 'resources.html', route: '/resources' },
  { file: 'ai.html', route: '/ai' },
  { file: 'login.html', route: '/login' },
  { file: 'about.html', route: '/about' },
  { file: 'skills.html', route: '/skills' },
  { file: 'projects.html', route: '/projects' },
  { file: 'blog.html', route: '/blog' },
  { file: 'contact.html', route: '/contact' },
  { file: 'termux.html', route: '/termux' },
  { file: 'linux.html', route: '/linux' },
  { file: 'powershell.html', route: '/powershell' },
  { file: 'bash.html', route: '/bash' },
  { file: 'git.html', route: '/git' },
  { file: 'programming.html', route: '/programming' },
  { file: 'apis.html', route: '/apis' },
  { file: 'opensource.html', route: '/opensource' },
  { file: 'pdfs.html', route: '/pdfs' },
  { file: 'courses.html', route: '/courses' },
  { file: 'qr.html', route: '/qr' },
  { file: '404.html', route: '/404' }
];

const LINK_REPLACEMENTS = [
  [/(href=["'])\.?\/?index\.html(["'])/g, '$1/$2'],
  [/(href=["'])\.?\/?developer\.html(["'])/g, '$1/developer$2'],
  [/(href=["'])\.?\/?android\.html(["'])/g, '$1/android$2'],
  [/(href=["'])\.?\/?roadmap\.html(["'])/g, '$1/roadmap$2'],
  [/(href=["'])\.?\/?creator\.html(["'])/g, '$1/creator$2'],
  [/(href=["'])\.?\/?tools\.html(["'])/g, '$1/tools$2'],
  [/(href=["'])\.?\/?resources\.html(["'])/g, '$1/resources$2'],
  [/(href=["'])\.?\/?ai\.html(["'])/g, '$1/ai$2'],
  [/(href=["'])\.?\/?login\.html(["'])/g, '$1/login$2'],
  [/(href=["'])\.?\/?about\.html(["'])/g, '$1/about$2'],
  [/(href=["'])\.?\/?skills\.html(["'])/g, '$1/skills$2'],
  [/(href=["'])\.?\/?projects\.html(["'])/g, '$1/projects$2'],
  [/(href=["'])\.?\/?blog\.html(["'])/g, '$1/blog$2'],
  [/(href=["'])\.?\/?contact\.html(["'])/g, '$1/contact$2'],
  [/(href=["'])\.?\/?termux\.html(["'])/g, '$1/termux$2'],
  [/(href=["'])\.?\/?linux\.html(["'])/g, '$1/linux$2'],
  [/(href=["'])\.?\/?powershell\.html(["'])/g, '$1/powershell$2'],
  [/(href=["'])\.?\/?bash\.html(["'])/g, '$1/bash$2'],
  [/(href=["'])\.?\/?git\.html(["'])/g, '$1/git$2'],
  [/(href=["'])\.?\/?programming\.html(["'])/g, '$1/programming$2'],
  [/(href=["'])\.?\/?apis\.html(["'])/g, '$1/apis$2'],
  [/(href=["'])\.?\/?opensource\.html(["'])/g, '$1/opensource$2'],
  [/(href=["'])\.?\/?pdfs\.html(["'])/g, '$1/pdfs$2'],
  [/(href=["'])\.?\/?courses\.html(["'])/g, '$1/courses$2'],
  [/(href=["'])\.?\/?qr\.html(["'])/g, '$1/qr$2'],
  [/(href=["'])\.?\/?404\.html(["'])/g, '$1/404$2'],
];

function cleanLinks(html) {
  let res = html;
  for (const [regex, rep] of LINK_REPLACEMENTS) {
    res = res.replace(regex, rep);
  }
  return res;
}

const routesObj = {};

for (const { file, route } of ROUTE_FILES) {
  const filePath = path.join(ROOT_DIR, file);
  if (!fs.existsSync(filePath)) {
    console.warn(`File missing: ${file}`);
    continue;
  }

  let content = fs.readFileSync(filePath, 'utf-8');
  // Clean links in the HTML file itself
  content = cleanLinks(content);

  // Ensure script tags: routesData.js before script.js
  if (!content.includes('routesData.js')) {
    content = content.replace('<script src="script.js"></script>', '<script src="/routesData.js"></script>\n    <script src="/script.js"></script>');
    content = content.replace('<script src="/script.js"></script>', '<script src="/routesData.js"></script>\n    <script src="/script.js"></script>');
    // remove duplicate if any
    content = content.replace('<script src="/routesData.js"></script>\n    <script src="/routesData.js"></script>', '<script src="/routesData.js"></script>');
  }

  // Ensure css path is absolute /style.css
  content = content.replace('href="style.css"', 'href="/style.css"');

  // Save back updated clean HTML
  fs.writeFileSync(filePath, content, 'utf-8');

  // Extract title
  const titleMatch = content.match(/<title>(.*?)<\/title>/is);
  const title = titleMatch ? titleMatch[1].trim() : 'Rauf Labs';

  // Extract description
  const descMatch = content.match(/<meta\s+name=["']description["']\s+content=["'](.*?)["']/is);
  const description = descMatch ? descMatch[1].trim() : '';

  // Extract <main class="main-content"> ... </main>
  const mainMatch = content.match(/<main class=["']main-content["'][^>]*>([\s\S]*?)<\/main>/is);
  const mainInner = mainMatch ? mainMatch[1].trim() : '';

  routesObj[route] = {
    title,
    description,
    content: mainInner
  };
}

// Write routesData.js
const routesDataJs = `/**
 * Pre-compiled Client Routes for Instant SPA Navigation
 * Generated automatically by prepare-routes.mjs
 */
window.RAUF_ROUTES = ${JSON.stringify(routesObj, null, 2)};
`;

fs.writeFileSync(path.join(ROOT_DIR, 'routesData.js'), routesDataJs, 'utf-8');
const publicDir = path.join(ROOT_DIR, 'public');
if (fs.existsSync(publicDir)) {
  fs.writeFileSync(path.join(publicDir, 'routesData.js'), routesDataJs, 'utf-8');
  fs.copyFileSync(path.join(ROOT_DIR, 'script.js'), path.join(publicDir, 'script.js'));
  fs.copyFileSync(path.join(ROOT_DIR, 'style.css'), path.join(publicDir, 'style.css'));
  if (fs.existsSync(path.join(ROOT_DIR, 'creatorHubData.js'))) {
    fs.copyFileSync(path.join(ROOT_DIR, 'creatorHubData.js'), path.join(publicDir, 'creatorHubData.js'));
  }
  if (fs.existsSync(path.join(ROOT_DIR, 'creatorHub.js'))) {
    fs.copyFileSync(path.join(ROOT_DIR, 'creatorHub.js'), path.join(publicDir, 'creatorHub.js'));
  }
  if (fs.existsSync(path.join(ROOT_DIR, 'coursesData.js'))) {
    fs.copyFileSync(path.join(ROOT_DIR, 'coursesData.js'), path.join(publicDir, 'coursesData.js'));
  }
  if (fs.existsSync(path.join(ROOT_DIR, 'coursesEngine.js'))) {
    fs.copyFileSync(path.join(ROOT_DIR, 'coursesEngine.js'), path.join(publicDir, 'coursesEngine.js'));
  }
  if (fs.existsSync(path.join(ROOT_DIR, 'pdfLibrary.js'))) {
    fs.copyFileSync(path.join(ROOT_DIR, 'pdfLibrary.js'), path.join(publicDir, 'pdfLibrary.js'));
  }
  if (fs.existsSync(path.join(ROOT_DIR, 'pdfsData.js'))) {
    fs.copyFileSync(path.join(ROOT_DIR, 'pdfsData.js'), path.join(publicDir, 'pdfsData.js'));
  }
}
console.log(`Successfully generated routesData.js with ${Object.keys(routesObj).length} routes!`);

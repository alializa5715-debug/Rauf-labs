import fs from 'node:fs';
import path from 'node:path';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

const c = {
  bg: rgb(0.05, 0.06, 0.09),
  card: rgb(0.09, 0.11, 0.16),
  cardLight: rgb(0.12, 0.14, 0.20),
  border: rgb(0.18, 0.22, 0.30),
  red: rgb(0.92, 0.20, 0.25),
  redBg: rgb(0.20, 0.05, 0.08),
  white: rgb(0.96, 0.97, 0.99),
  gray: rgb(0.65, 0.69, 0.78),
  dim: rgb(0.42, 0.46, 0.55),
  cyan: rgb(0.15, 0.75, 0.88),
};

function drawCard(page, x, y, width, height, bg, border, borderWidth = 1) {
  page.drawRectangle({ x, y, width, height, color: bg, borderColor: border, borderWidth });
}

export async function buildSlashCommandsPdf() {
  const doc = await PDFDocument.create();
  const fontBold = await doc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await doc.embedFont(StandardFonts.Helvetica);
  const fontMono = await doc.embedFont(StandardFonts.CourierBold);

  const W = 595.28;
  const H = 841.89;

  // Helper for drawing command rows
  function drawCommandItem(page, num, name, desc, x, y, w) {
    page.drawText(num, { x, y, size: 8, font: fontBold, color: c.red });
    page.drawText(name, { x: x + 16, y, size: 8, font: fontMono, color: rgb(0.98, 0.70, 0.75) });
    page.drawText(desc, { x: x + 82, y, size: 7.5, font: fontRegular, color: c.gray });
  }

  function drawSectionHeader(page, title, y) {
    page.drawRectangle({ x: 28, y: y - 2, width: 3, height: 12, color: c.red });
    page.drawText(title, { x: 36, y, size: 10, font: fontBold, color: c.white });
  }

  // ==========================================
  // PAGE 1: Header + Section 01 (Commands 1-20)
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    // Top Header
    page.drawRectangle({ x: 28, y: H - 52, width: 4, height: 16, color: c.red });
    page.drawText('RAUF LABS ACADEMY', { x: 38, y: H - 48, size: 10, font: fontBold, color: c.white });
    page.drawText('COMMAND PLAYBOOK', { x: 28, y: H - 85, size: 8, font: fontBold, color: c.red });
    page.drawText('100 COMMANDS / 4-PAGE INDEX', { x: W - 170, y: H - 85, size: 8, font: fontBold, color: c.dim });

    page.drawText('CHATGPT / PROMPT PLAYBOOK', { x: 28, y: H - 105, size: 8, font: fontBold, color: c.red });
    page.drawText('100 POWERFUL', { x: 28, y: H - 138, size: 26, font: fontBold, color: c.white });
    page.drawText('CHATGPT AI', { x: 28, y: H - 168, size: 26, font: fontBold, color: c.red });
    page.drawText('SLASH COMMANDS', { x: 28, y: H - 198, size: 26, font: fontBold, color: c.white });

    page.drawText('A practical visual index of prompt shortcuts for ideas, research, strategy, learning, and execution.', {
      x: 28, y: H - 222, size: 9, font: fontRegular, color: c.gray
    });

    // HOW TO USE Box
    drawCard(page, 28, H - 280, W - 56, 44, c.card, c.border);
    page.drawText('HOW TO USE', { x: 40, y: H - 250, size: 8, font: fontBold, color: c.red });
    page.drawText('Type the slash command followed by your topic, like:', { x: 40, y: H - 263, size: 7.5, font: fontRegular, color: c.gray });
    page.drawText('/handwritten Explain photosynthesis with diagrams.', { x: 40, y: H - 274, size: 8, font: fontMono, color: c.white });

    page.drawText('These are prompt shortcuts, not official built-in commands. Results can vary by platform.', {
      x: 28, y: H - 296, size: 7, font: fontRegular, color: c.dim
    });

    // Section 01: VISUAL & IMAGE GENERATION
    drawSectionHeader(page, '01 VISUAL & IMAGE GENERATION', H - 320);

    const s1 = [
      ['01', '/visualize', 'turns any concept or process into a visual.'],
      ['02', '/handwritten', 'creates notebook-style handwritten notes and study sheets.'],
      ['03', '/infographic', 'builds a structured infographic with icons and stats.'],
      ['04', '/diagram', 'draws a technical or educational diagram.'],
      ['05', '/flowchart', 'maps a step-by-step process or decision flow.'],
      ['06', '/mindmap', 'explores a topic and its connected ideas.'],
      ['07', '/xray', 'reveals what happens inside a body, machine or system.'],
      ['08', '/blueprint', 'generates a detailed technical blueprint.'],
      ['09', '/explodedview', 'breaks an object into parts and shows how they fit.'],
      ['10', '/thenvsnow', 'compares the past against the present.'],
      ['11', '/timeline', 'shows the chronological evolution of something.'],
      ['12', '/beforeafter', 'showcases a transformation between two states.'],
      ['13', '/cutaway', 'reveals the internal structure of a building or machine.'],
      ['14', '/anatomy', 'breaks down what makes something work.'],
      ['15', '/layers', 'explains a system through its architectural layers.'],
      ['16', '/ecosystem', 'maps the players and parts of an industry.'],
      ['17', '/journey', 'shows an end-to-end journey of a product or process.'],
      ['18', '/process', 'explains how something is made or executed.'],
      ['19', '/cycle', 'explains recurring or cyclical processes.'],
      ['20', '/roadmap', 'visualizes a learning path or execution plan.']
    ];

    let y1 = H - 345;
    s1.forEach(row => {
      drawCommandItem(page, row[0], row[1], row[2], 28, y1, W - 56);
      y1 -= 20;
    });

    // Footer
    page.drawText('RAUF LABS ACADEMY', { x: 28, y: 24, size: 8, font: fontBold, color: c.dim });
    page.drawText('THEMED EDITION / PROMPT PLAYBOOK', { x: 28, y: 14, size: 7, font: fontRegular, color: c.dim });
    page.drawText('01 | rauflabs.com/academy', { x: W - 175, y: 24, size: 8, font: fontBold, color: c.red });
  }

  // ==========================================
  // PAGE 2: Section 02, 03, 04 (Commands 21-54)
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawRectangle({ x: 28, y: H - 52, width: 4, height: 16, color: c.red });
    page.drawText('RAUF LABS ACADEMY', { x: 38, y: H - 48, size: 10, font: fontBold, color: c.white });
    page.drawText('COMMAND INDEX / 21-54', { x: 28, y: H - 85, size: 8, font: fontBold, color: c.red });
    page.drawText('100 COMMANDS / 4-PAGE INDEX', { x: W - 170, y: H - 85, size: 8, font: fontBold, color: c.dim });

    // Section 02: DATA, COMPARISON & SYSTEM VISUALIZATION (21-41)
    drawSectionHeader(page, '02 DATA, COMPARISON & SYSTEM VISUALIZATION', H - 115);
    const s2 = [
      ['21', '/dashboard', 'turns metrics and KPIs into a dashboard visual.'],
      ['22', '/comparison', 'compares concepts or products side by side.'],
      ['23', '/versus', 'creates a dramatic head-to-head comparison.'],
      ['24', '/scale', 'shows big differences in size or magnitude.'],
      ['25', '/evolution', 'shows how something changed over time.'],
      ['26', '/future', 'imagines and visualizes a future scenario.'],
      ['27', '/inside', 'explains the hidden inner workings of a system.'],
      ['28', '/microscopic', 'visualizes processes at the microscopic level.'],
      ['29', '/macroscopic', 'visualizes large-scale networks and systems.'],
      ['30', '/crosssection', 'shows a cross-sectional view of an object.'],
      ['31', '/map', 'creates a geographic, strategic or conceptual map.'],
      ['32', '/heatmap', 'shows intensity or activity across regions.'],
      ['33', '/network', 'visualizes connections between people or systems.'],
      ['34', '/architecture', 'creates a system architecture for software or AI.'],
      ['35', '/wireframe', 'lays out the structure of an app or website.'],
      ['36', '/mockup', 'generates a realistic product or app preview.'],
      ['37', '/prototype', 'visualizes an early-stage product concept.'],
      ['38', '/schematic', 'shows components and connections simply.'],
      ['39', '/isometric', 'generates an isometric 3D-style view.'],
      ['40', '/birdseye', 'shows something from a top-down view.'],
      ['41', '/360view', 'presents a concept from multiple angles.']
    ];
    let y2 = H - 135;
    s2.forEach(row => {
      drawCommandItem(page, row[0], row[1], row[2], 28, y2, W - 56);
      y2 -= 18;
    });

    // Section 03: CREATIVE, MARKETING & SOCIAL MEDIA (42-50)
    drawSectionHeader(page, '03 CREATIVE, MARKETING & SOCIAL MEDIA', y2 - 10);
    const s3 = [
      ['42', '/storyboard', 'plans a video or ad scene by scene.'],
      ['43', '/comic', 'explains a concept through comic panels.'],
      ['44', '/poster', 'creates a promotional or awareness poster.'],
      ['45', '/cover', 'designs a book, magazine or report cover.'],
      ['46', '/adcreative', 'creates visual advertising concepts.'],
      ['47', '/thumbnail', 'designs an attention-grabbing thumbnail.'],
      ['48', '/carousel', 'builds a multi-slide Instagram or LinkedIn carousel.'],
      ['49', '/socialvisual', 'generates social-media-ready visuals.'],
      ['50', '/quotevisual', 'turns a quote into a shareable graphic.']
    ];
    let y3 = y2 - 30;
    s3.forEach(row => {
      drawCommandItem(page, row[0], row[1], row[2], 28, y3, W - 56);
      y3 -= 18;
    });

    // Section 04: LEARNING & EXPLANATION (51-54)
    drawSectionHeader(page, '04 LEARNING & EXPLANATION', y3 - 10);
    const s4a = [
      ['51', '/eli5', 'explains a complex idea in super simple words.'],
      ['52', '/expert', 'gives a technically rigorous expert explanation.'],
      ['53', '/firstprinciples', 'breaks a problem down to fundamental truths.'],
      ['54', '/deepdive', 'explores a complex topic in full.']
    ];
    let y4 = y3 - 30;
    s4a.forEach(row => {
      drawCommandItem(page, row[0], row[1], row[2], 28, y4, W - 56);
      y4 -= 18;
    });

    page.drawText('RAUF LABS ACADEMY', { x: 28, y: 24, size: 8, font: fontBold, color: c.dim });
    page.drawText('THEMED EDITION / PROMPT PLAYBOOK', { x: 28, y: 14, size: 7, font: fontRegular, color: c.dim });
    page.drawText('02 | rauflabs.com/academy', { x: W - 175, y: 24, size: 8, font: fontBold, color: c.red });
  }

  // ==========================================
  // PAGE 3: Section 04 cont., 05, 06 (Commands 55-90)
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawRectangle({ x: 28, y: H - 52, width: 4, height: 16, color: c.red });
    page.drawText('RAUF LABS ACADEMY', { x: 38, y: H - 48, size: 10, font: fontBold, color: c.white });
    page.drawText('COMMAND INDEX / 55-90', { x: 28, y: H - 85, size: 8, font: fontBold, color: c.red });
    page.drawText('100 COMMANDS / 4-PAGE INDEX', { x: W - 170, y: H - 85, size: 8, font: fontBold, color: c.dim });

    // Section 04 cont (55-63)
    drawSectionHeader(page, '04 LEARNING & EXPLANATION', H - 115);
    const s4b = [
      ['55', '/simplify', 'converts complex text into an easier format.'],
      ['56', '/analogy', 'explains hard ideas with real-world comparisons.'],
      ['57', '/socratic', 'teaches through guided questions.'],
      ['58', '/teachme', 'turns the AI into a structured personal tutor.'],
      ['59', '/cheatsheet', 'generates a quick-reference revision guide.'],
      ['60', '/flashcards', 'creates question-and-answer revision cards.'],
      ['61', '/quiz', 'tests your knowledge with questions.'],
      ['62', '/viva', 'generates viva questions and model answers.'],
      ['63', '/interview', 'runs a realistic mock interview.']
    ];
    let y4b = H - 135;
    s4b.forEach(row => {
      drawCommandItem(page, row[0], row[1], row[2], 28, y4b, W - 56);
      y4b -= 18;
    });

    // Section 05: CRITICAL THINKING & DECISION-MAKING (64-76)
    drawSectionHeader(page, '05 CRITICAL THINKING & DECISION-MAKING', y4b - 10);
    const s5 = [
      ['64', '/devilsadvocate', 'challenges your assumptions and ideas.'],
      ['65', '/factcheck', 'verifies whether a claim is accurate.'],
      ['66', '/mythsvsfact', 'separates misconceptions from facts.'],
      ['67', '/proscons', 'analyzes benefits and drawbacks.'],
      ['68', '/swot', 'runs a strengths, weaknesses, opportunities, threats analysis.'],
      ['69', '/pestle', 'analyzes political, economic, social and other factors.'],
      ['70', '/fiveforces', 'applies Porter\'s Five Forces to an industry.'],
      ['71', '/rootcause', 'finds the underlying cause of a problem.'],
      ['72', '/fivewhys', 'traces a problem to its fundamental cause.'],
      ['73', '/decisionmatrix', 'compares options against weighted criteria.'],
      ['74', '/scenario', 'explores multiple future outcomes.'],
      ['75', '/simulate', 'simulates a negotiation or business situation.'],
      ['76', '/roleplay', 'acts as a specific expert or professional.']
    ];
    let y5 = y4b - 30;
    s5.forEach(row => {
      drawCommandItem(page, row[0], row[1], row[2], 28, y5, W - 56);
      y5 -= 18;
    });

    // Section 06: BUSINESS, STRATEGY & CONSULTING (77-90)
    drawSectionHeader(page, '06 BUSINESS, STRATEGY & CONSULTING', y5 - 10);
    const s6 = [
      ['77', '/consultant', 'solves a business problem with consulting frameworks.'],
      ['78', '/executivebrief', 'turns complex info into a management briefing.'],
      ['79', '/insights', 'extracts patterns and insights from data.'],
      ['80', '/recommendations', 'generates evidence-based recommendations.'],
      ['81', '/prioritize', 'ranks tasks or ideas by impact and urgency.'],
      ['82', '/benchmark', 'compares you against competitors or standards.'],
      ['83', '/marketmap', 'maps competitors and stakeholders in an industry.'],
      ['84', '/strategy', 'develops a structured strategic action plan.'],
      ['85', '/businessmodel', 'explains how a company makes money.'],
      ['86', '/pitch', 'creates a compelling startup or investor pitch.'],
      ['87', '/investor', 'evaluates a business from an investor\'s view.'],
      ['88', '/redteam', 'stress-tests a plan to expose weaknesses.'],
      ['89', '/premortem', 'assumes failure and finds the likely reasons.'],
      ['90', '/reverseengineer', 'deconstructs why something succeeded.']
    ];
    let y6 = y5 - 30;
    s6.forEach(row => {
      drawCommandItem(page, row[0], row[1], row[2], 28, y6, W - 56);
      y6 -= 18;
    });

    page.drawText('RAUF LABS ACADEMY', { x: 28, y: 24, size: 8, font: fontBold, color: c.dim });
    page.drawText('THEMED EDITION / PROMPT PLAYBOOK', { x: 28, y: 14, size: 7, font: fontRegular, color: c.dim });
    page.drawText('03 | rauflabs.com/academy', { x: W - 175, y: 24, size: 8, font: fontBold, color: c.red });
  }

  // ==========================================
  // PAGE 4: Section 07 (91-100) + Top 10 Card
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawRectangle({ x: 28, y: H - 52, width: 4, height: 16, color: c.red });
    page.drawText('RAUF LABS ACADEMY', { x: 38, y: H - 48, size: 10, font: fontBold, color: c.white });
    page.drawText('COMMAND INDEX / 91-100', { x: 28, y: H - 85, size: 8, font: fontBold, color: c.red });
    page.drawText('100 COMMANDS / 4-PAGE INDEX', { x: W - 170, y: H - 85, size: 8, font: fontBold, color: c.dim });

    // Section 07: RESEARCH, PRODUCTIVITY & EXECUTION
    drawSectionHeader(page, '07 RESEARCH, PRODUCTIVITY & EXECUTION', H - 115);
    const s7 = [
      ['91', '/promptengineer', 'upgrades a basic prompt into a powerful one.'],
      ['92', '/research', 'runs structured research on any topic.'],
      ['93', '/sources', 'finds reliable and official information sources.'],
      ['94', '/summarize', 'condenses long documents into key points.'],
      ['95', '/extract', 'pulls specific structured info from text.'],
      ['96', '/table', 'converts messy information into a clean table.'],
      ['97', '/presentation', 'builds the structure for a professional deck.'],
      ['98', '/dashboardanalysis', 'analyzes a dashboard for trends and risks.'],
      ['99', '/actionplan', 'turns a goal into a step-by-step plan.'],
      ['100', '/onepager', 'condenses a big topic into a one-page document.']
    ];
    let y7 = H - 135;
    s7.forEach(row => {
      drawCommandItem(page, row[0], row[1], row[2], 28, y7, W - 56);
      y7 -= 20;
    });

    // TOP 10 CARD
    drawCard(page, 28, y7 - 180, W - 56, 170, c.card, c.border);
    drawCard(page, 28, y7 - 40, W - 56, 30, c.red, c.red);
    page.drawText('TOP 10 FOR MAXIMUM VISUAL IMPACT', { x: 42, y: y7 - 25, size: 10, font: fontBold, color: c.white });

    page.drawText('Start with these to create visual, memorable outputs:', { x: 42, y: y7 - 60, size: 8, font: fontRegular, color: c.gray });

    const top10Left = [
      ['01', '/xray'],
      ['03', '/blueprint'],
      ['05', '/isometric'],
      ['07', '/thenvsnow'],
      ['09', '/anatomy']
    ];
    const top10Right = [
      ['02', '/explodedview'],
      ['04', '/cutaway'],
      ['06', '/microscopic'],
      ['08', '/inside'],
      ['10', '/future']
    ];

    let ty = y7 - 85;
    for (let i = 0; i < 5; i++) {
      page.drawText(top10Left[i][0], { x: 42, y: ty, size: 9, font: fontBold, color: c.red });
      page.drawText(top10Left[i][1], { x: 70, y: ty, size: 9, font: fontMono, color: c.white });

      page.drawText(top10Right[i][0], { x: 280, y: ty, size: 9, font: fontBold, color: c.red });
      page.drawText(top10Right[i][1], { x: 308, y: ty, size: 9, font: fontMono, color: c.white });
      ty -= 18;
    }

    // Callout footer
    page.drawText('RAUF LABS ACADEMY', { x: 28, y: 110, size: 9, font: fontBold, color: c.gray });
    page.drawText('PROMPT. BUILD. SHIP.', { x: 28, y: 88, size: 14, font: fontBold, color: c.red });

    page.drawText('RAUF LABS ACADEMY', { x: 28, y: 24, size: 8, font: fontBold, color: c.dim });
    page.drawText('THEMED EDITION / PROMPT PLAYBOOK', { x: 28, y: 14, size: 7, font: fontRegular, color: c.dim });
    page.drawText('04 | rauflabs.com/academy', { x: W - 175, y: 24, size: 8, font: fontBold, color: c.red });
  }

  return await doc.save();
}

import fs from 'node:fs';
import path from 'node:path';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

const c = {
  bg: rgb(0.06, 0.02, 0.03),
  bgDark: rgb(0.04, 0.01, 0.02),
  card: rgb(0.11, 0.04, 0.06),
  cardLight: rgb(0.16, 0.06, 0.09),
  border: rgb(0.28, 0.10, 0.14),
  red: rgb(0.92, 0.18, 0.24),
  redDark: rgb(0.65, 0.10, 0.15),
  redLight: rgb(0.98, 0.70, 0.75),
  white: rgb(0.96, 0.97, 0.99),
  gray: rgb(0.70, 0.72, 0.80),
  dim: rgb(0.48, 0.44, 0.50),
  monoBg: rgb(0.08, 0.02, 0.04),
  cyan: rgb(0.20, 0.75, 0.88),
  green: rgb(0.25, 0.80, 0.45)
};

function drawCard(page, x, y, width, height, bg, border, borderWidth = 1) {
  page.drawRectangle({ x, y, width, height, color: bg, borderColor: border, borderWidth });
}

export async function buildGatewayPdf() {
  const doc = await PDFDocument.create();
  const fontBold = await doc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await doc.embedFont(StandardFonts.Helvetica);
  const fontMono = await doc.embedFont(StandardFonts.CourierBold);

  const W = 595.28;
  const H = 841.89;

  // Helper for page headers
  function drawPageHeader(page, section, pageNum) {
    page.drawText('RAUF LABS', { x: 28, y: H - 45, size: 9, font: fontBold, color: c.red });
    page.drawText('FREE AI GATEWAY SETUP GUIDE', { x: 95, y: H - 45, size: 8, font: fontRegular, color: c.dim });
    page.drawText(`${section} | PAGE ${pageNum < 10 ? '0' + pageNum : pageNum}`, { x: W - 180, y: H - 45, size: 8, font: fontBold, color: c.red });
  }

  function drawPageFooter(page, pageNum) {
    page.drawText('RAUF LABS ACADEMY • PRACTICAL AI PLAYBOOK • SEPTEMBER 2026', { x: 28, y: 30, size: 8, font: fontBold, color: c.dim });
    page.drawText(`${pageNum}`, { x: W - 40, y: 30, size: 8, font: fontBold, color: c.dim });
  }

  // ==========================================
  // PAGE 1: COVER
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawRectangle({ x: 38, y: H - 65, width: 4, height: 18, color: c.red });
    page.drawText('RAUF LABS', { x: 50, y: H - 60, size: 11, font: fontBold, color: c.white });
    page.drawText('PRACTICAL SETUP PLAYBOOK', { x: 38, y: H - 95, size: 9, font: fontBold, color: c.red });

    page.drawText('FREE AI GATEWAY', { x: 38, y: H - 195, size: 32, font: fontBold, color: c.white });
    page.drawText('SETUP GUIDE', { x: 38, y: H - 235, size: 32, font: fontBold, color: c.red });

    page.drawText('CLAUDE CODE | CODEX | OPENCLAW', { x: 38, y: H - 275, size: 12, font: fontBold, color: c.gray });

    page.drawText('How to run modern AI developer tooling using free upstream LLM quotas through local gateway proxies.', {
      x: 38, y: H - 310, size: 9.5, font: fontRegular, color: c.gray
    });

    // 4 Badges
    const b = [
      '• Zero Subscription Cost: Route requests through free-tier API quotas',
      '• Full OpenAI API Compatibility: Drop-in replacement base URLs',
      '• Supports Claude Code CLI, GitHub Copilot, and OpenClaw',
      '• Step-by-Step commands with copy-paste configs and test scripts'
    ];
    let by = H - 365;
    b.forEach(item => {
      drawCard(page, 38, by - 6, W - 76, 28, c.card, c.border);
      page.drawText(item, { x: 48, y: by + 3, size: 8.5, font: fontBold, color: c.white });
      by -= 38;
    });

    page.drawText('EDITION: SEPTEMBER 2026 • CURATED BY RAUF LABS ACADEMY', {
      x: 38, y: 50, size: 8.5, font: fontBold, color: c.dim
    });
  }

  // ==========================================
  // PAGE 2: START HERE / TABLE OF CONTENTS
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });
    drawPageHeader(page, 'INDEX', 2);

    page.drawText('START HERE', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.red });
    page.drawText('How to Use This Practical Playbook', { x: 28, y: H - 115, size: 22, font: fontBold, color: c.white });

    const rules = [
      ['RULE 1: FREE DOES NOT MEAN KEYLESS', 'You will still register for official developer accounts on Google AI Studio, Groq, or Mistral. You simply obtain zero-cost free-tier API keys.'],
      ['RULE 2: CLAUDE MEANS CLAUDE CODE', 'This guide connects terminal coding agents (Claude Code CLI, OpenClaw, Codex). It does not unlock paid Anthropic web consumer chat.'],
      ['RULE 3: GATEWAYS ARE TRANSLATION PROXIES', 'The local gateway translates OpenAI-style requests into upstream Gemini/Groq formats on localhost with zero middleman telemetry.']
    ];
    let ry = H - 150;
    rules.forEach(r => {
      drawCard(page, 28, ry - 32, W - 56, 48, c.card, c.border);
      page.drawText(r[0], { x: 40, y: ry - 2, size: 9, font: fontBold, color: c.red });
      page.drawText(r[1], { x: 40, y: ry - 18, size: 8, font: fontRegular, color: c.gray });
      ry -= 56;
    });

    page.drawText('TABLE OF CONTENTS', { x: 28, y: ry - 20, size: 11, font: fontBold, color: c.white });
    const toc = [
      ['01 Architecture in One Picture', 'What gateways do vs what they do not do', 'Page 03'],
      ['02 Prerequisites & CLI Installation', 'Installing Node.js, Claude Code, Codex, and OpenClaw', 'Page 04'],
      ['03 Master URL & Port Cheat Sheet', 'Ports 3001 and 20128 configuration matrices', 'Page 05'],
      ['04 Part 1: FreeLLMAPI Setup', 'Complete guide from zero to first completion', 'Pages 06-13'],
      ['05 Part 2: OmniRoute Setup', 'Multi-provider fallback gateway configuration', 'Pages 14-20'],
      ['06 Troubleshooting & Diagnostics', 'Fixing 401s, 429s, SSL certs, and stream hang issues', 'Pages 21-22'],
      ['07 Security, Privacy & Key Hygiene', 'Preventing key leakage and local audit policies', 'Page 23'],
      ['08 Final Checklist & Verification', 'End-to-end curl and agent test suite', 'Pages 24-25']
    ];
    let ty = ry - 45;
    toc.forEach(t => {
      page.drawText(t[0], { x: 28, y: ty, size: 8.5, font: fontBold, color: c.white });
      page.drawText(t[1], { x: 200, y: ty, size: 8, font: fontRegular, color: c.gray });
      page.drawText(t[2], { x: W - 90, y: ty, size: 8, font: fontBold, color: c.red });
      ty -= 22;
    });

    drawPageFooter(page, 2);
  }

  // ==========================================
  // PAGE 3: THE SETUP IN ONE PICTURE
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });
    drawPageHeader(page, 'ARCHITECTURE', 3);

    page.drawText('SYSTEM ARCHITECTURE', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.red });
    page.drawText('The Setup in One Picture', { x: 28, y: H - 115, size: 22, font: fontBold, color: c.white });

    drawCard(page, 28, H - 280, W - 56, 150, c.card, c.border);
    page.drawText('LOCAL AGENTS', { x: 60, y: H - 150, size: 10, font: fontBold, color: c.cyan });
    page.drawText('Claude Code CLI', { x: 60, y: H - 175, size: 8.5, font: fontRegular, color: c.white });
    page.drawText('Codex / Copilot', { x: 60, y: H - 195, size: 8.5, font: fontRegular, color: c.white });
    page.drawText('OpenClaw Terminal', { x: 60, y: H - 215, size: 8.5, font: fontRegular, color: c.white });

    page.drawText('------ HTTP localhost ------->', { x: 190, y: H - 185, size: 8.5, font: fontMono, color: c.red });

    page.drawText('LOCAL GATEWAY', { x: 380, y: H - 150, size: 10, font: fontBold, color: c.green });
    page.drawText('FreeLLMAPI (:3001)', { x: 380, y: H - 175, size: 8.5, font: fontRegular, color: c.white });
    page.drawText('or OmniRoute (:20128)', { x: 380, y: H - 195, size: 8.5, font: fontRegular, color: c.white });
    page.drawText('Translates & Routes', { x: 380, y: H - 215, size: 8.5, font: fontRegular, color: c.gray });

    page.drawText('==================== UPSTREAM FREE QUOTAS ====================', { x: 80, y: H - 255, size: 8, font: fontMono, color: c.dim });

    // Table: What they do vs do not do
    drawCard(page, 28, H - 470, W - 56, 175, c.cardLight, c.border);
    page.drawText('WHAT THE GATEWAYS DO', { x: 42, y: H - 310, size: 9, font: fontBold, color: c.green });
    page.drawText('WHAT THEY DO NOT DO', { x: 310, y: H - 310, size: 9, font: fontBold, color: c.red });

    const doItems = [
      '• Map OpenAI spec to Gemini / Groq formats',
      '• Handle token authentication locally',
      '• Support streaming server-sent events (SSE)',
      '• Enable tool calling & function execution',
      '• Allow zero-subscription terminal workflows'
    ];
    const dontItems = [
      '• Do NOT give access to paid Claude.ai web chat',
      '• Do NOT bypass provider hard rate limits',
      '• Do NOT store your code on remote intermediate servers',
      '• Do NOT require credit cards or billing setup',
      '• Do NOT violate upstream terms when within quotas'
    ];

    let dy = H - 335;
    for (let i = 0; i < 5; i++) {
      page.drawText(doItems[i], { x: 42, y: dy, size: 8, font: fontRegular, color: c.white });
      page.drawText(dontItems[i], { x: 310, y: dy, size: 8, font: fontRegular, color: c.white });
      dy -= 24;
    }

    drawPageFooter(page, 3);
  }

  // ==========================================
  // PAGE 4: PREREQUISITES & CLI INSTALLATION
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });
    drawPageHeader(page, 'PREREQUISITES', 4);

    page.drawText('PREPARATION', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.red });
    page.drawText('Prerequisites & CLI Tools Installation', { x: 28, y: H - 115, size: 22, font: fontBold, color: c.white });

    const commands = [
      ['1. Verify Node.js (v18+ recommended)', 'node --version\nnpm --version'],
      ['2. Install Claude Code CLI globally', 'npm install -g @anthropic-ai/claude-code'],
      ['3. Install OpenClaw CLI', 'npm install -g openclaw-cli'],
      ['4. Optional: Docker for containerized gateway', 'docker --version && docker compose version']
    ];

    let cy = H - 155;
    commands.forEach(cmd => {
      drawCard(page, 28, cy - 50, W - 56, 68, c.card, c.border);
      page.drawText(cmd[0], { x: 40, y: cy + 4, size: 9.5, font: fontBold, color: c.white });
      drawCard(page, 40, cy - 42, W - 80, 26, c.monoBg, c.border);
      page.drawText(cmd[1], { x: 50, y: cy - 28, size: 8, font: fontMono, color: c.cyan });
      cy -= 80;
    });

    drawPageFooter(page, 4);
  }

  // ==========================================
  // PAGE 5: URL CHEAT SHEET & PORT MATRIX
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });
    drawPageHeader(page, 'CHEAT SHEET', 5);

    page.drawText('SAVE THIS PAGE', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.red });
    page.drawText('The Master URL & Port Cheat Sheet', { x: 28, y: H - 115, size: 22, font: fontBold, color: c.white });

    drawCard(page, 28, H - 350, W - 56, 220, c.card, c.border);
    page.drawText('GATEWAY COMPARISON AND CONNECTION MATRIX', { x: 42, y: H - 150, size: 9, font: fontBold, color: c.red });

    const matrix = [
      ['Attribute', 'FreeLLMAPI', 'OmniRoute'],
      ['Default Local Port', 'http://localhost:3001', 'http://localhost:20128'],
      ['OpenAI v1 Endpoint', 'http://localhost:3001/v1', 'http://localhost:20128/v1'],
      ['Primary Engine', 'Gemini Flash 2.5', 'Multi-Provider Failover'],
      ['Setup Complexity', 'Minimal (Single file or Docker)', 'Advanced (Routing config YAML)'],
      ['Tool Calling / Function Support', 'Native streaming tools', 'Full OpenAI tools spec'],
      ['Recommended Use Case', 'Quickest setup for Claude Code', 'Production multi-agent routing']
    ];

    let my = H - 180;
    matrix.forEach((m, idx) => {
      const isH = idx === 0;
      page.drawText(m[0], { x: 42, y: my, size: 8, font: isH ? fontBold : fontRegular, color: isH ? c.red : c.white });
      page.drawText(m[1], { x: 220, y: my, size: 8, font: isH ? fontBold : fontRegular, color: isH ? c.red : c.cyan });
      page.drawText(m[2], { x: 380, y: my, size: 8, font: isH ? fontBold : fontRegular, color: isH ? c.red : c.green });
      my -= 20;
    });

    drawPageFooter(page, 5);
  }

  // ==========================================
  // PAGES 6 TO 13: PART ONE: FREELLMAPI SETUP
  // ==========================================
  const part1Pages = [
    { title: 'Step 1: Obtaining Free Upstream Keys', sub: 'Google AI Studio, Groq, and Mistral Quotas', desc: 'Visit aistudio.google.com -> Create API Key. Gemini offers 15 requests per minute free with zero credit card required. Groq offers ultra-fast Llama 3 70B inference at zero cost.' },
    { title: 'Step 2: Launching FreeLLMAPI via Docker', sub: 'One-command containerized local launch', desc: 'docker run -d -p 3001:3001 -e GEMINI_API_KEY=your_key freellmapi/gateway:latest. The service starts listening on http://localhost:3001 with automatic SSE stream handling.' },
    { title: 'Step 3: Verifying the /v1/models Endpoint', sub: 'Confirming local gateway health before hooking CLI', desc: 'curl http://localhost:3001/v1/models. Expected response includes model IDs: gemini-2.5-flash, gemini-1.5-pro, and gpt-4o aliases mapped internally.' },
    { title: 'Step 4: Configuring Claude Code CLI', sub: 'Exporting ANTHROPIC_BASE_URL and custom tokens', desc: 'export ANTHROPIC_BASE_URL=http://localhost:3001/v1\nexport ANTHROPIC_API_KEY=freellm_local\nclaude --print "Write a quicksort in Go"' },
    { title: 'Step 5: Configuring OpenAI Codex & VS Code', sub: 'Pointing editor extensions to the local proxy', desc: 'In settings.json: "openai.apiBase": "http://localhost:3001/v1", "openai.apiKey": "dummy". VS Code completions immediately route through free quotas.' },
    { title: 'Step 6: Configuring OpenClaw Terminal Agent', sub: 'Autonomous multi-step coding execution', desc: 'openclaw config set baseUrl http://localhost:3001/v1\nopenclaw config set model gemini-2.5-flash\nopenclaw run "Fix TypeScript compile errors"' },
    { title: 'Step 7: Handling Streaming and SSE Buffers', sub: 'Preventing truncated responses in interactive CLIs', desc: 'Ensure HTTP keep-alive is active. If responses pause mid-stream, set STREAM_CHUNK_SIZE=256 in the gateway environment.' },
    { title: 'Step 8: Rate Limit Management & Fallbacks', sub: 'How to avoid HTTP 429 quota exhaustion', desc: 'Configure a secondary Groq or Mistral key. When Gemini reaches the 15 RPM limit, FreeLLMAPI automatically retries with secondary upstream credentials.' }
  ];

  for (let i = 0; i < 8; i++) {
    const pageNum = i + 6;
    const pInfo = part1Pages[i];
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });
    drawPageHeader(page, 'PART 1: FREELLMAPI', pageNum);

    page.drawText('PART ONE • FREELLMAPI', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.red });
    page.drawText(pInfo.title, { x: 28, y: H - 115, size: 20, font: fontBold, color: c.white });
    page.drawText(pInfo.sub, { x: 28, y: H - 135, size: 11, font: fontBold, color: c.gray });

    drawCard(page, 28, H - 320, W - 56, 160, c.card, c.border);
    page.drawText(pInfo.desc, { x: 42, y: H - 170, size: 9, font: fontRegular, color: c.white });

    drawCard(page, 42, H - 300, W - 84, 85, c.monoBg, c.border);
    page.drawText('VERIFIED RUN COMMAND:', { x: 55, y: H - 235, size: 8, font: fontBold, color: c.red });
    page.drawText('curl -X POST http://localhost:3001/v1/chat/completions \\', { x: 55, y: H - 255, size: 8, font: fontMono, color: c.cyan });
    page.drawText('  -H "Content-Type: application/json" \\', { x: 55, y: H - 270, size: 8, font: fontMono, color: c.cyan });
    page.drawText('  -d \'{"model":"gemini-2.5-flash","messages":[{"role":"user","content":"Hello"}]}\'', { x: 55, y: H - 285, size: 8, font: fontMono, color: c.cyan });

    drawPageFooter(page, pageNum);
  }

  // ==========================================
  // PAGES 14 TO 20: PART TWO: OMNIROUTE SETUP
  // ==========================================
  const part2Pages = [
    { title: 'OmniRoute Architecture & Port 20128', sub: 'High-throughput Rust/Go lightweight proxy', desc: 'OmniRoute acts as a multi-tier proxy capable of routing requests across 8 different free LLM providers with automatic load balancing.' },
    { title: 'Multi-Key Pooling & Round-Robin Rotation', sub: 'Multiplying your free RPM quotas', desc: 'By providing 3 free Google AI Studio keys, OmniRoute cycles requests so you effectively reach 45 RPM without hitting single-key limits.' },
    { title: 'Configuration via omniroute.yaml', sub: 'Defining upstream rules and model overrides', desc: 'routes:\n  - match: "gpt-4*"\n    target: "gemini-2.5-flash"\n  - match: "claude*"\n    target: "llama-3.3-70b-versatile"' },
    { title: 'Hooking Claude Code CLI to OmniRoute', sub: 'Zero latency local socket connections', desc: 'export ANTHROPIC_BASE_URL=http://localhost:20128/v1\nclaude --model gpt-4o' },
    { title: 'Benchmarking FreeLLMAPI vs OmniRoute', sub: 'Latency, TTFT, and memory consumption', desc: 'OmniRoute uses ~12MB RAM compared to Node.js 45MB. Time to First Token (TTFT) averages 420ms on Gemini Flash.' },
    { title: 'Offline Mode & Local Small Model Fallback', sub: 'Routing to Ollama when internet is down', desc: 'When upstream WiFi fails, OmniRoute seamlessly routes code completion requests to local Ollama (qwen2.5-coder:7b).' },
    { title: 'Production Stability & Daemon Services', sub: 'Running as a systemd service or macOS launchd', desc: 'systemctl --user enable omniroute.service\nKeeps the gateway online 24/7 across system reboots.' }
  ];

  for (let j = 0; j < 7; j++) {
    const pageNum = j + 14;
    const pInfo = part2Pages[j];
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });
    drawPageHeader(page, 'PART 2: OMNIROUTE', pageNum);

    page.drawText('PART TWO • OMNIROUTE', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.green });
    page.drawText(pInfo.title, { x: 28, y: H - 115, size: 20, font: fontBold, color: c.white });
    page.drawText(pInfo.sub, { x: 28, y: H - 135, size: 11, font: fontBold, color: c.gray });

    drawCard(page, 28, H - 320, W - 56, 160, c.card, c.border);
    page.drawText(pInfo.desc, { x: 42, y: H - 170, size: 9, font: fontRegular, color: c.white });

    drawCard(page, 42, H - 300, W - 84, 85, c.monoBg, c.border);
    page.drawText('PORT 20128 CONNECTION TEST:', { x: 55, y: H - 235, size: 8, font: fontBold, color: c.green });
    page.drawText('curl http://localhost:20128/health \\', { x: 55, y: H - 255, size: 8, font: fontMono, color: c.cyan });
    page.drawText('  -H "Authorization: Bearer omni_secret"', { x: 55, y: H - 270, size: 8, font: fontMono, color: c.cyan });
    page.drawText('Response: {"status":"healthy","active_routes":4,"latency_ms":12}', { x: 55, y: H - 285, size: 8, font: fontMono, color: c.green });

    drawPageFooter(page, pageNum);
  }

  // ==========================================
  // PAGES 21-22: TROUBLESHOOTING & DIAGNOSTICS
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });
    drawPageHeader(page, 'TROUBLESHOOTING', 21);

    page.drawText('DIAGNOSTICS', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.red });
    page.drawText('Common Error Codes & Exact Solutions', { x: 28, y: H - 115, size: 22, font: fontBold, color: c.white });

    const errors = [
      ['HTTP 401 Unauthorized', 'Cause: Missing or incorrect upstream API key in your .env file.\nFix: Check GEMINI_API_KEY in docker-compose.yml or export command.'],
      ['HTTP 429 Too Many Requests', 'Cause: Exceeded free RPM quota on upstream provider.\nFix: Add secondary key to pool or switch model to Llama-3-70b on Groq.'],
      ['HTTP 502 Bad Gateway / Connection Refused', 'Cause: Local gateway process is not running or blocked by firewall.\nFix: Verify port with lsof -i :3001 or netstat -vanp tcp | grep 3001.']
    ];
    let ey = H - 150;
    errors.forEach(err => {
      drawCard(page, 28, ey - 50, W - 56, 68, c.card, c.border);
      page.drawText(err[0], { x: 42, y: ey + 4, size: 10, font: fontBold, color: c.red });
      page.drawText(err[1], { x: 42, y: ey - 22, size: 8, font: fontRegular, color: c.white });
      ey -= 80;
    });

    drawPageFooter(page, 21);
  }

  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });
    drawPageHeader(page, 'CLIENT FIXES', 22);

    page.drawText('CLIENT-SPECIFIC FIXES', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.red });
    page.drawText('Claude Code, Codex & Shell Hiccups', { x: 28, y: H - 115, size: 22, font: fontBold, color: c.white });

    const fixes = [
      ['Claude Code says "Authentication failed"', 'Run: claude config set --global apiKey dummy-key. Claude Code requires non-empty string.'],
      ['Codex outputs raw JSON instead of code', 'Ensure the gateway returns standard SSE "choices[0].delta.content" format.'],
      ['Zsh / Bash environment variables lost on restart', 'Add export statements to ~/.zshrc or ~/.bashrc to persist across terminal sessions.']
    ];
    let fy = H - 150;
    fixes.forEach(f => {
      drawCard(page, 28, fy - 50, W - 56, 68, c.card, c.border);
      page.drawText(f[0], { x: 42, y: fy + 4, size: 10, font: fontBold, color: c.white });
      page.drawText(f[1], { x: 42, y: fy - 22, size: 8, font: fontRegular, color: c.gray });
      fy -= 80;
    });

    drawPageFooter(page, 22);
  }

  // ==========================================
  // PAGE 23: SECURITY & PRIVACY RULES
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });
    drawPageHeader(page, 'SECURITY RULES', 23);

    page.drawText('HYGIENE & COMPLIANCE', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.red });
    page.drawText('Security and Privacy Rules', { x: 28, y: H - 115, size: 22, font: fontBold, color: c.white });

    const rules = [
      '1. NEVER BIND GATEWAYS TO 0.0.0.0 WITHOUT AUTH: Keep gateway bound to 127.0.0.1.',
      '2. NEVER COMMIT .env OR API KEYS TO GIT REPOSITORIES: Use .gitignore strictly.',
      '3. AUDIT CODE PROMPTS: Avoid pasting unredacted company credentials or database passwords.',
      '4. ROTATE KEYS PERIODICALLY: Regenerate upstream Google/Groq tokens every 90 days.',
      '5. USE LOCAL AUDIT LOGS: Enable gateway access logs to review payload volume.'
    ];

    let ry = H - 160;
    rules.forEach(r => {
      drawCard(page, 28, ry - 28, W - 56, 42, c.card, c.border);
      page.drawText(r, { x: 40, y: ry - 4, size: 8.5, font: fontBold, color: c.white });
      ry -= 52;
    });

    drawPageFooter(page, 23);
  }

  // ==========================================
  // PAGE 24: FINAL SETUP CHECKLIST
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });
    drawPageHeader(page, 'CHECKLIST', 24);

    page.drawText('VERIFICATION', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.red });
    page.drawText('Final Setup Checklist', { x: 28, y: H - 115, size: 22, font: fontBold, color: c.white });

    const checks = [
      '[ ] Google AI Studio / Groq API key generated and tested via curl',
      '[ ] FreeLLMAPI (port 3001) or OmniRoute (port 20128) active in background',
      '[ ] Local endpoint responds 200 OK to /v1/models query',
      '[ ] Shell environment variables (ANTHROPIC_BASE_URL) set in ~/.zshrc',
      '[ ] Claude Code CLI executes test prompt without authentication errors',
      '[ ] OpenClaw executes file editing workflow successfully',
      '[ ] Secondary fallback provider configured in case of primary 429 quota'
    ];

    let cky = H - 160;
    checks.forEach(chk => {
      drawCard(page, 28, cky - 24, W - 56, 36, c.card, c.border);
      page.drawText(chk, { x: 40, y: cky - 2, size: 8.5, font: fontBold, color: c.cyan });
      cky -= 46;
    });

    drawPageFooter(page, 24);
  }

  // ==========================================
  // PAGE 25: OFFICIAL LINKS & REFERENCES
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });
    drawPageHeader(page, 'OFFICIAL LINKS', 25);

    page.drawText('RESOURCES', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.red });
    page.drawText('Official Links and Documentation', { x: 28, y: H - 115, size: 22, font: fontBold, color: c.white });

    const links = [
      ['Google AI Studio (Gemini Free Tier)', 'https://aistudio.google.com'],
      ['Groq Cloud Console (Ultra-Fast Llama)', 'https://console.groq.com'],
      ['Claude Code CLI Official Docs', 'https://docs.anthropic.com/en/docs/agents-and-tools/claude-code'],
      ['OpenClaw Terminal Agent Repository', 'https://github.com/openclaw/openclaw'],
      ['FreeLLMAPI Gateway Source Code', 'https://github.com/freellmapi/gateway'],
      ['OmniRoute Multi-Model Proxy', 'https://github.com/omniroute/omniroute'],
      ['Rauf Labs Academy Community', 'https://rauflabs.com/academy']
    ];

    let ly = H - 160;
    links.forEach(l => {
      drawCard(page, 28, ly - 32, W - 56, 48, c.card, c.border);
      page.drawText(l[0], { x: 42, y: ly - 2, size: 9.5, font: fontBold, color: c.white });
      page.drawText(l[1], { x: 42, y: ly - 18, size: 8, font: fontMono, color: c.red });
      ly -= 56;
    });

    page.drawText('PROMPT. BUILD. SHIP. — RAUF LABS ACADEMY', { x: 28, y: 80, size: 11, font: fontBold, color: c.white });

    drawPageFooter(page, 25);
  }

  return await doc.save();
}

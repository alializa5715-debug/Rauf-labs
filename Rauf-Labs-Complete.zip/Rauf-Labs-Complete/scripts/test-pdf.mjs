import fs from 'node:fs';
import path from 'node:path';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

async function test() {
  const doc = await PDFDocument.create();
  const page = doc.addPage([595.28, 841.89]); // A4
  const fontBold = await doc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await doc.embedFont(StandardFonts.Helvetica);

  page.drawRectangle({
    x: 0,
    y: 0,
    width: 595.28,
    height: 841.89,
    color: rgb(0.05, 0.06, 0.08)
  });

  page.drawText('RAUF LABS ACADEMY', {
    x: 50,
    y: 780,
    size: 14,
    font: fontBold,
    color: rgb(1, 0.8, 0.2)
  });

  const bytes = await doc.save();
  fs.writeFileSync('test.pdf', bytes);
  console.log('Test PDF generated successfully, size:', bytes.length);
}

test();

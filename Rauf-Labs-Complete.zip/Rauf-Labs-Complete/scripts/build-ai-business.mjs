import fs from 'node:fs';
import path from 'node:path';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

const c = {
  bg: rgb(0.04, 0.05, 0.08),
  card: rgb(0.08, 0.09, 0.14),
  cardLight: rgb(0.12, 0.14, 0.20),
  border: rgb(0.18, 0.21, 0.30),
  gold: rgb(0.96, 0.70, 0.18),
  goldDark: rgb(0.68, 0.48, 0.10),
  goldLight: rgb(0.98, 0.85, 0.45),
  white: rgb(0.96, 0.97, 0.99),
  gray: rgb(0.65, 0.69, 0.78),
  dim: rgb(0.42, 0.46, 0.55),
  cyan: rgb(0.15, 0.75, 0.88),
  green: rgb(0.20, 0.80, 0.45)
};

function drawCard(page, x, y, width, height, bg, border, borderWidth = 1) {
  page.drawRectangle({ x, y, width, height, color: bg, borderColor: border, borderWidth });
}

export async function buildAiBusinessPdf() {
  const doc = await PDFDocument.create();
  const fontBold = await doc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await doc.embedFont(StandardFonts.Helvetica);
  const fontMono = await doc.embedFont(StandardFonts.Courier);

  const W = 595.28;
  const H = 841.89;

  // PAGE 1: COVER
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    // Top gold mark
    page.drawRectangle({ x: 38, y: H - 65, width: 4, height: 18, color: c.gold });
    page.drawText('RAUF LABS ACADEMY', { x: 50, y: H - 60, size: 11, font: fontBold, color: c.white });
    page.drawText('THE AI BUSINESS PLAYBOOK', { x: 38, y: H - 95, size: 9, font: fontBold, color: c.gold });

    // Giant 60
    page.drawText('60', { x: 38, y: H - 240, size: 120, font: fontBold, color: c.gold });

    page.drawText('Ready-to-Launch', { x: 38, y: H - 280, size: 28, font: fontBold, color: c.white });
    page.drawText('AI Business Ideas', { x: 38, y: H - 315, size: 28, font: fontBold, color: c.gold });
    page.drawText('You Can Start This Weekend', { x: 38, y: H - 345, size: 18, font: fontBold, color: c.white });

    page.drawText('Complete with open-source codebases, unit economics, tech stacks, and step-by-step launch playbooks.', {
      x: 38, y: H - 380, size: 9.5, font: fontRegular, color: c.gray
    });

    // 4 Pill Badges
    const pills = [
      '+ MIT Licensed — keep 100% of revenue',
      '+ Stripe billing built in',
      '+ One-click Vercel deploy',
      '+ 10 categories • 60 clickable links'
    ];
    let py = H - 430;
    pills.forEach(p => {
      drawCard(page, 38, py - 4, W - 76, 26, c.card, c.border);
      page.drawText(p, { x: 50, y: py + 4, size: 9, font: fontBold, color: c.goldLight });
      py -= 34;
    });

    // Curator credit
    page.drawText('CURATED BY MUHAMMAD TAHIR ASHRAF • RAUF LABS ACADEMY', {
      x: 38, y: 50, size: 8.5, font: fontBold, color: c.dim
    });
  }

  // PAGE 2: READ THIS FIRST
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawText('RAUF LABS ACADEMY', { x: 28, y: H - 45, size: 9, font: fontBold, color: c.gold });
    page.drawText('THE AI BUSINESS PLAYBOOK / PAGE 02', { x: W - 200, y: H - 45, size: 8, font: fontRegular, color: c.dim });

    page.drawText('READ THIS FIRST', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.gold });
    page.drawText('Why these 60 ideas are different', { x: 28, y: H - 115, size: 22, font: fontBold, color: c.white });

    page.drawText('Most "AI business ideas" lists tell you to "build an AI wrapper" and leave you with nothing.', {
      x: 28, y: H - 145, size: 9.5, font: fontRegular, color: c.gray
    });
    page.drawText('Every idea in this playbook includes 3 verified structural advantages:', {
      x: 28, y: H - 162, size: 9.5, font: fontRegular, color: c.gray
    });

    const pillars = [
      ['1. Open-Source Repositories', 'Real, tested GitHub repositories you can git-clone and run locally in under 15 minutes.'],
      ['2. Proven Unit Economics', 'Calculated API cost margins (78-92% gross margins), realistic SaaS tiers from $29 to $199/mo.'],
      ['3. 48-Hour Execution Track', 'Designed specifically for solo developers to deploy on Friday and acquire users by Sunday evening.']
    ];

    let ply = H - 190;
    pillars.forEach(pil => {
      drawCard(page, 28, ply - 30, W - 56, 52, c.card, c.border);
      page.drawText(pil[0], { x: 42, y: ply + 2, size: 11, font: fontBold, color: c.gold });
      page.drawText(pil[1], { x: 42, y: ply - 16, size: 8.5, font: fontRegular, color: c.white });
      ply -= 64;
    });

    // Economics table
    drawCard(page, 28, ply - 80, W - 56, 95, c.cardLight, c.border);
    page.drawText('BENCHMARK UNIT ECONOMICS ACROSS THE 60 BUSINESSES', { x: 42, y: ply - 8, size: 9, font: fontBold, color: c.gold });
    const eco = [
      ['Metric', 'Typical Value', 'Notes'],
      ['Gross Profit Margin', '82% - 91%', 'Assuming modern Gemini Flash / Claude Haiku inference costs'],
      ['Average User CAC', '$12 - $45', 'Organic viral reels, LinkedIn technical writing, or SEO'],
      ['Target ARPU', '$39 / month', 'Micro-SaaS or B2B workflow niche automation']
    ];
    let ty = ply - 30;
    eco.forEach((row, i) => {
      const isH = i === 0;
      page.drawText(row[0], { x: 42, y: ty, size: 8, font: isH ? fontBold : fontRegular, color: isH ? c.gold : c.white });
      page.drawText(row[1], { x: 200, y: ty, size: 8, font: isH ? fontBold : fontRegular, color: isH ? c.gold : c.white });
      page.drawText(row[2], { x: 310, y: ty, size: 7.5, font: isH ? fontBold : fontRegular, color: isH ? c.gold : c.gray });
      ty -= 18;
    });

    page.drawText('RAUF LABS ACADEMY • 2026 EDITION', { x: 28, y: 30, size: 8, font: fontBold, color: c.dim });
  }

  // PAGE 3: WHAT'S INSIDE (10 CATEGORIES)
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawText('RAUF LABS ACADEMY', { x: 28, y: H - 45, size: 9, font: fontBold, color: c.gold });
    page.drawText('THE AI BUSINESS PLAYBOOK / PAGE 03', { x: W - 200, y: H - 45, size: 8, font: fontRegular, color: c.dim });

    page.drawText('WHAT\'S INSIDE', { x: 28, y: H - 85, size: 10, font: fontBold, color: c.gold });
    page.drawText('10 Categories • 60 Businesses', { x: 28, y: H - 115, size: 22, font: fontBold, color: c.white });

    const cats = [
      ['01. Content & Social Media', '6 Businesses: Viral scheduler, short-form clipper, thumbnail generator, newsletter AI.'],
      ['02. Sales & B2B Outreach', '6 Businesses: Personalized cold email engine, LinkedIn scraper bot, lead enricher.'],
      ['03. Developer Tools & Code', '6 Businesses: PR code reviewer, SQL query bot, auto-API documentation generator.'],
      ['04. Healthcare & Wellness', '6 Businesses: Medical transcription summarizer, patient intake bot, diet optimizer.'],
      ['05. Finance & Accounting', '6 Businesses: Automated receipt OCR, invoice tracker, bank statement categorizer.'],
      ['06. Legal & Contract Tech', '6 Businesses: Contract redliner, NDA generator, compliance auditor, clause search.'],
      ['07. Education & EdTech', '6 Businesses: Personalized homework tutor, quiz generator, interactive flashcard engine.'],
      ['08. E-Commerce & Retail', '6 Businesses: Product description writer, AI mockups generator, review sentiment analyzer.'],
      ['09. Customer Support', '6 Businesses: 24/7 WhatsApp AI agent, Zendesk auto-replier, ticket triage system.'],
      ['10. Audio, Voice & Video', '6 Businesses: AI podcast editor, multilingual dubber, voice cloning assistant.']
    ];

    let cy = H - 145;
    cats.forEach(cItem => {
      drawCard(page, 28, cy - 35, W - 56, 45, c.card, c.border);
      page.drawText(cItem[0], { x: 42, y: cy - 6, size: 10, font: fontBold, color: c.gold });
      page.drawText(cItem[1], { x: 42, y: cy - 22, size: 8, font: fontRegular, color: c.gray });
      cy -= 55;
    });

    page.drawText('RAUF LABS ACADEMY • 2026 EDITION', { x: 28, y: 30, size: 8, font: fontBold, color: c.dim });
  }

  // PAGES 4 TO 21: THE 60 BUSINESSES (18 PAGES, ~3-4 per page)
  const all60Businesses = [
    // Content & Media
    { cat: '01 Content & Media', num: '01', name: 'Open Generative Viral Scheduler', desc: 'AI agent that analyzes viral trends across Instagram and TikTok, generates 30 days of scripts, and schedules auto-posts.', tech: 'Next.js 15, Gemini 2.5 Flash, Supabase', price: '$29/mo - $79/mo', comp: 'Buffer, Hootsuite, Later', margin: '89%' },
    { cat: '01 Content & Media', num: '02', name: 'AutoShorts Clip Extraction Engine', desc: 'Converts long-form YouTube podcasts into 9:16 viral vertical reels with dynamic auto-subtitles and punch zooms.', tech: 'Python, Whisper, FFmpeg, Modal GPU', price: '$49/mo', comp: 'OpusClip, Munch, Klap', margin: '84%' },
    { cat: '01 Content & Media', num: '03', name: 'Thumbnail Click-Through Predictor', desc: 'Analyzes visual contrast, facial expressions, and title text to score and optimize YouTube thumbnails before publishing.', tech: 'TensorFlow.js, Claude 3.5 Sonnet Vision', price: '$19/mo', comp: 'ThumbnailTest, TubeBuddy', margin: '93%' },
    { cat: '01 Content & Media', num: '04', name: 'Autonomous Niche Newsletter Curator', desc: 'Scrapes ArXiv, Reddit, and HackerNews, synthesizes daily digests, and sends personalized Substack/Beehiiv issues.', tech: 'Node.js, LangChain, Resend API', price: '$39/mo', comp: 'Morning Brew, TLDR', margin: '91%' },
    { cat: '01 Content & Media', num: '05', name: 'Multi-Platform Blog Repurposer', desc: 'Takes 1 technical markdown post and automatically rewrites it into 5 tweet threads, 3 LinkedIn carousels, and an email blast.', tech: 'React, Tailwind, OpenAI API', price: '$25/mo', comp: 'Taplio, Tweethunter', margin: '92%' },
    { cat: '01 Content & Media', num: '06', name: 'Faceless YouTube Storyteller Bot', desc: 'Generates historical, horror, or motivational video stories with synchronized AI voiceovers and Midjourney image pans.', tech: 'Remotion, ElevenLabs, Runway Gen-3', price: '$69/mo', comp: 'InVideo AI, Steve.ai', margin: '79%' },

    // Sales & B2B
    { cat: '02 Sales & B2B Outreach', num: '07', name: 'AI Hyper-Personalized Cold Outreach', desc: 'Scrapes prospect LinkedIn profiles and recent posts to craft genuinely authentic opening icebreakers that convert.', tech: 'FastAPI, Crawl4AI, Claude 3.5 Haiku', price: '$59/mo', comp: 'Instantly, Lemlist', margin: '88%' },
    { cat: '02 Sales & B2B Outreach', num: '08', name: 'B2B Signal-Based Lead Scoring Bot', desc: 'Monitors job postings, funding rounds, and GitHub stars to notify sales teams the exact day a prospect needs their tool.', tech: 'PostgreSQL, Python, Slack Bot Webhook', price: '$99/mo', comp: 'Apollo, ZoomInfo', margin: '86%' },
    { cat: '02 Sales & B2B Outreach', num: '09', name: 'Interactive AI Sales Pitch Simulator', desc: 'Voice AI that acts as difficult enterprise procurement officers so account executives can roleplay and sharpen closing skills.', tech: 'LiveKit, WebRTC, Gemini 2.0 Flash Live', price: '$149/mo', comp: 'Gong, Second Nature', margin: '85%' },
    { cat: '02 Sales & B2B Outreach', num: '10', name: 'RFP Proposal Autonomous Generator', desc: 'Upload 200-page government or corporate RFPs and auto-populate compliant response grids from company document vaults.', tech: 'ChromaDB, LangChain, Docx Templater', price: '$199/mo', comp: 'Loopio, Responsive.io', margin: '92%' },
    { cat: '02 Sales & B2B Outreach', num: '11', name: 'LinkedIn Thought Leadership Assistant', desc: 'Curates industry news and drafts founder-voice thought leadership posts with high-engagement formatting and hooks.', tech: 'Chrome Extension, Next.js, Gemini API', price: '$29/mo', comp: 'AuthoredUp, Taplio', margin: '94%' },
    { cat: '02 Sales & B2B Outreach', num: '12', name: 'Competitor Win-Loss Battlecard Generator', desc: 'Monitors G2, Capterra, and Trustpilot reviews of competitors and creates real-time battlecards for sales reps.', tech: 'BeautifulSoup, Claude 3.5 Sonnet, Notion Sync', price: '$79/mo', comp: 'Klue, Crayon', margin: '89%' },

    // Developer Tools
    { cat: '03 Developer Tools', num: '13', name: 'Automated GitHub PR Code Reviewer', desc: 'GitHub app that reads pull requests, identifies security flaws, performance bugs, and enforces clean architecture.', tech: 'GitHub Webhooks, TypeScript, Claude Sonnet', price: '$49/repo/mo', comp: 'Coderabbit, Greptile', margin: '91%' },
    { cat: '03 Developer Tools', num: '14', name: 'Natural Language to Production SQL Bot', desc: 'Connects to Postgres/MySQL, reads schema metadata safely without viewing row data, and executes verified read-only queries.', tech: 'Prisma, Next.js 15, DuckDB, Gemini Flash', price: '$39/mo', comp: 'Text2SQL, Census', margin: '95%' },
    { cat: '03 Developer Tools', num: '15', name: 'Zero-Effort OpenAPI Documentation AI', desc: 'Watches backend codebases and generates interactive Scalar/Swagger API reference docs with curl and SDK examples.', tech: 'AST Parser, Node.js, Express, Tailwind', price: '$29/mo', comp: 'Mintlify, Readme.com', margin: '93%' },
    { cat: '03 Developer Tools', num: '16', name: 'Legacy Code Migration & Refactorer', desc: 'Assists companies in porting legacy COBOL, PHP 5, or jQuery codebases into modern TypeScript and Go microservices.', tech: 'Docker, Tree-sitter, Claude 3.5 Sonnet', price: '$299/project', comp: 'ModernLogic, Grit.io', margin: '87%' },
    { cat: '03 Developer Tools', num: '17', name: 'Synthetic Test Data & Mock Database Generator', desc: 'Generates GDPR-compliant, relational fake user databases matching complex foreign-key constraints for integration tests.', tech: 'Python, Faker, Polars, PostgreSQL', price: '$19/mo', comp: 'Tonic.ai, Mockaroo', margin: '92%' },
    { cat: '03 Developer Tools', num: '18', name: 'Cloud Infrastructure Cost Optimizer Bot', desc: 'Scans AWS/GCP bills and Terraform plans to identify over-provisioned idle instances and suggest exact savings commands.', tech: 'Terraform CLI, AWS Cost Explorer API, Go', price: '$49/mo', comp: 'Vantage, Kubecost', margin: '96%' },

    // Healthcare & Wellness
    { cat: '04 Healthcare & Wellness', num: '19', name: 'Ambient Clinical Doctor Notes Assistant', desc: 'Records doctor-patient consultations and automatically writes SOAP notes, lab orders, and discharge summaries.', tech: 'Whisper Large v3, HIPAA-compliant LLM gateway', price: '$129/doctor/mo', comp: 'Abridge, Nabla, Suki', margin: '82%' },
    { cat: '04 Healthcare & Wellness', num: '20', name: 'Dental X-Ray Anomaly Highlighting Tool', desc: 'Assists dentists by highlighting potential caries, bone loss, and periapical lesions on standard panoramic radiographs.', tech: 'PyTorch, YOLOv8-med, Next.js Web Viewer', price: '$199/clinic/mo', comp: 'Pearl, Overjet', margin: '85%' },
    { cat: '04 Healthcare & Wellness', num: '21', name: 'Smart Patient Intake & Triage Kiosk', desc: 'Mobile-friendly multilingual intake form that asks adaptive clinical questions and summarizes symptoms for triage nurses.', tech: 'React Native, WebSockets, Fastify', price: '$69/clinic/mo', comp: 'Phreesia, Klara', margin: '90%' },
    { cat: '04 Healthcare & Wellness', num: '22', name: 'Personalized Nutrition & Bloodwork Optimizer', desc: 'Upload routine blood test PDFs to receive plain-English biomarker explanations and micronutrient food plans.', tech: 'OCR PDF Parser, Supabase, Anthropic Claude', price: '$29/one-time', comp: 'InsideTracker, Levels', margin: '94%' },
    { cat: '04 Healthcare & Wellness', num: '23', name: 'Elderly Daily Voice Check-in Companion', desc: 'Automated AI phone caller that speaks with senior citizens daily, checks medication adherence, and alerts families if distress.', tech: 'Twilio Voice API, Vapi.ai, Node.js', price: '$19/mo', comp: 'CarePredict, ElliQ', margin: '80%' },
    { cat: '04 Healthcare & Wellness', num: '24', name: 'Mental Health Therapy Session Homework Bot', desc: 'Provides licensed therapists with a secure portal to send CBT journal prompts and track patient mood between sessions.', tech: 'End-to-End Encrypted React, SQLite, WebCrypto', price: '$39/therapist/mo', comp: 'Upheal, SimplePractice', margin: '92%' },

    // Finance & Accounting
    { cat: '05 Finance & Accounting', num: '25', name: 'Automated WhatsApp Receipt & Expense Bot', desc: 'Contractors snap photos of fuel and hardware receipts on WhatsApp; bot categorizes expenses and syncs directly to QuickBooks.', tech: 'WhatsApp Business API, Tesseract, Node.js', price: '$15/mo', comp: 'Expensify, Dext', margin: '88%' },
    { cat: '05 Finance & Accounting', num: '26', name: 'Bank Statement PDF to Clean Excel Converter', desc: 'Parses messy scanned multi-column PDF bank statements into clean reconciliation CSVs with zero manual data entry.', tech: 'PyMuPDF, Tabula, FastAPI, React', price: '$29/mo', comp: 'Docparser, Laserfiche', margin: '93%' },
    { cat: '05 Finance & Accounting', num: '27', name: 'Small Business Cash-Flow Runway Forecaster', desc: 'Connects to Stripe and Plaid to predict 90-day cash balances, warning founders of upcoming payroll crunches before they happen.', tech: 'Plaid API, Stripe API, Chart.js, Next.js', price: '$49/mo', comp: 'Float, Pulse, Fathom', margin: '94%' },
    { cat: '05 Finance & Accounting', num: '28', name: 'Autonomous Accounts Payable Invoice Matcher', desc: 'Matches incoming vendor invoices against purchase orders and shipping manifests to prevent fraudulent overpayments.', tech: 'Postgres, pgvector, Claude 3.5 Haiku', price: '$99/mo', comp: 'Tipalti, Bill.com', margin: '89%' },
    { cat: '05 Finance & Accounting', num: '29', name: 'Freelancer Real-Time Tax Reserve Estimator', desc: 'Calculates self-employment quarterly tax withholdings in real-time as invoices get paid, moving reserves to sub-accounts.', tech: 'Stripe Treasury, Plaid, SvelteKit', price: '$12/mo', comp: 'Catch.co, Keeper Tax', margin: '96%' },
    { cat: '05 Finance & Accounting', num: '30', name: 'Cryptocurrency Tax Lot Reconciliation Engine', desc: 'Imports wallet transactions across EVM, Solana, and Bitcoin to calculate FIFO/LIFO capital gains reports for accountants.', tech: 'Ethers.js, Go, DuckDB, Tailwind', price: '$49/tax-season', comp: 'Koinly, CoinTracker', margin: '91%' },

    // Legal & Compliance
    { cat: '06 Legal & Compliance', num: '31', name: 'Instant NDA & Contract Redliner', desc: 'Upload vendor contracts to automatically detect non-standard liability caps, indemnity traps, and suggest redlines.', tech: 'Docx-wasm, Claude 3.5 Sonnet, React', price: '$49/mo', comp: 'Ironclad, Robin AI', margin: '92%' },
    { cat: '06 Legal & Compliance', num: '32', name: 'GDPR & Privacy Policy Compliance Auditor', desc: 'Crawls website cookies, tracking scripts, and forms to ensure privacy notices match actual telemetry practices.', tech: 'Playwright, Node.js, Express', price: '$39/site/mo', comp: 'OneTrust, Termly', margin: '95%' },
    { cat: '06 Legal & Compliance', num: '33', name: 'Lease Agreement Clause Comparison Tool', desc: 'Commercial real estate brokers compare 10 concurrent lease offers across escalation clauses and tenant improvement allowances.', tech: 'Python, LangChain, Streamlit', price: '$79/mo', comp: 'Prophia, Dappr', margin: '90%' },
    { cat: '06 Legal & Compliance', num: '34', name: 'SOC 2 Evidence Collection Automation Bot', desc: 'Connects to AWS, GitHub, and Google Workspace to collect weekly compliance screenshots and audit logs automatically.', tech: 'AWS IAM, GitHub API, Google Workspace API', price: '$149/mo', comp: 'Vanta, Drata', margin: '91%' },
    { cat: '06 Legal & Compliance', num: '35', name: 'Immigration Visa Document Checklist Engine', desc: 'Guides H1B, O1, and Express Entry applicants through evidentiary requirements and flags missing portfolio evidence.', tech: 'Next.js, Supabase Storage, Gemini Flash', price: '$99/case', comp: 'Legalpad, Boundless', margin: '89%' },
    { cat: '06 Legal & Compliance', num: '36', name: 'Trademark Name Conflict Scanner', desc: 'Searches USPTO and global trademark gazettes alongside domain registries to score brand name clearance risk.', tech: 'USPTO API, Whois XML, Python, React', price: '$29/search', comp: 'Corsearch, Trademarkia', margin: '96%' },

    // Education & EdTech
    { cat: '07 Education & EdTech', num: '37', name: 'Personalized Socratic Coding Tutor', desc: 'Interactive browser IDE that guides beginners through code bugs with questions instead of giving away copy-paste answers.', tech: 'Monaco Editor, WebContainer, Gemini Flash', price: '$15/mo', comp: 'Codecademy, Replit', margin: '93%' },
    { cat: '07 Education & EdTech', num: '38', name: 'Textbook to Interactive Anki Deck Generator', desc: 'Uploads university lecture slides or PDF chapters to generate spaced-repetition flashcards with memory retention scores.', tech: 'AnkiConnect API, Python, Next.js', price: '$9/mo', comp: 'RemNote, Quizlet', margin: '95%' },
    { cat: '07 Education & EdTech', num: '39', name: 'Autonomous Multiple-Choice Exam Creator', desc: 'Enables teachers to upload curriculum standards and produce 50 randomized test questions with verified answer keys.', tech: 'FastAPI, ReportLab PDF, Vue.js', price: '$19/teacher/mo', comp: 'Formative, Kahoot', margin: '94%' },
    { cat: '07 Education & EdTech', num: '40', name: 'Language Speaking Partner with Accent Correction', desc: 'Conversational voice bot that practices French, Spanish, or German dialogue and provides phonetic pronunciation feedback.', tech: 'Whisper, WebRTC, ElevenLabs, React', price: '$14/mo', comp: 'Duolingo Max, Speak.com', margin: '82%' },
    { cat: '07 Education & EdTech', num: '41', name: 'Academic Paper Plain-English De-Jargonizer', desc: 'Transforms dense biomedical and machine-learning ArXiv papers into digestible summaries with interactive pop-up glossaries.', tech: 'Semantic Scholar API, Claude Haiku, Svelte', price: '$12/mo', comp: 'Elicit, Consensus', margin: '94%' },
    { cat: '07 Education & EdTech', num: '42', name: 'Children\'s Illustrated Storybook Generator', desc: 'Parents enter child\'s name, pet, and lesson; generates an 8-page illustrated hardcover-ready printable storybook PDF.', tech: 'Flux.1 Schnell, pdf-lib, Next.js', price: '$19/book', comp: 'Wonderbly, StoryOwl', margin: '86%' },

    // E-Commerce & Retail
    { cat: '08 E-Commerce & Retail', num: '43', name: 'Shopify SEO Product Description Bulk Writer', desc: 'Connects to Shopify store and rewrites 5,000 product descriptions with search-optimized keywords and schema markup.', tech: 'Shopify GraphQL API, Node.js, Claude Haiku', price: '$49/catalog', comp: 'Copy.ai, Jasper', margin: '92%' },
    { cat: '08 E-Commerce & Retail', num: '44', name: 'Studio AI Product Photography Mockup Generator', desc: 'Place flat product images into luxury architectural scenes with realistic shadows and reflections for Amazon listings.', tech: 'Stable Diffusion XL, Inpainting, Canvas API', price: '$29/mo', comp: 'Flair.ai, Photoroom', margin: '85%' },
    { cat: '08 E-Commerce & Retail', num: '45', name: 'Amazon Customer Review Sentiment Inspector', desc: 'Scrapes 10,000 reviews from competing ASINs to extract top consumer complaints, sizing issues, and feature requests.', tech: 'BrightData, Python, NLTK, Next.js', price: '$39/mo', comp: 'Helium10, JungleScout', margin: '90%' },
    { cat: '08 E-Commerce & Retail', num: '46', name: 'E-Commerce Abandoned Cart WhatsApp Recoverer', desc: 'Sends personalized recovery messages with discount codes and checkout links directly via WhatsApp Business.', tech: 'Shopify Webhooks, Twilio, Node.js', price: '$49/mo + 2% rev', comp: 'Klaviyo, Omnisend', margin: '89%' },
    { cat: '08 E-Commerce & Retail', num: '47', name: 'Dynamic Competitor Price Tracker & Repricer', desc: 'Monitors competitor storefronts every hour and automatically adjusts prices to maintain buy-box victory margins.', tech: 'Playwright, Redis, Golang, PostgreSQL', price: '$99/mo', comp: 'Prisync, Competera', margin: '93%' },
    { cat: '08 E-Commerce & Retail', num: '48', name: 'Virtual Sizing Recommendation AI Widget', desc: 'Embeddable size calculator that reduces apparel return rates by matching shopper measurements to brand size charts.', tech: 'Vanilla JS Embed, Fastify, SQLite', price: '$39/store/mo', comp: 'Fit Analytics, TrueFit', margin: '96%' },

    // Customer Support
    { cat: '09 Customer Support', num: '49', name: 'Zendesk Autonomous Ticket Resolver', desc: 'Reads incoming support tickets, queries internal Notion knowledge bases, and drafts responses for agent one-click approval.', tech: 'Zendesk Apps Framework, Claude 3.5 Haiku', price: '$79/mo', comp: 'Fin by Intercom, Ada', margin: '92%' },
    { cat: '09 Customer Support', num: '50', name: '24/7 WhatsApp AI Customer Service Agent', desc: 'Handles order tracking, returns policy, and booking appointments on WhatsApp without requiring human intervention.', tech: 'Meta Cloud API, Supabase, Gemini Flash', price: '$49/mo', comp: 'Wati, ManyChat', margin: '90%' },
    { cat: '09 Customer Support', num: '51', name: 'Voice Support Phone AI for Local Trades', desc: 'Answers phone calls for plumbers, electricians, and HVAC contractors, collects address and problem, and books slots.', tech: 'Twilio, Vapi.ai, Google Calendar API', price: '$89/mo', comp: 'Bland.ai, Dialpad', margin: '83%' },
    { cat: '09 Customer Support', num: '52', name: 'Real-Time Customer Sentiment Dashboard', desc: 'Analyzes live call center transcripts to detect angry or churn-risk customers and alerts supervisors in real-time.', tech: 'Kafka, Python, WebSockets, Chart.js', price: '$149/mo', comp: 'Balto, Cogito', margin: '89%' },
    { cat: '09 Customer Support', num: '53', name: 'Multi-Language Help Center Synchronizer', desc: 'Keeps help desk articles translated and synchronized across 12 languages whenever the English master doc updates.', tech: 'DeepL API, GitHub Actions, Markdown parser', price: '$29/mo', comp: 'Lokalise, Transifex', margin: '94%' },
    { cat: '09 Customer Support', num: '54', name: 'FAQ to Interactive Video Avatar Generator', desc: 'Converts written help documentation into 30-second animated video tutorials with AI presenters answering common questions.', tech: 'HeyGen API, ffmpeg, Next.js', price: '$69/mo', comp: 'Synthesia, Colossyan', margin: '80%' },

    // Audio, Voice & Video
    { cat: '10 Audio & Voice', num: '55', name: 'AI Podcast Filler Word & Silence Stripper', desc: 'Detects and cuts out "um", "uh", lip smacks, and dead air from raw multi-track podcast audio with zero phasing artifacts.', tech: 'Python, librosa, PyTorch, React WebAudio', price: '$25/mo', comp: 'Descript, Cleanfeed', margin: '88%' },
    { cat: '10 Audio & Voice', num: '56', name: 'Multi-Lingual Video Lip-Sync Dubbing Suite', desc: 'Translates YouTube videos into Spanish, Hindi, and Portuguese while matching the original speaker voice and mouth motion.', tech: 'Wav2Lip, Whisper, ElevenLabs, Celery', price: '$79/mo', comp: 'HeyGen, ElevenLabs Dubbing', margin: '78%' },
    { cat: '10 Audio & Voice', num: '57', name: 'Royalty-Free AI Background Music Generator', desc: 'Produces customized 30-second background music stems for video editors matched to emotion, tempo, and scene markers.', tech: 'AudioCraft, MusicGen, Next.js', price: '$19/mo', comp: 'Soundraw, Epidemic Sound', margin: '92%' },
    { cat: '10 Audio & Voice', num: '58', name: 'Audiobook Chapter Splitter & Normalizer', desc: 'Processes long author recordings to match ACX (Audible) loudness standards (-23dB to -19dB RMS) and split chapters.', tech: 'FFmpeg, SoX, Python, Electron', price: '$35/book', comp: 'Auphonic, Audacity', margin: '95%' },
    { cat: '10 Audio & Voice', num: '59', name: 'Voice Clone Customer Greeting IVR System', desc: 'Allows boutique hotels and brands to have their celebrity or founder voice greet callers on corporate phone systems.', tech: 'ElevenLabs Voice Clone, Asterisk / Twilio', price: '$99/system', comp: 'Nuance, Genesys', margin: '85%' },
    { cat: '10 Audio & Voice', num: '60', name: 'Autonomous Video Subtitle Styler & Animator', desc: 'Generates animated "Hormozi style" vertical captions with kinetic bounces, emoji pop-ups, and audio sound triggers.', tech: 'FFmpeg, Ass Subtitle Spec, React Remotion', price: '$29/mo', comp: 'Submagic, Captions.ai', margin: '89%' }
  ];

  // Group into 18 pages (approx 3 or 4 per page)
  const businessesPerPage = 3;
  const totalPages = Math.ceil(all60Businesses.length / businessesPerPage); // 20 pages, let's fit nicely into pages 4 to 21

  for (let pageIdx = 0; pageIdx < 18; pageIdx++) {
    const pageNum = pageIdx + 4;
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawText('RAUF LABS ACADEMY', { x: 28, y: H - 45, size: 9, font: fontBold, color: c.gold });
    page.drawText(`THE AI BUSINESS PLAYBOOK / PAGE ${pageNum < 10 ? '0' + pageNum : pageNum}`, { x: W - 200, y: H - 45, size: 8, font: fontRegular, color: c.dim });

    // 3 businesses on this page (or 4 on some pages to total 60)
    const startIdx = Math.floor((pageIdx * 60) / 18);
    const endIdx = Math.floor(((pageIdx + 1) * 60) / 18);
    const slice = all60Businesses.slice(startIdx, endIdx);

    const firstCat = slice[0]?.cat || 'AI Business Category';
    page.drawText(firstCat.toUpperCase(), { x: 28, y: H - 85, size: 9, font: fontBold, color: c.gold });
    page.drawText('Ready-to-Launch Opportunities', { x: 28, y: H - 110, size: 18, font: fontBold, color: c.white });

    let by = H - 135;
    slice.forEach(b => {
      drawCard(page, 28, by - 165, W - 56, 160, c.card, c.border);

      // Number badge
      drawCard(page, 38, by - 28, 32, 22, c.goldDark, c.gold);
      page.drawText(b.num, { x: 44, y: by - 22, size: 10, font: fontBold, color: c.white });

      // Title
      page.drawText(b.name, { x: 78, y: by - 20, size: 12, font: fontBold, color: c.white });

      // Description
      page.drawText(b.desc, { x: 38, y: by - 48, size: 8.5, font: fontRegular, color: c.gray });

      // Details row
      page.drawText(`• Pricing Tier: ${b.price}`, { x: 38, y: by - 72, size: 8, font: fontBold, color: c.goldLight });
      page.drawText(`• Gross Margin: ${b.margin}`, { x: 220, y: by - 72, size: 8, font: fontBold, color: c.green });
      page.drawText(`• Competes with: ${b.comp}`, { x: 38, y: by - 90, size: 8, font: fontRegular, color: c.white });
      page.drawText(`• Recommended Stack: ${b.tech}`, { x: 38, y: by - 108, size: 8, font: fontRegular, color: c.cyan });

      // Code repo & 48h launch banner
      drawCard(page, 38, by - 152, W - 76, 32, c.cardLight, c.border);
      page.drawText('GET THE CODE ON GITHUB (MIT LICENSED)', { x: 48, y: by - 135, size: 8, font: fontBold, color: c.gold });
      page.drawText('48-Hour Launch: Clone repo -> Configure API keys -> Add Stripe keys -> Deploy to Vercel.', {
        x: 48, y: by - 148, size: 7.5, font: fontRegular, color: c.gray
      });

      by -= 175;
    });

    page.drawText('RAUF LABS ACADEMY • 2026 EDITION', { x: 28, y: 30, size: 8, font: fontBold, color: c.dim });
  }

  // PAGE 22: YOUR MOVE / DON'T COLLECT IDEAS. LAUNCH ONE.
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawText('RAUF LABS ACADEMY', { x: 28, y: H - 45, size: 9, font: fontBold, color: c.gold });
    page.drawText('THE AI BUSINESS PLAYBOOK / PAGE 22', { x: W - 200, y: H - 45, size: 8, font: fontRegular, color: c.dim });

    page.drawText('YOUR MOVE', { x: 28, y: H - 95, size: 12, font: fontBold, color: c.gold });
    page.drawText('Don\'t collect ideas. Launch one.', { x: 28, y: H - 135, size: 26, font: fontBold, color: c.white });

    page.drawText('Ideas are worth zero until deployed. Here is your exact 48-hour launch timeline for this weekend:', {
      x: 28, y: H - 170, size: 10, font: fontRegular, color: c.gray
    });

    const weekendSteps = [
      ['FRIDAY 7:00 PM - CHOOSE & CLONE', 'Pick exactly ONE idea from this playbook. Fork the repository to your personal GitHub. Run it locally. Do not change the core architecture.'],
      ['SATURDAY 10:00 AM - BRAND & STRIPE', 'Add your custom logo, replace placeholder text with your niche offer, and connect your Stripe test keys. Create your $29/mo recurring subscription tier.'],
      ['SATURDAY 4:00 PM - DEPLOY TO VERCEL', 'Deploy with one click to Vercel or Cloudflare Pages. Point a custom .com or .ai domain. Test live checkout with a real credit card.'],
      ['SUNDAY 9:00 AM - DIRECT USER OUTREACH', 'Message 25 people in your target market on LinkedIn, Twitter, or Discord. Offer a 50% lifetime founding discount in exchange for direct feedback. Close your first customer before Sunday midnight.']
    ];

    let wy = H - 210;
    weekendSteps.forEach((st, idx) => {
      drawCard(page, 28, wy - 45, W - 56, 75, c.card, c.border);
      page.drawRectangle({ x: 28, y: wy - 45, width: 4, height: 75, color: c.gold });
      page.drawText(`STEP 0${idx + 1}: ${st[0]}`, { x: 42, y: wy + 15, size: 10, font: fontBold, color: c.gold });
      page.drawText(st[1], { x: 42, y: wy - 2, size: 8.5, font: fontRegular, color: c.white });
      wy -= 90;
    });

    // Final CTA Box
    drawCard(page, 28, wy - 50, W - 56, 85, c.cardLight, c.goldDark);
    page.drawText('THE FOUNDER MINDSET', { x: 42, y: wy + 15, size: 11, font: fontBold, color: c.gold });
    page.drawText('Execution is the only differentiator. The technology is already built. The demand already exists.', {
      x: 42, y: wy - 5, size: 9, font: fontRegular, color: c.white
    });
    page.drawText('Take action this weekend. Share your launch with us at Rauf Labs Academy.', {
      x: 42, y: wy - 22, size: 9, font: fontBold, color: c.white
    });

    page.drawText('CURATED BY MUHAMMAD TAHIR ASHRAF • RAUF LABS ACADEMY', {
      x: 28, y: 30, size: 8.5, font: fontBold, color: c.dim
    });
  }

  return await doc.save();
}

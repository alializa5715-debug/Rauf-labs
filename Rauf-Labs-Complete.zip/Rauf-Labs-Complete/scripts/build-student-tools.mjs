import fs from 'node:fs';
import path from 'node:path';
import { PDFDocument, rgb, StandardFonts } from 'pdf-lib';

const c = {
  white: rgb(1, 1, 1),
  bg: rgb(0.98, 0.98, 0.99),
  card: rgb(1, 1, 1),
  border: rgb(0.88, 0.90, 0.94),
  red: rgb(0.88, 0.16, 0.20),
  redLight: rgb(0.99, 0.94, 0.95),
  dark: rgb(0.09, 0.11, 0.15),
  gray: rgb(0.40, 0.44, 0.52),
  dim: rgb(0.60, 0.64, 0.72),
};

function drawCard(page, x, y, width, height, bg, border, borderWidth = 1) {
  page.drawRectangle({ x, y, width, height, color: bg, borderColor: border, borderWidth });
}

export async function buildStudentToolsPdf() {
  const doc = await PDFDocument.create();
  const fontBold = await doc.embedFont(StandardFonts.HelveticaBold);
  const fontRegular = await doc.embedFont(StandardFonts.Helvetica);

  const W = 595.28;
  const H = 841.89;

  function drawOfferCard(page, title, subtitle, region, y) {
    drawCard(page, 28, y - 10, W - 56, 44, c.white, c.border);
    // Red left marker
    page.drawRectangle({ x: 28, y: y - 10, width: 4, height: 44, color: c.red });
    // Title & Region
    page.drawText(title, { x: 42, y: y + 18, size: 10, font: fontBold, color: c.dark });
    page.drawText(region, { x: W - 145, y: y + 18, size: 7.5, font: fontBold, color: c.red });
    // Subtitle
    page.drawText(subtitle, { x: 42, y: y + 3, size: 8, font: fontRegular, color: c.gray });
  }

  // ==========================================
  // PAGE 1: Cover
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.white });

    // Red top header bar
    page.drawRectangle({ x: 0, y: H - 18, width: W, height: 18, color: c.red });

    // Top Brand & Red dot
    page.drawText('RAUF LABS', { x: 38, y: H - 65, size: 10, font: fontBold, color: c.dark });
    page.drawCircle({ x: 120, y: H - 62, size: 4, color: c.red });

    // Big Title
    page.drawText('FREE AI TOOLS', { x: 38, y: H - 165, size: 28, font: fontBold, color: c.dark });
    page.drawText('FOR SOUTH ASIA STUDENTS', { x: 38, y: H - 200, size: 28, font: fontBold, color: c.red });

    page.drawText('India + Pakistan | 2026 Student Edition', { x: 38, y: H - 235, size: 11, font: fontBold, color: c.gray });

    // 25+ VERIFIED OFFERS badge
    drawCard(page, 38, H - 280, 140, 24, c.redLight, rgb(0.95, 0.80, 0.82));
    page.drawText('25+ VERIFIED OFFERS', { x: 50, y: H - 272, size: 8.5, font: fontBold, color: c.red });

    // Card in the middle-bottom
    drawCard(page, 38, 140, W - 76, 110, rgb(0.97, 0.98, 1.0), rgb(0.90, 0.93, 0.98));
    page.drawRectangle({ x: 38, y: 140, width: 22, height: 110, color: c.red });

    page.drawText('AI • CODING • DESIGN • VIDEO • 3D', { x: 74, y: 215, size: 11, font: fontBold, color: c.dark });
    page.drawText('Simple list. What is free. Who can claim it.', { x: 74, y: 185, size: 9.5, font: fontRegular, color: c.gray });
    page.drawText('Built for students in India and Pakistan.', { x: 74, y: 165, size: 9.5, font: fontRegular, color: c.gray });

    page.drawText('CURATED BY RAUF LABS', { x: 38, y: 40, size: 8, font: fontBold, color: c.dark });
  }

  // ==========================================
  // PAGE 2: 01 / CORE AI + CODING
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawText('RAUF LABS', { x: 28, y: H - 40, size: 8, font: fontBold, color: c.dark });
    page.drawText('FREE AI TOOLS FOR SOUTH ASIA STUDENTS', { x: W - 220, y: H - 40, size: 8, font: fontRegular, color: c.dim });

    page.drawText('01 / CORE AI + CODING', { x: 28, y: H - 85, size: 8, font: fontBold, color: c.red });
    page.drawText('AI & Coding', { x: 28, y: H - 115, size: 20, font: fontBold, color: c.dark });
    page.drawText('The strongest direct student offers for building, coding and working with AI.', { x: 28, y: H - 132, size: 9, font: fontRegular, color: c.gray });

    const offers1 = [
      ['Google AI Plus Student', '12 months free Google AI Plus with enhanced Gemini access, 400 GB storage and expanded creative AI limits.', 'INDIA + PAKISTAN'],
      ['GitHub Copilot Student', 'Free GitHub Copilot for verified students, including AI coding assistance in supported editors.', 'INDIA + PAKISTAN'],
      ['GitHub Student Developer Pack', 'Free student bundle with developer, cloud, hosting, database and learning benefits.', 'INDIA + PAKISTAN'],
      ['GitHub Codespaces', 'Student allowance for cloud development environments through GitHub Education.', 'INDIA + PAKISTAN'],
      ['Microsoft Azure for Students', 'US$100 Azure credit for 12 months plus selected free cloud services; no credit card required.', 'INDIA + PAKISTAN*'],
      ['JetBrains Student Pack', 'Professional JetBrains IDEs free while you remain an eligible student.', 'INDIA + PAKISTAN'],
      ['Framer Student Programme', 'Free Framer student access with design, CMS features and a monthly AI credit allowance.', 'INDIA + PAKISTAN*']
    ];

    let y = H - 170;
    offers1.forEach(off => {
      drawOfferCard(page, off[0], off[1], off[2], y);
      y -= 54;
    });

    page.drawText('India + Pakistan | Student & education access | September 2026', { x: 28, y: 24, size: 7.5, font: fontRegular, color: c.dim });
    page.drawText('02', { x: W - 45, y: 24, size: 8, font: fontRegular, color: c.dim });
  }

  // ==========================================
  // PAGE 3: 02 / CREATIVE STACK
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawText('RAUF LABS', { x: 28, y: H - 40, size: 8, font: fontBold, color: c.dark });
    page.drawText('FREE AI TOOLS FOR SOUTH ASIA STUDENTS', { x: W - 220, y: H - 40, size: 8, font: fontRegular, color: c.dim });

    page.drawText('02 / CREATIVE STACK', { x: 28, y: H - 85, size: 8, font: fontBold, color: c.red });
    page.drawText('Design, Video, 3D & VFX', { x: 28, y: H - 115, size: 20, font: fontBold, color: c.dark });
    page.drawText('Premium creative software and AI-assisted production tools available through education programmes.', { x: 28, y: H - 132, size: 9, font: fontRegular, color: c.gray });

    const offers2 = [
      ['Figma Education', 'Professional Figma + FigJam education access; eligible higher-ed users receive monthly Figma AI credits.', 'INDIA + PAKISTAN*'],
      ['Autodesk Flow Studio Education', 'AI motion capture, character animation, camera tracking, clean plates, masks and 3D scene export.', 'INDIA + PAKISTAN'],
      ['Autodesk Education', 'Free educational access to eligible Autodesk software including Maya and 3ds Max.', 'INDIA + PAKISTAN'],
      ['Adobe Substance 3D Education', 'Free education license for Substance 3D tools used for texturing, materials and 3D creation.', 'INDIA + PAKISTAN*'],
      ['D5 Render Education', 'Free education license for architectural rendering, interiors and animated walkthroughs.', 'INDIA + PAKISTAN'],
      ['Lumion Pro Student', 'Free renewable student license for architectural rendering, images and animation.', 'INDIA + PAKISTAN*'],
      ['Unity Student Plan', 'Free student access to Unity Pro Editor and eligible student tools / assets.', 'INDIA + PAKISTAN'],
      ['Sketch Education', 'Free one-year professional Sketch workspace, renewable while eligible.', 'INDIA + PAKISTAN*'],
      ['Shapr3D Education', 'Free one-year educational access to professional Shapr3D features.', 'INDIA + PAKISTAN*'],
      ['Graphisoft Archicad Education', 'Free renewable educational version of Archicad for eligible students.', 'INDIA + PAKISTAN*']
    ];

    let y = H - 165;
    offers2.forEach(off => {
      drawOfferCard(page, off[0], off[1], off[2], y);
      y -= 52;
    });

    page.drawText('India + Pakistan | Student & education access | September 2026', { x: 28, y: 24, size: 7.5, font: fontRegular, color: c.dim });
    page.drawText('03', { x: W - 45, y: 24, size: 8, font: fontRegular, color: c.dim });
  }

  // ==========================================
  // PAGE 4: 03 / STUDY & DATA
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawText('RAUF LABS', { x: 28, y: H - 40, size: 8, font: fontBold, color: c.dark });
    page.drawText('FREE AI TOOLS FOR SOUTH ASIA STUDENTS', { x: W - 220, y: H - 40, size: 8, font: fontRegular, color: c.dim });

    page.drawText('03 / STUDY & DATA', { x: 28, y: H - 85, size: 8, font: fontBold, color: c.red });
    page.drawText('Productivity, Voice & Analytics', { x: 28, y: H - 115, size: 20, font: fontBold, color: c.dark });
    page.drawText('Useful student tools for studying, research, voice, collaboration and data work.', { x: 28, y: H - 132, size: 9, font: fontRegular, color: c.gray });

    const offers3 = [
      ['Miro Education', 'Free education workspace with unlimited boards and limited Miro AI access.', 'INDIA + PAKISTAN*'],
      ['Notion Education', 'Free upgraded one-person education workspace for eligible university students.', 'INDIA + PAKISTAN*'],
      ['ElevenReader Ultra for Students', 'One year free to turn PDFs, articles, books and notes into natural audio.', 'INDIA + PAKISTAN*'],
      ['Fish Audio Student Credits', 'Free student voice-generation credits, voice models and API access for educational use.', 'INDIA + PAKISTAN*'],
      ['Coda Education', 'Free annual Pro Doc Maker account for qualifying students and educators.', 'INDIA + PAKISTAN*'],
      ['Lucid Education', 'Free education access to visual collaboration and diagramming tools.', 'INDIA + PAKISTAN*'],
      ['Alteryx SparkED', 'Free student access to Alteryx Designer, learning resources and education benefits.', 'INDIA + PAKISTAN*'],
      ['SAS Viya for Learners', 'Free cloud learning environment for analytics, machine learning, Python, R and SAS.', 'INDIA + PAKISTAN*'],
      ['Qlik Academic Programme', 'Free Qlik analytics software, learning resources and academic qualifications.', 'INDIA + PAKISTAN*']
    ];

    let y = H - 165;
    offers3.forEach(off => {
      drawOfferCard(page, off[0], off[1], off[2], y);
      y -= 54;
    });

    page.drawText('India + Pakistan | Student & education access | September 2026', { x: 28, y: 24, size: 7.5, font: fontRegular, color: c.dim });
    page.drawText('04', { x: W - 45, y: 24, size: 8, font: fontRegular, color: c.dim });
  }

  // ==========================================
  // PAGE 5: 04 / CAMPUS ACCESS & INDIA EXTRA
  // ==========================================
  {
    const page = doc.addPage([W, H]);
    page.drawRectangle({ x: 0, y: 0, width: W, height: H, color: c.bg });

    page.drawText('RAUF LABS', { x: 28, y: H - 40, size: 8, font: fontBold, color: c.dark });
    page.drawText('FREE AI TOOLS FOR SOUTH ASIA STUDENTS', { x: W - 220, y: H - 40, size: 8, font: fontRegular, color: c.dim });

    page.drawText('04 / CAMPUS ACCESS', { x: 28, y: H - 85, size: 8, font: fontBold, color: c.red });
    page.drawText('Free Through Your School or University', { x: 28, y: H - 115, size: 20, font: fontBold, color: c.dark });
    page.drawText('These are free when your institution participates or activates the programme.', { x: 28, y: H - 132, size: 9, font: fontRegular, color: c.gray });

    const offers4 = [
      ['Adobe Creative Cloud Pro - Higher Education', 'Photoshop, Premiere Pro, After Effects, Illustrator, Firefly, Acrobat and more through participating universities.', 'INDIA ONLY / VIA UNIVERSITY'],
      ['Microsoft Copilot Chat for Education', 'Copilot Chat through eligible Microsoft 365 Education institutional accounts.', 'VIA UNIVERSITY'],
      ['Google Workspace for Education Fundamentals', 'Gemini for Education, Gemini Notebook and other education AI features through qualifying institutions.', 'VIA UNIVERSITY'],
      ['Canva for Education', 'Premium Canva classroom environment with eligible design and AI tools.', 'K-12 / VIA SCHOOL'],
      ['Adobe Express for Education', 'Premium classroom creation tools for image, video, presentations and generative AI.', 'K-12 / VIA SCHOOL'],
      ['Foundry Education Collective', 'Nuke, NukeX, Nuke Studio, Mari and Katana through participating institutions.', 'VIA UNIVERSITY*'],
      ['Avid Media Composer Education', 'Education access through participating Avid Learning Affiliate institutions.', 'VIA UNIVERSITY*']
    ];

    let y = H - 165;
    offers4.forEach(off => {
      drawOfferCard(page, off[0], off[1], off[2], y);
      y -= 48;
    });

    // INDIA EXTRA OFFERS SECTION
    page.drawText('INDIA EXTRA OFFERS', { x: 28, y: y - 10, size: 8.5, font: fontBold, color: c.red });
    y -= 25;

    drawOfferCard(page, 'Jio Google AI Pro', '18 months free Google AI Pro for eligible Jio users on qualifying plans.', 'INDIA / ELIGIBLE JIO USERS', y);
    y -= 52;
    drawOfferCard(page, 'Airtel Adobe Express Premium', '12 months free Adobe Express Premium, 100 GB storage and monthly generative AI credits.', 'INDIA / ELIGIBLE AIRTEL USERS', y);

    // Callout footer
    page.drawText('* Institution recognition, country support or manual verification may apply. Offers and quotas can change. Verified September 2026.', {
      x: 28, y: 70, size: 7, font: fontRegular, color: c.dim
    });
    page.drawText('RAUF LABS • Save it. Share it. Use the benefits before they expire.', {
      x: 28, y: 50, size: 9, font: fontBold, color: c.dark
    });

    page.drawText('India + Pakistan | Student & education access | September 2026', { x: 28, y: 24, size: 7.5, font: fontRegular, color: c.dim });
    page.drawText('05', { x: W - 45, y: 24, size: 8, font: fontRegular, color: c.dim });
  }

  return await doc.save();
}

import os
import zipfile
import sys

ROOT_DIR = os.path.abspath(os.getcwd())
ZIP_NAME = "Rauf-Labs-Complete.zip"
OUTPUT_PATHS = [
    os.path.join(ROOT_DIR, ZIP_NAME),
    os.path.join(ROOT_DIR, "public", ZIP_NAME),
    os.path.join(ROOT_DIR, "dist", ZIP_NAME) if os.path.exists(os.path.join(ROOT_DIR, "dist")) else None
]

# Excluded folders and files
EXCLUDE_DIRS = {
    'node_modules',
    '.git',
    '.aistudio',
    '.cache',
    'dist'
}

EXCLUDE_FILES = {
    ZIP_NAME,
    '.DS_Store'
}

print(f"Packaging project from {ROOT_DIR} into {ZIP_NAME}...")

# Count included files
included_files = []

with zipfile.ZipFile(os.path.join(ROOT_DIR, ZIP_NAME), 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(ROOT_DIR):
        # Modify dirs in-place to avoid traversing excluded directories
        dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS and not d.startswith('.')]

        for file in files:
            if file in EXCLUDE_FILES or file.endswith('.zip'):
                continue
            
            abs_path = os.path.join(root, file)
            rel_path = os.path.relpath(abs_path, ROOT_DIR)
            
            # Place inside Rauf-Labs-Complete/ folder
            arcname = os.path.join("Rauf-Labs-Complete", rel_path)
            zipf.write(abs_path, arcname)
            included_files.append(rel_path)

zip_size_bytes = os.path.getsize(os.path.join(ROOT_DIR, ZIP_NAME))
zip_size_mb = zip_size_bytes / (1024 * 1024)

# Copy to public directory and dist directory if they exist
for dest in OUTPUT_PATHS[1:]:
    if dest:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(os.path.join(ROOT_DIR, ZIP_NAME), 'rb') as src_file:
            with open(dest, 'wb') as dst_file:
                dst_file.write(src_file.read())

print(f"SUCCESS: Packaged {len(included_files)} files into {ZIP_NAME} ({zip_size_mb:.2f} MB)")
print(f"Available at root: {ZIP_NAME}")
if os.path.exists(os.path.join(ROOT_DIR, "public", ZIP_NAME)):
    print(f"Available at public: public/{ZIP_NAME}")

import fs from 'node:fs';
import path from 'node:path';

const ROOT_DIR = process.cwd();

console.log('Building all-in-one standalone HTML file...');

// 1. Read base index.html
const indexHtml = fs.readFileSync(path.join(ROOT_DIR, 'index.html'), 'utf-8');

// 2. Read style.css
const styleCss = fs.readFileSync(path.join(ROOT_DIR, 'style.css'), 'utf-8');

// 3. Read pre-compiled routes data
let routesDataJs = '';
if (fs.existsSync(path.join(ROOT_DIR, 'routesData.js'))) {
  routesDataJs = fs.readFileSync(path.join(ROOT_DIR, 'routesData.js'), 'utf-8');
}

// 4. Read other scripts
const scriptJs = fs.readFileSync(path.join(ROOT_DIR, 'script.js'), 'utf-8');
const creatorHubDataJs = fs.existsSync(path.join(ROOT_DIR, 'creatorHubData.js')) ? fs.readFileSync(path.join(ROOT_DIR, 'creatorHubData.js'), 'utf-8') : '';
const creatorHubJs = fs.existsSync(path.join(ROOT_DIR, 'creatorHub.js')) ? fs.readFileSync(path.join(ROOT_DIR, 'creatorHub.js'), 'utf-8') : '';
const coursesDataJs = fs.existsSync(path.join(ROOT_DIR, 'coursesData.js')) ? fs.readFileSync(path.join(ROOT_DIR, 'coursesData.js'), 'utf-8') : '';
const coursesEngineJs = fs.existsSync(path.join(ROOT_DIR, 'coursesEngine.js')) ? fs.readFileSync(path.join(ROOT_DIR, 'coursesEngine.js'), 'utf-8') : '';
const pdfsDataJs = fs.existsSync(path.join(ROOT_DIR, 'pdfsData.js')) ? fs.readFileSync(path.join(ROOT_DIR, 'pdfsData.js'), 'utf-8') : '';
const pdfLibraryJs = fs.existsSync(path.join(ROOT_DIR, 'pdfLibrary.js')) ? fs.readFileSync(path.join(ROOT_DIR, 'pdfLibrary.js'), 'utf-8') : '';

// 5. Construct Standalone HTML
// Strip external stylesheet links and script tags from index.html
let standaloneHtml = indexHtml;

// Replace style.css link with inline <style>
standaloneHtml = standaloneHtml.replace(
  /<link\s+rel=["']stylesheet["']\s+href=["']\/?style\.css["']\s*\/?>/i,
  `<style id="standalone-inline-css">\n${styleCss}\n</style>`
);

// Remove existing external script tags for our local JS files
standaloneHtml = standaloneHtml.replace(/<script\s+src=["']\/?routesData\.js["']><\/script>\s*/gi, '');
standaloneHtml = standaloneHtml.replace(/<script\s+src=["']\/?creatorHubData\.js["']><\/script>\s*/gi, '');
standaloneHtml = standaloneHtml.replace(/<script\s+src=["']\/?creatorHub\.js["']><\/script>\s*/gi, '');
standaloneHtml = standaloneHtml.replace(/<script\s+src=["']\/?coursesData\.js["']><\/script>\s*/gi, '');
standaloneHtml = standaloneHtml.replace(/<script\s+src=["']\/?coursesEngine\.js["']><\/script>\s*/gi, '');
standaloneHtml = standaloneHtml.replace(/<script\s+src=["']\/?pdfsData\.js["']><\/script>\s*/gi, '');
standaloneHtml = standaloneHtml.replace(/<script\s+src=["']\/?pdfLibrary\.js["']><\/script>\s*/gi, '');
standaloneHtml = standaloneHtml.replace(/<script\s+src=["']\/?script\.js["']><\/script>\s*/gi, '');

// Append all scripts inline before </body>
const combinedScripts = `
  <!-- ============================================================ -->
  <!-- ALL-IN-ONE STANDALONE INLINE SCRIPT SUITE -->
  <!-- Contains Routes Cache, Creator Hub, Courses, PDFs & Interactive Engine -->
  <!-- ============================================================ -->
  <script>
  ${routesDataJs}
  </script>
  <script>
  ${creatorHubDataJs}
  </script>
  <script>
  ${creatorHubJs}
  </script>
  <script>
  ${coursesDataJs}
  </script>
  <script>
  ${coursesEngineJs}
  </script>
  <script>
  ${pdfsDataJs}
  </script>
  <script>
  ${pdfLibraryJs}
  </script>
  <script>
  ${scriptJs}
  </script>
  <script>
  // Standalone offline hash router fallback
  window.addEventListener('DOMContentLoaded', () => {
    // If opened via file:// or with a hash, handle navigation
    function handleHashOrUrl() {
      const hash = window.location.hash.replace(/^#/, '');
      if (hash && hash.startsWith('/')) {
        if (typeof window.navigateTo === 'function') {
          window.navigateTo(hash, false);
        }
      }
    }
    window.addEventListener('hashchange', handleHashOrUrl);
    handleHashOrUrl();
  });
  </script>
`;

standaloneHtml = standaloneHtml.replace('</body>', `${combinedScripts}\n</body>`);

// Write standalone.html
const outPath = path.join(ROOT_DIR, 'standalone.html');
fs.writeFileSync(outPath, standaloneHtml, 'utf-8');

const publicPath = path.join(ROOT_DIR, 'public', 'standalone.html');
fs.writeFileSync(publicPath, standaloneHtml, 'utf-8');

const distDir = path.join(ROOT_DIR, 'dist');
if (fs.existsSync(distDir)) {
  fs.writeFileSync(path.join(distDir, 'standalone.html'), standaloneHtml, 'utf-8');
}

const stats = fs.statSync(outPath);
console.log(`Successfully generated standalone.html (${(stats.size / 1024).toFixed(1)} KB)`);

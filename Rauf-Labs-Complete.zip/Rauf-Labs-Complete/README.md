# Rauf Labs — Developer Portfolio & Learning Platform

> A comprehensive, modern developer portfolio, interactive learning portal, and engineering command center for Termux, Linux, PowerShell, Bash, Git, Android Engineering, 1,700+ Public APIs, and Gemini AI.

---

## 🚀 Project Overview

**Rauf Labs** is a production-grade full-stack web platform built for software engineers, mobile developers, and creators. It combines interactive education, real developer utility tools, a curated public API catalog, an interactive course player with quizzes, an offline digital book reader, and server-side Google Gemini AI integration.

### Key Features
- **Interactive Command Center**: Complete mastery tracks for Termux, Linux, Bash, PowerShell, Git, Programming, and Android (13 hands-on lessons).
- **Interactive Courses Engine**: Structured curricula with modular lessons, code sandboxes, interactive knowledge checks, and progress tracking.
- **1,700+ Public APIs Directory**: Curated, searchable, and categorised catalog with instant copy endpoints, auth requirements, and documentation links.
- **Developer Utilities Suite**: 11 in-browser developer utilities (JSON Formatter, Base64 Encoder/Decoder, Hash Generator, UUIDv4, Regex Tester, Markdown Previewer, and more).
- **Viral Creator Hub & Academy**: 29 video editing tutorials, meme format libraries, viral hooks database, and asset resources.
- **Digital PDF Library & Reader**: Built-in PDF reader with offline caching and category filtering.
- **Gemini AI Copilot**: Server-side proxy powering code explanations, shell troubleshooting, and programming assistance.
- **All-in-One Standalone Version**: Included `standalone.html` bundle capable of running 100% offline without Node.js or a web server.

---

## 🛠️ System Requirements

- **Node.js**: `v18.0.0` or higher (Node.js 20+ recommended)
- **Package Manager**: `npm` (included with Node.js) or `pnpm` / `bun`
- **Operating System**: Linux, macOS, or Windows (WSL2 recommended on Windows)
- **Google Gemini API Key** *(Optional for AI Copilot)*: Obtain free from [Google AI Studio](https://aistudio.google.com/)

---

## 📦 Installation Instructions

1. **Extract or clone the project archive:**
   ```bash
   cd Rauf-Labs-Complete
   ```

2. **Install all dependencies:**
   ```bash
   npm install
   ```

3. **Configure Environment Variables:**
   Copy the example environment file:
   ```bash
   cp .env.example .env
   ```
   Open `.env` and set your Google Gemini API key:
   ```env
   GEMINI_API_KEY=your_gemini_api_key_here
   ```
   *(Note: The platform functions completely without the API key; AI features will safely prompt for configuration).*

---

## ⚡ NPM Scripts & Commands

| Command | Description |
| :--- | :--- |
| `npm run dev` | Starts the development server on `http://localhost:3000` with Express + Vite middleware and hot reload. |
| `npm run build` | Builds the client application with Vite, compiles the Express server with esbuild into `dist/server.cjs`, and generates `standalone.html`. |
| `npm start` | Runs the compiled production server (`node dist/server.cjs`) on `http://0.0.0.0:3000`. |
| `npm run lint` | Runs TypeScript type checking (`tsc --noEmit`) to verify code integrity across all routes. |
| `npm run preview` | Previews the compiled static assets using Vite's built-in preview server. |
| `npm run clean` | Cleans up the `dist` build artifacts directory. |

---

## 🤖 Gemini API Configuration & Security

The application strictly adheres to server-side API proxy security:
- **Server Proxy Route**: `/api/gemini/chat` and `/api/gemini/test-connection` in `server.ts`.
- **Zero Client Exposure**: The `GEMINI_API_KEY` is loaded securely via `dotenv` and `process.env.GEMINI_API_KEY` in `server.ts` and is never bundled into client JavaScript.
- **Model Support**: Automatically defaults to `gemini-3.8-flash` with support for `gemini-flash-latest`, `gemini-3.1-flash-lite`, and `gemini-3.1-pro-preview`.
- **Direct Client Override**: Users can optionally supply a temporary header `x-gemini-api-key` in the AI Copilot UI for client-directed queries without saving secrets to disk.

---

## 📁 Project Structure

```text
Rauf-Labs-Complete/
├── package.json              # Project dependencies, scripts, and engine specifications
├── vite.config.ts            # Vite Multi-Page Application (MPA) build configuration
├── tsconfig.json             # TypeScript compiler settings
├── server.ts                 # Full-stack Express backend & Vite middleware server
├── metadata.json             # AI Studio applet manifest
├── .env.example              # Environment variables template
├── README.md                 # Documentation and guide
├── index.html                # Homepage & navigation entry
├── courses.html              # Interactive Courses Platform
├── pdfs.html                 # Digital Books & PDF Library
├── creator.html              # Viral Creator Hub & Editing Academy
├── developer.html            # Developer Command Center Hub
├── android.html              # Android Engineering Masterclass
├── termux.html               # Termux Mobile Workstation Guide
├── linux.html                # Linux Systems Administration Guide
├── bash.html                 # Bash Shell Scripting Guide
├── powershell.html           # PowerShell & Automation Guide
├── git.html                  # Git & GitHub Collaboration Guide
├── programming.html          # Programming Languages & Foundations
├── apis.html                 # 1,700+ Public APIs Directory
├── tools.html                # 11 Developer Utilities Suite
├── projects.html             # 20+ Practical Software Projects
├── roadmap.html              # 10-Stage Engineering Roadmap
├── ai.html                   # Gemini AI Copilot Interface
├── login.html                # Developer Profile & Portal
├── about.html                # About & Mission
├── skills.html               # Technical Skills Matrix
├── blog.html                 # Engineering Blog
├── contact.html              # Consultation & Contact Form
├── qr.html                   # QR Code Generator & Scanner
├── 404.html                  # 404 Not Found Page
├── style.css                 # Master Design System & Stylesheet (156 KB)
├── script.js                 # Universal SPA Routing Engine & App Controllers
├── routesData.js             # Pre-compiled SPA client cache
├── coursesData.js            # Structured Course Curricula & Lessons
├── coursesEngine.js          # Interactive Course & Quiz Runtime
├── creatorHubData.js         # Creator Trends & Meme Database
├── creatorHub.js             # Creator Hub & Editing Academy Controller
├── pdfsData.js               # Digital Books Catalog
├── pdfLibrary.js             # PDF Search & Reader Controller
├── standalone.html           # 100% Offline Single-File HTML Build
├── public/                   # Static assets, icons, vendor libraries, PDFs
│   ├── vendor/pdfjs/         # Mozilla PDF.js rendering distribution
│   └── assets/               # Project badges and media
├── pdfs/                     # High-quality developer reference guides
└── scripts/                  # Build automation & route compiler scripts
    ├── build-standalone-html.mjs
    └── prepare-routes.mjs
```

---

## 🚢 Deployment Options

### 1. Cloud Run / Docker Container
The included `package.json` specifies `"start": "node dist/server.cjs"`. When containerized:
```dockerfile
FROM node:20-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

### 2. Traditional VPS (Ubuntu, Debian, CentOS)
```bash
git clone <your-repo>
cd Rauf-Labs-Complete
npm install
npm run build
pm2 start dist/server.cjs --name "rauf-labs"
```

### 3. Static Hosting (Netlify, Vercel, GitHub Pages)
Because the application generates pre-rendered HTML files (`dist/*.html`) and includes `dist/_redirects`, you can directly deploy the contents of the `dist/` folder to any static host.

### 4. 100% Offline / Desktop Mode
Simply double-click `standalone.html` in any web browser. It operates with zero dependencies, zero network requests, and full client-side routing.

---

## 📄 License & Credits

Created by **Rauf** — Developer, Systems Specialist & Creator.  
Released under the MIT License.

/**
 * 🔥 VIRAL CREATOR HUB DATA ARCHITECTURE
 * Curated databases for Editing Academy, Memes, Guides, AI Tools & Workflows
 */

window.VIRAL_MEMES_DATA = [
  {
    id: 'm1',
    title: "The 'Wait For It' Drop Audio Loop",
    platform: 'Reels',
    velocity: '🔥 +340% Velocity (Rising)',
    updated: 'Today · 1 hour ago',
    explanation: 'A sudden audio frequency low-pass filter paired with a visual zoom cut. Triggers curiosity and boosts viewer completion rate by 2.4x.',
    example: 'Showing a messy code file or broken terminal, cutting precisely on the 808 sub-bass beat drop to a fully automated responsive app.',
    nicheTips: {
      hook: 'First 1.5s: Extreme closeup of the problem or error message with on-screen text "Never do this in 2026".',
      audio: 'Use the official trending sound loop directly inside Instagram or Shorts audio picker to register trend velocity.',
      niche: 'Tech: Termux compilation; Fitness: Form comparison; Finance: Compound interest chart reveal.'
    }
  },
  {
    id: 'm2',
    title: 'POV: Senior vs Junior in 2026',
    platform: 'Shorts',
    velocity: '⚡ High Engagement (Peaking)',
    updated: 'Today · 2 hours ago',
    explanation: 'Side-by-side comparison playing on shared industry pain points. Captures high comment volume through relatable debates.',
    example: 'Junior writing 50 lines of complex nested loops vs Senior using a single optimized regex or terminal command.',
    nicheTips: {
      hook: 'First 2s: Text reads "How Juniors fix bugs vs Seniors" with fast eye contact to camera.',
      audio: 'Upbeat lo-fi beat or dramatic tension riser building to comedy punchline.',
      niche: 'Adapts to Coding, Video Editing, Investing, and Everyday Workflows.'
    }
  },
  {
    id: 'm3',
    title: 'Green Screen CapCut Reaction Format',
    platform: 'Instagram',
    velocity: '🔥 +280% Velocity',
    updated: 'Today · 3 hours ago',
    explanation: 'Creator cuts themselves out using CapCut auto-cutout and reacts expressively in the bottom corner while dissecting real-time tech news.',
    example: 'Creator pointing at a breaking GitHub repo or new AI model benchmark chart with animated callouts.',
    nicheTips: {
      hook: 'Point directly up at the headline within 0.8s: "Wait until you see what just dropped."',
      audio: 'Background whisper audio ducked to -22dB so voiceover is crisp and punchy.',
      niche: 'Perfect for fast tech breakdowns, tutorials, and app reviews.'
    }
  },
  {
    id: 'm4',
    title: 'The 7-Second Rule Kinetic Loop',
    platform: 'Reels',
    velocity: '⚡ +195% Velocity',
    updated: 'Today · 4 hours ago',
    explanation: 'Short 6–8 second video where the last spoken sentence connects seamlessly back into the first sentence, tricking viewers into watching twice.',
    example: 'End sentence: "And that is the exact reason why...", Video start: "...you should never deploy on a Friday."',
    nicheTips: {
      hook: 'No intro greeting. Jump straight into the mid-sentence action.',
      audio: 'Continuous loop ambient track without a distinctive end or fade.',
      niche: 'Maximizes watch time percentage to 140%+, triggering algorithmic Explore push.'
    }
  },
  {
    id: 'm5',
    title: 'Fast Screen Recording with Beat Drops',
    platform: 'YouTube',
    velocity: '🔥 +220% Velocity',
    updated: 'Today · 5 hours ago',
    explanation: 'Screen capture speed-ramped at 400% with kinetic zoom pans on key terminal outputs or code saves, cutting on music beats.',
    example: 'Spinning up a Linux server or running a Python scraper in under 20 seconds with rhythmic cuts.',
    nicheTips: {
      hook: 'Full completed product shown in frame 1 for 0.5s before rewinding to start.',
      audio: 'High-energy electronic or drill instrumental with distinct snare hits.',
      niche: 'Coding, Terminal setups, 3D design, and Video Editing timelapses.'
    }
  },
  {
    id: 'm6',
    title: '3 Mistakes You Are Making Right Now',
    platform: 'Memes',
    velocity: '⚡ High Retention Format',
    updated: 'Today · 6 hours ago',
    explanation: 'Loss aversion psychological trigger. Viewers fear they are wasting time or damaging their devices, guaranteeing high bookmark/save rates.',
    example: '3 mistakes beginners make with Git commits or smartphone battery health.',
    nicheTips: {
      hook: 'Contrarian statement: "Stop learning X until you fix this single habit."',
      audio: 'Subtle tense ticking clock sound effect under the first 3 seconds.',
      niche: 'Universal across Tech, Productivity, Finance, and Fitness.'
    }
  }
];

window.IG_GUIDES_DATA = {
  'ig-hashtags': {
    title: 'Instagram Hashtags Strategy: The 3-5 Rule',
    badge: 'Hashtag Science',
    content: `
      <h4>Why 30 Hashtags No Longer Works</h4>
      <p>In recent algorithm updates, Meta's AI categorizes content primarily through <strong>computer vision, spoken audio transcription, and on-screen text</strong>. Flooding your caption with 30 broad hashtags dilutes your topic categorization and triggers spam filters.</p>
      <h4>The 3–5 High-Intent Formula:</h4>
      <ul>
        <li><strong>1 Broad Industry Tag:</strong> 500k–2M posts (e.g. <code>#webdevelopment</code> or <code>#videoediting</code>) to signal the overarching vertical.</li>
        <li><strong>2 Niche Community Tags:</strong> 50k–300k posts (e.g. <code>#termuxlinux</code>, <code>#premiereprotips</code>) to hit engaged peers.</li>
        <li><strong>1–2 Specific Context Tags:</strong> &lt;50k posts describing the exact video subject (e.g. <code>#pythonwebscraping</code>).</li>
      </ul>
      <p>Place tags at the very end of your caption separated by line breaks. Avoid putting tags in comments, as caption tags index faster.</p>
    `
  },
  'ig-niches': {
    title: 'Hashtag Clusters by Niche (Verified)',
    badge: 'Niche Clusters',
    content: `
      <h4>Tech &amp; Coding:</h4>
      <p><code>#codinglife #developerlife #learnprogramming #termux #linuxterminal</code></p>
      <h4>Video Editing &amp; Creators:</h4>
      <p><code>#videoeditingtips #capcuttutorial #contentcreator #reelsediting #premierepro</code></p>
      <h4>AI &amp; Automation:</h4>
      <p><code>#aitools #artificialintelligence #promptengineering #futuretech #automation</code></p>
      <h4>Productivity &amp; Career:</h4>
      <p><code>#productivityhacks #devcommunity #softwareengineer #worksmart #techcareer</code></p>
      <p><em>Tip: Always tailor the last 2 tags to the exact tool or concept shown in your video.</em></p>
    `
  },
  'ig-formats': {
    title: '6 Highest-Converting Reels Formats',
    badge: 'Viral Formats',
    content: `
      <h4>1. The Side-by-Side Reality Check:</h4>
      <p>Split screen showing expectations on top and the messy truth on bottom. Drives massive comment arguments.</p>
      <h4>2. The 15-Second Actionable Hack:</h4>
      <p>Zero fluff. Frame 1 shows the result, frame 2 shows the 1-line command or button, frame 3 gives the tip.</p>
      <h4>3. The "Don't Do This" Contrarian Hook:</h4>
      <p>Challenge accepted wisdom in your niche. Disagreeing with popular dogma immediately halts scrolling thumbs.</p>
      <h4>4. The Seamless Infinite Loop:</h4>
      <p>Script your final sentence so the last word flows grammatically into the first spoken word.</p>
      <h4>5. The Fast Screen Speedrun:</h4>
      <p>Screen recording at 300% speed with energetic audio and voiceover explaining 3 key steps.</p>
      <h4>6. The Before vs After Reveal:</h4>
      <p>Show how a project looked 1 hour ago vs how it looks now with polished styling.</p>
    `
  },
  'ig-make-reel': {
    title: 'How to Make a Reel (Step-by-Step Production)',
    badge: 'Production Guide',
    content: `
      <ol>
        <li><strong>Resolution &amp; Framing:</strong> Shoot in 4K or 1080p at 30fps or 60fps in portrait 9:16 (1080x1920). Keep subject eyes on the upper third gridline.</li>
        <li><strong>Audio First:</strong> Ensure voiceover is recorded with a clean lapel or close condenser mic. Add gentle audio compression and high-pass filter at 80Hz.</li>
        <li><strong>The 2.5-Second Rule:</strong> Never keep a static shot longer than 2.5 seconds without a pattern interrupt (zoom cut, graphic overlay, or sound effect).</li>
        <li><strong>Safe Margins:</strong> Keep all important subtitles inside the middle 80% to avoid bottom caption text and right-hand like/share icons.</li>
      </ol>
    `
  },
  'ig-upload-settings': {
    title: 'How to Upload a Reel (High-Quality Config)',
    badge: 'Upload Protocol',
    content: `
      <h4>Essential Settings Before You Post:</h4>
      <ul>
        <li><strong>Enable High-Quality Uploads:</strong> In Instagram, go to Profile &gt; Settings &gt; Media Quality &gt; Turn ON <em>"Upload at highest quality"</em>. Otherwise IG aggressively compresses video over cellular data.</li>
        <li><strong>Select Cover Frame:</strong> Scrub to the cleanest facial expression or high-contrast frame. Do not leave it on a blurry mid-transition.</li>
        <li><strong>Turn Off In-App Video Compression:</strong> Export your video at 20–25 Mbps bitrate in H.264 MP4. Do not upload bloated ProRes files.</li>
        <li><strong>Audio Volume:</strong> When adding trending background music, lower music volume to 8–12% so voiceover remains completely intelligible.</li>
      </ul>
    `
  },
  'ig-captions': {
    title: 'Caption Best Practices: The 125-Character Hook',
    badge: 'Copywriting',
    content: `
      <p>Instagram truncates captions after approximately 125 characters with a "...more" button. Tapping "...more" counts as an active engagement signal!</p>
      <h4>The 3-Part Caption Architecture:</h4>
      <ul>
        <li><strong>Line 1 (The Hook):</strong> Provocative question or incomplete cliffhanger that compels tapping "...more".</li>
        <li><strong>Body (The Value Drop):</strong> 3–5 bullet points summarizing commands, steps, or tools mentioned in the Reel.</li>
        <li><strong>Call to Action (The Save Trigger):</strong> "Save this post for your next project so you don't lose the config." Saves signal high content utility to the algorithm.</li>
      </ul>
    `
  },
  'ig-hooks': {
    title: '25+ High-Retention Hook Formulas',
    badge: 'Hook Formulas',
    content: `
      <h4>Contrarian Hooks:</h4>
      <ul>
        <li>"Stop doing [X] the hard way in 2026."</li>
        <li>"Why 95% of creators fail at [topic]."</li>
        <li>"This common advice is actually killing your reach."</li>
      </ul>
      <h4>Curiosity Gap Hooks:</h4>
      <ul>
        <li>"I tested [X] for 30 days so you don't have to."</li>
        <li>"Nobody is talking about this hidden setting."</li>
        <li>"The single command that saved me 4 hours yesterday."</li>
      </ul>
      <h4>Direct Benefit Hooks:</h4>
      <ul>
        <li>"How to set up [tool] in exactly 60 seconds."</li>
        <li>"Copy this exact workflow for your next video."</li>
      </ul>
    `
  },
  'ig-cover-design': {
    title: 'Reel Cover & Thumbnail Safe Zones',
    badge: 'Safe Zones',
    content: `
      <p>Reels appear in 3 different aspect ratios across Instagram:</p>
      <ul>
        <li><strong>9:16 (Full Screen):</strong> When viewing inside the Reels feed.</li>
        <li><strong>4:5 (Home Feed):</strong> When appearing in followers' main home feeds.</li>
        <li><strong>1:1 (Square Profile Grid):</strong> When visitors browse your profile tab.</li>
      </ul>
      <p><strong>Golden Rule:</strong> Place all cover typography inside the exact 1:1 center square. If text extends outside the center square, it will be cut off on your profile grid.</p>
    `
  },
  'ig-seo': {
    title: 'Instagram SEO: Ranking on the Explore Page',
    badge: 'SEO Indexing',
    content: `
      <h4>Where Instagram Searches for Keywords:</h4>
      <ol>
        <li><strong>Your Name Field:</strong> In your profile, your Name can be different from your @handle. Add keywords (e.g. "Rauf | Tech &amp; Coding").</li>
        <li><strong>Spoken Dialogue:</strong> Meta AI transcribes your audio into text. Clearly speak your target keywords during the first 5 seconds.</li>
        <li><strong>Caption Body:</strong> Naturally include 3–5 semantic keywords in your caption paragraph.</li>
        <li><strong>Advanced Settings Alt Text:</strong> Add descriptive accessibility alt text describing the visuals.</li>
      </ol>
    `
  },
  'ig-reach': {
    title: 'How to Expand Non-Follower Reach',
    badge: 'Reach Multipliers',
    content: `
      <p>The Instagram distribution hierarchy ranks actions by value:</p>
      <p style="font-size: 1.1rem; font-weight: 700; color: #38bdf8;">DMs/Shares &gt; Saves &gt; Comments &gt; Likes</p>
      <p>When a viewer sends your Reel to a friend in Instagram DMs, the algorithm registers the highest possible recommendation signal. Craft content that makes people think: <em>"My friend/coworker needs to see this."</em></p>
    `
  },
  'ig-insights': {
    title: 'How to Analyze Professional Insights',
    badge: 'Analytics Reading',
    content: `
      <h4>Key Metrics to Inspect:</h4>
      <ul>
        <li><strong>Non-Follower Reach Ratio:</strong> If &gt;70% of viewers are non-followers, the algorithm pushed your Reel to Explore. If &lt;30%, the hook failed to hold cold audiences.</li>
        <li><strong>Average Watch Percentage:</strong> For videos under 20s, aim for &gt;85%. For videos over 45s, aim for &gt;65%.</li>
        <li><strong>Drop-Off Curve:</strong> Check where the line drops sharply. That is where your pacing slowed down or where you used filler words.</li>
      </ul>
    `
  },
  'ig-cadence': {
    title: 'Posting Cadence & Community Engagement Window',
    badge: 'Cadence Blueprint',
    content: `
      <p>Quality and retention trump blind quantity. Posting 3–4 high-retention, well-edited Reels per week consistently outperforms posting daily low-effort slides.</p>
      <p><strong>The 30-Minute Golden Rule:</strong> Stay inside the app for the first 25–30 minutes after publishing. Reply to incoming comments with open-ended questions to spark conversation threads.</p>
    `
  }
};

window.YT_GUIDES_DATA = {
  'yt-hashtags': {
    title: 'YouTube Hashtags Strategy',
    badge: 'Tag Rules',
    content: `
      <p>YouTube only displays the first <strong>3 hashtags</strong> above the video title on mobile and desktop. Adding more than 15 hashtags violates YouTube policies and causes all tags on the video to be disregarded.</p>
      <p>Use 1 channel branding tag (e.g. <code>#RaufLabs</code>) and 2 precise topical tags (e.g. <code>#Termux</code> <code>#Linux</code>). Place them at the very bottom of your description.</p>
    `
  },
  'yt-shorts-tags': {
    title: 'YouTube Shorts Hashtags & Distribution',
    badge: 'Shorts Engine',
    content: `
      <p>Always include <code>#shorts</code> in the title or first line of your description. This explicitly instructs the indexing robot to categorize the media in the vertical Shorts shelf.</p>
      <p>Pair with 2 high-volume vertical tags like <code>#tech</code>, <code>#programming</code>, or <code>#editing</code>.</p>
    `
  },
  'yt-seo': {
    title: 'YouTube Video SEO & Metadata Optimization',
    badge: 'Search Engine',
    content: `
      <h4>The 3 Pillars of YouTube Search:</h4>
      <ul>
        <li><strong>Title Front-Loading:</strong> Put the primary search query in the first 4 words of the title.</li>
        <li><strong>First 2 Lines of Description:</strong> Summarize the solution with natural keyword density before the 'Show More' fold.</li>
        <li><strong>Structured Chapters:</strong> Timestamps starting with <code>00:00 Intro</code> allow Google Search to feature key moments directly in Google web search results.</li>
      </ul>
    `
  },
  'yt-start-channel': {
    title: 'How to Start a YouTube Channel (0 to 1,000 Subscribers)',
    badge: 'Channel Launch',
    content: `
      <ol>
        <li><strong>Define Your Single Viewer:</strong> What exact problem do you solve for what specific person? (e.g. "Practical Linux tutorials for beginners on Android").</li>
        <li><strong>Record 5 Videos Before Launching:</strong> Never launch with just 1 video. Having 4–5 related videos allows viewers to binge your channel immediately.</li>
        <li><strong>Focus on Search First:</strong> Brand-new channels have 0 authority for Browse/Suggested. Build search-first evergreen tutorials to generate baseline views.</li>
      </ol>
    `
  },
  'yt-upload-video': {
    title: 'How to Upload a Video (Studio Settings)',
    badge: 'Upload Protocol',
    content: `
      <p><strong>The Unlisted Protocol:</strong> Always upload as <em>Unlisted</em> 2 hours before your scheduled public launch time. This allows YouTube servers to:</p>
      <ul>
        <li>Process 1080p and 4K high-definition video tiers.</li>
        <li>Run automated copyright scans and checks.</li>
        <li>Generate automatic transcripts and closed captions.</li>
      </ul>
      <p>Configure End Screens to point to a relevant video or playlist, not your generic channel homepage.</p>
    `
  },
  'yt-upload-shorts': {
    title: 'How to Upload Shorts for Maximum Retention',
    badge: 'Shorts Protocol',
    content: `
      <p>Sweet spot duration for Shorts is <strong>28 to 42 seconds</strong>. Anything under 15 seconds often struggles to communicate value; anything over 50 seconds requires flawless retention pacing.</p>
      <p>Always select your thumbnail frame inside the YouTube mobile app during upload by tapping the pencil icon on the preview frame.</p>
    `
  },
  'yt-titles': {
    title: 'How to Write High-CTR Titles (&lt;60 Chars)',
    badge: 'Headline Science',
    content: `
      <p>Keep titles under 60 characters so they are never truncated on mobile screens.</p>
      <h4>Title Formats that Drive Clicks:</h4>
      <ul>
        <li><strong>The Specific Case Study:</strong> "How I Turned My Android Phone into a Linux Server"</li>
        <li><strong>The Curiosity Gap:</strong> "The Python Feature You Should Never Use"</li>
        <li><strong>The Fast Tutorial:</strong> "Git Merge Conflicts Explained in 4 Minutes"</li>
      </ul>
    `
  },
  'yt-description': {
    title: 'How to Write a Professional YouTube Description',
    badge: 'Description Template',
    content: `
      <p>Structure your description like a technical documentation page:</p>
      <pre style="background: rgba(0,0,0,0.4); padding: 12px; border-radius: 6px; font-family: monospace; font-size: 0.85rem; color: #38bdf8;">
[Line 1-2: What viewer learns + Primary Keyword]

TIMESTAMPS:
00:00 - Introduction &amp; Overview
01:15 - Installing Dependencies
03:40 - Writing the Script
06:20 - Testing &amp; Verification

RESOURCES &amp; CODE:
GitHub Repository: https://github.com/...
Official Documentation: https://...

CONNECT WITH ME:
Instagram: https://instagram.com/...
Website: https://rauflabs.local/
      </pre>
    `
  },
  'yt-keywords': {
    title: 'Keyword Research & Autocomplete Mining',
    badge: 'Keyword Mining',
    content: `
      <p>Type your broad topic into the YouTube search bar and append an underscore (<code>_</code>) before or after words (e.g. <code>termux _ tutorial</code>). YouTube autocomplete shows the exact queries real humans are typing right now.</p>
      <p>Target queries with clear search intent: "How to fix...", "Step by step...", "For beginners".</p>
    `
  },
  'yt-analytics': {
    title: 'YouTube Analytics Basics (CTR &amp; AVD)',
    badge: 'Studio Analytics',
    content: `
      <p>Your video's success is determined by a simple mathematical formula:</p>
      <p style="font-size: 1.1rem; font-weight: 700; color: #34d399;">Impressions × Click-Through Rate (CTR) × Average View Duration (AVD)</p>
      <p>A healthy CTR benchmark for established topics is <strong>4% to 8%</strong>. If your CTR is below 3%, redesign your thumbnail and title immediately.</p>
    `
  },
  'yt-retention': {
    title: 'Audience Retention Curve Analysis',
    badge: 'Retention Graph',
    content: `
      <h4>How to Read the Retention Line:</h4>
      <ul>
        <li><strong>The First 30 Seconds:</strong> If your retention curve drops below 65% at 0:30, your intro was too slow or talked about yourself instead of the promised topic.</li>
        <li><strong>Spikes:</strong> Viewers rewound to rewatch a code snippet or visual diagram. Note these moments and do more of them!</li>
        <li><strong>Dips:</strong> Viewers skipped forward through boring explanations or long sponsor reads.</li>
      </ul>
    `
  },
  'yt-strategy': {
    title: 'Beginner Channel Strategy: Search First &gt; Browse',
    badge: 'Channel Strategy',
    content: `
      <p>New channels cannot rely on the Browse feed. Produce 70% Search-Focused evergreen content that will steadily bring 20–100 views a day for years. Once you have a core subscriber base, introduce Browse-focused trending opinion and commentary videos.</p>
    `
  }
};

window.EDITING_ACADEMY_LESSONS = {
  beginner: [
    {
      id: 'b1',
      title: 'Timeline Organization & Project Setup',
      diff: 'Beginner',
      time: '10 mins',
      desc: 'How to structure project folders, import media without linking errors, and organize video and audio tracks.',
      steps: [
        'Create a dedicated folder for Footages, B-Roll, Audio, and Graphics.',
        'Set project timeline framerate to 30fps or 60fps matching source footage.',
        'Assign Track 1 for primary dialogue, Track 2 for sound effects, Track 3 for background music.',
        'Enable autosave every 5 minutes in preferences.'
      ],
      task: 'Create a clean 3-folder directory on your device and import 3 video clips into a 1080x1920 vertical timeline.',
      mistake: 'Dumping all files on Desktop or Camera Roll without folder separation.'
    },
    {
      id: 'b2',
      title: 'Cutting and Trimming (J-Cuts & L-Cuts)',
      diff: 'Beginner',
      time: '12 mins',
      desc: 'Removing dead pauses, eliminating "uhm" hesitations, and creating smooth audio cross-overlaps.',
      steps: [
        'Zoom in to view audio waveforms on your timeline.',
        'Blade and delete every silence gap longer than 0.3 seconds.',
        'Extend audio under the preceding clip (J-Cut) so speech begins before the visual changes.',
        'Use L-Cuts to allow speech to linger while displaying relevant B-roll.'
      ],
      task: 'Take a 60-second raw voice recording and trim it down to 35 seconds of punchy dialogue.',
      mistake: 'Leaving 1-second awkward pauses between sentences that cause viewer drop-off.'
    },
    {
      id: 'b3',
      title: 'Adding Music & Background Audio Balancing',
      diff: 'Beginner',
      time: '14 mins',
      desc: 'Finding copyright-safe music and ducking background audio under speech.',
      steps: [
        'Source royalty-free music from YouTube Audio Library or copyright-cleared platforms.',
        'Normalize voiceover dialogue to peak between -6dB and -3dB.',
        'Lower background music track to -22dB to -26dB whenever dialogue is active.',
        'Apply a 1.5-second fade in at the start and fade out at the end.'
      ],
      task: 'Balance a voiceover track with an upbeat instrumental so every word is crystal clear.',
      mistake: 'Background music playing at -10dB, drowning out the speaker voice.'
    },
    {
      id: 'b4',
      title: 'Text & Captions Placement',
      diff: 'Beginner',
      time: '15 mins',
      desc: 'Font selection, contrast outlines, safe margins, and subtitle readability.',
      steps: [
        'Select a clean, bold sans-serif font like Plus Jakarta Sans, Montserrat, or Arial Black.',
        'Add a subtle 2px dark drop shadow or 1px outline for readability on bright backgrounds.',
        'Keep subtitle lines under 4–6 words per screen for fast mobile scanning.',
        'Position captions at 35% height from bottom to clear Instagram and TikTok UI buttons.'
      ],
      task: 'Add animated subtitles to a 15-second clip highlighting key action verbs in cyan or yellow.',
      mistake: 'Using delicate cursive fonts placed too close to the bottom screen edge.'
    },
    {
      id: 'b5',
      title: 'Transitions: Cut on Action & Whip Pans',
      diff: 'Beginner',
      time: '11 mins',
      desc: 'Moving between scenes naturally without relying on cheesy spinning 3D transitions.',
      steps: [
        'Cut on action: Slice the clip midway through a hand gesture or head turn.',
        'Use whip-pans or quick directional motion blurs between related scenes.',
        'Keep transition duration under 6–10 frames (approx 0.25 seconds).',
        'Ensure the focal point of the outgoing frame matches the focal point of the incoming frame.'
      ],
      task: 'Edit 3 clips together using only hard cuts on action without any plugin transitions.',
      mistake: 'Overusing rainbow wipes and 3D cube rotations that look amateur.'
    },
    {
      id: 'b6',
      title: 'Aspect Ratios: 9:16 vs 16:9 vs 4:5',
      diff: 'Beginner',
      time: '9 mins',
      desc: 'Targeting correct screen dimensions for Shorts/Reels, YouTube, and feed posts.',
      steps: [
        'Vertical Shorts/Reels: 1080 × 1920 (9:16 aspect ratio).',
        'Standard YouTube/Desktop: 1920 × 1080 or 3840 × 2160 (16:9 aspect ratio).',
        'Instagram Feed: 1080 × 1350 (4:5 vertical feed crop).',
        'Enable grid guides to monitor center-weighted mobile display.'
      ],
      task: 'Export the same master clip in both 16:9 widescreen and 9:16 vertical formats.',
      mistake: 'Uploading 16:9 videos with black bars on top and bottom into Shorts feed.'
    },
    {
      id: 'b7',
      title: 'Export Settings: 1080p, Bitrate & Codecs',
      diff: 'Beginner',
      time: '13 mins',
      desc: 'Optimal export settings for mobile and web video players.',
      steps: [
        'Format: MP4 container with H.264 video codec.',
        'Framerate: Constant 30fps or 60fps (avoid Variable Frame Rate VFR).',
        'Bitrate: 15–20 Mbps for 1080p; 35–45 Mbps for 4K exports.',
        'Audio: AAC Stereo, 320 kbps, 48 kHz sample rate.'
      ],
      task: 'Export a 30-second test video and verify file size is under 60MB with zero compression artifacts.',
      mistake: 'Exporting at 100 Mbps creating a 2GB file that mobile apps fail to upload.'
    },
    {
      id: 'b8',
      title: 'Basic Audio: Noise Reduction & Normalization',
      diff: 'Beginner',
      time: '16 mins',
      desc: 'Removing room hiss, HVAC hum, and normalizing volume levels.',
      steps: [
        'Capture 2 seconds of room tone silence to sample background noise.',
        'Apply mild noise reduction (6dB to 12dB max) to avoid robotic metallic artifacts.',
        'Use an 80Hz High-Pass filter to strip out air conditioner rumbles.',
        'Apply a limiter to prevent peaks from exceeding -1.0dB true peak.'
      ],
      task: 'Clean a noisy mobile audio recording and normalize dialogue to -14 LUFS integrated.',
      mistake: 'Maxing out noise suppression so the speaker sounds like they are speaking underwater.'
    },
    {
      id: 'b9',
      title: 'Basic Color Adjustment: Exposure & Contrast',
      diff: 'Beginner',
      time: '14 mins',
      desc: 'Balancing shadows, highlights, and natural skin tone saturation.',
      steps: [
        'Set correct white balance using a neutral gray or white object in the frame.',
        'Adjust exposure so shadows sit above 0% and highlights do not clip at 100%.',
        'Add gentle S-curve contrast to add punch and depth to flat mobile footage.',
        'Check skin tones against the vectorscope skin-tone indicator line.'
      ],
      task: 'Correct an underexposed indoor video clip to look warm and natural.',
      mistake: 'Oversaturating colors until skin looks orange or sunburned.'
    }
  ],
  intermediate: [
    {
      id: 'i1',
      title: 'Advanced Transitions: Match Cuts & Speed Wipes',
      diff: 'Intermediate',
      time: '18 mins',
      desc: 'Creative invisible transitions matching geometry, motion direction, or color.',
      steps: [
        'Align moving subjects along identical vector paths across the cut.',
        'Accelerate speed at the end of Clip A and start of Clip B with directional blur.',
        'Use audio whoosh impacts precisely 2 frames before the visual transition point.',
        'Color match the transition frames so lighting changes feel intentional.'
      ],
      task: 'Create a seamless match-cut transition between two different locations.',
      mistake: 'Misaligning the screen position of the subject, causing visual jarring.'
    },
    {
      id: 'i2',
      title: 'Keyframes: Position, Scale & Custom Easing',
      diff: 'Intermediate',
      time: '20 mins',
      desc: 'Moving graphics and camera punches with organic acceleration and deceleration curves.',
      steps: [
        'Set initial keyframe for Position or Scale.',
        'Move playhead forward 12 frames and adjust end value.',
        'Open the Curve Graph Editor (Bezier curves).',
        'Apply Ease-In and Ease-Out so motion starts fast and decelerates smoothly.'
      ],
      task: 'Animate a code callout card that slides in smoothly from the left and settles naturally.',
      mistake: 'Leaving keyframes on Linear interpolation, making motion look robotic and stiff.'
    },
    {
      id: 'i3',
      title: 'Speed Ramping with Optical Flow',
      diff: 'Intermediate',
      time: '16 mins',
      desc: 'Smooth transitions between 400% high-speed motion and 50% slow-motion beat drops.',
      steps: [
        'Record footage in 60fps or 120fps high framerate.',
        'Place speed keyframes on your timeline clip.',
        'Curve speed from 300% down to 50% on musical accents.',
        'Enable Optical Flow frame interpolation for butter-smooth slow motion.'
      ],
      task: 'Create a dynamic 5-second speed ramp video synced to a kick drum drop.',
      mistake: 'Slowing down 24fps footage to 50%, resulting in choppy frame duplication.'
    },
    {
      id: 'i4',
      title: 'Motion Effects: Parallax & Directional Blur',
      diff: 'Intermediate',
      time: '15 mins',
      desc: 'Simulating multi-plane depth with subtle camera drift and motion blurs.',
      steps: [
        'Separate foreground subject from background using cutout or masks.',
        'Scale background slightly and move in opposite direction to foreground.',
        'Apply 180-degree shutter angle motion blur to fast-moving graphics.',
        'Add subtle floating camera wiggle expressions to static screen recordings.'
      ],
      task: 'Turn a flat static screenshot into a 3D parallax moving showcase.',
      mistake: 'Excessive camera shake that induces motion sickness.'
    },
    {
      id: 'i5',
      title: 'Beat Synchronization & Rhythm Editing',
      diff: 'Intermediate',
      time: '14 mins',
      desc: 'Cutting to drum kicks, basslines, and syncopated rhythmic patterns.',
      steps: [
        'Play music track and press "M" key on each snare/kick hit to drop markers.',
        'Snap video cut points directly to audio markers.',
        'Vary cut frequency: 3 rapid cuts on drum rolls followed by a long sustained shot.',
        'Use subtle visual scale punches (102% scale) on heavy bass impacts.'
      ],
      task: 'Edit a 15-second product demo cutting precisely on 8 consecutive musical beats.',
      mistake: 'Cutting on every single beat monotonously without rhythm variation.'
    },
    {
      id: 'i6',
      title: 'Kinetic Captions & Keyword Bounces',
      diff: 'Intermediate',
      time: '17 mins',
      desc: 'High-energy animated captions highlighting keywords with color shifts and pops.',
      steps: [
        'Auto-transcribe speech to generate word-by-word timestamps.',
        'Highlight primary noun or verb in vibrant accent color (Cyan, Yellow, Green).',
        'Add a 3-frame scale bounce (100% &gt; 115% &gt; 100%) as each keyword is spoken.',
        'Add subtle pop sound effect to accent words.'
      ],
      task: 'Build kinetic animated captions for a 20-second tutorial hook.',
      mistake: 'Entire paragraphs displayed on screen at once with no visual hierarchy.'
    },
    {
      id: 'i7',
      title: 'Better Audio Mixing & Equalization (EQ)',
      diff: 'Intermediate',
      time: '19 mins',
      desc: 'Parametric EQ carving, vocal warmth boost, and frequency unmasking.',
      steps: [
        'Cut frequencies below 80Hz to eliminate microphone handling rumble.',
        'Notch cut between 300Hz–500Hz to remove muddy cardboard vocal frequencies.',
        'Gently boost between 3kHz–5kHz for vocal presence and clarity.',
        'Apply multiband compression to tame aggressive vocal spikes.'
      ],
      task: 'EQ two different microphones to match vocal tone and presence seamlessly.',
      mistake: 'Boosting high treble frequencies excessively, introducing harsh sibilant "S" sounds.'
    },
    {
      id: 'i8',
      title: 'Color Correction: Scopes & Histogram Reading',
      diff: 'Intermediate',
      time: '18 mins',
      desc: 'Using waveform monitors and RGB parade scopes rather than relying on uncalibrated eyes.',
      steps: [
        'Open Waveform (Luma) scope to measure luminance levels.',
        'Adjust Black Level so deepest shadows sit at 0–5 IRE.',
        'Adjust White Level so brightest diffuse highlights peak around 90–95 IRE.',
        'Open Vectorscope and align skin tones strictly along the 10-to-2 o\'clock line.'
      ],
      task: 'Correct three mismatched video clips to have identical skin tones and exposure levels.',
      mistake: 'Grading by eye on an oversaturated phone screen without consulting scopes.'
    },
    {
      id: 'i9',
      title: 'Storytelling Architecture: Hook to Climax',
      diff: 'Intermediate',
      time: '22 mins',
      desc: 'Crafting micro-narratives with tension, stakes, and satisfying payoffs.',
      steps: [
        'Hook (0:00–0:03): State the stakes or conflict immediately.',
        'Inciting Incident (0:03–0:10): Introduce why the conventional approach failed.',
        'Rising Action (0:10–0:40): 3 sequential milestones building toward solution.',
        'Climax &amp; Takeaway (0:40–0:55): Reveal the solution and deliver actionable next steps.'
      ],
      task: 'Write a 60-second video script following this exact 4-phase narrative arc.',
      mistake: 'Spending the first 20 seconds on greetings and personal life updates.'
    },
    {
      id: 'i10',
      title: 'Reel & Short Pacing: Pattern Interrupts',
      diff: 'Intermediate',
      time: '15 mins',
      desc: 'Resetting the viewer\'s dopamine attention clock every 2.5 seconds.',
      steps: [
        'Alternate between A-Roll camera view, full-screen B-roll, and screen captures.',
        'Use digital push-ins: Scale from 100% to 110% on important points.',
        'Inject sound effects (whoosh, click, pop, risers) on every visual shift.',
        'Never let a single visual state persist longer than 3 seconds without an interrupt.'
      ],
      task: 'Review an existing 30-second draft and insert 6 deliberate pattern interrupts.',
      mistake: 'Talking head staring at camera without any B-roll or text overlays for 15 seconds.'
    }
  ],
  advanced: [
    {
      id: 'a1',
      title: 'Motion Graphics & Lower Thirds Design',
      diff: 'Advanced',
      time: '25 mins',
      desc: 'Building bespoke branded lower thirds, animated callout boxes, and technical HUDs.',
      steps: [
        'Design vector elements in Figma or Illustrator with clean alpha transparency.',
        'Animate entrance with track-matte reveals and spring easing curves.',
        'Add subtle glassmorphic backdrop with 15px Gaussian blur.',
        'Export as reusable Motion Graphics Template (MOGRT) or ProRes 4444.'
      ],
      task: 'Build a custom developer lower-third displaying your handle and terminal icon.',
      mistake: 'Low-contrast text on bright backgrounds that disappears in video compression.'
    },
    {
      id: 'a2',
      title: 'Advanced Keyframing & Velocity Curves',
      diff: 'Advanced',
      time: '24 mins',
      desc: 'Mastering Bezier handle manipulation, overshoot bouncing, and velocity matching.',
      steps: [
        'Open value graph and separate X and Y spatial dimensions.',
        'Pull right Bezier handle to 85% influence for dramatic whip-snap motion.',
        'Add a 2-frame overshoot past final position for organic physics elasticity.',
        'Match camera tracking velocity to animated graphic movement.'
      ],
      task: 'Animate a 3-element UI card with physics-based overshoot spring easing.',
      mistake: 'Equal speed across all keyframes resulting in flat, lifeless animations.'
    },
    {
      id: 'a3',
      title: 'Masking: Inverted Masks & Clone Effects',
      diff: 'Advanced',
      time: '28 mins',
      desc: 'Split-screen interactions, walking wipe transitions, and invisible clone composites.',
      steps: [
        'Lock camera on solid tripod; lock shutter speed, ISO, and white balance manually.',
        'Record Action A on the left side; record Action B on the right side.',
        'Stack clips on Tracks 1 and 2; draw linear or pen mask down the center.',
        'Feather mask edge by 15–25 pixels to conceal lighting micro-fluctuations.'
      ],
      task: 'Create a video where you talk to and hand an object to yourself across a split mask.',
      mistake: 'Shooting on handheld camera or auto-exposure, making the mask seam visible.'
    },
    {
      id: 'a4',
      title: 'Motion Tracking: Planar 3D & Face Tracking',
      diff: 'Advanced',
      time: '26 mins',
      desc: 'Pinning graphics to moving screens, tracking text into camera perspectives, and auto-following faces.',
      steps: [
        'Select high-contrast planar surface (e.g. phone screen, monitor, or wall).',
        'Run Planar Tracker or Mocha to generate 4-corner perspective pin data.',
        'Attach target graphic or code screenshot to tracking data.',
        'Match motion blur, noise grain, and ambient lighting to source plate.'
      ],
      task: 'Track a code editor screenshot onto a handheld smartphone screen in motion.',
      mistake: 'Tracking low-contrast blurry surfaces that cause tracking points to slip.'
    },
    {
      id: 'a5',
      title: 'Cinematic Color Grading & Custom Film Emulation',
      diff: 'Advanced',
      time: '30 mins',
      desc: 'Building custom film looks using color wheel wheels, split toning, and LUT conversions.',
      steps: [
        'Normalize log footage to Rec.709 color space in node 1.',
        'Balance exposure and contrast in node 2.',
        'Push teal/cyan into shadows and warm gold/amber into highlights in node 3.',
        'Add 35mm film grain overlay set to Overlay blending mode at 15% opacity.'
      ],
      task: 'Grade a flat raw camera clip into a rich cyberpunk dark-mode developer aesthetic.',
      mistake: 'Slapping a heavy LUT directly onto un-normalized log footage.'
    },
    {
      id: 'a6',
      title: 'Sound Design: Risers, Sub-Impacts & Foley Layers',
      diff: 'Advanced',
      time: '22 mins',
      desc: 'Building immersive 3-layer audio soundscapes: Ambient layer, Action foley, and Emotional punctuation.',
      steps: [
        'Bed layer: Low mechanical room tone or server hum at -28dB.',
        'Foley layer: Keyboard mechanical clicks, mouse clicks, paper rustles at -18dB.',
        'Impact layer: Low sub-bass boom (60Hz–90Hz) on key reveals at -8dB.',
        'Use stereo panning (-30% Left / +30% Right) to widen soundstage.'
      ],
      task: 'Design a 10-second sound effects stack for a technical app demonstration.',
      mistake: 'Leaving video with only voiceover and zero ambient or foley sound effects.'
    },
    {
      id: 'a7',
      title: 'Advanced Compositing & Green Screen Keying',
      diff: 'Advanced',
      time: '27 mins',
      desc: 'Chroma key green screen, despill suppression, edge feathering, and light wrap integration.',
      steps: [
        'Light green screen evenly with 2 soft lights 6 feet away from subject.',
        'Sample key color from shadow-adjacent green region.',
        'Adjust Screen Matte High/Low sliders until background is 100% pure black.',
        'Apply Light Wrap effect sampling background highlights onto subject edges.'
      ],
      task: 'Clean key a green screen recording and composite into a virtual 3D terminal backdrop.',
      mistake: 'Standing too close to green screen, causing green bounce spill on hair and shoulders.'
    },
    {
      id: 'a8',
      title: 'Professional Workflow & Proxy Media Pipelines',
      diff: 'Advanced',
      time: '20 mins',
      desc: 'Editing 4K/6K ProRes smoothly on laptop hardware using lightweight ProRes Proxy or DNxHR proxies.',
      steps: [
        'Batch generate 1080p ProRes Proxy files on media import.',
        'Toggle Proxy mode on timeline for zero-lag 60fps scrubbing.',
        'Color grade and apply effects while connected to proxies.',
        'Switch seamlessly back to full-resolution RAW media before final export.'
      ],
      task: 'Set up an automated proxy generation workflow for high-bitrate video clips.',
      mistake: 'Trying to scrub 4K 10-bit H.265 footage directly, causing dropped frames.'
    },
    {
      id: 'a9',
      title: 'Retention-Focused Editing: Retention Drop-Off Fixing',
      diff: 'Advanced',
      time: '24 mins',
      desc: 'Analyzing minute-by-minute audience retention graphs to engineer high-velocity cuts.',
      steps: [
        'Study YouTube Studio Retention graph for existing videos.',
        'Identify common 5-second drop-off valleys.',
        'Re-edit pacing: shorten setup explanations, insert visual proof earlier.',
        'Use open loops: tease a key result that will be solved in the final 15 seconds.'
      ],
      task: 'Audit a past video retention curve and identify 3 places where editing failed.',
      mistake: 'Assuming viewer drop-off is random rather than directly caused by pacing flaws.'
    },
    {
      id: 'a10',
      title: 'Advanced Visual Storytelling & Tension Loops',
      diff: 'Advanced',
      time: '28 mins',
      desc: 'Psychological tension and release loops that hold viewer curiosity for 10+ minutes.',
      steps: [
        'Establish an unresolved question in scene 1.',
        'Introduce unexpected obstacle in scene 2 (the plan breaks).',
        'Show raw debugging and trial-and-error in scene 3 (authentic struggle).',
        'Deliver breakthrough solution in scene 4 with clear takeaways.'
      ],
      task: 'Outline an 8-minute technical video using the Tension-Struggle-Breakthrough structure.',
      mistake: 'Showing a flawless perfect walkthrough where nothing ever goes wrong.'
    }
  ]
};

window.EDITING_SOFTWARE_DATA = {
  capcut: {
    title: 'CapCut (Mobile & Desktop)',
    badge: 'Mobile & Desktop King',
    overview: 'The default editor for TikTok, Reels, and Shorts. Packed with auto-captions, speed curves, keyframing, and cloud templates.',
    parityNotice: 'Mobile version features instant camera beauty filters, audio extraction, and template sharing. Desktop version offers multi-monitor layouts, professional shortcut maps, and higher bitrate ProRes exports.',
    beginnerTutorial: 'Import clip, tap "Auto captions", select template with animated word bounce, trim silence, and export at 1080p 30fps.',
    intermediateTutorial: 'Use Speed &gt; Curve &gt; Custom to create 4-point speed ramps. Add 3D Zoom effect to photos. Use Keyframes on overlay tracks.',
    advancedTutorial: 'Manual chroma keying with color picker and despill, tracking text to moving hands, and custom Bezier easing.',
    workflow: 'Record on phone &gt; AirDrop/Transfer to PC CapCut &gt; Auto-captions &gt; Color adjustment &gt; Sound effects &gt; Direct 1080p export.',
    project: 'Create a 15-second kinetic text Reel with 3 speed ramps and sound effects on beat.',
    exportTips: 'Disable "Add default ending" watermark in settings. Set bitrate to "Higher" instead of "Recommended".',
    mistakes: 'Leaving the default CapCut ending clip; using default loud sound effects without volume attenuation.'
  },
  vn: {
    title: 'VN Video Editor (Mobile Clean)',
    badge: 'No Watermark Mobile NLE',
    overview: 'The cleanest non-intrusive mobile editing app with no forced watermarks, professional curve speed ramping, and custom LUT color grade imports.',
    parityNotice: 'Optimized for touch screens on iOS and Android with desktop macOS/Windows ports available.',
    beginnerTutorial: 'Import footage onto multi-track timeline, blade clips using scissors icon, drag clip edges to trim, and add background audio.',
    intermediateTutorial: 'Import custom .cube 3D LUTs for color grading. Use Curve Speed ramping with preset curves (Bullet, Montage, Hero).',
    advancedTutorial: 'Keyframe masking with inverted circle and rectangle masks for picture-in-picture reactions.',
    workflow: 'Shoot in 4K &gt; Cut raw takes in VN &gt; Apply signature LUT &gt; Add subtitles with custom fonts &gt; Export at 25 Mbps.',
    project: 'Edit a 30-second clean aesthetic desk tour with speed ramps and custom typography.',
    exportTips: 'Select Manual Export to lock bitrate to 24 Mbps and resolution to 1080p.',
    mistakes: 'Leaving default crossfade transitions between fast-moving clips.'
  },
  alight: {
    title: 'Alight Motion (Mobile VFX & Animation)',
    badge: 'Mobile After Effects',
    overview: 'The premier mobile motion design tool. Vector illustration, keyframe easing curves, visual effects shaders, and XML preset sharing.',
    parityNotice: 'Mobile-first Android & iOS app. Requires modern processor for complex multi-layer rendering.',
    beginnerTutorial: 'Create a 9:16 project, add shape layer, animate scale from 0 to 100% using two keyframes, and export MP4.',
    intermediateTutorial: 'Open Graph editor, pull velocity curves for smooth bounce easing, apply Motion Blur effect (1.50 multiplier).',
    advancedTutorial: 'Vector path animation, parent-child layer rigging, displace map shaders, and exporting reusable XML presets.',
    workflow: 'Design vector assets &gt; Import to Alight &gt; Animate keyframe curves &gt; Render with motion blur &gt; Overlay in CapCut.',
    project: 'Design and animate an animated technical subscribe button with glowing border gradients.',
    exportTips: 'Use High Performance mode in settings when rendering heavy motion blur.',
    mistakes: 'Too many simultaneous blur layers causing GPU out-of-memory crashes on mobile.'
  },
  premiere: {
    title: 'Adobe Premiere Pro (Desktop Industry Standard)',
    badge: 'Professional NLE',
    overview: 'The benchmark nonlinear editor for television, film, and high-production YouTube creators. Deep integration with After Effects and Audition.',
    parityNotice: 'Desktop only (Windows & macOS). Requires dedicated GPU and 16GB+ RAM for optimal 4K timeline playback.',
    beginnerTutorial: 'Create Sequence matching footage, use "Q" and "W" keys for ripple trimming, and assemble rough cut on Track 1.',
    intermediateTutorial: 'Text-Based Editing (edit video by deleting text in transcript window). Essential Sound panel for auto-ducking.',
    advancedTutorial: 'Lumetri Color wheels with 3-way color correction, Dynamic Link with After Effects for complex composites, and multi-cam sync.',
    workflow: 'Ingest footage &gt; Transcribe &gt; Ripple edit script &gt; Add B-roll &gt; Lumetri grade &gt; Essential Sound mix &gt; Media Encoder export.',
    project: 'Produce a full 5-minute technical tutorial with multi-track audio and custom graphics.',
    exportTips: 'Export with H.264 VBR 2-Pass or Hardware Encoding (NVENC / Apple Silicon) at 20 Mbps.',
    mistakes: 'Editing on slow external hard drives without creating local ProRes proxies.'
  },
  davinci: {
    title: 'DaVinci Resolve (Color & Audio Powerhouse)',
    badge: 'Free Tier Monster',
    overview: 'Hollywood-standard node-based color science, Fairlight audio suite, and Fusion visual effects built into a single free application.',
    parityNotice: 'Desktop only. Free version is extremely generous with no watermarks; Studio version unlocks neural engine and GPU noise reduction.',
    beginnerTutorial: 'Cut page for fast assembly, Edit page for fine-tuning, and Deliver page with dedicated YouTube presets.',
    intermediateTutorial: 'Node-based color grading: Serial nodes for exposure, balance, contrast, and film look LUT.',
    advancedTutorial: 'Fusion 3D camera tracker, Fairlight bus routing and dialogue isolation, ACES color managed workflows.',
    workflow: 'Cut page rough cut &gt; Edit page pacing &gt; Color page node grade &gt; Fairlight loudness normalization &gt; Deliver export.',
    project: 'Take a raw camera clip and build a 4-node cinematic grade with balanced skin tones.',
    exportTips: 'Render cache set to ProRes Proxy or DNxHR SQ for real-time 60fps playback.',
    mistakes: 'Applying heavy spatial noise reduction on timeline before finishing color grade, causing playback stutter.'
  },
  finalcut: {
    title: 'Final Cut Pro (macOS Speed & Performance)',
    badge: 'Apple Silicon Efficiency',
    overview: 'Lightning-fast magnetic timeline with background rendering tuned specifically for Mac hardware. Beloved by solo YouTube creators.',
    parityNotice: 'macOS & iPadOS only. Requires Apple hardware.',
    beginnerTutorial: 'Import into Library, skim with "S" key, drop clips onto Magnetic Timeline with "E", and trim with blade tool.',
    intermediateTutorial: 'Compound clips for nested edits, Voice Isolation slider for noisy rooms, and Keyword Collections for media tagging.',
    advancedTutorial: 'Object Tracker to pin titles to moving subjects, color wheels with HDR scopes, and exporting Compressor batches.',
    workflow: 'Keyword tagging &gt; Magnetic assembly &gt; Voice Isolation &gt; Title overlays &gt; Instant background export.',
    project: 'Assemble a 3-minute vlog or tutorial in under 30 minutes utilizing magnetic ripple trimming.',
    exportTips: 'Turn on background rendering and export directly to Apple Devices 4K for maximum hardware acceleration.',
    mistakes: 'Letting render cache files balloon to 500GB; clean generated library files regularly in File menu.'
  }
};

window.WORKFLOW_STEPS_DATA = {
  1: {
    title: '1. TREND (Discovery & Validation)',
    badge: 'Step 1 of 10',
    desc: 'Never create content in a vacuum. Identify high-velocity formats, trending audio, and burning questions before filming a single second.',
    checklist: [
      'Check YouTube autocomplete for rising search queries.',
      'Inspect Instagram Explore and Reels audio charts for rising sounds.',
      'Validate if the topic has strong search intent or strong emotional shareability.',
      'Formulate a 1-sentence hypothesis: "Why will someone watch this to the end?"'
    ],
    proTip: 'A mediocre idea with great editing gets 1,000 views. A viral idea with decent editing gets 100,000 views. Spend 40% of your energy here.',
    pitfall: 'Creating tutorials on outdated tools that nobody is searching for.'
  },
  2: {
    title: '2. IDEA (Angles & Differentiation)',
    badge: 'Step 2 of 10',
    desc: 'Transform a generic topic into a compelling, click-worthy concept with a unique contrarian angle or high-speed challenge.',
    checklist: [
      'Brainstorm 5 different angles for the same topic.',
      'Select the angle with the highest curiosity gap.',
      'Draft 3 potential thumbnail concepts and titles BEFORE writing the script.',
      'Ensure the idea can deliver a clear, tangible payoff.'
    ],
    proTip: 'If you cannot describe the thumbnail and title in 5 seconds, the idea is not sharp enough yet.',
    pitfall: 'Picking generic titles like "My thoughts on Python in 2026".'
  },
  3: {
    title: '3. SCRIPT (Pacing & Retention Hooks)',
    badge: 'Step 3 of 10',
    desc: 'Structure every sentence to maintain psychological momentum and eliminate viewer drop-off.',
    checklist: [
      'Write the first 3 seconds: Visual action + Spoken sentence.',
      'Map out 3 distinct value milestones with zero fluff.',
      'Place open loops early: tease the final revelation.',
      'Read script aloud with a stopwatch; cut 20% of the words.'
    ],
    proTip: 'Write the hook last after you know the exact final result of the video.',
    pitfall: 'Starting with: "Hey guys welcome back to my channel today we will...".'
  },
  4: {
    title: '4. RECORD (Lighting, Audio & Framing)',
    badge: 'Step 4 of 10',
    desc: 'Capture clean audio and high-contrast visuals so post-production editing is fast and painless.',
    checklist: [
      'Set key light at 45-degree angle; diffuse with softbox.',
      'Check audio levels: voice peaking between -6dB and -3dB with no clipping.',
      'Clean your smartphone/camera lens with microfiber cloth.',
      'Record 3 different versions of the intro hook for safety.'
    ],
    proTip: 'Bad video with great audio is watchable. Great video with bad audio is unwatchable.',
    pitfall: 'Leaving phone on auto-exposure so brightness pulses every time you move your hands.'
  },
  5: {
    title: '5. EDIT (Cutting, Pacing & Polish)',
    badge: 'Step 5 of 10',
    desc: 'Ruthlessly cut all silence, inject visual pattern interrupts every 2.5s, balance audio, and animate captions.',
    checklist: [
      'Execute rough cut: eliminate every gap over 0.3s.',
      'Add B-roll and screen recordings on Track 2.',
      'Apply kinetic animated captions with keyword color shifts.',
      'Balance audio: Dialogue -6dB, SFX -12dB, Music -24dB.'
    ],
    proTip: 'Watch your video on 1.25x speed. If any section feels slightly boring, cut it out immediately.',
    pitfall: 'Overloading the video with 50 sound effects that overwhelm the voice.'
  },
  6: {
    title: '6. THUMBNAIL / COVER (High-CTR Visuals)',
    badge: 'Step 6 of 10',
    desc: 'Design the single image that earns the click against hundreds of competing videos in the feed.',
    checklist: [
      'Max 3 words of bold high-contrast text.',
      'Clear subject with directional rim lighting and high-contrast background.',
      'Test at 10% mobile scale: can you read it in 1 second?',
      'Ensure bottom-right corner is completely empty for the timestamp.'
    ],
    proTip: 'Create 2 thumbnail variations so you can A/B test in YouTube Studio.',
    pitfall: 'Copying the full video title into the thumbnail image.'
  },
  7: {
    title: '7. SEO (Metadata & Indexing)',
    badge: 'Step 7 of 10',
    desc: 'Optimize titles, descriptions, chapters, and tags so search engines recommend your content.',
    checklist: [
      'Front-load search keyword in the first 4 words of the title.',
      'Write 2 clear summary lines in description before the fold.',
      'Include timestamps starting with 00:00 Intro.',
      'Add 3 precise hashtags at the bottom of description.'
    ],
    proTip: 'Timestamps allow Google web search to index your video clips directly into Google results.',
    pitfall: 'Keyword stuffing 50 tags in description violating spam guidelines.'
  },
  8: {
    title: '8. UPLOAD (Quality Settings & Launch)',
    badge: 'Step 8 of 10',
    desc: 'Follow the unlisted upload protocol to ensure HD processing and optimal audience arrival.',
    checklist: [
      'Upload as Unlisted 2 hours before launch time.',
      'Verify HD/4K tier has finished processing.',
      'Configure End Screens and Info Cards.',
      'Switch to Public at peak audience activity window.'
    ],
    proTip: 'Publishing as Unlisted first gives YouTube time to run copyright and content checks safely.',
    pitfall: 'Uploading directly to Public in 360p while HD is still processing in the background.'
  },
  9: {
    title: '9. ANALYTICS (Diagnosing Data Signals)',
    badge: 'Step 9 of 10',
    desc: 'Inspect CTR, retention drop-offs, and traffic sources after 24–48 hours.',
    checklist: [
      'Check CTR: is it above 4%? If not, swap thumbnail/title.',
      'Inspect 0:30 retention: did more than 65% stay past the intro?',
      'Check traffic sources: is search or suggested dominating?',
      'Note where viewers dropped off for future editing fixes.'
    ],
    proTip: 'A low CTR with high retention means great video with poor packaging. Swap thumbnail immediately.',
    pitfall: 'Checking views every 5 minutes instead of analyzing retention percentages.'
  },
  10: {
    title: '10. IMPROVE (The Compound Growth Loop)',
    badge: 'Step 10 of 10',
    desc: 'Document the single lesson learned from this video and apply it to the next release.',
    checklist: [
      'Pin top viewer comment and engage with community.',
      'Document 1 specific production mistake to avoid next time.',
      'Plan follow-up video solving the top question in the comments.',
      'Add video to dedicated topical playlist for binge sessions.'
    ],
    proTip: 'Great creators do not get lucky; they iterate 1% on every single upload.',
    pitfall: 'Abandoning a niche after 2 videos before algorithmic momentum can build.'
  }
};

window.AI_CREATOR_TOOLS_DATA = [
  {
    id: 'ai-script',
    name: 'Script Architecture & Hook Engine',
    category: 'Scripting',
    what: 'Generates high-retention 3-part video scripts with visual cue notes and spoken dialogue.',
    who: 'Solo creators and developers who struggle with pacing or talking too long.',
    how: 'Provide topic, target audience, and length (30s Reel vs 8m YouTube).',
    example: 'Generating a 45-second script on "How to run Python scripts in Termux with zero errors".',
    prompt: 'Act as a viral video retention editor. Write a 45-second YouTube Shorts script on [TOPIC]. Format: 1. Visual Hook (First 2s), 2. Spoken Hook, 3. Three rapid 10-second value steps with on-screen text notes, 4. Clear CTA to save the video.'
  },
  {
    id: 'ai-hooks',
    name: '20x Viral Hook Brainstormer',
    category: 'Hooks',
    what: 'Generates 20 high-retention hook variations across Curiosity, Contrarian, and Direct Benefit angles.',
    who: 'Creators whose videos have great content but suffer from low 3-second retention.',
    how: 'Input your core video idea and target audience.',
    example: 'Brainstorming hooks for a tutorial on Git merge conflicts.',
    prompt: 'Give me 15 viral hooks for a short-form video about [TOPIC]. Group into: 5 Contrarian hooks ("Stop doing X"), 5 Curiosity gap hooks ("The hidden setting..."), and 5 Challenge hooks ("I tested X for 30 days"). Keep every hook under 12 words.'
  },
  {
    id: 'ai-captions',
    name: 'Instagram Caption & CTA Optimizer',
    category: 'Captions',
    what: 'Formats 125-character cliffhanger captions with line breaks, bullet points, and save/share CTAs.',
    who: 'Creators who want captions that get read and trigger the "...more" engagement tap.',
    how: 'Enter the main points of your Reel.',
    example: 'Writing an Instagram caption summarizing 3 Termux shortcut keys.',
    prompt: 'Write an Instagram Reel caption for [TOPIC]. Requirements: First line must hook the reader and cut off at 120 characters before "...more". Body must contain 3 formatted bullet points. End with a CTA asking viewers to save the post for reference.'
  },
  {
    id: 'ai-hashtags',
    name: 'Semantic Hashtag Cluster Builder',
    category: 'Hashtags',
    what: 'Builds 3-5 high-intent categorized hashtag tiers instead of spamming 30 tags.',
    who: 'Creators wanting proper algorithmic search indexing without triggering spam flags.',
    how: 'Input your exact niche and target topic.',
    example: 'Generating tags for an Android Linux terminal walkthrough.',
    prompt: 'Generate 5 high-intent hashtags for a video on [TOPIC]. 1 Broad industry tag (1M+ posts), 2 Niche community tags (50K-300K posts), and 2 Specific context tags (<50K posts). No generic spam tags.'
  },
  {
    id: 'ai-thumbnails',
    name: 'Thumbnail Visual Concept Generator',
    category: 'Thumbnails',
    what: 'Describes 3 visual thumbnail scenes following the 3-Element rule, high contrast, and safe zones.',
    who: 'YouTubers wanting high-CTR click-worthy concepts before opening Photoshop or Canva.',
    how: 'Provide video title and core emotional payoff.',
    example: 'Designing thumbnail for "I coded an entire app on an Android phone".',
    prompt: 'Design 3 YouTube thumbnail visual concepts for the video title: "[TITLE]". For each concept describe: 1. Main focal subject & facial expression, 2. Background setting and contrast colors, 3. Exactly 2-3 words of bold text (never repeat title), 4. Why it complies with the bottom-right timestamp safe zone.'
  },
  {
    id: 'ai-titles',
    name: 'High-CTR YouTube Title Generator',
    category: 'Titles',
    what: 'Crafts 10 click-worthy titles under 60 characters balancing search keywords and curiosity gaps.',
    who: 'Creators whose videos have low click-through rates (CTR < 4%).',
    how: 'Enter your video topic and target keyword.',
    example: 'Generating titles for a Linux command line tutorial.',
    prompt: 'Generate 10 YouTube video titles for [TOPIC]. Rules: 1. Every title must be under 58 characters (no truncation on mobile). 2. Front-load the primary search keyword in first 4 words. 3. Zero cheesy all-caps clickbait. Include 3 curiosity gap titles, 3 search-intent titles, and 4 case-study titles.'
  },
  {
    id: 'ai-calendar',
    name: '30-Day Content Planner & Roadmap',
    category: 'Planning',
    what: 'Builds a 4-week thematic content calendar linking Shorts, Reels, and long-form YouTube tutorials.',
    who: 'Creators who struggle with daily "what should I post today?" decision fatigue.',
    how: 'Input your niche, target weekly cadence (e.g. 3 Reels + 1 YouTube video), and goal.',
    example: 'Building a 30-day curriculum for beginner Python developers.',
    prompt: 'Create a 4-week content calendar for a creator in the [NICHE] space. Schedule: 3 short-form videos per week (Reels/Shorts) and 1 long-form YouTube tutorial per week. For each video list: Title, Hook, and Core Takeaway.'
  },
  {
    id: 'ai-editing',
    name: 'B-Roll & Pattern Interrupt Assistant',
    category: 'Editing',
    what: 'Reviews your video outline and suggests exact B-roll shots, audio SFX, and zoom cuts.',
    who: 'Video editors looking to turn boring talking-head footage into high-retention video.',
    how: 'Paste your raw script or topic outline.',
    example: 'Adding visual pacing notes to a 2-minute API tutorial.',
    prompt: 'Here is my video script outline: [PASTE OUTLINE]. Add detailed editing instructions: specify where to add a digital punch-in (100% to 110%), exact B-roll screen capture to show, and audio sound effect cue (whoosh, pop, click, riser) every 3 seconds.'
  }
];

import express from 'express';
import path from 'path';
import fs from 'fs';
import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = 3000;
const HOST = '0.0.0.0';

app.use(express.json());

// List of supported/available Gemini models
const SUPPORTED_MODELS = [
  'gemini-3.8-flash',
  'gemini-flash-latest',
  'gemini-3.1-flash-lite',
  'gemini-3.1-pro-preview'
];
const DEFAULT_MODEL = 'gemini-3.8-flash';

// Helper to determine active API key (from environment or authorized client header)
function resolveApiKey(req: express.Request): string | null {
  const customKey = req.headers['x-gemini-api-key'];
  if (typeof customKey === 'string' && customKey.trim().length > 10) {
    return customKey.trim();
  }
  const envKey = process.env.GEMINI_API_KEY;
  if (envKey && envKey.trim().length > 10 && !envKey.includes('MY_GEMINI_API_KEY')) {
    return envKey.trim();
  }
  return null;
}

// -----------------------------------------------------------------------------
// 1. API: Gemini Status
// -----------------------------------------------------------------------------
app.get('/api/gemini/status', (req, res) => {
  const activeKey = resolveApiKey(req);
  const isServerConfigured = Boolean(
    process.env.GEMINI_API_KEY &&
    process.env.GEMINI_API_KEY.trim().length > 10 &&
    !process.env.GEMINI_API_KEY.includes('MY_GEMINI_API_KEY')
  );

  res.json({
    status: 'ok',
    configured: Boolean(activeKey),
    isServerConfigured,
    defaultModel: DEFAULT_MODEL,
    supportedModels: SUPPORTED_MODELS
  });
});

// -----------------------------------------------------------------------------
// 2. API: Gemini Test Connection (Real Verification)
// -----------------------------------------------------------------------------
app.post('/api/gemini/test-connection', async (req, res) => {
  const activeKey = resolveApiKey(req);
  const requestedModel = (req.body?.model || DEFAULT_MODEL).trim();

  if (!activeKey) {
    return res.status(400).json({
      ok: false,
      error: 'Server configuration missing: GEMINI_API_KEY is not configured on the server. Please add your key in the AI Studio Secrets panel or configure a custom API key.',
      code: 'KEY_MISSING'
    });
  }

  // Validate model name
  if (!SUPPORTED_MODELS.includes(requestedModel) && !requestedModel.startsWith('gemini-')) {
    return res.status(400).json({
      ok: false,
      error: 'Configured Gemini model is unavailable.',
      code: 'MODEL_UNAVAILABLE'
    });
  }

  const startTime = Date.now();
  try {
    const ai = new GoogleGenAI({
      apiKey: activeKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const response = await ai.models.generateContent({
      model: requestedModel,
      contents: 'Ping. Respond with "pong" only.'
    });

    const text = response.text || '';
    const latencyMs = Date.now() - startTime;

    return res.json({
      ok: true,
      model: requestedModel,
      latencyMs,
      message: `Successfully connected to Gemini API (${requestedModel})`,
      preview: text.trim().slice(0, 50)
    });
  } catch (err: any) {
    const message = err?.message || String(err);
    const status = err?.status || err?.statusCode || 500;

    let userError = 'Request failed';
    let errorCode = 'REQUEST_FAILED';

    if (message.includes('API_KEY_INVALID') || message.includes('API key not valid') || status === 401) {
      userError = 'Authentication failed: Invalid API key.';
      errorCode = 'AUTH_FAILED';
    } else if (message.includes('not found') || message.includes('is not supported') || status === 404) {
      userError = 'Configured Gemini model is unavailable.';
      errorCode = 'MODEL_UNAVAILABLE';
    } else if (message.includes('quota') || message.includes('RESOURCE_EXHAUSTED') || status === 429) {
      userError = 'Rate limit reached or quota exceeded.';
      errorCode = 'RATE_LIMIT';
    } else if (message.includes('PERMISSION_DENIED') || status === 403) {
      userError = 'Permission denied for this model or API key.';
      errorCode = 'PERMISSION_DENIED';
    } else {
      userError = `Connection test failed: ${message}`;
    }

    return res.status(status >= 400 && status < 600 ? status : 500).json({
      ok: false,
      error: userError,
      code: errorCode
    });
  }
});

// -----------------------------------------------------------------------------
// 3. API: Gemini Chat Synthesis
// -----------------------------------------------------------------------------
app.post('/api/gemini/chat', async (req, res) => {
  const activeKey = resolveApiKey(req);
  const { message, model } = req.body || {};
  const selectedModel = (model || DEFAULT_MODEL).trim();

  if (!message || typeof message !== 'string' || !message.trim()) {
    return res.status(400).json({
      ok: false,
      error: 'Message text is required.'
    });
  }

  if (!activeKey) {
    return res.status(400).json({
      ok: false,
      error: 'Server configuration missing: GEMINI_API_KEY is not configured on the server.',
      code: 'KEY_MISSING'
    });
  }

  if (!SUPPORTED_MODELS.includes(selectedModel) && !selectedModel.startsWith('gemini-')) {
    return res.status(400).json({
      ok: false,
      error: 'Configured Gemini model is unavailable.',
      code: 'MODEL_UNAVAILABLE'
    });
  }

  try {
    const ai = new GoogleGenAI({
      apiKey: activeKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build'
        }
      }
    });

    const response = await ai.models.generateContent({
      model: selectedModel,
      contents: message.trim(),
      config: {
        systemInstruction:
          'You are Rauf Labs AI, an expert, beginner-friendly technical developer assistant for Rauf Labs (created by Rauf from Kashmir, India). You specialize in Android development & internals, Termux setup, packages & workflows, Linux systems administration, shell scripting (Bash, PowerShell), Git & GitHub workflows, programming languages (Python, JavaScript, TypeScript, Go, Rust, C++), web development, APIs and integration, cybersecurity fundamentals & defense, AI SaaS, LLM engineering, Gemini API, content creation & algorithm growth. Provide clear, comprehensive explanations, copy-pasteable terminal commands, and structured code snippets. If a user asks about a topic not yet covered by an existing Rauf Labs page or course, dynamically generate a comprehensive, structured technical tutorial/module covering core concepts, prerequisites, step-by-step commands, code implementation, best practices, and next steps.'
      }
    });

    const candidateText = response.text || '';
    if (!candidateText) {
      throw new Error('No candidate content received from Gemini model.');
    }

    return res.json({
      ok: true,
      model: selectedModel,
      reply: candidateText
    });
  } catch (err: any) {
    const messageText = err?.message || String(err);
    const status = err?.status || err?.statusCode || 500;

    let userError = 'Request failed';
    let errorCode = 'REQUEST_FAILED';

    if (messageText.includes('API_KEY_INVALID') || messageText.includes('API key not valid') || status === 401) {
      userError = 'Authentication failed: Invalid API key.';
      errorCode = 'AUTH_FAILED';
    } else if (messageText.includes('not found') || messageText.includes('is not supported') || status === 404) {
      userError = 'Configured Gemini model is unavailable.';
      errorCode = 'MODEL_UNAVAILABLE';
    } else if (messageText.includes('quota') || messageText.includes('RESOURCE_EXHAUSTED') || status === 429) {
      userError = 'Rate limit reached or quota exceeded.';
      errorCode = 'RATE_LIMIT';
    } else if (messageText.includes('PERMISSION_DENIED') || status === 403) {
      userError = 'Permission denied for this model.';
      errorCode = 'PERMISSION_DENIED';
    } else {
      userError = `Gemini request failed: ${messageText}`;
    }

    return res.status(status >= 400 && status < 600 ? status : 500).json({
      ok: false,
      error: userError,
      code: errorCode
    });
  }
});

// -----------------------------------------------------------------------------
// 4. PDF File Serving (Direct Binary Streams)
// -----------------------------------------------------------------------------
function servePdfFile(pdfFileName: string, res: express.Response) {
  let safeName = path.basename(pdfFileName);
  try {
    safeName = path.basename(decodeURIComponent(pdfFileName));
  } catch (e) {}

  const searchPaths = [
    path.join(process.cwd(), 'public', 'pdfs', safeName),
    path.join(process.cwd(), 'pdfs', safeName),
    path.join(process.cwd(), 'dist', 'pdfs', safeName),
    path.join(process.cwd(), 'public', safeName)
  ];

  let foundPath: string | null = null;
  for (const p of searchPaths) {
    if (fs.existsSync(p) && fs.statSync(p).isFile()) {
      foundPath = p;
      break;
    }
  }

  if (!foundPath) {
    res.status(404).send('PDF currently unavailable');
    return;
  }

  const stat = fs.statSync(foundPath);
  res.setHeader('Content-Type', 'application/pdf');
  res.setHeader('Content-Length', stat.size);
  res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(safeName)}"`);
  res.setHeader('Cache-Control', 'public, max-age=86400');
  fs.createReadStream(foundPath).pipe(res);
}

app.get('/pdfs/:filename', (req, res, next) => {
  const filename = req.params.filename;
  if (filename && filename.toLowerCase().endsWith('.pdf')) {
    return servePdfFile(filename, res);
  }
  next();
});

app.get('/public/pdfs/:filename', (req, res, next) => {
  const filename = req.params.filename;
  if (filename && filename.toLowerCase().endsWith('.pdf')) {
    return servePdfFile(filename, res);
  }
  next();
});

// -----------------------------------------------------------------------------
// 5. Setup Frontend / Static / SPA Routing
// -----------------------------------------------------------------------------
const SPA_ROUTES = [
  'developer',
  'android',
  'roadmap',
  'creator',
  'tools',
  'resources',
  'ai',
  'login',
  'about',
  'skills',
  'projects',
  'blog',
  'contact',
  'termux',
  'linux',
  'powershell',
  'bash',
  'git',
  'programming',
  'apis',
  'opensource',
  'pdfs',
  'courses',
  'qr',
  'standalone',
  '404'
];

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'custom'
    });

    // Mount Vite middleware first for static assets, scripts, CSS, and HMR
    app.use(vite.middlewares);

    // Handle HTML page requests with Vite transformIndexHtml
    app.use(async (req, res, next) => {
      if (req.method !== 'GET' && req.method !== 'HEAD') {
        return next();
      }

      const urlPath = req.url.split('?')[0].split('#')[0];
      if (urlPath.startsWith('/api/')) {
        return next();
      }

      const clean = urlPath.replace(/^\//, '').replace(/\/$/, '');

      let htmlFile = 'index.html';
      let is404 = false;

      if (clean === '' || clean === 'index' || clean === 'index.html') {
        htmlFile = 'index.html';
      } else if (clean === 'courses' || clean.startsWith('courses/')) {
        htmlFile = 'courses.html';
      } else if (clean === 'pdfs' || clean.startsWith('pdfs/read') || clean === 'pdfs.html') {
        htmlFile = 'pdfs.html';
      } else if (SPA_ROUTES.includes(clean)) {
        htmlFile = `${clean}.html`;
      } else if (SPA_ROUTES.includes(clean.replace(/\.html$/, ''))) {
        htmlFile = `${clean.replace(/\.html$/, '')}.html`;
      } else {
        htmlFile = '404.html';
        is404 = true;
      }

      const filePath = path.resolve(process.cwd(), htmlFile);
      if (fs.existsSync(filePath)) {
        if (htmlFile === 'standalone.html') {
          return res.sendFile(filePath);
        }
        try {
          const rawHtml = fs.readFileSync(filePath, 'utf-8');
          const transformedHtml = await vite.transformIndexHtml(req.originalUrl || req.url, rawHtml);
          res.status(is404 ? 404 : 200).set({ 'Content-Type': 'text/html; charset=utf-8' }).end(transformedHtml);
          return;
        } catch (err: any) {
          vite.ssrFixStacktrace(err);
          return next(err);
        }
      }
      res.status(404).sendFile(path.resolve(process.cwd(), '404.html'));
    });
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath, { extensions: ['html'] }));

    // Root route
    app.get('/', (req, res) => {
      const indexPath = path.join(distPath, 'index.html');
      if (fs.existsSync(indexPath)) {
        res.sendFile(indexPath);
      } else {
        res.status(404).sendFile(path.join(distPath, '404.html'));
      }
    });

    // Explicit production route mapping
    app.get(['/courses', '/courses/*'], (req, res) => {
      const coursesHtml = path.join(distPath, 'courses.html');
      if (fs.existsSync(coursesHtml)) {
        res.sendFile(coursesHtml);
      } else {
        res.status(404).sendFile(path.join(distPath, '404.html'));
      }
    });

    app.get(['/pdfs', '/pdfs/read', '/pdfs/read/*'], (req, res) => {
      const pdfsHtml = path.join(distPath, 'pdfs.html');
      if (fs.existsSync(pdfsHtml)) {
        res.sendFile(pdfsHtml);
      } else {
        res.status(404).sendFile(path.join(distPath, '404.html'));
      }
    });

    for (const route of SPA_ROUTES) {
      app.get(`/${route}`, (req, res) => {
        const file = path.join(distPath, `${route}.html`);
        if (fs.existsSync(file)) {
          if (route === '404') {
            res.status(404).sendFile(file);
          } else {
            res.sendFile(file);
          }
        } else {
          const notFound = path.join(distPath, '404.html');
          if (fs.existsSync(notFound)) {
            res.status(404).sendFile(notFound);
          } else {
            res.status(404).send('Page Not Found');
          }
        }
      });
    }

    // 404 handler for any unmapped route
    app.use((req, res) => {
      const notFoundPath = path.join(distPath, '404.html');
      if (fs.existsSync(notFoundPath)) {
        res.status(404).sendFile(notFoundPath);
      } else {
        res.status(404).send('Page Not Found');
      }
    });
  }

  app.listen(PORT, HOST, () => {
    console.log(`[Rauf Labs] Server running on http://${HOST}:${PORT}`);
  });
}

startServer();

/**
 * 📚 RAUF LABS ACADEMY — INTERNAL PDF READER & CATALOG ENGINE
 * 
 * High-performance PDF.js canvas viewer, touch navigation, search,
 * filtering, deep linking, fullscreen, and direct downloads.
 */

(function () {
  'use strict';

  // Configure PDF.js worker
  function setupPdfJsWorker() {
    if (typeof window !== 'undefined' && window.pdfjsLib) {
      if (!window.pdfjsLib.GlobalWorkerOptions.workerSrc) {
        window.pdfjsLib.GlobalWorkerOptions.workerSrc = '/vendor/pdfjs/pdf.worker.min.js';
      }
    }
  }
  setupPdfJsWorker();

  // Helper to dynamically ensure PDF.js is loaded
  function ensurePdfJsLoaded() {
    if (typeof window !== 'undefined' && window.pdfjsLib) {
      setupPdfJsWorker();
      return Promise.resolve(window.pdfjsLib);
    }
    return new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = '/vendor/pdfjs/pdf.min.js';
      script.onload = () => {
        setupPdfJsWorker();
        resolve(window.pdfjsLib);
      };
      script.onerror = () => {
        const cdnScript = document.createElement('script');
        cdnScript.src = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js';
        cdnScript.onload = () => {
          setupPdfJsWorker();
          resolve(window.pdfjsLib);
        };
        cdnScript.onerror = () => reject(new Error('Failed to load PDF.js library'));
        document.head.appendChild(cdnScript);
      };
      document.head.appendChild(script);
    });
  }

  function initPdfLibrary() {
    const container = document.getElementById('pdf-library-container');
    if (!container) return;

    let currentCategory = 'all';
    let currentSort = 'newest';
    let searchQuery = '';

    // Active Reader State
    let activePdf = null;
    let pdfDoc = null;
    let currentPageNum = 1;
    let totalPageCount = 1;
    let currentScale = 1.15;
    let currentRenderTask = null;
    let isRendering = false;
    let renderPending = false;
    let touchStartX = 0;
    let touchEndX = 0;

    const searchInput = document.getElementById('pdf-search-input');
    const sortSelect = document.getElementById('pdf-sort-select');
    const filterWrap = document.getElementById('pdf-category-filters');
    const countBadge = document.getElementById('pdf-results-count');
    const grid = document.getElementById('pdf-cards-grid');
    const readerSection = document.getElementById('pdf-reader-section');

    // Event Listeners: Search & Sort
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        searchQuery = e.target.value.trim().toLowerCase();
        renderCatalog();
      });
    }

    if (sortSelect) {
      sortSelect.addEventListener('change', (e) => {
        currentSort = e.target.value;
        renderCatalog();
      });
    }

    // Event Listeners: Category Filter Buttons
    if (filterWrap) {
      filterWrap.querySelectorAll('.pdf-cat-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          filterWrap.querySelectorAll('.pdf-cat-btn').forEach(b => b.classList.remove('active'));
          btn.classList.add('active');
          currentCategory = btn.dataset.category || 'all';
          renderCatalog();
        });
      });
    }

    // Category colors & gradient themes
    function getCategoryColor(cat) {
      const colors = {
        'AI SaaS': { bg: 'rgba(245, 158, 11, 0.15)', text: '#fbbf24', border: 'rgba(245, 158, 11, 0.35)', grad: 'linear-gradient(135deg, #b45309, #d97706)' },
        'AI Gateway': { bg: 'rgba(225, 29, 72, 0.15)', text: '#f43f5e', border: 'rgba(225, 29, 72, 0.35)', grad: 'linear-gradient(135deg, #881337, #e11d48)' },
        'Prompts': { bg: 'rgba(168, 85, 247, 0.15)', text: '#c084fc', border: 'rgba(168, 85, 247, 0.35)', grad: 'linear-gradient(135deg, #581c87, #9333ea)' },
        'Education': { bg: 'rgba(16, 185, 129, 0.15)', text: '#34d399', border: 'rgba(16, 185, 129, 0.35)', grad: 'linear-gradient(135deg, #065f46, #059669)' },
        'Video AI': { bg: 'rgba(26, 115, 232, 0.15)', text: '#60a5fa', border: 'rgba(26, 115, 232, 0.35)', grad: 'linear-gradient(135deg, #1e3a8a, #2563eb)' }
      };
      return colors[cat] || { bg: 'rgba(148, 163, 184, 0.15)', text: '#94a3b8', border: 'rgba(148, 163, 184, 0.3)', grad: 'linear-gradient(135deg, #334155, #475569)' };
    }

    // Render Cards Grid
    function renderCatalog() {
      if (!grid) return;
      const allPdfs = window.PDFS_DATA || [];

      // Category filter
      let filtered = allPdfs;
      if (currentCategory !== 'all') {
        filtered = filtered.filter(item => 
          (item.category && item.category.toLowerCase() === currentCategory.toLowerCase()) ||
          (Array.isArray(item.tags) && item.tags.some(t => t.toLowerCase() === currentCategory.toLowerCase()))
        );
      }

      // Search query filter
      if (searchQuery) {
        filtered = filtered.filter(item => {
          const tMatch = item.title.toLowerCase().includes(searchQuery);
          const sMatch = (item.subtitle || '').toLowerCase().includes(searchQuery);
          const dMatch = (item.description || '').toLowerCase().includes(searchQuery);
          const cMatch = item.category.toLowerCase().includes(searchQuery);
          const tagsMatch = Array.isArray(item.tags) && item.tags.some(t => t.toLowerCase().includes(searchQuery));
          return tMatch || sMatch || dMatch || cMatch || tagsMatch;
        });
      }

      // Sorting
      filtered = [...filtered].sort((a, b) => {
        if (currentSort === 'newest') {
          return new Date(b.date || '2026-01-01') - new Date(a.date || '2026-01-01');
        } else if (currentSort === 'az') {
          return a.title.localeCompare(b.title);
        } else if (currentSort === 'category') {
          return a.category.localeCompare(b.category);
        }
        return 0;
      });

      // Update count badge
      if (countBadge) {
        countBadge.textContent = `Showing ${filtered.length} of ${allPdfs.length} Rauf Labs Publications`;
      }

      // Empty State
      if (filtered.length === 0) {
        grid.innerHTML = `
          <div class="pdf-empty-state">
            <div class="pdf-empty-icon">📂</div>
            <h3 style="font-size: 1.3rem; color: #fff; margin-bottom: 8px;">No publications found</h3>
            <p style="color: var(--text-secondary); max-width: 480px; margin-bottom: 20px;">
              No documents matched "<strong>${searchQuery || currentCategory}</strong>".
            </p>
            <button class="btn btn-secondary" id="reset-pdf-filters-btn">View All Editions</button>
          </div>
        `;
        const resetBtn = document.getElementById('reset-pdf-filters-btn');
        if (resetBtn) {
          resetBtn.onclick = () => {
            if (searchInput) searchInput.value = '';
            searchQuery = '';
            currentCategory = 'all';
            if (filterWrap) {
              filterWrap.querySelectorAll('.pdf-cat-btn').forEach(b => b.classList.remove('active'));
              const allBtn = filterWrap.querySelector('.pdf-cat-btn[data-category="all"]');
              if (allBtn) allBtn.classList.add('active');
            }
            renderCatalog();
          };
        }
        return;
      }

      // Render Cards
      let html = '';
      filtered.forEach(pdf => {
        const cStyle = getCategoryColor(pdf.category);
        const tagsHtml = (pdf.tags || []).slice(0, 4).map(t => `<span class="pdf-card-tag">${t}</span>`).join('');
        const fileName = pdf.file.split('/').pop();

        html += `
          <article class="pdf-card" data-pdf-id="${pdf.id}">
            <div class="pdf-card-cover" style="background: ${cStyle.grad};">
              <div class="pdf-card-cover-pattern"></div>
              <div class="pdf-card-cover-content">
                <span class="pdf-cover-badge">RAUF LABS ACADEMY</span>
                <div class="pdf-cover-title">${pdf.title}</div>
                <div class="pdf-cover-meta">
                  <span>📄 ${pdf.pageCount} Pages • ${pdf.fileSize}</span>
                  <span>${pdf.category}</span>
                </div>
              </div>
            </div>

            <div class="pdf-card-body">
              <div class="pdf-card-header">
                <span class="pdf-cat-badge" style="background: ${cStyle.bg}; color: ${cStyle.text}; border: 1px solid ${cStyle.border};">
                  ${pdf.category}
                </span>
                <span class="pdf-page-indicator">📄 ${pdf.pageCount} Pages</span>
              </div>

              <h3 class="pdf-card-title" title="${pdf.title}">${pdf.title}</h3>
              <p class="pdf-card-desc">${pdf.description}</p>

              <div class="pdf-card-tags">
                ${tagsHtml}
              </div>

              <div class="pdf-card-footer">
                <button class="btn btn-primary btn-sm read-pdf-btn" data-id="${pdf.id}" title="Read ${pdf.title} inside Rauf Labs">
                  📖 Read Here
                </button>
                <a href="${pdf.file}" download="${fileName}" class="btn btn-secondary btn-sm download-pdf-btn" title="Download ${pdf.title}">
                  ⬇ Download PDF
                </a>
                ${pdf.source ? `
                  <a href="${pdf.source}" target="_blank" rel="noopener noreferrer" class="pdf-source-btn" title="Official Source">
                    🔗
                  </a>
                ` : ''}
              </div>
            </div>
          </article>
        `;
      });

      grid.innerHTML = html;

      // Attach "Read Here" Click Handlers
      grid.querySelectorAll('.read-pdf-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
          e.preventDefault();
          openInternalReader(btn.dataset.id);
        });
      });
    }

    // Open Internal Reader inside Rauf Labs
    async function openInternalReader(pdfId) {
      const allPdfs = window.PDFS_DATA || [];
      const pdf = allPdfs.find(p => p.id === pdfId);
      if (!pdf || !readerSection) return;

      if (currentRenderTask) {
        try { currentRenderTask.cancel(); } catch (e) {}
        currentRenderTask = null;
      }
      isRendering = false;
      renderPending = false;

      activePdf = pdf;
      currentPageNum = 1;
      currentScale = 1.15;
      pdfDoc = null;

      // Update URL without page refresh (deep link / route support)
      try {
        const newUrl = new URL(window.location.href);
        newUrl.searchParams.set('read', pdf.id);
        window.history.pushState({ pdfId: pdf.id }, '', newUrl.toString());
      } catch (err) {
        // Safe fallback
      }

      const cStyle = getCategoryColor(pdf.category);
      const learnList = (pdf.learn || []).map(item => `<li>${item}</li>`).join('');
      const tagsList = (pdf.tags || []).map(t => `<span class="pdf-detail-tag">${t}</span>`).join('');
      const fileName = pdf.file.split('/').pop();

      // Reader UI markup
      readerSection.style.display = 'block';
      readerSection.innerHTML = `
        <div class="pdf-reader-container" id="pdf-reader-active-box">
          <!-- Reader Sticky Header & Controls -->
          <div class="pdf-reader-header">
            <div class="pdf-reader-info">
              <span class="pdf-cat-badge" style="background: ${cStyle.bg}; color: ${cStyle.text}; border: 1px solid ${cStyle.border};">
                ${pdf.category}
              </span>
              <h2 class="pdf-reader-title">${pdf.title}</h2>
              <div class="pdf-reader-meta">
                <span>Publisher: <strong>Rauf Labs Academy</strong></span>
                <span>•</span>
                <span>Pages: <strong id="pdf-header-total">${pdf.pageCount}</strong></span>
                <span>•</span>
                <span>Size: <strong>${pdf.fileSize}</strong></span>
              </div>
            </div>

            <!-- Toolbar Controls -->
            <div class="pdf-reader-actions">
              <!-- Page Controls -->
              <div class="pdf-toolbar-group">
                <button class="pdf-toolbar-btn" id="pdf-prev-btn" title="Previous Page (Left Arrow)" aria-label="Previous Page">‹</button>
                <span class="pdf-page-display" id="pdf-page-indicator">Page <strong id="current-page-num">1</strong> of <span id="total-page-num">${pdf.pageCount}</span></span>
                <button class="pdf-toolbar-btn" id="pdf-next-btn" title="Next Page (Right Arrow)" aria-label="Next Page">›</button>
              </div>

              <!-- Zoom Controls -->
              <div class="pdf-toolbar-group">
                <button class="pdf-toolbar-btn" id="pdf-zoom-out-btn" title="Zoom Out (-)" aria-label="Zoom Out">−</button>
                <span class="pdf-zoom-display" id="pdf-zoom-val">${Math.round(currentScale * 100)}%</span>
                <button class="pdf-toolbar-btn" id="pdf-zoom-in-btn" title="Zoom In (+)" aria-label="Zoom In">+</button>
                <button class="pdf-toolbar-btn" id="pdf-fit-width-btn" title="Fit to Width">Fit</button>
              </div>

              <!-- Document Actions -->
              <div class="pdf-toolbar-group">
                <button class="pdf-toolbar-btn" id="pdf-share-link-btn" title="Copy Direct Reader Link">🔗 Share</button>
                <button class="pdf-toolbar-btn" id="pdf-fullscreen-btn" title="Toggle Fullscreen">⛶</button>
                <a href="${pdf.file}" target="_blank" rel="noopener noreferrer" class="pdf-toolbar-btn" title="Open PDF in New Tab">↗</a>
                <a href="${pdf.file}" download="${fileName}" class="btn btn-primary btn-sm" style="padding: 6px 14px; font-size: 0.85rem;" title="Download Original PDF">
                  ⬇ Download
                </a>
                <button class="pdf-close-btn" id="pdf-close-reader-btn" title="Close Reader (Esc)" aria-label="Close Reader">✕</button>
              </div>
            </div>
          </div>

          <!-- Reader Viewport Area -->
          <div class="pdf-viewport-wrapper" id="pdf-viewport-wrapper">
            <!-- Loading Overlay -->
            <div class="pdf-loading-overlay" id="pdf-loading-overlay">
              <div class="pdf-loading-spinner"></div>
              <span id="pdf-loading-text">Loading Rauf Labs Academy document...</span>
            </div>

            <!-- Fallback Error Panel (Shown if PDF cannot be rendered) -->
            <div class="pdf-fallback-panel" id="pdf-fallback-panel" style="display: none;">
              <div style="font-size: 2.8rem; margin-bottom: 12px;">⚠️</div>
              <h3 style="color: #fff; margin-bottom: 8px;">PDF preview is temporarily unavailable.</h3>
              <p style="color: var(--text-secondary); max-width: 520px; margin: 0 auto 20px; font-size: 0.95rem;">
                The document is available directly. You can open it in your browser or download the file to your device.
              </p>
              <div style="display: flex; gap: 14px; justify-content: center; flex-wrap: wrap;">
                <a href="${pdf.file}" target="_blank" rel="noopener noreferrer" class="btn btn-primary">
                  Open PDF
                </a>
                <a href="${pdf.file}" download="${fileName}" class="btn btn-secondary">
                  Download PDF (${pdf.fileSize})
                </a>
              </div>
            </div>

            <!-- PDF.js Canvas Container -->
            <div class="pdf-canvas-container" id="pdf-canvas-container">
              <canvas id="pdf-render-canvas"></canvas>
            </div>
          </div>

          <!-- Document Info & Details Under Reader -->
          <div class="pdf-details-under-reader">
            <div class="pdf-details-grid">
              <div class="pdf-details-main">
                <div class="pdf-detail-card">
                  <h3 class="pdf-detail-title">📌 About This Edition</h3>
                  <p class="pdf-detail-desc">${pdf.about || pdf.description}</p>
                  <div class="pdf-tags-cluster">
                    ${tagsList}
                  </div>
                </div>

                ${learnList ? `
                  <div class="pdf-detail-card">
                    <h3 class="pdf-detail-title">🎯 What You Will Learn</h3>
                    <ul class="pdf-learn-checklist">
                      ${learnList}
                    </ul>
                  </div>
                ` : ''}
              </div>

              <div class="pdf-details-side">
                <div class="pdf-detail-card">
                  <h3 class="pdf-detail-title">⚙️ Requirements & Prerequisites</h3>
                  <p class="pdf-requirements-text">${pdf.requirements || 'None — Beginner friendly.'}</p>
                </div>

                <div class="pdf-detail-card">
                  <h3 class="pdf-detail-title">📥 Document Actions</h3>
                  <div class="pdf-action-stack">
                    <a href="${pdf.file}" download="${fileName}" class="btn btn-primary" style="width: 100%; justify-content: center;">
                      ⬇ Download PDF (${pdf.fileSize})
                    </a>
                    <a href="${pdf.file}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary" style="width: 100%; justify-content: center;">
                      ↗ Open in Full Tab
                    </a>
                    ${pdf.source ? `
                      <a href="${pdf.source}" target="_blank" rel="noopener noreferrer" class="btn btn-secondary" style="width: 100%; justify-content: center;">
                        🔗 Official Source
                      </a>
                    ` : ''}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      `;

      // Smooth scroll reader into view
      readerSection.scrollIntoView({ behavior: 'smooth', block: 'start' });

      // Attach Control Events
      const prevBtn = document.getElementById('pdf-prev-btn');
      const nextBtn = document.getElementById('pdf-next-btn');
      const zoomInBtn = document.getElementById('pdf-zoom-in-btn');
      const zoomOutBtn = document.getElementById('pdf-zoom-out-btn');
      const fitWidthBtn = document.getElementById('pdf-fit-width-btn');
      const fullscreenBtn = document.getElementById('pdf-fullscreen-btn');
      const closeBtn = document.getElementById('pdf-close-reader-btn');
      const canvasContainer = document.getElementById('pdf-canvas-container');

      if (prevBtn) {
        prevBtn.onclick = () => {
          if (currentPageNum > 1) {
            currentPageNum--;
            queueRender();
          }
        };
      }

      if (nextBtn) {
        nextBtn.onclick = () => {
          if (currentPageNum < totalPageCount) {
            currentPageNum++;
            queueRender();
          }
        };
      }

      if (zoomInBtn) {
        zoomInBtn.onclick = () => {
          currentScale = Math.min(3.0, currentScale + 0.2);
          queueRender();
        };
      }

      if (zoomOutBtn) {
        zoomOutBtn.onclick = () => {
          currentScale = Math.max(0.5, currentScale - 0.2);
          queueRender();
        };
      }

      if (fitWidthBtn && canvasContainer) {
        fitWidthBtn.onclick = () => {
          if (!pdfDoc) return;
          pdfDoc.getPage(currentPageNum).then(page => {
            const viewport = page.getViewport({ scale: 1.0 });
            const containerWidth = canvasContainer.clientWidth - 48;
            if (containerWidth > 0 && viewport.width > 0) {
              currentScale = Math.max(0.5, Math.min(2.5, containerWidth / viewport.width));
              queueRender();
            }
          }).catch(() => {});
        };
      }

      if (fullscreenBtn) {
        fullscreenBtn.onclick = () => {
          const readerBox = document.getElementById('pdf-reader-active-box');
          if (!readerBox) return;

          if (!document.fullscreenElement) {
            if (readerBox.requestFullscreen) {
              readerBox.requestFullscreen().catch(() => {});
            }
            readerBox.classList.add('pdf-reader-fullscreen');
            fullscreenBtn.textContent = '✕';
          } else {
            if (document.exitFullscreen) {
              document.exitFullscreen().catch(() => {});
            }
            readerBox.classList.remove('pdf-reader-fullscreen');
            fullscreenBtn.textContent = '⛶';
          }
        };
      }

      const shareBtn = document.getElementById('pdf-share-link-btn');
      if (shareBtn) {
        shareBtn.onclick = () => {
          const directUrl = `${window.location.origin}/pdfs/read/${pdf.id}`;
          navigator.clipboard.writeText(directUrl).then(() => {
            const originalText = shareBtn.textContent;
            shareBtn.textContent = '✓ Copied!';
            setTimeout(() => { shareBtn.textContent = originalText; }, 2000);
            if (typeof window.showToast === 'function') {
              window.showToast('Direct reader link copied to clipboard!', 'success');
            }
          }).catch(() => {
            if (typeof window.showToast === 'function') {
              window.showToast(`Link: ${directUrl}`, 'info');
            }
          });
        };
      }

      if (closeBtn) {
        closeBtn.onclick = () => {
          closeInternalReader();
        };
      }

      // Touch swipe navigation for mobile readers
      if (canvasContainer) {
        canvasContainer.addEventListener('touchstart', (e) => {
          touchStartX = e.changedTouches[0].screenX;
        }, { passive: true });

        canvasContainer.addEventListener('touchend', (e) => {
          touchEndX = e.changedTouches[0].screenX;
          const diffX = touchEndX - touchStartX;
          if (Math.abs(diffX) > 60) {
            if (diffX < 0 && currentPageNum < totalPageCount) {
              // Swipe Left -> Next Page
              currentPageNum++;
              queueRender();
            } else if (diffX > 0 && currentPageNum > 1) {
              // Swipe Right -> Previous Page
              currentPageNum--;
              queueRender();
            }
          }
        }, { passive: true });
      }

      // Keyboard navigation
      const keyHandler = (e) => {
        if (!activePdf) return;
        if (e.key === 'ArrowLeft' || e.key === 'PageUp') {
          if (currentPageNum > 1) {
            e.preventDefault();
            currentPageNum--;
            queueRender();
          }
        } else if (e.key === 'ArrowRight' || e.key === 'PageDown' || e.key === ' ') {
          if (currentPageNum < totalPageCount) {
            e.preventDefault();
            currentPageNum++;
            queueRender();
          }
        } else if (e.key === 'Escape') {
          closeInternalReader();
        } else if (e.key === '+' || e.key === '=') {
          currentScale = Math.min(3.0, currentScale + 0.2);
          queueRender();
        } else if (e.key === '-') {
          currentScale = Math.max(0.5, currentScale - 0.2);
          queueRender();
        }
      };

      window.removeEventListener('keydown', window.__pdfReaderKeyHandler);
      window.__pdfReaderKeyHandler = keyHandler;
      window.addEventListener('keydown', keyHandler);

      // Load Document with PDF.js
      await loadPdfWithPdfJs(pdf);
    }

    // Load Document using PDF.js
    async function loadPdfWithPdfJs(pdf) {
      const loadingOverlay = document.getElementById('pdf-loading-overlay');
      const fallbackPanel = document.getElementById('pdf-fallback-panel');
      const canvasContainer = document.getElementById('pdf-canvas-container');

      if (loadingOverlay) loadingOverlay.style.display = 'flex';
      if (fallbackPanel) fallbackPanel.style.display = 'none';

      try {
        await ensurePdfJsLoaded();
      } catch (err) {
        console.warn('PDF.js failed to load:', err);
        showFallback();
        return;
      }

      if (!window.pdfjsLib) {
        console.warn('PDF.js library not loaded; falling back.');
        showFallback();
        return;
      }

      try {
        setupPdfJsWorker();
        const loadingTask = window.pdfjsLib.getDocument({
          url: pdf.file,
          cMapUrl: 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/cmaps/',
          cMapPacked: true
        });

        pdfDoc = await loadingTask.promise;
        totalPageCount = pdfDoc.numPages || pdf.pageCount || 1;

        const totalInd = document.getElementById('total-page-num');
        const headerTotal = document.getElementById('pdf-header-total');
        if (totalInd) totalInd.textContent = totalPageCount;
        if (headerTotal) headerTotal.textContent = totalPageCount;

        // Auto-fit scale on mobile
        if (canvasContainer && canvasContainer.clientWidth < 650) {
          currentScale = Math.max(0.65, (canvasContainer.clientWidth - 32) / 600);
        }

        queueRender();
      } catch (err) {
        console.error('Failed to load PDF with PDF.js:', err);
        showFallback();
      }
    }

    // Render Queue Controller to prevent canvas concurrency collisions
    function queueRender() {
      if (isRendering) {
        renderPending = true;
        if (currentRenderTask) {
          try {
            currentRenderTask.cancel();
          } catch (e) {}
        }
      } else {
        renderCurrentPage();
      }
    }

    // Render Current Page onto HTML5 Canvas
    async function renderCurrentPage() {
      if (!pdfDoc || !activePdf) return;

      if (isRendering) {
        renderPending = true;
        if (currentRenderTask) {
          try {
            currentRenderTask.cancel();
          } catch (e) {}
        }
        return;
      }

      isRendering = true;
      renderPending = false;

      const loadingOverlay = document.getElementById('pdf-loading-overlay');
      const pageIndicator = document.getElementById('current-page-num');
      const zoomVal = document.getElementById('pdf-zoom-val');
      const prevBtn = document.getElementById('pdf-prev-btn');
      const nextBtn = document.getElementById('pdf-next-btn');
      const canvasContainer = document.getElementById('pdf-canvas-container');

      // Update Toolbar state
      if (pageIndicator) pageIndicator.textContent = currentPageNum;
      if (zoomVal) zoomVal.textContent = `${Math.round(currentScale * 100)}%`;
      if (prevBtn) prevBtn.style.opacity = currentPageNum <= 1 ? '0.4' : '1';
      if (nextBtn) nextBtn.style.opacity = currentPageNum >= totalPageCount ? '0.4' : '1';

      if (loadingOverlay) loadingOverlay.style.display = 'flex';

      // Cancel previous task if still running and await settlement
      if (currentRenderTask) {
        try {
          currentRenderTask.cancel();
          await currentRenderTask.promise;
        } catch (e) {
          // Expected cancellation
        }
        currentRenderTask = null;
      }

      let canvas = document.getElementById('pdf-render-canvas');
      if (!canvas && canvasContainer) {
        canvas = document.createElement('canvas');
        canvas.id = 'pdf-render-canvas';
        canvasContainer.appendChild(canvas);
      }

      try {
        const pageToRender = currentPageNum;
        const scaleToRender = currentScale;

        const page = await pdfDoc.getPage(pageToRender);

        // If another render was queued while fetching page data, abort
        if (renderPending || pageToRender !== currentPageNum || scaleToRender !== currentScale) {
          return;
        }

        const dpr = window.devicePixelRatio || 1;
        const viewport = page.getViewport({ scale: scaleToRender });

        // If canvas has an ongoing or unclean render task on it, replace canvas with a clean element
        if (canvas && canvas._renderTask) {
          const freshCanvas = document.createElement('canvas');
          freshCanvas.id = 'pdf-render-canvas';
          if (canvas.parentNode) {
            canvas.parentNode.replaceChild(freshCanvas, canvas);
            canvas = freshCanvas;
          }
        }

        const context = canvas.getContext('2d');
        canvas.width = Math.floor(viewport.width * dpr);
        canvas.height = Math.floor(viewport.height * dpr);
        canvas.style.width = `${Math.floor(viewport.width)}px`;
        canvas.style.height = `${Math.floor(viewport.height)}px`;

        const renderContext = {
          canvasContext: context,
          viewport: viewport,
          transform: [dpr, 0, 0, dpr, 0, 0]
        };

        currentRenderTask = page.render(renderContext);
        await currentRenderTask.promise;
        currentRenderTask = null;

        if (loadingOverlay) loadingOverlay.style.display = 'none';
      } catch (err) {
        currentRenderTask = null;
        if (err && err.name === 'RenderingCancelledException') {
          // Normal when switching pages fast
        } else if (err && err.message && err.message.includes('Cannot use the same canvas')) {
          // Safety recovery if canvas conflict occurred
          if (canvasContainer) {
            const freshCanvas = document.createElement('canvas');
            freshCanvas.id = 'pdf-render-canvas';
            canvasContainer.innerHTML = '';
            canvasContainer.appendChild(freshCanvas);
          }
          renderPending = true;
        } else {
          console.error('Error rendering PDF page:', err);
        }
      } finally {
        isRendering = false;
        if (loadingOverlay && !renderPending) {
          loadingOverlay.style.display = 'none';
        }
        if (renderPending) {
          renderPending = false;
          setTimeout(() => {
            renderCurrentPage();
          }, 0);
        }
      }
    }

    // Show Fallback Panel
    function showFallback() {
      const loadingOverlay = document.getElementById('pdf-loading-overlay');
      const fallbackPanel = document.getElementById('pdf-fallback-panel');
      const canvasContainer = document.getElementById('pdf-canvas-container');

      if (loadingOverlay) loadingOverlay.style.display = 'none';
      if (canvasContainer) canvasContainer.style.display = 'none';
      if (fallbackPanel) fallbackPanel.style.display = 'flex';
    }

    // Close Reader
    function closeInternalReader() {
      activePdf = null;
      isRendering = false;
      renderPending = false;
      if (currentRenderTask) {
        try {
          currentRenderTask.cancel();
        } catch (e) {}
        currentRenderTask = null;
      }
      pdfDoc = null;

      if (readerSection) {
        readerSection.innerHTML = '';
        readerSection.style.display = 'none';
      }

      // Exit fullscreen if active
      if (document.fullscreenElement && document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }

      // Clean URL params
      try {
        const newUrl = new URL(window.location.href);
        newUrl.searchParams.delete('read');
        window.history.pushState({}, '', newUrl.pathname);
      } catch (err) {}

      // Scroll back to library catalog
      const filterToolbar = document.querySelector('.pdf-toolbar-container');
      if (filterToolbar) {
        filterToolbar.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }

    // Initial Catalog Render
    renderCatalog();

    // Check URL parameters for direct deep-link reading (?read=<pdf-id> or path /pdfs/read/<pdf-id>)
    const url = new URL(window.location.href);
    const readParam = url.searchParams.get('read');
    const pathMatch = window.location.pathname.match(/\/pdfs\/read\/([^\/]+)/);
    const targetPdfId = readParam || (pathMatch ? pathMatch[1] : null);

    if (targetPdfId) {
      setTimeout(() => {
        openInternalReader(targetPdfId);
      }, 100);
    }

    // Handle browser back/forward navigation
    window.addEventListener('popstate', () => {
      const curUrl = new URL(window.location.href);
      const curReadParam = curUrl.searchParams.get('read');
      const curPathMatch = window.location.pathname.match(/\/pdfs\/read\/([^\/]+)/);
      const curPdfId = curReadParam || (curPathMatch ? curPathMatch[1] : null);

      if (curPdfId) {
        openInternalReader(curPdfId);
      } else {
        closeInternalReader();
      }
    });
  }

  // Auto-initialize when ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPdfLibrary);
  } else {
    initPdfLibrary();
  }

  window.initPdfLibrary = initPdfLibrary;
})();

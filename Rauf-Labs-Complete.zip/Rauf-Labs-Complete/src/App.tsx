import { useState, useEffect, useMemo } from 'react';
import { Navbar } from './components/Navbar';
import { HeroSection } from './components/HeroSection';
import { AboutRaufSection } from './components/AboutRaufSection';
import { CourseCards } from './components/CourseCards';
import { LessonSection } from './components/LessonSection';
import { ProgrammingSection } from './components/ProgrammingSection';
import { ApiDirectory } from './components/ApiDirectory';
import { ToolsSection } from './components/ToolsSection';
import { CommandRefSection } from './components/CommandRefSection';
import { RoadmapSection } from './components/RoadmapSection';
import { BlogSection } from './components/BlogSection';
import { GlobalSearch } from './components/GlobalSearch';
import { FaqSection } from './components/FaqSection';
import { ConnectSection } from './components/ConnectSection';
import { Footer } from './components/Footer';
import { LessonModal } from './components/LessonModal';
import { Toast } from './components/Toast';
import { RAW_LESSON_TITLES, LESSON_DETAILS } from './data/learningData';
import { LessonDetail } from './types';

export default function App() {
  // Theme state
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    const saved = localStorage.getItem('termforge_theme') || localStorage.getItem('theme');
    return saved === 'light' ? 'light' : 'dark';
  });

  // Completed lessons map
  const [completedMap, setCompletedMap] = useState<Record<string, boolean>>(() => {
    const map: Record<string, boolean> = {};
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (key && key.startsWith('done_')) {
        map[key] = localStorage.getItem(key) === '1';
      }
    }
    return map;
  });

  // Active Lesson for modal
  const [activeLesson, setActiveLesson] = useState<LessonDetail | null>(null);

  // Toast feedback
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Apply theme to html root
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('termforge_theme', theme);
    localStorage.setItem('theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((current) => (current === msg ? null : current));
    }, 2200);
  };

  const copyToClipboard = (text: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text);
    }
    showToast('Copied to clipboard');
  };

  // Open Lesson Modal
  const handleOpenLesson = (title: string, section: string, idx: number) => {
    // Generate or retrieve full lesson content
    const existing = LESSON_DETAILS[section]?.[idx];
    if (existing) {
      setActiveLesson(existing);
    } else {
      // Default fallback generator
      const defaultCmd =
        section === 'termux'
          ? 'pkg update && pkg upgrade -y'
          : section === 'git'
          ? 'git status && git log --oneline'
          : section === 'powershell'
          ? 'Get-Help Get-Process -Detailed'
          : section === 'linux'
          ? 'pwd && ls -la && whoami'
          : 'echo "Executing Bash script..."';

      const generated: LessonDetail = {
        id: `${section}-${idx}`,
        section,
        idx,
        title,
        summary: `Practical ${section} lesson focusing on ${title.toLowerCase()} for command-line workflows.`,
        command: defaultCmd,
        explanation: `This lesson explains core principles of ${title}. You will run standard commands, inspect process exit codes, and learn to avoid common errors.`,
        expectedOutput: `[Command executed successfully]\nstatus: OK\ntarget: ${title}`,
        safetyTip: 'Never run shell commands with elevated privileges (root or administrator) unless strictly necessary.',
        exercise: `Open your terminal, execute the command above, and inspect its stdout and stderr outputs.`,
        tags: [section, 'CLI', 'Practical']
      };
      setActiveLesson(generated);
    }
  };

  const toggleLessonComplete = () => {
    if (!activeLesson) return;
    const key = `done_${activeLesson.section}_${activeLesson.idx}`;
    const nextVal = !completedMap[key];

    const updated = { ...completedMap, [key]: nextVal };
    setCompletedMap(updated);

    if (nextVal) {
      localStorage.setItem(key, '1');
      showToast(`Completed: ${activeLesson.title} ✓`);
    } else {
      localStorage.removeItem(key);
      showToast(`Marked incomplete: ${activeLesson.title}`);
    }
  };

  const handleNextLesson = () => {
    if (!activeLesson) return;
    const titles = RAW_LESSON_TITLES[activeLesson.section] || [];
    const nextIdx = activeLesson.idx + 1;
    if (nextIdx < titles.length) {
      handleOpenLesson(titles[nextIdx], activeLesson.section, nextIdx);
    } else {
      showToast(`Congratulations! You have reached the end of ${activeLesson.section.toUpperCase()} track.`);
      setActiveLesson(null);
    }
  };

  // Calculate percentage per track for CourseCards
  const progressMap = useMemo(() => {
    const result: Record<string, number> = {};

    Object.entries(RAW_LESSON_TITLES).forEach(([sec, titles]) => {
      const completed = titles.filter((_, idx) => completedMap[`done_${sec}_${idx}`]).length;
      result[sec] = Math.round((completed / titles.length) * 100);
    });

    // Programming track default progress
    result['programming'] = 100;

    return result;
  }, [completedMap]);

  return (
    <div className="min-h-screen flex flex-col bg-[var(--bg)] text-[var(--text)] selection:bg-[#48a9ff]/30 selection:text-[#79caff] transition-colors duration-200">
      {/* Sticky Navigation */}
      <Navbar theme={theme} onToggleTheme={toggleTheme} brandName="TermForge" />

      {/* Main Content Areas */}
      <main id="main-content" className="flex-1">
        {/* STEP 2: HERO */}
        <HeroSection />

        {/* STEP 3: ABOUT RAUF */}
        <AboutRaufSection onCopy={copyToClipboard} />

        {/* Course Cards Overview */}
        <CourseCards progressMap={progressMap} />

        {/* 3. Termux Guide */}
        <LessonSection
          id="termux"
          kicker="01 · Android Terminal"
          title="Termux Guide"
          description="From first setup and package management to Git, Python, Node.js, SSH, Bash scripting, and practical mini projects."
          lessons={RAW_LESSON_TITLES.termux}
          completedMap={completedMap}
          onOpenLesson={handleOpenLesson}
        />

        {/* 4. Linux Guide */}
        <LessonSection
          id="linux"
          kicker="02 · Linux Operating System"
          title="Linux Guide"
          description="Filesystem architecture, permissions, users, processes, package managers, networking, SSH, and troubleshooting."
          lessons={RAW_LESSON_TITLES.linux}
          completedMap={completedMap}
          onOpenLesson={handleOpenLesson}
        />

        {/* 5. PowerShell Guide */}
        <LessonSection
          id="powershell"
          kicker="03 · Windows Automation"
          title="PowerShell Guide"
          description="Commands, object pipelines, provider cmdlets, system services, networking, scripts, and error handling."
          lessons={RAW_LESSON_TITLES.powershell}
          completedMap={completedMap}
          onOpenLesson={handleOpenLesson}
        />

        {/* 6. Bash Scripting Guide */}
        <LessonSection
          id="bash"
          kicker="04 · Shell Scripting"
          title="Bash Guide"
          description="Variables, conditions, loops, functions, arguments, pipes, redirection, grep, sed, awk, and production automation."
          lessons={RAW_LESSON_TITLES.bash}
          completedMap={completedMap}
          onOpenLesson={handleOpenLesson}
        />

        {/* 7. Git & GitHub Guide */}
        <LessonSection
          id="git"
          kicker="05 · Version Control"
          title="Git & GitHub"
          description="Master git init, commits, branches, pull requests, SSH keypairs, and team collaboration workflows."
          lessons={RAW_LESSON_TITLES.git}
          completedMap={completedMap}
          onOpenLesson={handleOpenLesson}
        />

        {/* 8. Programming Paths */}
        <ProgrammingSection onCopy={copyToClipboard} />

        {/* 9. Public APIs Dynamic Directory */}
        <ApiDirectory onNotify={showToast} />

        {/* 10. Open Source Tools */}
        <ToolsSection onCopy={copyToClipboard} />

        {/* 11. Command Reference */}
        <CommandRefSection onCopy={copyToClipboard} />

        {/* 12. Beginner Roadmap */}
        <RoadmapSection />

        {/* 13. Developer Blog */}
        <BlogSection onCopy={copyToClipboard} />

        {/* 14. Global Search */}
        <GlobalSearch
          onOpenLesson={handleOpenLesson}
          onCopyCommand={copyToClipboard}
        />

        {/* 15. FAQ */}
        <FaqSection />

        {/* 16. Connect With Us */}
        <ConnectSection />
      </main>

      {/* Footer */}
      <Footer brandName="TermForge" />

      {/* Lesson Details Modal */}
      {activeLesson && (
        <LessonModal
          lesson={activeLesson}
          isCompleted={!!completedMap[`done_${activeLesson.section}_${activeLesson.idx}`]}
          onClose={() => setActiveLesson(null)}
          onToggleComplete={toggleLessonComplete}
          onNextLesson={
            activeLesson.idx + 1 < (RAW_LESSON_TITLES[activeLesson.section] || []).length
              ? handleNextLesson
              : undefined
          }
          onCopy={copyToClipboard}
        />
      )}

      {/* Notification Toast */}
      <Toast message={toastMessage} />
    </div>
  );
}

import React from 'react';
import { Terminal, Cpu, GitBranch, Globe2, ArrowRight } from 'lucide-react';

const ROADMAP_STEPS = [
  {
    step: '01 · FOUNDATIONS',
    title: 'Terminal & Files',
    desc: 'Navigation, directories, package managers, text editors, permissions and safe command habits.',
    icon: Terminal,
    color: 'from-blue-500/20 to-cyan-500/20',
    accent: 'text-cyan-400'
  },
  {
    step: '02 · AUTOMATION',
    title: 'Shell Scripting',
    desc: 'Bash & PowerShell variables, conditionals, loops, functions, arguments, pipes and cron automation.',
    icon: Cpu,
    color: 'from-cyan-500/20 to-emerald-500/20',
    accent: 'text-emerald-400'
  },
  {
    step: '03 · DEVELOPMENT',
    title: 'Git + Programming',
    desc: 'Python or JavaScript fundamentals, building projects, committing history, and branching workflows.',
    icon: GitBranch,
    color: 'from-purple-500/20 to-indigo-500/20',
    accent: 'text-purple-400'
  },
  {
    step: '04 · REAL WORLD',
    title: 'APIs + Open Source',
    desc: 'Reading documentation, querying REST APIs with curl, contributing to GitHub repos, and shipping software.',
    icon: Globe2,
    color: 'from-amber-500/20 to-orange-500/20',
    accent: 'text-amber-400'
  }
];

export const RoadmapSection: React.FC = () => {
  return (
    <section id="roadmap" className="py-16 border-t border-[var(--line)]">
      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        <div className="mb-10 flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <div className="text-xs font-black tracking-widest text-[#73c5ff] uppercase">
              Your Path
            </div>
            <h2 className="mt-1 text-3xl font-extrabold tracking-tight text-[var(--text)] sm:text-4xl">
              Beginner Roadmap
            </h2>
            <p className="mt-2 max-w-2xl text-sm sm:text-base text-[var(--muted)]">
              Build confidence in progressive layers instead of trying to memorize everything at once.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {ROADMAP_STEPS.map((s, idx) => {
            const Icon = s.icon;
            return (
              <div
                key={idx}
                className="relative flex flex-col justify-between rounded-2xl border border-[var(--line)] bg-[var(--panel)] p-6 transition-all duration-200 hover:-translate-y-1 hover:border-[#48a9ff]/40"
              >
                <div>
                  <div className="flex items-center justify-between mb-4">
                    <span className="text-[10px] font-black tracking-wider text-[#74c7ff]">
                      {s.step}
                    </span>
                    <span className={`p-2 rounded-xl bg-gradient-to-br ${s.color} ${s.accent}`}>
                      <Icon className="h-4 w-4" />
                    </span>
                  </div>

                  <strong className="block text-base font-bold text-[var(--text)]">
                    {s.title}
                  </strong>

                  <p className="mt-2 text-xs leading-relaxed text-[var(--muted)]">
                    {s.desc}
                  </p>
                </div>

                <div className="mt-6 pt-3 border-t border-[var(--line)]/50 flex items-center justify-between text-[11px] text-[var(--muted)]">
                  <span>Phase {idx + 1} of 4</span>
                  <ArrowRight className="h-3.5 w-3.5 text-[#48a9ff]" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

import React from 'react';
import { Youtube, Instagram, ExternalLink, Sparkles } from 'lucide-react';

export const ConnectSection: React.FC = () => {
  return (
    <section className="py-12 border-t border-[var(--line)]">
      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        <div className="relative overflow-hidden rounded-3xl border border-[#48a9ff]/30 bg-gradient-to-r from-[var(--panel)] via-[var(--panel2)] to-[var(--panel)] p-6 sm:p-10 shadow-xl">
          {/* Subtle glow background */}
          <div className="pointer-events-none absolute -left-20 top-0 h-60 w-60 rounded-full bg-[#48a9ff]/15 blur-3xl" />
          <div className="pointer-events-none absolute -right-20 bottom-0 h-60 w-60 rounded-full bg-[#4be0d4]/15 blur-3xl" />

          <div className="relative z-10 flex flex-col items-start justify-between gap-6 md:flex-row md:items-center">
            <div>
              <div className="inline-flex items-center gap-1.5 text-xs font-black tracking-widest text-[#73c5ff] uppercase mb-1">
                <Sparkles className="h-3 w-3" />
                Connect With Us
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-[var(--text)] tracking-tight">
                Learn together. Build together.
              </h2>
              <p className="mt-1 text-xs sm:text-sm text-[var(--muted)] max-w-lg">
                Follow the project for practical tutorials, terminal tips, coding cheat sheets and new open-source developer resources.
              </p>
            </div>

            <div className="flex flex-wrap items-center gap-3">
              <a
                href="https://youtube.com/@islamic_78618?si=rBK5DpAFxDuWSFos"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-xl border border-[var(--line)] bg-[var(--panel2)] px-4 py-3 text-xs sm:text-sm font-bold text-[var(--text)] shadow-sm transition-all hover:-translate-y-0.5 hover:border-rose-500/50 hover:bg-rose-500/10 hover:text-rose-400"
              >
                <Youtube className="h-4 w-4 text-rose-500" />
                <span>YouTube</span>
                <ExternalLink className="h-3 w-3 opacity-60" />
              </a>

              <a
                href="https://www.instagram.com/not._.u._.rauf?stkn=MXVhN3JvYnF3NDh1bg=="
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 rounded-xl border border-[var(--line)] bg-[var(--panel2)] px-4 py-3 text-xs sm:text-sm font-bold text-[var(--text)] shadow-sm transition-all hover:-translate-y-0.5 hover:border-pink-500/50 hover:bg-pink-500/10 hover:text-pink-400"
              >
                <Instagram className="h-4 w-4 text-pink-400" />
                <span>Instagram</span>
                <ExternalLink className="h-3 w-3 opacity-60" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

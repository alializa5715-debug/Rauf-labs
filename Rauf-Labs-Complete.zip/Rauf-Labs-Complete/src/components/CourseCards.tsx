import React from 'react';
import { Course } from '../types';
import { COURSES } from '../data/learningData';
import { ArrowUpRight } from 'lucide-react';

interface CourseCardsProps {
  progressMap: Record<string, number>;
}

export const CourseCards: React.FC<CourseCardsProps> = ({ progressMap }) => {
  return (
    <section className="py-16 border-t border-[var(--line)]">
      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        <div className="mb-10 flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <div className="text-xs font-black tracking-widest text-[#73c5ff] uppercase">
              Learning Paths
            </div>
            <h2 className="mt-1 text-3xl font-extrabold tracking-tight text-[var(--text)] sm:text-4xl">
              What can you learn?
            </h2>
            <p className="mt-2 max-w-2xl text-sm sm:text-base text-[var(--muted)]">
              Learn by doing: command line fundamentals, automation, version control, programming languages and public APIs.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {COURSES.map((course: Course) => {
            const percentage = progressMap[course.id] || 0;

            return (
              <a
                key={course.id}
                href={`#${course.sectionId}`}
                id={`course-card-${course.id}`}
                className="group relative flex flex-col justify-between rounded-2xl border border-[var(--line)] bg-gradient-to-b from-[var(--panel)] to-[var(--panel2)] p-6 shadow-lg shadow-black/5 transition-all duration-200 hover:-translate-y-1 hover:border-[#48a9ff]/40 hover:shadow-xl hover:shadow-[#48a9ff]/5"
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#48a9ff]/10 text-xl font-bold text-[#79caff] transition-transform duration-200 group-hover:scale-110">
                      {course.icon}
                    </div>
                    <span className="flex h-7 w-7 items-center justify-center rounded-full bg-[var(--panel2)] text-[var(--muted)] transition-colors group-hover:bg-[#48a9ff]/20 group-hover:text-[#48a9ff]">
                      <ArrowUpRight className="h-4 w-4" />
                    </span>
                  </div>

                  <h3 className="mt-4 text-lg font-bold text-[var(--text)] group-hover:text-[#79caff] transition-colors">
                    {course.title}
                  </h3>
                  <p className="mt-2 text-xs sm:text-sm leading-relaxed text-[var(--muted)]">
                    {course.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-[var(--line)]/50">
                  <div className="flex flex-wrap gap-1.5">
                    {course.tags.map((tag, idx) => (
                      <span
                        key={idx}
                        className="rounded-full border border-[var(--line)] bg-[var(--panel2)] px-2.5 py-0.5 text-[10px] font-semibold text-[#9bb0c8]"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>

                  {/* Dynamic Progress Bar */}
                  <div className="mt-4">
                    <div className="flex items-center justify-between text-[11px] font-medium text-[var(--muted)] mb-1.5">
                      <span>Progress</span>
                      <span className="font-mono font-semibold text-[#48a9ff]">{percentage}%</span>
                    </div>
                    <div className="h-1.5 w-full overflow-hidden rounded-full bg-slate-700/20">
                      <div
                        className="h-full bg-gradient-to-r from-[#48a9ff] to-[#4be0d4] transition-all duration-500 rounded-full"
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                </div>
              </a>
            );
          })}
        </div>
      </div>
    </section>
  );
};

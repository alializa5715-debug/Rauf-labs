import React, { useState } from 'react';
import { CheckCircle2, ArrowRight, BookOpen, Search } from 'lucide-react';

interface LessonSectionProps {
  id: string;
  kicker: string;
  title: string;
  description: string;
  lessons: string[];
  completedMap: Record<string, boolean>;
  onOpenLesson: (title: string, section: string, idx: number) => void;
}

export const LessonSection: React.FC<LessonSectionProps> = ({
  id,
  kicker,
  title,
  description,
  lessons,
  completedMap,
  onOpenLesson
}) => {
  const [filterText, setFilterText] = useState('');

  const completedCount = lessons.filter((_, idx) => completedMap[`done_${id}_${idx}`]).length;
  const progressPercent = Math.round((completedCount / lessons.length) * 100) || 0;

  const filteredLessons = lessons
    .map((title, idx) => ({ title, idx }))
    .filter((item) => item.title.toLowerCase().includes(filterText.toLowerCase()));

  return (
    <section id={id} className="py-16 border-t border-[var(--line)]">
      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        {/* Section Header */}
        <div className="mb-8 flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <div className="text-xs font-black tracking-widest text-[#73c5ff] uppercase">
              {kicker}
            </div>
            <h2 className="mt-1 text-3xl font-extrabold tracking-tight text-[var(--text)] sm:text-4xl">
              {title}
            </h2>
            <p className="mt-2 max-w-2xl text-sm sm:text-base text-[var(--muted)]">
              {description}
            </p>
          </div>

          {/* Stats Badge */}
          <div className="flex items-center gap-3">
            <div className="flex items-center gap-2 rounded-full border border-[var(--line)] bg-[var(--panel)] px-3.5 py-1.5 text-xs font-bold text-[#8bcaff]">
              <span className="flex h-2 w-2 rounded-full bg-cyan-400" />
              <span>
                {completedCount} / {lessons.length} Completed ({progressPercent}%)
              </span>
            </div>
          </div>
        </div>

        {/* Quick Lesson Filter if section has many lessons */}
        {lessons.length > 8 && (
          <div className="mb-6 max-w-sm">
            <div className="relative">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-[var(--muted)]" />
              <input
                type="text"
                value={filterText}
                onChange={(e) => setFilterText(e.target.value)}
                placeholder={`Filter ${title} lessons...`}
                className="w-full rounded-xl border border-[var(--line)] bg-[var(--panel)] py-2 pl-9 pr-4 text-xs text-[var(--text)] placeholder-[var(--muted)] outline-none transition-colors focus:border-[#48a9ff]"
              />
            </div>
          </div>
        )}

        {/* Lessons Grid */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredLessons.map(({ title: lessonTitle, idx }) => {
            const isCompleted = !!completedMap[`done_${id}_${idx}`];

            return (
              <article
                key={idx}
                className={`flex flex-col justify-between rounded-2xl border transition-all duration-200 p-5 ${
                  isCompleted
                    ? 'border-emerald-500/30 bg-gradient-to-b from-[var(--panel)] to-[var(--panel2)]'
                    : 'border-[var(--line)] bg-gradient-to-b from-[var(--panel)] to-[var(--panel2)] hover:border-[#48a9ff]/40 hover:-translate-y-0.5'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-[#48a9ff]/10 font-mono text-xs font-bold text-[#79caff]">
                      {String(idx + 1).padStart(2, '0')}
                    </div>
                    {isCompleted && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/10 px-2 py-0.5 text-[10px] font-semibold text-emerald-400 border border-emerald-500/20">
                        <CheckCircle2 className="h-3 w-3" />
                        Completed
                      </span>
                    )}
                  </div>

                  <h3 className="mt-3.5 text-base font-bold text-[var(--text)] line-clamp-1">
                    {lessonTitle}
                  </h3>

                  <p className="mt-1.5 text-xs leading-relaxed text-[var(--muted)] line-clamp-2">
                    {id === 'termux'
                      ? 'Hands-on Termux lesson with commands, expected output, mistakes and safety notes.'
                      : id === 'git'
                      ? 'Step-by-step Git lesson with workflow examples, terminal commands, and GitHub collaboration habits.'
                      : 'Step-by-step lesson with runnable command examples, practical tasks and safety notes.'}
                  </p>

                  <div className="mt-4 flex flex-wrap gap-1.5">
                    <span className="rounded-md border border-[var(--line)] bg-[var(--panel2)] px-2 py-0.5 text-[10px] text-[#9bb0c8]">
                      {isCompleted ? 'Finished' : 'Beginner friendly'}
                    </span>
                    <span className="rounded-md border border-[var(--line)] bg-[var(--panel2)] px-2 py-0.5 text-[10px] text-[#9bb0c8]">
                      Copy-ready
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  id={`btn-${id}-lesson-${idx}`}
                  onClick={() => onOpenLesson(lessonTitle, id, idx)}
                  className={`mt-5 flex w-full items-center justify-center gap-2 rounded-xl py-2.5 text-xs font-bold transition-all ${
                    isCompleted
                      ? 'border border-[var(--line)] bg-[var(--panel2)] text-[var(--text)] hover:bg-[var(--panel)]'
                      : 'border border-[var(--line)] bg-[var(--panel)] text-[var(--text)] hover:border-[#48a9ff] hover:bg-[var(--panel2)] hover:text-[#48a9ff]'
                  }`}
                >
                  <BookOpen className="h-3.5 w-3.5" />
                  <span>{isCompleted ? 'Review lesson' : 'Start lesson'}</span>
                  <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                </button>
              </article>
            );
          })}
        </div>
      </div>
    </section>
  );
};

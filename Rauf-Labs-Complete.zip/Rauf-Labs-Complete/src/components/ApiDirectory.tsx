import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { PublicApiItem } from '../types';
import { FALLBACK_PUBLIC_APIS, parsePublicApisReadme, normalizeFallbackApiEntry } from '../data/fallbackApis';
import {
  Search,
  ExternalLink,
  ShieldCheck,
  Globe,
  RefreshCw,
  Sparkles,
  Layers,
  CheckCircle2,
  XCircle,
  HelpCircle,
  ArrowRight
} from 'lucide-react';

interface ApiDirectoryProps {
  onNotify?: (msg: string) => void;
}

const GITHUB_README_URL = 'https://raw.githubusercontent.com/public-apis/public-apis/master/README.md';
const FALLBACK_API_URL = 'https://api.publicapis.org/entries';
const INITIAL_BATCH_SIZE = 48;
const BATCH_INCREMENT = 48;

export const ApiDirectory: React.FC<ApiDirectoryProps> = ({ onNotify }) => {
  const [apis, setApis] = useState<PublicApiItem[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [dataSource, setDataSource] = useState<string>('Connecting…');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('');
  const [visibleCount, setVisibleCount] = useState<number>(INITIAL_BATCH_SIZE);

  // Load and parse APIs dynamically with multi-tier fallback
  const fetchApis = useCallback(async () => {
    setIsLoading(true);
    setDataSource('Loading APIs…');

    let loadedApis: PublicApiItem[] = [];
    let sourceLabel = '';

    // 1. Primary Source: GitHub README markdown
    try {
      const response = await fetch(GITHUB_README_URL, {
        cache: 'no-store',
        headers: {
          Accept: 'text/plain, text/markdown, */*'
        }
      });

      if (!response.ok) {
        throw new Error(`GitHub README fetch failed with status ${response.status}`);
      }

      const markdown = await response.text();
      const parsed = parsePublicApisReadme(markdown);

      // Clean out any accidental separator rows or invalid records
      const sanitized = parsed.filter(
        (item) =>
          item.name &&
          !item.name.includes('---') &&
          !item.name.startsWith(':') &&
          item.description &&
          !item.description.includes('---') &&
          !item.description.startsWith(':')
      );

      if (sanitized.length > 0) {
        loadedApis = sanitized;
        sourceLabel = 'Public APIs GitHub repository';
      } else {
        throw new Error('Parsed 0 valid records from markdown');
      }
    } catch (primaryError) {
      console.warn('GitHub README fetch failed, trying fallback API:', primaryError);

      // 2. Fallback Source: JSON endpoint
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 6000);

        const response2 = await fetch(FALLBACK_API_URL, {
          cache: 'no-store',
          signal: controller.signal
        });
        clearTimeout(timeoutId);

        if (!response2.ok) {
          throw new Error(`Fallback API returned HTTP ${response2.status}`);
        }

        const data = await response2.json();
        if (data && Array.isArray(data.entries) && data.entries.length > 0) {
          loadedApis = data.entries
            .map(normalizeFallbackApiEntry)
            .filter(
              (item: PublicApiItem) =>
                item.name &&
                !item.name.includes('---') &&
                !item.name.startsWith(':') &&
                item.description &&
                !item.description.includes('---') &&
                !item.description.startsWith(':')
            );
          sourceLabel = 'Public APIs JSON service';
        } else {
          throw new Error('Fallback JSON contained no entries');
        }
      } catch (secondaryError) {
        console.warn('Fallback endpoint failed, using curated built-in catalog:', secondaryError);

        // 3. Guaranteed Built-in Fallback: Curated popular APIs
        loadedApis = FALLBACK_PUBLIC_APIS;
        sourceLabel = 'Built-in curated catalog';
      }
    }

    // Sort alphabetically by API name (Requirement 16)
    loadedApis.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));

    setApis(loadedApis);
    setDataSource(sourceLabel);
    setIsLoading(false);
  }, []);

  useEffect(() => {
    fetchApis();
  }, [fetchApis]);

  // Unique sorted categories list
  const categories = useMemo(() => {
    const set = new Set<string>();
    apis.forEach((api) => {
      if (api.category && api.category.trim() !== '') {
        set.add(api.category.trim());
      }
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b));
  }, [apis]);

  // Real-time filtering and sorting (Alphabetical: Requirement 16)
  const filteredApis = useMemo(() => {
    const q = searchQuery.toLowerCase().trim();

    return apis
      .filter((api) => {
        // Category filtering (Requirement 15)
        if (selectedCategory && api.category !== selectedCategory) {
          return false;
        }

        // Search filtering (Requirement 14)
        if (q) {
          const nameMatch = api.name.toLowerCase().includes(q);
          const catMatch = (api.category || '').toLowerCase().includes(q);
          const descMatch = (api.description || '').toLowerCase().includes(q);
          const authMatch = (api.auth || '').toLowerCase().includes(q);
          return nameMatch || catMatch || descMatch || authMatch;
        }

        return true;
      })
      .sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));
  }, [apis, searchQuery, selectedCategory]);

  const handleSearchChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    setVisibleCount(INITIAL_BATCH_SIZE);
  };

  const handleCategoryChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSelectedCategory(e.target.value);
    setVisibleCount(INITIAL_BATCH_SIZE);
  };

  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedCategory('');
    setVisibleCount(INITIAL_BATCH_SIZE);
  };

  const handleLoadMore = () => {
    setVisibleCount((prev) => prev + BATCH_INCREMENT);
  };

  return (
    <section id="apis" className="relative py-20 border-t border-[var(--line)] overflow-hidden">
      {/* Subtle background ambient lighting */}
      <div className="pointer-events-none absolute -top-24 left-1/2 -z-10 h-96 w-full -translate-x-1/2 opacity-20 blur-3xl [background:radial-gradient(ellipse_at_center,rgba(103,232,249,0.35),transparent_70%)]" />

      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        {/* Section Header */}
        <div className="flex flex-col items-start justify-between gap-4 md:flex-row md:items-end mb-8">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-black tracking-widest text-[#67e8f9] uppercase mb-1.5">
              <Sparkles className="h-3.5 w-3.5 text-[#4be0d4]" />
              DYNAMIC DIRECTORY · 06
            </div>
            <h2 className="text-3xl sm:text-4xl font-black tracking-tight text-[var(--text)]">
              Public APIs Directory
            </h2>
            <p className="mt-2.5 max-w-2xl text-xs sm:text-sm leading-relaxed text-[var(--muted)]">
              Explore thousands of free, community-curated APIs across dozens of industries.
              Sourced directly from{' '}
              <a
                href="https://github.com/public-apis/public-apis"
                target="_blank"
                rel="noopener noreferrer"
                className="text-[#67e8f9] hover:underline font-semibold"
              >
                public-apis/public-apis
              </a>
              . Note: The repository is a community index and does not own or operate the listed services.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            {/* Status Line (Requirement 21) */}
            <div
              id="api-status-badge"
              className="inline-flex items-center gap-2 rounded-full border border-cyan-500/20 bg-cyan-500/5 px-3.5 py-1.5 text-xs font-bold text-[#67e8f9] backdrop-blur-sm"
            >
              <span
                className={`h-2 w-2 rounded-full ${
                  isLoading ? 'bg-amber-400 animate-pulse' : 'bg-[#4be0d4]'
                }`}
              />
              <span>
                {isLoading
                  ? 'Loading APIs…'
                  : `Loaded ${apis.length.toLocaleString()}+ APIs from the Public APIs directory.`}
              </span>
            </div>

            {/* Manual Refresh Button */}
            <button
              type="button"
              onClick={fetchApis}
              disabled={isLoading}
              title="Refresh API directory from source"
              className="flex h-8 w-8 items-center justify-center rounded-xl border border-[var(--line)] bg-[var(--panel)] text-[var(--muted)] hover:text-[#67e8f9] hover:border-[#67e8f9]/40 transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`h-3.5 w-3.5 ${isLoading ? 'animate-spin' : ''}`} />
            </button>
          </div>
        </div>

        {/* Search & Category Filter Controls (Requirements 12, 13, 14, 15) */}
        <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-center">
          {/* Search Box (Requirement 12) */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 h-4 w-4 text-[var(--muted)]" />
            <input
              id="api-search-input"
              type="text"
              value={searchQuery}
              onChange={handleSearchChange}
              placeholder="Search API name, category or description…"
              className="w-full rounded-xl border border-[var(--line)] bg-[var(--panel)] py-2.5 pl-10 pr-4 text-xs sm:text-sm text-[var(--text)] placeholder-[var(--muted)] outline-none transition-all focus:border-[#67e8f9] focus:ring-1 focus:ring-[#67e8f9]/30"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => setSearchQuery('')}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-[var(--muted)] hover:text-[var(--text)] font-semibold"
              >
                Clear
              </button>
            )}
          </div>

          {/* Category Dropdown (Requirement 13) */}
          <div className="relative min-w-[210px]">
            <select
              id="api-category-select"
              value={selectedCategory}
              onChange={handleCategoryChange}
              className="w-full appearance-none rounded-xl border border-[var(--line)] bg-[var(--panel)] px-3.5 py-2.5 pr-8 text-xs sm:text-sm font-medium text-[var(--text)] outline-none transition-all focus:border-[#67e8f9] focus:ring-1 focus:ring-[#67e8f9]/30 cursor-pointer"
            >
              <option value="">All Categories</option>
              {categories.map((cat) => (
                <option key={cat} value={cat}>
                  {cat}
                </option>
              ))}
            </select>
            <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[var(--muted)]">
              <Layers className="h-3.5 w-3.5" />
            </div>
          </div>
        </div>

        {/* Loading Indicator (Requirement 22) */}
        {isLoading && (
          <div className="py-20 text-center rounded-2xl border border-[var(--line)] bg-[var(--panel)]/50 backdrop-blur-md">
            <div className="inline-flex h-10 w-10 animate-spin items-center justify-center rounded-full border-2 border-cyan-500/20 border-t-[#67e8f9] mb-4" />
            <h3 className="text-base font-bold text-[var(--text)]">Loading APIs…</h3>
            <p className="mt-1 text-xs text-[var(--muted)]">
              Fetching and parsing the latest directory from GitHub…
            </p>
          </div>
        )}

        {/* Empty Search State (Requirement 23) */}
        {!isLoading && filteredApis.length === 0 && (
          <div className="rounded-2xl border border-dashed border-[var(--line)] bg-[var(--panel)]/40 p-12 text-center backdrop-blur-md">
            <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-500/10 text-cyan-400 mb-3 border border-cyan-500/20">
              <Search className="h-5 w-5" />
            </div>
            <h3 className="text-base font-bold text-[var(--text)]">
              No APIs found. Try another search.
            </h3>
            <p className="mt-1.5 text-xs text-[var(--muted)] max-w-md mx-auto">
              We couldn't find any API matching{' '}
              <strong className="text-[var(--text)]">"{searchQuery || selectedCategory}"</strong>.
              Try adjusting your query or resetting the category filter.
            </p>
            <button
              type="button"
              onClick={handleClearFilters}
              className="mt-5 inline-flex items-center gap-1.5 rounded-xl border border-cyan-500/30 bg-cyan-500/10 px-4 py-2 text-xs font-bold text-cyan-300 transition-colors hover:bg-cyan-500/20 hover:text-white"
            >
              <span>Reset Filters</span>
              <ArrowRight className="h-3 w-3" />
            </button>
          </div>
        )}

        {/* Responsive Grid: Desktop 3 cols, Tablet 2 cols, Mobile 1 col (Requirements 17, 18, 19, 20) */}
        {!isLoading && filteredApis.length > 0 && (
          <>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 sm:gap-6">
              {filteredApis.slice(0, visibleCount).map((api, index) => {
                const hasValidLink =
                  Boolean(api.link) &&
                  api.link !== '#' &&
                  !api.link.startsWith('javascript:') &&
                  /^https?:\/\//i.test(api.link);

                const isHttps =
                  api.https === true ||
                  String(api.https).toLowerCase() === 'yes' ||
                  String(api.https).toLowerCase() === 'true';

                return (
                  <article
                    key={`${api.name}-${api.category}-${index}`}
                    className="group relative flex flex-col justify-between rounded-2xl border border-[var(--line)] bg-[var(--panel)]/80 p-5 sm:p-6 backdrop-blur-xl shadow-md transition-all duration-300 hover:-translate-y-1 hover:border-[#67e8f9]/40 hover:shadow-xl hover:shadow-cyan-500/5"
                  >
                    {/* Top row: Category Badge */}
                    <div>
                      <div className="flex items-center justify-between gap-2">
                        <span className="inline-flex items-center rounded-lg border border-cyan-500/25 bg-cyan-500/10 px-2.5 py-1 text-[11px] font-bold text-[#67e8f9] tracking-wide">
                          {api.category || 'General'}
                        </span>

                        {/* HTTPS Indicator */}
                        <span
                          className={`inline-flex items-center gap-1 text-[11px] font-semibold ${
                            isHttps ? 'text-emerald-400' : 'text-amber-400'
                          }`}
                          title={isHttps ? 'HTTPS Supported' : 'HTTPS Not Verified'}
                        >
                          {isHttps ? (
                            <CheckCircle2 className="h-3.5 w-3.5" />
                          ) : (
                            <XCircle className="h-3.5 w-3.5" />
                          )}
                          <span>HTTPS: {isHttps ? 'Yes' : 'No'}</span>
                        </span>
                      </div>

                      {/* API Name */}
                      <h3 className="mt-3.5 text-lg font-bold text-[var(--text)] tracking-tight group-hover:text-[#67e8f9] transition-colors line-clamp-1">
                        {api.name}
                      </h3>

                      {/* Short Description */}
                      <p className="mt-2 text-xs sm:text-sm leading-relaxed text-[var(--muted)] line-clamp-3">
                        {api.description || 'Public web API service with official documentation.'}
                      </p>
                    </div>

                    {/* Bottom row: Authentication + Official Docs Button */}
                    <div className="mt-5 pt-4 border-t border-[var(--line)]/60 flex items-center justify-between gap-2">
                      {/* Authentication Information */}
                      <div className="inline-flex items-center gap-1.5 text-[11px] font-medium text-[var(--muted)] bg-[var(--panel2)] border border-[var(--line)] rounded-lg px-2.5 py-1">
                        <ShieldCheck className="h-3.5 w-3.5 text-cyan-400 shrink-0" />
                        <span className="truncate max-w-[130px]">
                          Auth: {api.auth && api.auth !== 'No' ? api.auth : 'No'}
                        </span>
                      </div>

                      {/* Official Docs Button (Requirements 17 & 18) */}
                      {hasValidLink ? (
                        <a
                          href={api.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 rounded-xl border border-cyan-500/30 bg-cyan-500/10 px-3 py-1.5 text-xs font-bold text-[#67e8f9] transition-all hover:bg-cyan-500/20 hover:border-cyan-400 hover:text-white shrink-0"
                        >
                          <span>Official Docs</span>
                          <ExternalLink className="h-3 w-3" />
                        </a>
                      ) : (
                        <span className="text-[11px] text-[var(--muted)] italic">
                          No link listed
                        </span>
                      )}
                    </div>
                  </article>
                );
              })}
            </div>

            {/* Pagination / Load More */}
            {filteredApis.length > visibleCount && (
              <div className="mt-10 flex flex-col items-center justify-center gap-2">
                <button
                  type="button"
                  onClick={handleLoadMore}
                  className="inline-flex items-center gap-2 rounded-xl border border-cyan-500/30 bg-[var(--panel)] px-6 py-2.5 text-xs sm:text-sm font-bold text-[var(--text)] transition-all hover:border-[#67e8f9] hover:bg-cyan-500/10 hover:text-[#67e8f9] shadow-sm"
                >
                  <span>
                    Load more APIs ({Math.min(BATCH_INCREMENT, filteredApis.length - visibleCount)} more of {filteredApis.length.toLocaleString()})
                  </span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
                <span className="text-[11px] text-[var(--muted)] font-mono">
                  Showing {Math.min(visibleCount, filteredApis.length).toLocaleString()} of {filteredApis.length.toLocaleString()} matching APIs
                </span>
              </div>
            )}
          </>
        )}
      </div>
    </section>
  );
};

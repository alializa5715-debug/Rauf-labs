import React from 'react';
import { Youtube, Instagram, Sparkles, MapPin, Calendar, GraduationCap, Microscope, Briefcase, Clock, Quote, Target } from 'lucide-react';

interface AboutRaufSectionProps {
  onCopy?: (text: string) => void;
}

export const AboutRaufSection: React.FC<AboutRaufSectionProps> = () => {
  return (
    <section className="rauf-about" id="about">
      <div className="rauf-about-container">
        {/* SECTION HEADER */}
        <div className="rauf-about-header">
          <div className="rauf-about-badge">
            <span role="img" aria-label="developer">👨‍💻</span> About the Creator
          </div>

          <h2>
            Meet <span className="rauf-gradient">Rauf</span>
          </h2>

          <p>
            The person behind this developer learning platform —
            building, learning and sharing practical knowledge
            about modern technology.
          </p>
        </div>

        {/* MAIN CONTENT */}
        <div className="rauf-about-grid">
          {/* PROFILE */}
          <div className="rauf-profile-card">
            <div className="rauf-avatar">
              R
            </div>

            <h3>Rauf</h3>

            <div className="rauf-role">
              Software Developer • B.Tech
            </div>

            <p>
              Hello! I'm Rauf, a software developer from Kashmir, India.
              I enjoy exploring technology, software development,
              programming and developer tools.
            </p>

            <div className="rauf-info-list">
              <div className="rauf-info-item">
                <span className="inline-flex items-center gap-1.5">
                  <MapPin className="h-3.5 w-3.5 text-[#67e8f9] inline" /> Based In
                </span>
                <span>Kashmir, India</span>
              </div>

              <div className="rauf-info-item">
                <span className="inline-flex items-center gap-1.5">
                  <Calendar className="h-3.5 w-3.5 text-[#67e8f9] inline" /> Age
                </span>
                <span>20+</span>
              </div>

              <div className="rauf-info-item">
                <span className="inline-flex items-center gap-1.5">
                  <GraduationCap className="h-3.5 w-3.5 text-[#67e8f9] inline" /> Education
                </span>
                <span>12th + B.Tech</span>
              </div>

              <div className="rauf-info-item">
                <span className="inline-flex items-center gap-1.5">
                  <Microscope className="h-3.5 w-3.5 text-[#67e8f9] inline" /> Background
                </span>
                <span>Science + Medical + Computer Science</span>
              </div>

              <div className="rauf-info-item">
                <span className="inline-flex items-center gap-1.5">
                  <Briefcase className="h-3.5 w-3.5 text-[#67e8f9] inline" /> Profession
                </span>
                <span>Software Developer</span>
              </div>

              <div className="rauf-info-item">
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="h-3.5 w-3.5 text-[#67e8f9] inline" /> Experience
                </span>
                <span>~5 Years</span>
              </div>
            </div>
          </div>

          {/* DOCUMENTATION */}
          <div className="rauf-doc-card">
            <h3>
              My Journey in <span className="rauf-gradient">Technology</span>
            </h3>

            <p>
              My journey started with a strong interest in science,
              technology and computers. After completing my 12th
              education with a Science, Medical and Computer Science
              background, I continued my journey into technology and
              software development.
            </p>

            <h4>🎓 Education</h4>

            <p>
              I have completed my 12th education and B.Tech.
              My academic journey has helped me develop a strong
              foundation for understanding computer science,
              software and technology.
            </p>

            <h4>💻 Software Development</h4>

            <p>
              I have around five years of experience in software
              development. During this journey, I have explored
              programming, development environments, command-line
              tools, web technologies and modern developer workflows.
            </p>

            <h4>🛠️ Areas I Explore</h4>

            <div className="rauf-skills">
              <span className="rauf-skill">Software Development</span>
              <span className="rauf-skill">Web Development</span>
              <span className="rauf-skill">Programming</span>
              <span className="rauf-skill">Linux</span>
              <span className="rauf-skill">Termux</span>
              <span className="rauf-skill">Bash</span>
              <span className="rauf-skill">PowerShell</span>
              <span className="rauf-skill">Git</span>
              <span className="rauf-skill">GitHub</span>
              <span className="rauf-skill">APIs</span>
              <span className="rauf-skill">Open Source</span>
              <span className="rauf-skill">Automation</span>
            </div>

            <div className="rauf-quote flex items-start gap-2.5">
              <Quote className="h-5 w-5 text-[#67e8f9] shrink-0 opacity-70 mt-0.5" />
              <span>
                "Don't just learn technology. Experiment with it,
                build with it, and understand how it works."
              </span>
            </div>

            <div className="rauf-mission">
              <strong className="flex items-center gap-1.5">
                <Target className="h-4 w-4 text-[#60a5fa] inline" /> My Mission
              </strong>

              <p>
                My goal is to make technical learning simple,
                practical and beginner-friendly. Through this platform,
                I want to share useful guides, commands, tools,
                projects and resources that can help learners become
                more confident with technology.
              </p>
            </div>

            {/* SOCIAL LINKS */}
            <div className="rauf-social">
              <a
                href="https://youtube.com/@islamic_78618?si=rBK5DpAFxDuWSFos"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Visit Rauf on YouTube"
              >
                <Youtube className="h-4 w-4 text-rose-400" /> YouTube
              </a>

              <a
                href="https://www.instagram.com/not._.u._.rauf?stkn=MXVhN3JvYnF3NDh1bg=="
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Visit Rauf on Instagram"
              >
                <Instagram className="h-4 w-4 text-pink-400" /> Instagram
              </a>
            </div>
          </div>
        </div>

        {/* STATS */}
        <div className="rauf-about-bottom">
          <div className="rauf-stat-card">
            <strong>5+</strong>
            <span>Years Software Development</span>
          </div>

          <div className="rauf-stat-card">
            <strong>B.Tech</strong>
            <span>Technical Education</span>
          </div>

          <div className="rauf-stat-card">
            <strong>∞</strong>
            <span>Always Learning</span>
          </div>
        </div>
      </div>
    </section>
  );
};

import React, { useState } from 'react';
import { FAQS } from '../data/learningData';
import { ChevronDown } from 'lucide-react';

export const FaqSection: React.FC = () => {
  const [openIdx, setOpenIdx] = useState<number | null>(null);

  const toggle = (i: number) => {
    setOpenIdx(openIdx === i ? null : i);
  };

  return (
    <section className="py-16 border-t border-[var(--line)]">
      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        <div className="mb-8">
          <div className="text-xs font-black tracking-widest text-[#73c5ff] uppercase">
            Common Questions
          </div>
          <h2 className="mt-1 text-3xl font-extrabold tracking-tight text-[var(--text)] sm:text-4xl">
            Frequently Asked Questions
          </h2>
        </div>

        <div className="rounded-3xl border border-[var(--line)] bg-[var(--panel)] divide-y divide-[var(--line)] overflow-hidden shadow-lg shadow-black/5">
          {FAQS.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div key={idx} className="transition-colors">
                <button
                  type="button"
                  onClick={() => toggle(idx)}
                  className="flex w-full items-center justify-between p-5 sm:p-6 text-left font-bold text-sm sm:text-base text-[var(--text)] hover:text-[#48a9ff] transition-colors"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`h-4 w-4 shrink-0 text-[var(--muted)] transition-transform duration-200 ${
                      isOpen ? 'rotate-180 text-[#48a9ff]' : ''
                    }`}
                  />
                </button>
                {isOpen && (
                  <div className="px-5 pb-6 sm:px-6 text-xs sm:text-sm leading-relaxed text-[var(--muted)] animate-in fade-in">
                    <p>{faq.a}</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

import React, { useEffect } from 'react';
import { LessonDetail } from '../types';
import { X, Copy, Check, AlertTriangle, Terminal, CheckCircle2, ArrowRight, BookOpen } from 'lucide-react';

interface LessonModalProps {
  lesson: LessonDetail | null;
  isCompleted: boolean;
  onClose: () => void;
  onToggleComplete: () => void;
  onNextLesson?: () => void;
  onCopy: (text: string) => void;
}

export const LessonModal: React.FC<LessonModalProps> = ({
  lesson,
  isCompleted,
  onClose,
  onToggleComplete,
  onNextLesson,
  onCopy
}) => {
  const [copied, setCopied] = React.useState(false);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  if (!lesson) return null;

  const handleCopyCommand = () => {
    onCopy(lesson.command);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-[95] flex items-center justify-center bg-black/80 p-4 backdrop-blur-md animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-[var(--line)] bg-[var(--panel)] shadow-2xl transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[var(--line)] bg-[var(--panel)]/95 px-6 py-4 backdrop-blur-md">
          <div className="flex items-center gap-2.5">
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-[#48a9ff]/10 font-mono text-xs font-bold text-[#79caff]">
              {String(lesson.idx + 1).padStart(2, '0')}
            </span>
            <span className="rounded-full border border-[var(--line)] bg-[var(--panel2)] px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#8bcaff]">
              {lesson.section}
            </span>
          </div>

          <button
            onClick={onClose}
            aria-label="Close lesson modal"
            className="flex h-8 w-8 items-center justify-center rounded-xl border border-[var(--line)] bg-[var(--panel2)] text-[var(--text)] transition-colors hover:bg-[var(--line)]"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6 sm:p-8">
          <h2 className="text-xl sm:text-2xl font-black tracking-tight text-[var(--text)]">
            {lesson.title}
          </h2>

          <p className="mt-3 text-xs sm:text-sm leading-relaxed text-[var(--muted)]">
            {lesson.summary}
          </p>

          {/* Explanation */}
          <div className="mt-5 text-xs sm:text-sm leading-relaxed text-[var(--text)]/90">
            <h4 className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-[#79caff] mb-1.5">
              <BookOpen className="h-3.5 w-3.5" />
              Lesson Explanation
            </h4>
            <p>{lesson.explanation}</p>
          </div>

          {/* Code Command Box */}
          <div className="mt-6 rounded-2xl border border-[var(--line)] bg-[#050b14] p-4">
            <div className="flex items-center justify-between text-xs font-mono text-[#8bcaff] mb-2">
              <span className="flex items-center gap-1.5">
                <Terminal className="h-3.5 w-3.5" />
                Terminal Command
              </span>
              <button
                type="button"
                onClick={handleCopyCommand}
                className="flex items-center gap-1.5 rounded-lg border border-white/10 bg-white/5 px-2 py-1 text-xs font-medium text-white transition-colors hover:bg-white/15"
              >
                {copied ? (
                  <>
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                    <span className="text-emerald-400">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="h-3.5 w-3.5" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
            <pre className="overflow-x-auto whitespace-pre font-mono text-xs leading-relaxed text-[#c3d4e9]">
              <code>{lesson.command}</code>
            </pre>
          </div>

          {/* Expected Output */}
          <div className="mt-4 rounded-2xl border border-[var(--line)]/60 bg-[#080f1c] p-3.5">
            <div className="text-[11px] font-mono text-[#7890aa] mb-1">
              Expected Output:
            </div>
            <pre className="overflow-x-auto whitespace-pre font-mono text-[11px] text-emerald-400/90 leading-relaxed">
              {lesson.expectedOutput}
            </pre>
          </div>

          {/* Practical Exercise */}
          <div className="mt-6 rounded-2xl border border-[var(--line)] bg-[var(--panel2)] p-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-cyan-300 mb-1">
              🎯 Practical Exercise
            </h4>
            <p className="text-xs sm:text-sm text-[var(--muted)] leading-relaxed">
              {lesson.exercise}
            </p>
          </div>

          {/* Safety Warning Note */}
          <div className="mt-4 rounded-2xl border border-amber-500/20 bg-amber-500/10 p-4">
            <div className="flex items-center gap-2 text-xs font-bold text-amber-300 mb-1">
              <AlertTriangle className="h-4 w-4 shrink-0" />
              <span>Safety Note</span>
            </div>
            <p className="text-xs text-amber-200/80 leading-relaxed">
              {lesson.safetyTip} Never paste commands you do not understand, especially commands that delete files, change permissions, expose credentials or modify system configuration.
            </p>
          </div>

          {/* Bottom Actions */}
          <div className="mt-8 flex flex-wrap items-center justify-between gap-3 border-t border-[var(--line)] pt-5">
            <button
              type="button"
              onClick={onToggleComplete}
              className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold transition-all ${
                isCompleted
                  ? 'border border-emerald-500/30 bg-emerald-500/15 text-emerald-300'
                  : 'border border-[var(--line)] bg-[var(--panel2)] text-[var(--text)] hover:border-emerald-500/50'
              }`}
            >
              <CheckCircle2 className={`h-4 w-4 ${isCompleted ? 'text-emerald-400' : 'text-gray-400'}`} />
              <span>{isCompleted ? 'Completed ✓' : 'Mark as Completed'}</span>
            </button>

            <div className="flex items-center gap-2">
              {onNextLesson && (
                <button
                  type="button"
                  onClick={onNextLesson}
                  className="flex items-center gap-1.5 rounded-xl bg-gradient-to-r from-[#48a9ff] to-[#647dff] px-4 py-2.5 text-xs font-bold text-[#04101d] shadow-md transition-all hover:scale-[1.02] active:scale-95"
                >
                  <span>Next lesson</span>
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { Terminal, Heart } from 'lucide-react';

interface FooterProps {
  brandName?: string;
}

export const Footer: React.FC<FooterProps> = ({ brandName = 'TermForge' }) => {
  return (
    <footer className="border-t border-[var(--line)] bg-[var(--bg)]/90 pt-14 pb-8 transition-colors">
      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        <div className="grid grid-cols-1 gap-10 sm:grid-cols-2 md:grid-cols-4 lg:grid-cols-[1.6fr_1fr_1fr_1fr]">
          {/* Brand Col */}
          <div>
            <a href="#home" className="inline-flex items-center gap-2.5 text-lg font-black tracking-tight text-[var(--text)]">
              <span className="flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-[#48a9ff] to-[#4be0d4] text-[#03101b] shadow-md shadow-[#48a9ff]/20">
                <Terminal className="h-4 w-4 stroke-[2.5]" />
              </span>
              <span>{brandName}</span>
            </a>
            <p className="mt-3 max-w-xs text-xs sm:text-sm leading-relaxed text-[var(--muted)]">
              A practical developer learning hub for terminals, Linux, PowerShell, Bash, Git, APIs, and open-source software.
            </p>
          </div>

          {/* Learn Column */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-[var(--text)] mb-3">
              Learn
            </h4>
            <ul className="space-y-2 text-xs text-[var(--muted)]">
              <li>
                <a href="#termux" className="hover:text-[var(--text)] transition-colors">Termux</a>
              </li>
              <li>
                <a href="#linux" className="hover:text-[var(--text)] transition-colors">Linux</a>
              </li>
              <li>
                <a href="#powershell" className="hover:text-[var(--text)] transition-colors">PowerShell</a>
              </li>
              <li>
                <a href="#bash" className="hover:text-[var(--text)] transition-colors">Bash Scripting</a>
              </li>
            </ul>
          </div>

          {/* Develop Column */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-[var(--text)] mb-3">
              Develop
            </h4>
            <ul className="space-y-2 text-xs text-[var(--muted)]">
              <li>
                <a href="#git" className="hover:text-[var(--text)] transition-colors">Git & GitHub</a>
              </li>
              <li>
                <a href="#programming" className="hover:text-[var(--text)] transition-colors">Programming</a>
              </li>
              <li>
                <a href="#apis" className="hover:text-[var(--text)] transition-colors">Public APIs</a>
              </li>
              <li>
                <a href="#opensource" className="hover:text-[var(--text)] transition-colors">Open Source</a>
              </li>
            </ul>
          </div>

          {/* Connect Column */}
          <div>
            <h4 className="text-xs font-black uppercase tracking-wider text-[var(--text)] mb-3">
              Connect
            </h4>
            <ul className="space-y-2 text-xs text-[var(--muted)]">
              <li>
                <a href="#about" className="hover:text-[var(--text)] transition-colors">About Creator</a>
              </li>
              <li>
                <a href="#blog" className="hover:text-[var(--text)] transition-colors">Developer Blog</a>
              </li>
              <li>
                <a
                  href="https://youtube.com/@islamic_78618?si=rBK5DpAFxDuWSFos"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-rose-400 transition-colors"
                >
                  YouTube
                </a>
              </li>
              <li>
                <a
                  href="https://www.instagram.com/not._.u._.rauf?stkn=MXVhN3JvYnF3NDh1bg=="
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hover:text-pink-400 transition-colors"
                >
                  Instagram
                </a>
              </li>
              <li>
                <a href="#search" className="hover:text-[var(--text)] transition-colors">Global Search</a>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 flex flex-col items-center justify-between gap-3 border-t border-[var(--line)] pt-6 text-xs text-[var(--muted)] sm:flex-row">
          <div className="flex items-center gap-1.5">
            <span>Made with</span>
            <Heart className="h-3.5 w-3.5 fill-rose-500 text-rose-500 inline" />
            <span>by <a href="#about" className="text-[var(--text)] hover:underline font-semibold">Rauf</a></span>
          </div>
          <div>© 2026 TermForge. All Rights Reserved.</div>
        </div>
      </div>
    </footer>
  );
};

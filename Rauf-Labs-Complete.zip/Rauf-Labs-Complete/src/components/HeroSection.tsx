import React, { useState, useEffect, useRef } from 'react';
import { Terminal as TerminalIcon, Sparkles, ArrowRight, BookOpen, CheckCircle2, Play, CornerDownLeft } from 'lucide-react';

const AUTO_COMMANDS = [
  { cmd: 'pkg update && pkg upgrade -y', out: 'Checking repositories... 42 packages upgraded ✓' },
  { cmd: 'pkg install -y git python nodejs-lts', out: 'Installed git (2.44), python (3.12), nodejs (v20.11) ✓' },
  { cmd: 'git clone https://github.com/public-apis/public-apis.git', out: 'Cloning into \'public-apis\'... done (1,400+ APIs ready).' },
  { cmd: 'python -m venv .venv && source .venv/bin/activate', out: 'Virtual environment activated (.venv)' },
  { cmd: 'curl -s https://api.github.com/zen', out: '"Approachable, idiomatic code wins every time."' },
  { cmd: 'termforge --status', out: 'All developer paths loaded: Termux, Linux, PowerShell, Git & APIs ✓' }
];

export const HeroSection: React.FC = () => {
  // Automated typing state
  const [lineIdx, setLineIdx] = useState(0);
  const [charIdx, setCharIdx] = useState(0);
  const [completedLines, setCompletedLines] = useState<Array<{ cmd: string; out: string }>>([]);
  const [interactiveMode, setInteractiveMode] = useState(false);
  const [inputVal, setInputVal] = useState('');
  const [interactiveHistory, setInteractiveHistory] = useState<Array<{ text: string; isOutput?: boolean }>>([
    { text: 'Interactive Terminal Shell initialized. Type "help" or run a command.' }
  ]);
  const interactiveInputRef = useRef<HTMLInputElement>(null);

  // Typewriter effect
  useEffect(() => {
    if (interactiveMode) return;

    const currentItem = AUTO_COMMANDS[lineIdx];
    const targetText = currentItem.cmd;

    if (charIdx < targetText.length) {
      const timer = setTimeout(() => {
        setCharIdx((prev) => prev + 1);
      }, 45);
      return () => clearTimeout(timer);
    } else {
      const waitTimer = setTimeout(() => {
        setCompletedLines((prev) => {
          const next = [...prev, currentItem];
          return next.slice(-4);
        });
        setCharIdx(0);
        setLineIdx((prev) => (prev + 1) % AUTO_COMMANDS.length);
      }, 1600);
      return () => clearTimeout(waitTimer);
    }
  }, [lineIdx, charIdx, interactiveMode]);

  const handleInteractiveSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const cleanCmd = inputVal.trim();
    if (!cleanCmd) return;

    let response = '';
    const lower = cleanCmd.toLowerCase();

    if (lower === 'help') {
      response = 'Available commands: help, pwd, ls, whoami, fastfetch, git status, pkg update, curl, clear, exit';
    } else if (lower === 'pwd') {
      response = '/data/data/com.termux/files/home/termforge';
    } else if (lower === 'ls' || lower === 'ls -la') {
      response = 'drwx------ 2 student student 4096 Sep 09 08:20 .\ndrwx------ 4 student student 4096 Sep 09 08:15 ..\n-rw-r--r-- 1 student student  342 Sep 09 08:20 README.md\n-rwxr-xr-x 1 student student  812 Sep 09 08:18 build.sh\ndrwxr-xr-x 8 student student 4096 Sep 09 08:19 projects';
    } else if (lower === 'whoami') {
      response = 'student (uid=10245 gid=10245 groups=inet,storage)';
    } else if (lower === 'fastfetch' || lower === 'neofetch') {
      response = '  OS: Termux / Android Linux 5.15 (arm64)\n  Host: Developer Virtual Environment\n  Uptime: 4 days, 12 hours\n  Packages: 172 (dpkg)\n  Shell: bash 5.2.26\n  Terminal: TermForge Web Terminal';
    } else if (lower.startsWith('git')) {
      response = 'On branch main\nYour branch is up to date with \'origin/main\'.\nnothing to commit, working tree clean';
    } else if (lower.startsWith('pkg') || lower.startsWith('apt')) {
      response = 'Reading package lists... Done\nBuilding dependency tree... Done\nPackage operation succeeded ✓';
    } else if (lower.startsWith('curl')) {
      response = 'HTTP/2 200 OK\ncontent-type: application/json\n{"status":"online","service":"termforge-api"}';
    } else if (lower === 'clear') {
      setInteractiveHistory([]);
      setInputVal('');
      return;
    } else if (lower === 'exit') {
      setInteractiveMode(false);
      setInputVal('');
      return;
    } else {
      response = `bash: ${cleanCmd}: command recognized (simulated sandbox execution ✓)`;
    }

    setInteractiveHistory((prev) => [
      ...prev,
      { text: `$ ${cleanCmd}` },
      { text: response, isOutput: true }
    ]);
    setInputVal('');
  };

  return (
    <section id="home" className="relative overflow-hidden pt-12 pb-16 md:pt-20 md:pb-24">
      {/* Background ambient lighting */}
      <div className="pointer-events-none absolute top-0 left-1/2 -z-10 h-[500px] w-full -translate-x-1/2 opacity-35 blur-[100px] [background:radial-gradient(ellipse_at_top,rgba(72,169,255,0.35),transparent_70%)]" />

      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-[1.05fr_0.95fr]">
          {/* Left Column: Headline & Action */}
          <div className="flex flex-col items-start">
            {/* Eyebrow badge */}
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-[var(--line)] bg-[#48a9ff]/10 px-3.5 py-1 text-xs font-bold text-[#8bcaff] backdrop-blur-sm">
              <span className="relative flex h-2 w-2">
                <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-[#4be0d4] opacity-75" />
                <span className="relative inline-flex h-2 w-2 rounded-full bg-[#4be0d4]" />
              </span>
              <span>Beginner → Advanced Developer Learning</span>
            </div>

            {/* Main title */}
            <h1 className="text-4xl font-extrabold tracking-tight text-[var(--text)] sm:text-6xl md:text-7xl lg:leading-[1.05]">
              Learn.{' '}
              <span className="bg-gradient-to-r from-white via-[#79c8ff] to-[#66e6d9] bg-clip-text text-transparent">
                Build.
              </span>{' '}
              Master.
            </h1>

            {/* Subtext */}
            <p className="mt-5 max-w-xl text-base leading-relaxed text-[var(--muted)] sm:text-lg">
              Your complete beginner-friendly guide to Termux, Linux, PowerShell, Bash, Git, Public APIs, and open-source tools.
              Read guided lessons, copy tested commands, and track your progress locally.
            </p>

            {/* Action buttons */}
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <a
                id="hero-start-learning-btn"
                href="#termux"
                className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-r from-[#48a9ff] to-[#647dff] px-5 py-3 text-sm font-bold text-[#04101d] shadow-lg shadow-[#48a9ff]/25 transition-all duration-200 hover:-translate-y-0.5 hover:shadow-xl hover:shadow-[#48a9ff]/40 active:translate-y-0"
              >
                <span>Start Learning</span>
                <ArrowRight className="h-4 w-4" />
              </a>

              <a
                id="hero-explore-apis-btn"
                href="#apis"
                className="inline-flex items-center gap-2 rounded-xl border border-[var(--line)] bg-[var(--panel)] px-5 py-3 text-sm font-bold text-[var(--text)] transition-all duration-200 hover:-translate-y-0.5 hover:border-[#48a9ff]/40 hover:bg-[var(--panel2)] active:translate-y-0"
              >
                <Sparkles className="h-4 w-4 text-[#4be0d4]" />
                <span>Explore Public APIs</span>
              </a>
            </div>

            {/* Tags / value props */}
            <div className="mt-7 flex flex-wrap gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--panel)]/70 px-3 py-1 text-xs font-medium text-[var(--muted)]">
                <CheckCircle2 className="h-3.5 w-3.5 text-emerald-400" />
                Hands-on lessons
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--panel)]/70 px-3 py-1 text-xs font-medium text-[var(--muted)]">
                <TerminalIcon className="h-3.5 w-3.5 text-[#48a9ff]" />
                Copy-ready commands
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-[var(--line)] bg-[var(--panel)]/70 px-3 py-1 text-xs font-medium text-[var(--muted)]">
                <BookOpen className="h-3.5 w-3.5 text-purple-400" />
                Local progress storage
              </span>
            </div>
          </div>

          {/* Right Column: High-fidelity Terminal */}
          <div className="relative">
            <div className="overflow-hidden rounded-2xl border border-[#48a9ff]/25 bg-[#050a12] shadow-2xl shadow-black/80">
              {/* Terminal Title Bar */}
              <div className="flex h-10 items-center justify-between border-b border-white/10 bg-[#0a111d] px-4">
                <div className="flex items-center gap-1.5">
                  <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f56]" />
                  <span className="h-2.5 w-2.5 rounded-full bg-[#ffbd2e]" />
                  <span className="h-2.5 w-2.5 rounded-full bg-[#27c93f]" />
                </div>
                <div className="font-mono text-xs font-medium text-[#73869f]">
                  student@termforge:~
                </div>
                <button
                  type="button"
                  onClick={() => {
                    setInteractiveMode(!interactiveMode);
                    setTimeout(() => interactiveInputRef.current?.focus(), 50);
                  }}
                  className="inline-flex items-center gap-1 rounded border border-white/10 bg-white/5 px-2 py-0.5 text-[10px] font-mono text-[#8bcaff] transition-colors hover:bg-white/10"
                  title="Toggle interactive typing mode"
                >
                  <Play className="h-2.5 w-2.5" />
                  <span>{interactiveMode ? 'Auto Demo' : 'Live Shell'}</span>
                </button>
              </div>

              {/* Terminal Body */}
              <div className="min-h-[320px] p-4 sm:p-5 font-mono text-xs sm:text-[13px] leading-relaxed text-[#c3d4e9]">
                {!interactiveMode ? (
                  <div className="space-y-3">
                    {/* Historic completed lines */}
                    {completedLines.map((item, idx) => (
                      <div key={idx} className="space-y-1">
                        <div className="flex items-center gap-2">
                          <span className="text-[#63e7db] select-none">$</span>
                          <span className="text-white font-medium">{item.cmd}</span>
                        </div>
                        <div className="text-[#7890aa] pl-4 border-l border-white/5">{item.out}</div>
                      </div>
                    ))}

                    {/* Active typing line */}
                    <div className="flex items-center gap-2">
                      <span className="text-[#63e7db] select-none">$</span>
                      <span className="text-white font-medium">
                        {AUTO_COMMANDS[lineIdx]?.cmd.slice(0, charIdx)}
                      </span>
                      <span className="inline-block h-4 w-2 bg-[#4be0d4] animate-pulse" />
                    </div>

                    <div className="pt-4 text-[11px] text-[#556982] flex items-center justify-between border-t border-white/5">
                      <span>💡 Click "Live Shell" above to execute interactive sandbox commands.</span>
                    </div>
                  </div>
                ) : (
                  <div className="flex flex-col justify-between h-[300px]">
                    <div className="overflow-y-auto space-y-2 pr-1 max-h-[250px]">
                      {interactiveHistory.map((h, i) => (
                        <div
                          key={i}
                          className={h.isOutput ? 'text-[#7890aa] pl-3 border-l border-cyan-500/30' : 'text-[#63e7db]'}
                        >
                          {h.text}
                        </div>
                      ))}
                    </div>

                    {/* Interactive Input Form */}
                    <form onSubmit={handleInteractiveSubmit} className="flex items-center gap-2 pt-2 border-t border-white/10">
                      <span className="text-[#63e7db] select-none">$</span>
                      <input
                        ref={interactiveInputRef}
                        type="text"
                        value={inputVal}
                        onChange={(e) => setInputVal(e.target.value)}
                        placeholder="Type 'help', 'fastfetch', 'pwd', 'ls'..."
                        className="w-full bg-transparent text-white outline-none placeholder:text-gray-600 font-mono text-xs sm:text-[13px]"
                        autoFocus
                      />
                      <button
                        type="submit"
                        className="rounded bg-cyan-500/20 p-1 text-cyan-300 hover:bg-cyan-500/30 transition-colors"
                      >
                        <CornerDownLeft className="h-3.5 w-3.5" />
                      </button>
                    </form>
                  </div>
                )}
              </div>
            </div>

            {/* Subtle glow beneath terminal */}
            <div className="absolute -bottom-4 -left-4 -right-4 -z-10 h-20 rounded-3xl bg-cyan-500/10 blur-xl" />
          </div>
        </div>
      </div>
    </section>
  );
};

import React from 'react';
import { BlogPost } from '../types';
import { X, Clock, Bookmark, Terminal, CheckCircle2, Copy } from 'lucide-react';

interface BlogModalProps {
  post: BlogPost | null;
  onClose: () => void;
  onCopy: (text: string) => void;
}

export const BlogModal: React.FC<BlogModalProps> = ({ post, onClose, onCopy }) => {
  if (!post) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      className="fixed inset-0 z-[90] flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm animate-in fade-in"
      onClick={onClose}
    >
      <div
        className="relative max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-3xl border border-[var(--line)] bg-[var(--panel)] shadow-2xl transition-all"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="sticky top-0 z-10 flex items-center justify-between border-b border-[var(--line)] bg-[var(--panel)]/95 px-6 py-4 backdrop-blur-md">
          <div className="flex items-center gap-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-lg bg-[#48a9ff]/10 text-base">
              {post.icon}
            </span>
            <span className="rounded-full border border-[var(--line)] bg-[var(--panel2)] px-2.5 py-0.5 text-[10px] font-bold text-[#71c4ff]">
              {post.category}
            </span>
          </div>

          <button
            onClick={onClose}
            aria-label="Close article modal"
            className="flex h-8 w-8 items-center justify-center rounded-xl border border-[var(--line)] bg-[var(--panel2)] text-[var(--text)] hover:bg-[var(--line)] transition-colors"
          >
            <X className="h-4 w-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 sm:p-8">
          <div className="flex items-center gap-2 text-xs text-[var(--muted)] mb-3">
            <Clock className="h-3.5 w-3.5" />
            <span>{post.readTime}</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-black tracking-tight text-[var(--text)]">
            {post.title}
          </h2>

          <p className="mt-3 text-sm leading-relaxed text-[var(--muted)] font-medium border-l-2 border-[#48a9ff] pl-3 py-1">
            {post.summary}
          </p>

          <div className="mt-6 space-y-4 text-sm leading-relaxed text-[var(--text)]">
            {post.content.map((para, i) => (
              <p key={i} className="text-[var(--text)]/90">
                {para}
              </p>
            ))}
          </div>

          {/* Key Takeaways */}
          <div className="mt-8 rounded-2xl border border-[var(--line)] bg-[var(--panel2)] p-5">
            <h4 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#79caff] mb-3">
              <Bookmark className="h-4 w-4" />
              Key Takeaways
            </h4>
            <ul className="space-y-2 text-xs text-[var(--muted)]">
              {post.keyTakeaways.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <CheckCircle2 className="h-4 w-4 text-cyan-400 shrink-0 mt-0.5" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Recommended Command */}
          {post.recommendedCommand && (
            <div className="mt-6 rounded-2xl border border-[var(--line)] bg-[#050b14] p-4">
              <div className="flex items-center justify-between text-xs font-mono text-[#8bcaff] mb-2">
                <span className="flex items-center gap-1.5">
                  <Terminal className="h-3.5 w-3.5" />
                  Recommended Shell Command
                </span>
                <button
                  onClick={() => onCopy(post.recommendedCommand!)}
                  className="flex items-center gap-1 hover:text-white transition-colors"
                >
                  <Copy className="h-3.5 w-3.5" />
                  <span>Copy</span>
                </button>
              </div>
              <code className="block overflow-x-auto whitespace-pre font-mono text-xs text-[#cbd9e9]">
                {post.recommendedCommand}
              </code>
            </div>
          )}

          <div className="mt-8 pt-4 border-t border-[var(--line)] flex justify-end">
            <button
              onClick={onClose}
              className="rounded-xl border border-[var(--line)] bg-[var(--panel2)] px-5 py-2 text-xs font-bold text-[var(--text)] hover:bg-[var(--panel)] transition-colors"
            >
              Close Article
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { OPEN_SOURCE_TOOLS } from '../data/learningData';
import { ExternalLink, Terminal, Copy } from 'lucide-react';

interface ToolsSectionProps {
  onCopy: (text: string) => void;
}

export const ToolsSection: React.FC<ToolsSectionProps> = ({ onCopy }) => {
  return (
    <section id="opensource" className="py-16 border-t border-[var(--line)]">
      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        <div className="mb-10 flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <div className="text-xs font-black tracking-widest text-[#73c5ff] uppercase">
              Build with others
            </div>
            <h2 className="mt-1 text-3xl font-extrabold tracking-tight text-[var(--text)] sm:text-4xl">
              Open Source Tools
            </h2>
            <p className="mt-2 max-w-2xl text-sm sm:text-base text-[var(--muted)]">
              Crucial developer software to install, inspect, configure and contribute to in everyday workflows.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {OPEN_SOURCE_TOOLS.map((tool) => (
            <article
              key={tool.name}
              className="flex flex-col justify-between rounded-2xl border border-[var(--line)] bg-gradient-to-b from-[var(--panel)] to-[var(--panel2)] p-5 shadow-sm transition-all duration-200 hover:-translate-y-1 hover:border-[#48a9ff]/40"
            >
              <div>
                <div className="flex items-center justify-between">
                  <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-[#48a9ff]/10 text-[#79caff]">
                    <Terminal className="h-5 w-5" />
                  </div>
                  <span className="rounded-full border border-[var(--line)] bg-[var(--panel2)] px-2.5 py-0.5 text-[10px] font-bold text-[#8bcaff]">
                    {tool.category}
                  </span>
                </div>

                <h3 className="mt-4 text-lg font-bold text-[var(--text)]">{tool.name}</h3>
                <p className="mt-1.5 text-xs sm:text-sm leading-relaxed text-[var(--muted)]">
                  {tool.description}
                </p>

                {/* Quick install snippet */}
                <div className="mt-4 rounded-xl border border-[var(--line)] bg-[#050b14] p-2.5 text-xs font-mono text-[#cbd9e9]">
                  <div className="flex items-center justify-between text-[10px] text-[#7890aa] mb-1">
                    <span>Install</span>
                    <button
                      onClick={() => onCopy(tool.installCommand)}
                      className="hover:text-cyan-300 transition-colors"
                      title="Copy install command"
                    >
                      <Copy className="h-3 w-3" />
                    </button>
                  </div>
                  <pre className="overflow-x-auto whitespace-pre text-[11px] text-cyan-200/90">
                    {tool.installCommand}
                  </pre>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-[var(--line)]/50 flex items-center justify-end">
                <a
                  href={tool.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#48a9ff] hover:underline"
                >
                  <span>Official site</span>
                  <ExternalLink className="h-3 w-3" />
                </a>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

import React from 'react';

interface ToastProps {
  message: string | null;
}

export const Toast: React.FC<ToastProps> = ({ message }) => {
  if (!message) return null;

  return (
    <div
      id="toast"
      role="status"
      aria-live="polite"
      className="fixed bottom-6 right-6 z-[100] flex items-center gap-2 rounded-xl border border-cyan-500/30 bg-[#0b1627] px-4 py-3 text-sm font-medium text-white shadow-2xl shadow-cyan-950/50 backdrop-blur-md transition-all duration-300 animate-in fade-in slide-in-from-bottom-3"
    >
      <span className="flex h-2 w-2 rounded-full bg-cyan-400 shadow-[0_0_8px_#4be0d4]" />
      <span>{message}</span>
    </div>
  );
};

import React, { useState } from 'react';
import { Sun, Moon, Menu, X, Terminal, Search } from 'lucide-react';

interface NavbarProps {
  theme: 'dark' | 'light';
  onToggleTheme: () => void;
  brandName?: string;
}

export const Navbar: React.FC<NavbarProps> = ({
  theme,
  onToggleTheme,
  brandName = 'TermForge'
}) => {
  const [mobileOpen, setMobileOpen] = useState(false);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'About', href: '#about' },
    { label: 'Termux', href: '#termux' },
    { label: 'Linux', href: '#linux' },
    { label: 'PowerShell', href: '#powershell' },
    { label: 'Bash', href: '#bash' },
    { label: 'Git & GitHub', href: '#git' },
    { label: 'Public APIs', href: '#apis' },
    { label: 'Open Source', href: '#opensource' },
    { label: 'Programming', href: '#programming' },
    { label: 'Blog', href: '#blog' },
    { label: 'Search', href: '#search' }
  ];

  const handleLinkClick = () => {
    setMobileOpen(false);
  };

  return (
    <header className="sticky top-0 z-50 border-b border-[var(--line)] bg-[var(--bg)]/85 backdrop-blur-md transition-colors duration-200">
      <div className="mx-auto flex min-h-[70px] w-full max-w-[1180px] items-center justify-between px-4 sm:px-6">
        {/* Brand */}
        <a
          id="brand-logo-link"
          href="#home"
          className="flex items-center gap-2.5 text-lg font-extrabold tracking-tight transition-transform hover:scale-[1.02]"
        >
          <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#48a9ff] to-[#4be0d4] text-[#03101b] shadow-lg shadow-[#48a9ff]/25">
            <Terminal className="h-5 w-5 stroke-[2.5]" />
          </span>
          <span className="bg-gradient-to-r from-[var(--text)] via-[var(--text)] to-[var(--muted)] bg-clip-text font-black tracking-tight text-transparent">
            {brandName}
          </span>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden items-center gap-1 xl:flex">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="rounded-lg px-2.5 py-1.5 text-xs font-semibold text-[var(--muted)] transition-colors duration-150 hover:bg-[var(--panel)] hover:text-[var(--text)]"
            >
              {link.label}
            </a>
          ))}
        </nav>

        {/* Medium Screen Nav (truncated) */}
        <nav className="hidden items-center gap-1 md:flex xl:hidden">
          {navLinks.slice(0, 6).map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="rounded-lg px-2 py-1.5 text-xs font-semibold text-[var(--muted)] transition-colors hover:bg-[var(--panel)] hover:text-[var(--text)]"
            >
              {link.label}
            </a>
          ))}
          <a
            href="#apis"
            className="rounded-lg px-2 py-1.5 text-xs font-semibold text-[var(--muted)] transition-colors hover:bg-[var(--panel)] hover:text-[var(--text)]"
          >
            APIs
          </a>
          <a
            href="#search"
            aria-label="Quick Search"
            className="rounded-lg p-1.5 text-[var(--muted)] transition-colors hover:bg-[var(--panel)] hover:text-[var(--text)]"
          >
            <Search className="h-4 w-4" />
          </a>
        </nav>

        {/* Action Tools */}
        <div className="flex items-center gap-2">
          <button
            id="theme-toggle-btn"
            onClick={onToggleTheme}
            aria-label="Toggle dark/light theme"
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-[var(--line)] bg-[var(--panel)] text-[var(--text)] shadow-sm transition-all hover:scale-105 hover:border-[#48a9ff]/50"
          >
            {theme === 'dark' ? (
              <Sun className="h-4 w-4 text-amber-300 transition-transform" />
            ) : (
              <Moon className="h-4 w-4 text-indigo-500 transition-transform" />
            )}
          </button>

          {/* Mobile hamburger button */}
          <button
            id="mobile-menu-btn"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-[var(--line)] bg-[var(--panel)] text-[var(--text)] transition-all md:hidden"
          >
            {mobileOpen ? <X className="h-4 w-4" /> : <Menu className="h-4 w-4" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="border-t border-[var(--line)] bg-[var(--panel)]/95 px-4 py-4 backdrop-blur-xl md:hidden">
          <div className="grid grid-cols-2 gap-2">
            {navLinks.map((link) => (
              <a
                key={link.href}
                href={link.href}
                onClick={handleLinkClick}
                className="flex items-center rounded-lg border border-[var(--line)]/50 bg-[var(--panel2)] px-3 py-2 text-xs font-semibold text-[var(--text)] transition-all active:scale-95"
              >
                {link.label}
              </a>
            ))}
          </div>
        </div>
      )}
    </header>
  );
};

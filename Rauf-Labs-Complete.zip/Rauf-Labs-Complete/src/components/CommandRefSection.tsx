import React, { useState } from 'react';
import { COMMAND_REFERENCES } from '../data/learningData';
import { Copy, Check, Terminal } from 'lucide-react';

interface CommandRefSectionProps {
  onCopy: (text: string) => void;
}

export const CommandRefSection: React.FC<CommandRefSectionProps> = ({ onCopy }) => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const categories = ['All', 'Termux / Linux', 'Bash', 'PowerShell', 'Git'];

  const filteredCommands = COMMAND_REFERENCES.filter((item) => {
    if (selectedCategory === 'All') return true;
    return item.category.includes(selectedCategory);
  });

  const handleCopy = (id: string, text: string) => {
    onCopy(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 1800);
  };

  return (
    <section id="commands" className="py-16 border-t border-[var(--line)]">
      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        <div className="mb-8 flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <div className="text-xs font-black tracking-widest text-[#73c5ff] uppercase">
              Quick Reference
            </div>
            <h2 className="mt-1 text-3xl font-extrabold tracking-tight text-[var(--text)] sm:text-4xl">
              Command Reference
            </h2>
            <p className="mt-2 max-w-2xl text-sm sm:text-base text-[var(--muted)]">
              Daily driver terminal commands for Termux, Linux, Bash, PowerShell, and Git with syntax flags and 1-click clipboard copy.
            </p>
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="mb-6 flex flex-wrap gap-2">
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition-all ${
                selectedCategory === cat
                  ? 'bg-[#48a9ff] text-[#03101b] shadow-md shadow-blue-500/20'
                  : 'border border-[var(--line)] bg-[var(--panel)] text-[var(--muted)] hover:text-[var(--text)] hover:bg-[var(--panel2)]'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>

        {/* Commands Grid */}
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filteredCommands.map((cmd) => (
            <article
              key={cmd.id}
              className="flex flex-col justify-between rounded-2xl border border-[var(--line)] bg-gradient-to-b from-[var(--panel)] to-[var(--panel2)] p-5 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-[#48a9ff]/40"
            >
              <div>
                <span className="rounded-full border border-[var(--line)] bg-[var(--panel2)] px-2.5 py-0.5 text-[10px] font-bold text-[#8bcaff]">
                  {cmd.category}
                </span>

                <h3 className="mt-3 font-mono text-base font-bold text-[#4be0d4]">
                  {cmd.command}
                </h3>

                <p className="mt-1.5 text-xs text-[var(--muted)] leading-relaxed">
                  {cmd.description}
                </p>

                {cmd.flagNotes && (
                  <p className="mt-2 text-[11px] font-mono text-[#7890aa]">
                    💡 {cmd.flagNotes}
                  </p>
                )}
              </div>

              {/* Codebox with copy button */}
              <div className="relative mt-4 overflow-hidden rounded-xl border border-[var(--line)] bg-[#050b14] p-3 pr-12 font-mono text-xs text-[#cbd9e9]">
                <code className="block overflow-x-auto whitespace-pre">{cmd.example}</code>
                <button
                  type="button"
                  onClick={() => handleCopy(cmd.id, cmd.example)}
                  className="absolute right-2 top-2 flex h-7 w-7 items-center justify-center rounded-lg border border-[var(--line)] bg-[var(--panel)] text-[var(--muted)] transition-colors hover:border-[#48a9ff] hover:text-[var(--text)]"
                  title="Copy command"
                >
                  {copiedId === cmd.id ? (
                    <Check className="h-3.5 w-3.5 text-emerald-400" />
                  ) : (
                    <Copy className="h-3.5 w-3.5" />
                  )}
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

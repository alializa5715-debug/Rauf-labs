import React, { useState, useMemo } from 'react';
import { Search, ArrowUpRight, Terminal, BookOpen, Wrench, Code2 } from 'lucide-react';
import { RAW_LESSON_TITLES, COMMAND_REFERENCES, OPEN_SOURCE_TOOLS, BLOG_POSTS, PROGRAMMING_PATHS } from '../data/learningData';

interface GlobalSearchProps {
  onOpenLesson: (title: string, section: string, idx: number) => void;
  onCopyCommand: (cmd: string) => void;
}

export const GlobalSearch: React.FC<GlobalSearchProps> = ({ onOpenLesson, onCopyCommand }) => {
  const [query, setQuery] = useState('');

  // Flatten all searchable items
  const allItems = useMemo(() => {
    const list: Array<{
      id: string;
      type: string;
      title: string;
      desc: string;
      section?: string;
      idx?: number;
      cmd?: string;
      iconType?: 'lesson' | 'command' | 'tool' | 'blog' | 'prog';
    }> = [];

    // Lessons
    Object.entries(RAW_LESSON_TITLES).forEach(([section, titles]) => {
      titles.forEach((title, idx) => {
        list.push({
          id: `lesson-${section}-${idx}`,
          type: section.toUpperCase(),
          title,
          desc: `Interactive ${section} lesson with commands and exercises.`,
          section,
          idx,
          iconType: 'lesson'
        });
      });
    });

    // Commands
    COMMAND_REFERENCES.forEach((c) => {
      list.push({
        id: `cmd-${c.id}`,
        type: 'Command',
        title: c.command,
        desc: c.description,
        cmd: c.example,
        iconType: 'command'
      });
    });

    // Open Source Tools
    OPEN_SOURCE_TOOLS.forEach((t) => {
      list.push({
        id: `tool-${t.name}`,
        type: 'Tool',
        title: t.name,
        desc: t.description,
        iconType: 'tool'
      });
    });

    // Blogs
    BLOG_POSTS.forEach((b) => {
      list.push({
        id: `blog-${b.id}`,
        type: 'Guide',
        title: b.title,
        desc: b.summary,
        iconType: 'blog'
      });
    });

    // Programming
    PROGRAMMING_PATHS.forEach((p) => {
      list.push({
        id: `prog-${p.id}`,
        type: 'Programming',
        title: p.name,
        desc: p.summary,
        iconType: 'prog'
      });
    });

    // Creator / About
    list.push({
      id: 'about-rauf',
      type: 'About',
      title: 'About Rauf (Creator & Educator)',
      desc: 'Meet Rauf, the developer and creator behind TermForge guides, tutorials, and open-source resources.',
      section: 'about'
    });

    return list;
  }, []);

  const results = useMemo(() => {
    const q = query.toLowerCase().trim();
    if (!q) return [];
    return allItems
      .filter((item) => (item.title + ' ' + item.desc + ' ' + item.type).toLowerCase().includes(q))
      .slice(0, 24);
  }, [allItems, query]);

  const handleItemClick = (item: (typeof allItems)[0]) => {
    if (item.section !== undefined && item.idx !== undefined) {
      onOpenLesson(item.title, item.section, item.idx);
    } else if (item.cmd) {
      onCopyCommand(item.cmd);
    } else {
      const anchor = document.getElementById(item.type.toLowerCase()) || document.getElementById('home');
      anchor?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="search" className="py-16 border-t border-[var(--line)]">
      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        <div className="mb-8 flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <div className="text-xs font-black tracking-widest text-[#73c5ff] uppercase">
              Find Anything
            </div>
            <h2 className="mt-1 text-3xl font-extrabold tracking-tight text-[var(--text)] sm:text-4xl">
              Global Search
            </h2>
            <p className="mt-2 max-w-2xl text-sm sm:text-base text-[var(--muted)]">
              Search across lessons, commands, tools, public APIs, blogs and programming tracks in real-time.
            </p>
          </div>
        </div>

        {/* Global Search Input */}
        <div className="relative max-w-3xl">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-[var(--muted)]" />
          <input
            id="globalSearch"
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Try searching: git clone, permissions, Python, weather API, ssh, bash..."
            className="w-full rounded-2xl border border-[var(--line)] bg-[var(--panel)] py-3.5 pl-12 pr-4 text-sm text-[var(--text)] placeholder-[var(--muted)] outline-none shadow-lg shadow-black/5 transition-colors focus:border-[#48a9ff]"
          />
        </div>

        {/* Quick Suggestion Chips */}
        {!query && (
          <div className="mt-4 flex flex-wrap items-center gap-2 text-xs text-[var(--muted)]">
            <span>Quick queries:</span>
            {['git status', 'chmod 755', 'Termux storage', 'curl', 'Python venv', 'REST APIs'].map(
              (tag) => (
                <button
                  key={tag}
                  onClick={() => setQuery(tag)}
                  className="rounded-lg border border-[var(--line)] bg-[var(--panel)] px-2.5 py-1 text-xs text-[var(--muted)] hover:border-[#48a9ff] hover:text-[var(--text)] transition-colors"
                >
                  {tag}
                </button>
              )
            )}
          </div>
        )}

        {/* Results Container */}
        <div className="mt-6">
          {query && results.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-[var(--line)] p-8 text-center text-sm text-[var(--muted)]">
              No matching learning content found for "{query}". Try a different keyword.
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {results.map((item) => (
                <article
                  key={item.id}
                  onClick={() => handleItemClick(item)}
                  className="flex flex-col justify-between rounded-2xl border border-[var(--line)] bg-gradient-to-b from-[var(--panel)] to-[var(--panel2)] p-4 shadow-sm transition-all duration-200 hover:-translate-y-0.5 hover:border-[#48a9ff]/40 cursor-pointer"
                >
                  <div>
                    <div className="flex items-center justify-between">
                      <span className="rounded-full border border-[var(--line)] bg-[var(--panel2)] px-2.5 py-0.5 text-[10px] font-bold text-[#74c7ff]">
                        {item.type}
                      </span>
                      <ArrowUpRight className="h-4 w-4 text-[var(--muted)]" />
                    </div>

                    <h3 className="mt-2.5 text-sm font-bold text-[var(--text)] line-clamp-1">
                      {item.title}
                    </h3>

                    <p className="mt-1 text-xs text-[var(--muted)] line-clamp-2 leading-relaxed">
                      {item.desc}
                    </p>
                  </div>

                  <div className="mt-3 pt-2 border-t border-[var(--line)]/50 flex items-center gap-1.5 text-[11px] font-semibold text-[#48a9ff]">
                    {item.iconType === 'lesson' && <BookOpen className="h-3 w-3" />}
                    {item.iconType === 'command' && <Terminal className="h-3 w-3" />}
                    {item.iconType === 'tool' && <Wrench className="h-3 w-3" />}
                    {item.iconType === 'prog' && <Code2 className="h-3 w-3" />}
                    <span>
                      {item.iconType === 'lesson'
                        ? 'Open lesson'
                        : item.iconType === 'command'
                        ? 'Copy command'
                        : 'Explore section'}
                    </span>
                  </div>
                </article>
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
};

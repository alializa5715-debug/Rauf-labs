import React, { useState } from 'react';
import { PROGRAMMING_PATHS } from '../data/learningData';
import { Copy, Check, Terminal, Code2, Layers, CheckCircle2 } from 'lucide-react';

interface ProgrammingSectionProps {
  onCopy: (text: string) => void;
}

export const ProgrammingSection: React.FC<ProgrammingSectionProps> = ({ onCopy }) => {
  const [activeLang, setActiveLang] = useState(PROGRAMMING_PATHS[0].id);
  const [copiedCode, setCopiedCode] = useState(false);

  const currentPath = PROGRAMMING_PATHS.find((p) => p.id === activeLang) || PROGRAMMING_PATHS[0];

  const handleCopyCode = (code: string) => {
    onCopy(code);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <section id="programming" className="py-16 border-t border-[var(--line)]">
      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        <div className="mb-10 flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <div className="text-xs font-black tracking-widest text-[#73c5ff] uppercase">
              06 · Programming Paths
            </div>
            <h2 className="mt-1 text-3xl font-extrabold tracking-tight text-[var(--text)] sm:text-4xl">
              Programming Paths
            </h2>
            <p className="mt-2 max-w-2xl text-sm sm:text-base text-[var(--muted)]">
              Each path moves from fundamentals to intermediate concepts, real-world mini projects, and production roadmaps.
            </p>
          </div>
        </div>

        {/* Language Switcher Tabs */}
        <div className="mb-8 flex flex-wrap gap-2">
          {PROGRAMMING_PATHS.map((path) => {
            const isActive = path.id === activeLang;
            return (
              <button
                key={path.id}
                id={`tab-prog-${path.id}`}
                onClick={() => setActiveLang(path.id)}
                className={`flex items-center gap-2 rounded-xl px-4 py-2.5 text-xs font-bold transition-all ${
                  isActive
                    ? 'bg-gradient-to-r from-[#48a9ff] to-[#4be0d4] text-[#03101b] shadow-md shadow-cyan-500/20'
                    : 'border border-[var(--line)] bg-[var(--panel)] text-[var(--muted)] hover:bg-[var(--panel2)] hover:text-[var(--text)]'
                }`}
              >
                <span className="font-mono text-sm">{path.icon}</span>
                <span>{path.name}</span>
              </button>
            );
          })}
        </div>

        {/* Path Detail Spotlight */}
        <div className="rounded-3xl border border-[var(--line)] bg-gradient-to-b from-[var(--panel)] to-[var(--panel2)] p-6 sm:p-8 shadow-xl">
          <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
            {/* Left Column: Roadmap & Use Cases */}
            <div>
              <div className="flex items-center gap-3">
                <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#48a9ff]/10 text-2xl font-black text-[#79caff]">
                  {currentPath.icon}
                </span>
                <div>
                  <h3 className="text-2xl font-black text-[var(--text)]">{currentPath.name}</h3>
                  <p className="text-xs text-[var(--muted)]">{currentPath.summary}</p>
                </div>
              </div>

              {/* Install / Environment Command */}
              <div className="mt-6 rounded-xl border border-[var(--line)] bg-[#050b14] p-3.5">
                <div className="flex items-center justify-between text-[11px] font-mono text-[#8bcaff] mb-1.5">
                  <span className="flex items-center gap-1.5">
                    <Terminal className="h-3 w-3" />
                    Environment & Setup
                  </span>
                  <button
                    onClick={() => onCopy(currentPath.installCommand)}
                    className="hover:text-white transition-colors"
                    title="Copy install command"
                  >
                    <Copy className="h-3 w-3" />
                  </button>
                </div>
                <pre className="font-mono text-xs text-[#cbd9e9] overflow-x-auto whitespace-pre">
                  {currentPath.installCommand}
                </pre>
              </div>

              {/* Curriculum Roadmap */}
              <div className="mt-6">
                <h4 className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#79caff]">
                  <Layers className="h-3.5 w-3.5" />
                  Learning Roadmap
                </h4>
                <div className="mt-3 grid grid-cols-1 gap-2 sm:grid-cols-2">
                  {currentPath.roadmap.map((stage, idx) => (
                    <div
                      key={idx}
                      className="flex items-center gap-2 rounded-xl border border-[var(--line)] bg-[var(--panel2)]/60 px-3 py-2 text-xs text-[var(--text)]"
                    >
                      <CheckCircle2 className="h-3.5 w-3.5 text-cyan-400 shrink-0" />
                      <span className="truncate">{stage}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Real World Applications */}
              <div className="mt-6">
                <h4 className="text-xs font-bold uppercase tracking-wider text-[var(--muted)]">
                  Primary Use Cases
                </h4>
                <div className="mt-2.5 flex flex-wrap gap-2">
                  {currentPath.keyUseCases.map((useCase, idx) => (
                    <span
                      key={idx}
                      className="rounded-lg border border-[var(--line)] bg-[var(--panel2)] px-2.5 py-1 text-xs text-[var(--muted)]"
                    >
                      {useCase}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Right Column: Interactive Starter Code */}
            <div className="flex flex-col">
              <div className="flex items-center justify-between rounded-t-2xl border border-b-0 border-[var(--line)] bg-[#0a111d] px-4 py-2.5">
                <div className="flex items-center gap-2 text-xs font-mono text-[#cbd9e9]">
                  <Code2 className="h-4 w-4 text-[#48a9ff]" />
                  <span>main.{currentPath.id === 'python' ? 'py' : currentPath.id === 'html' ? 'html' : currentPath.id === 'css' ? 'css' : 'js'}</span>
                </div>
                <button
                  onClick={() => handleCopyCode(currentPath.starterCode)}
                  className="flex items-center gap-1.5 rounded-lg border border-[var(--line)] bg-[var(--panel2)] px-2.5 py-1 text-xs font-medium text-[var(--text)] transition-colors hover:border-[#48a9ff]"
                >
                  {copiedCode ? (
                    <>
                      <Check className="h-3.5 w-3.5 text-emerald-400" />
                      <span className="text-emerald-400">Copied!</span>
                    </>
                  ) : (
                    <>
                      <Copy className="h-3.5 w-3.5" />
                      <span>Copy Code</span>
                    </>
                  )}
                </button>
              </div>
              <div className="relative flex-1 overflow-auto rounded-b-2xl border border-[var(--line)] bg-[#050b14] p-4 font-mono text-xs leading-relaxed text-[#cbd9e9] shadow-inner max-h-[420px]">
                <pre className="whitespace-pre">{currentPath.starterCode}</pre>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

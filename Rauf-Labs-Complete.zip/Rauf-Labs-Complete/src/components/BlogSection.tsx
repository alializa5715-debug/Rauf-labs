import React, { useState } from 'react';
import { BLOG_POSTS } from '../data/learningData';
import { BlogPost } from '../types';
import { BlogModal } from './BlogModal';
import { BookOpen, ArrowRight, Clock } from 'lucide-react';

interface BlogSectionProps {
  onCopy: (text: string) => void;
}

export const BlogSection: React.FC<BlogSectionProps> = ({ onCopy }) => {
  const [selectedPost, setSelectedPost] = useState<BlogPost | null>(null);

  return (
    <section id="blog" className="py-16 border-t border-[var(--line)]">
      <div className="mx-auto w-full max-w-[1180px] px-4 sm:px-6">
        <div className="mb-10 flex flex-col items-start justify-between gap-4 md:flex-row md:items-end">
          <div>
            <div className="text-xs font-black tracking-widest text-[#73c5ff] uppercase">
              Fresh Guides
            </div>
            <h2 className="mt-1 text-3xl font-extrabold tracking-tight text-[var(--text)] sm:text-4xl">
              Developer Blog
            </h2>
            <p className="mt-2 max-w-2xl text-sm sm:text-base text-[var(--muted)]">
              Short, practical engineering articles for learning by doing without unnecessary fluff.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {BLOG_POSTS.map((post) => (
            <article
              key={post.id}
              onClick={() => setSelectedPost(post)}
              className="group flex flex-col justify-between overflow-hidden rounded-2xl border border-[var(--line)] bg-[var(--panel)] shadow-sm transition-all duration-200 hover:-translate-y-1 hover:border-[#48a9ff]/40 cursor-pointer"
            >
              <div>
                {/* Visual Cover Banner */}
                <div className="flex h-28 items-center justify-center bg-gradient-to-br from-[#12365b] via-[#0d2a45] to-[#123b3b] text-4xl shadow-inner group-hover:scale-105 transition-transform duration-300">
                  <span>{post.icon}</span>
                </div>

                <div className="p-5">
                  <div className="flex items-center justify-between text-xs text-[var(--muted)] mb-2">
                    <span className="font-bold text-[#71c4ff]">{post.category}</span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {post.readTime}
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-[var(--text)] group-hover:text-[#79caff] transition-colors line-clamp-2">
                    {post.title}
                  </h3>

                  <p className="mt-2 text-xs leading-relaxed text-[var(--muted)] line-clamp-2">
                    {post.summary}
                  </p>
                </div>
              </div>

              <div className="p-5 pt-0">
                <div className="flex items-center justify-between border-t border-[var(--line)]/50 pt-3 text-xs font-bold text-[#48a9ff]">
                  <span className="flex items-center gap-1.5">
                    <BookOpen className="h-3.5 w-3.5" />
                    Read guide
                  </span>
                  <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>

      {/* Reader Modal */}
      <BlogModal
        post={selectedPost}
        onClose={() => setSelectedPost(null)}
        onCopy={onCopy}
      />
    </section>
  );
};

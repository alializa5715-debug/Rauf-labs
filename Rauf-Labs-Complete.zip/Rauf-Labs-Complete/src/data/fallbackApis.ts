import { PublicApiItem } from '../types';

/**
 * High-quality curated offline fallback list of popular public APIs.
 * Used if both live GitHub README and the fallback endpoint cannot be fetched.
 * Absolutely clean of any ':---' or markdown artifacts.
 */
export const FALLBACK_PUBLIC_APIS: PublicApiItem[] = [
  {
    name: 'Open-Meteo',
    description: 'Free open-source weather API with solar, temperature, wind, and forecast models. No API key required.',
    category: 'Weather',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://open-meteo.com/'
  },
  {
    name: 'Open Library',
    description: 'Millions of book records, authors, ISBNs, book covers, and full-text search.',
    category: 'Books',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://openlibrary.org/developers/api'
  },
  {
    name: 'REST Countries',
    description: 'Comprehensive world countries directory with borders, currencies, capitals, flags and ISO codes.',
    category: 'Geocoding',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://restcountries.com/'
  },
  {
    name: 'PokeAPI',
    description: 'All the Pokémon data you will ever need: species, moves, abilities, types, sprites and evolutions.',
    category: 'Games & Comics',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://pokeapi.co/'
  },
  {
    name: 'JSONPlaceholder',
    description: 'Free fake REST API for prototyping frontend applications with fake posts, users, albums, and comments.',
    category: 'Development',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://jsonplaceholder.typicode.com/'
  },
  {
    name: 'Dog CEO',
    description: 'Crowdsourced collection of open-source dog images with breed categorization and random queries.',
    category: 'Animals',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://dog.ceo/dog-api/'
  },
  {
    name: 'Cat Facts',
    description: 'Random and daily cat facts powered by ninja endpoints.',
    category: 'Animals',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://catfact.ninja/'
  },
  {
    name: 'GitHub REST API',
    description: 'Interact with public repositories, user profiles, commits, releases, issues, and gists.',
    category: 'Development',
    auth: 'apiKey (optional)',
    https: true,
    cors: 'Yes',
    link: 'https://docs.github.com/en/rest'
  },
  {
    name: 'CoinGecko Public API',
    description: 'Real-time cryptocurrency prices, market capitalization, trading volumes, and exchange stats.',
    category: 'Cryptocurrency',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://www.coingecko.com/en/api'
  },
  {
    name: 'NASA Open APIs',
    description: 'Astronomy Picture of the Day (APOD), Mars Rover photos, asteroid tracking, and Earth imagery.',
    category: 'Science & Math',
    auth: 'apiKey',
    https: true,
    cors: 'Yes',
    link: 'https://api.nasa.gov/'
  },
  {
    name: 'Universities List',
    description: 'Worldwide university directory with domains, web pages, state/province, and alpha-2 country codes.',
    category: 'Education',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://github.com/Hipo/university-domains-list'
  },
  {
    name: 'Frankfurter',
    description: 'Free foreign exchange currency converter and historical currency rates published by the European Central Bank.',
    category: 'Finance',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://www.frankfurter.app/docs/'
  },
  {
    name: 'Wikipedia REST API',
    description: 'Read and search Wikipedia articles, summaries, page views, and featured daily contents.',
    category: 'Open Data',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://en.wikipedia.org/api/rest_v1/'
  },
  {
    name: 'DummyJSON',
    description: 'Realistic fake REST data for products, carts, users, posts, comments, quotes, and auth tokens.',
    category: 'Development',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://dummyjson.com/'
  },
  {
    name: 'Chuck Norris Jokes',
    description: 'Curated database of funny Chuck Norris jokes with category filtering and random retrieval.',
    category: 'Entertainment',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://api.chucknorris.io/'
  },
  {
    name: 'Advice Slip',
    description: 'Simple advice generator API giving pieces of advice for daily wisdom and motivation.',
    category: 'Personality',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://api.adviceslip.com/'
  },
  {
    name: 'Agify.io',
    description: 'Predict the age of a person based on their first name using worldwide demographic datasets.',
    category: 'Machine Learning',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://agify.io/'
  },
  {
    name: 'Genderize.io',
    description: 'Predict the gender of a name with probabilistic accuracy across multiple languages.',
    category: 'Machine Learning',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://genderize.io/'
  },
  {
    name: 'Nationalize.io',
    description: 'Estimate the nationality of a person based on their first name with country probability distributions.',
    category: 'Machine Learning',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://nationalize.io/'
  },
  {
    name: 'Free Dictionary API',
    description: 'English dictionary API with phonetics, pronunciations, definitions, examples, and synonyms.',
    category: 'Dictionaries',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://dictionaryapi.dev/'
  },
  {
    name: 'Nobel Prize API',
    description: 'Detailed information on Nobel Prizes and Nobel Laureates since 1901.',
    category: 'Science & Math',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://www.nobelprize.org/about/developer-zone-2/'
  },
  {
    name: 'IPify',
    description: 'A simple and resilient public IP address lookup API that returns IPv4 and IPv6 addresses.',
    category: 'Development',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://www.ipify.org/'
  },
  {
    name: 'Bored API',
    description: 'Activity recommendation generator that suggests things to do when you are bored.',
    category: 'Personality',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://boredapi.com/'
  },
  {
    name: 'ReqRes',
    description: 'A hosted REST-API ready to respond to AJAX requests with simulated users, status codes, and latency.',
    category: 'Development',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://reqres.in/'
  },
  {
    name: 'Quotable',
    description: 'Open source quotations API providing quotes by famous authors, categorized by tags.',
    category: 'Personality',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://github.com/lukePeavey/quotable'
  },
  {
    name: 'Sunrise and Sunset',
    description: 'Free REST API providing sunrise, sunset, dawn, and dusk times for any latitude and longitude.',
    category: 'Weather',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://sunrise-sunset.org/api'
  },
  {
    name: 'Zipcodebase',
    description: 'Worldwide postal codes, postal coordinates, distance calculations and zip code lookup.',
    category: 'Geocoding',
    auth: 'apiKey',
    https: true,
    cors: 'Yes',
    link: 'https://zipcodebase.com/'
  },
  {
    name: 'RandomUser.me',
    description: 'Free API for generating realistic random user placeholder data with photos, addresses, and bios.',
    category: 'Test Data',
    auth: 'No',
    https: true,
    cors: 'Yes',
    link: 'https://randomuser.me/'
  }
];

/**
 * Strips HTML tags and markdown formatting to produce clean, safe text.
 */
function sanitizeText(str: string): string {
  if (!str) return '';
  return str
    .replace(/<[^>]*>/g, '') // remove HTML tags
    .replace(/`([^`]+)`/g, '$1') // inline code
    .replace(/\*\*([^*]+)\*\*/g, '$1') // bold
    .replace(/\*([^*]+)\*/g, '$1') // italic
    .replace(/\[([^\]]+)\]\([^)]+\)/g, '$1') // markdown link text
    .replace(/[\r\n\t]+/g, ' ')
    .replace(/\s{2,}/g, ' ')
    .trim();
}

/**
 * Extracts a valid HTTP/HTTPS URL from a string.
 */
function extractSafeUrl(str: string): string {
  if (!str) return '';
  // Check for markdown link [Name](URL)
  const mdMatch = str.match(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/i);
  if (mdMatch && mdMatch[2]) {
    return mdMatch[2].trim();
  }
  // Check for raw URL
  const rawMatch = str.match(/(https?:\/\/[^\s)]+)/i);
  if (rawMatch && rawMatch[1]) {
    return rawMatch[1].trim();
  }
  return '';
}

/**
 * Checks if a set of table cells represents a markdown separator row (e.g. :--- | :---)
 */
function isSeparatorRow(cells: string[]): boolean {
  if (!cells || cells.length === 0) return true;
  return cells.every((c) => {
    const trimmed = c.trim();
    return /^:?-{2,}:?$/.test(trimmed) || trimmed === '';
  });
}

/**
 * Robust dynamic Markdown parser for the Public APIs repository README.
 * Detects categories, parses table rows of variable column layouts,
 * completely filters out markdown syntax and ':---' separator artifacts,
 * sanitizes strings, and eliminates duplicates.
 */
export function parsePublicApisReadme(md: string): PublicApiItem[] {
  if (!md || typeof md !== 'string') {
    return FALLBACK_PUBLIC_APIS;
  }

  const out: PublicApiItem[] = [];
  const lines = md.split(/\r?\n/);

  // Non-API category headings to ignore
  const ignoreHeadings = new Set([
    'apis covered under apilayer suite!',
    'apilayer apis',
    'learn more about public apis',
    'index',
    'license',
    'try public apis for free',
    'table of contents',
    'contributing'
  ]);

  let currentCategory = '';
  const seenKeys = new Set<string>();

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    // Detect Category Headings (e.g., ## Animals or ### Animals)
    const headingMatch = line.match(/^#{2,4}\s+(.+)$/);
    if (headingMatch) {
      const headingText = headingMatch[1].replace(/^\d+\.\s*/, '').trim();
      if (!ignoreHeadings.has(headingText.toLowerCase())) {
        currentCategory = headingText;
      }
      continue;
    }

    if (!currentCategory) continue;

    // Check if line represents a markdown table row (has at least 2 pipes)
    const pipeCount = (line.match(/\|/g) || []).length;
    if (pipeCount >= 2) {
      let trimmed = line;
      if (trimmed.startsWith('|')) trimmed = trimmed.slice(1);
      if (trimmed.endsWith('|')) trimmed = trimmed.slice(0, -1);
      const cells = trimmed.split('|').map((c) => c.trim());

      // Needs at least: Name/API, Description, Auth
      if (cells.length < 3) continue;

      // Skip table separator rows (e.g. :---|:---|:---)
      if (isSeparatorRow(cells)) continue;

      const rawName = cells[0];
      const name = sanitizeText(rawName);

      // Skip header rows or invalid placeholder names like ':---', 'API', etc.
      if (
        !name ||
        /^api$/i.test(name) ||
        /^name$/i.test(name) ||
        name.includes('---') ||
        name.startsWith(':')
      ) {
        continue;
      }

      const rawDesc = cells[1];
      const description = sanitizeText(rawDesc);

      // Skip header or separator in description column
      if (
        !description ||
        /^description$/i.test(description) ||
        description.includes('---') ||
        description.startsWith(':')
      ) {
        continue;
      }

      // Authentication extraction
      const rawAuth = cells[2] || '';
      let auth = sanitizeText(rawAuth);
      if (/^auth$/i.test(auth) || auth.includes('---')) continue;
      if (!auth || auth.toLowerCase() === 'no' || auth.toLowerCase() === 'none') {
        auth = 'No';
      }

      // HTTPS support extraction
      const rawHttps = cells[3] || 'No';
      const httpsClean = sanitizeText(rawHttps).toLowerCase();
      const https = httpsClean === 'yes' || httpsClean === 'true';

      // CORS extraction
      const rawCors = cells[4] ? sanitizeText(cells[4]) : 'Unknown';

      // Official documentation URL extraction
      const link = extractSafeUrl(rawName) || (rawDesc ? extractSafeUrl(rawDesc) : '');

      // Deduplicate entries by name and category
      const dedupeKey = `${name.toLowerCase()}:::${currentCategory.toLowerCase()}`;
      if (seenKeys.has(dedupeKey)) continue;
      seenKeys.add(dedupeKey);

      out.push({
        name,
        description,
        category: currentCategory,
        auth,
        https,
        cors: rawCors,
        link: link || '#'
      });
    }
  }

  // Ensure alphabetical ordering by default
  out.sort((a, b) => a.name.localeCompare(b.name, undefined, { sensitivity: 'base' }));

  return out.length > 0 ? out : FALLBACK_PUBLIC_APIS;
}

/**
 * Normalizes entries returned from https://api.publicapis.org/entries
 */
export function normalizeFallbackApiEntry(x: any): PublicApiItem {
  const name = sanitizeText(x.API || x.name || 'Public API');
  const description = sanitizeText(x.Description || x.description || '');
  const category = sanitizeText(x.Category || x.category || 'Other');
  let auth = sanitizeText(x.Auth || x.auth || 'No');
  if (!auth || auth.toLowerCase() === 'none') auth = 'No';
  const https = x.HTTPS === true || x.HTTPS === 'Yes' || String(x.HTTPS).toLowerCase() === 'true';
  const link = extractSafeUrl(x.Link || x.link || '') || '#';

  return {
    name,
    description,
    category,
    auth,
    https,
    cors: x.Cors || 'Unknown',
    link
  };
}

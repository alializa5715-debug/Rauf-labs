import { Course, LessonDetail, ProgrammingPath, OpenSourceTool, CommandRef, BlogPost } from '../types';

export const COURSES: Course[] = [
  {
    id: 'termux',
    icon: '⌘',
    title: 'Termux',
    description: "Master Android's terminal from first setup to Python, Git, SSH, Bash and real mini projects.",
    tags: ['17 lessons', 'Android', 'CLI'],
    sectionId: 'termux',
    lessonCount: 17
  },
  {
    id: 'linux',
    icon: '◈',
    title: 'Linux',
    description: 'Understand files, permissions, processes, packages, networking, SSH and shell scripting.',
    tags: ['Foundations', '17 lessons', 'Server'],
    sectionId: 'linux',
    lessonCount: 17
  },
  {
    id: 'powershell',
    icon: 'PS',
    title: 'PowerShell',
    description: 'Learn objects, pipelines, scripts, automation, services and administrative troubleshooting.',
    tags: ['Windows', '17 lessons', 'Automation'],
    sectionId: 'powershell',
    lessonCount: 17
  },
  {
    id: 'bash',
    icon: '$',
    title: 'Bash',
    description: 'Write useful shell scripts with variables, loops, functions, pipes, sed, awk and automation.',
    tags: ['Scripting', '11 lessons', 'Automation'],
    sectionId: 'bash',
    lessonCount: 11
  },
  {
    id: 'git',
    icon: '⎇',
    title: 'Git & GitHub',
    description: 'From git init and commits to branches, pull requests, SSH keys and collaborative workflows.',
    tags: ['Version control', '17 lessons', 'Collaboration'],
    sectionId: 'git',
    lessonCount: 17
  },
  {
    id: 'programming',
    icon: '</>',
    title: 'Programming',
    description: 'Python, JavaScript, HTML, CSS and Node.js paths with structured project-based learning.',
    tags: ['5 paths', 'Full-stack', 'Projects'],
    sectionId: 'programming',
    lessonCount: 5
  }
];

export const RAW_LESSON_TITLES: Record<string, string[]> = {
  termux: [
    'What is Termux?',
    'Installation & Safe Sources',
    'First Setup & Environment',
    'Storage Permission (termux-setup-storage)',
    'Updating Packages (pkg update)',
    'Package Management (pkg / apt)',
    'Essential Navigation Commands',
    'Files & Directories Operations',
    'Git Installation & Setup',
    'Python Setup & Virtualenvs',
    'Node.js & npm Setup',
    'SSH Client & Server Setup',
    'Networking Basics & curl/ping',
    'Bash Scripting in Termux',
    'Running Background Scripts & cron',
    'Useful Productivity Tools',
    'Common Errors & Mini Projects'
  ],
  linux: [
    'Linux Introduction & Architecture',
    'Distributions (Debian, Ubuntu, Fedora, Arch)',
    'Terminal Basics & Shell Concepts',
    'Filesystem Hierarchy Standard (FHS)',
    'pwd, ls & cd in Depth',
    'mkdir, touch, cp, mv & rm',
    'cat, less, grep & find',
    'File Permissions & Ownership Concept',
    'chmod (Symbolic & Octal Modes)',
    'chown & chgrp Operations',
    'Users & Groups Administration',
    'Processes & Task Management (ps, top, kill)',
    'Package Managers (apt, dnf, pacman)',
    'Networking Fundamentals (ip, ss, curl, ping)',
    'Secure Shell (SSH) Configuration',
    'Environment Variables & PATH',
    'Systemd Services & Troubleshooting'
  ],
  powershell: [
    'PowerShell Introduction & Core Engine',
    'Windows Terminal Customization',
    'Basic Commands & Cmdlet Syntax',
    'Get-Help & Discovering Commands',
    'Get-Command & Searching Aliases',
    'Files and Folders with Provider Cmdlets',
    'Variables & Data Types',
    'Working with Objects (Not Just Text)',
    'The PowerShell Pipeline (|)',
    'Process Management (Get-Process, Stop-Process)',
    'Windows Services (Get-Service, Restart-Service)',
    'Networking & Web Requests (Invoke-RestMethod)',
    'Writing Scripts (.ps1) & Execution Policies',
    'Functions & Custom Parameters',
    'Automation Scripts & Scheduled Tasks',
    'Error Handling (try / catch / finally)',
    'PowerShell Mini Projects & Modules'
  ],
  bash: [
    'Bash Basics & Shebang (#!)',
    'Variables, Environment & Quoting Rules',
    'Conditional Statements (if, elif, else, test)',
    'Loops (for, while, until)',
    'Functions, Scope & Return Codes',
    'Script Arguments ($1, $@, $#)',
    'Pipes and I/O Redirection (>, >>, 2>&1)',
    'String Manipulation & Parameter Expansion',
    'Text Processing with grep, sed and awk',
    'Automated Backup Scripting',
    'Practical Production Scripts & Best Practices'
  ],
  git: [
    'What is Git & Distributed Version Control?',
    'Installation & Global Configuration (git config)',
    'git init (Creating a Local Repository)',
    'git clone (Cloning Remote Repositories)',
    'git status & The Three Trees Model',
    'git add & The Staging Area',
    'git commit (Writing Meaningful Commit Messages)',
    'git log & Inspecting History',
    'git push (Publishing to Remote)',
    'git pull & git fetch Differences',
    'Branches (git branch, git switch, git checkout)',
    'Merging Branches & Resolving Merge Conflicts',
    'GitHub Remote Repositories & Remotes',
    'Pull Requests & Code Review Habits',
    'GitHub Issues, Milestones & Projects',
    'SSH Keys Configuration for GitHub',
    'Real-World GitHub Collaboration Workflow'
  ]
};

export const LESSON_DETAILS: Record<string, Record<number, LessonDetail>> = {
  termux: {
    0: {
      id: 'termux-0',
      section: 'termux',
      idx: 0,
      title: 'What is Termux?',
      summary: 'Understand what Termux is, how it leverages Linux user-space on Android, and how it differs from traditional Linux or rooted shells.',
      command: 'uname -a && echo $PREFIX',
      explanation: 'Termux runs directly on Android without requiring root access by leveraging Android Linux kernel user-space and sandboxing. It provides a customized Debian/Ubuntu-like package manager (pkg/apt) compiled specifically for Android architecture (Bionic libc).',
      expectedOutput: 'Linux localhost 5.15.0-arm64-v8a #1 SMP PREEMPT ...\n/data/data/com.termux/files/usr',
      safetyTip: 'Always download Termux exclusively from F-Droid or the official GitHub releases. Never install Termux from Google Play Store as Play Store builds are deprecated and cannot receive package updates.',
      exercise: 'Launch Termux on your phone, type "echo $PREFIX" to observe where Termux stores its entire root filesystem in the app sandbox directory.',
      tags: ['Foundations', 'Android', 'Architecture']
    },
    1: {
      id: 'termux-1',
      section: 'termux',
      idx: 1,
      title: 'Installation & Safe Sources',
      summary: 'Setting up Termux properly from verified F-Droid or GitHub release repositories to avoid broken repositories.',
      command: 'termux-change-repo',
      explanation: 'Because mirrors across the world can occasionally become slow or experience downtime, Termux provides the "termux-change-repo" utility to switch to optimal mirrors (like Albatross, Grimler, or Tsinghua).',
      expectedOutput: '[*] Checking available mirrors...\n[*] Updated sources.list repository configuration successfully.',
      safetyTip: 'Beware of unofficial APKs claiming to be "Termux Pro" or "Termux Mod with Root". They often contain malware or backdoors.',
      exercise: 'Run "termux-change-repo", choose "Main repository", and pick a mirror with good latency in your geographic region.',
      tags: ['Setup', 'F-Droid', 'Mirrors']
    },
    2: {
      id: 'termux-2',
      section: 'termux',
      idx: 2,
      title: 'First Setup & Environment',
      summary: 'Initialize the base environment, configure color schemes, and set up your shell for daily coding.',
      command: 'pkg update && pkg upgrade -y',
      explanation: 'Upon first boot, Termux has a minimal package set. Running pkg update updates the repository index and upgrades core packages like bash, coreutils, and openssl.',
      expectedOutput: 'Hit:1 https://packages.termux.dev/apt/termux-main stable InRelease\nReading package lists... Done\nAll packages are up to date.',
      safetyTip: 'If prompted during upgrade: "What would you like to do about modified config file?", choose the default or press "N" to keep current configurations unless you specifically customized them.',
      exercise: 'Run the update command and inspect the terminal output to confirm that all mirror endpoints responded with 200 OK.',
      tags: ['First Steps', 'Environment', 'Maintenance']
    },
    3: {
      id: 'termux-3',
      section: 'termux',
      idx: 3,
      title: 'Storage Permission (termux-setup-storage)',
      summary: 'Grant Termux access to your device storage to read and write files in Downloads, Pictures, and documents.',
      command: 'termux-setup-storage',
      explanation: 'This creates symlinks in ~/storage to shared Android storage directories such as /sdcard/Download, Movies, Music, Pictures, and external shared storage.',
      expectedOutput: 'ls -l ~/storage\ntotal 0\nlrwxrwxrwx 1 ... downloads -> /storage/emulated/0/Download\nlrwxrwxrwx 1 ... shared -> /storage/emulated/0',
      safetyTip: 'Never delete files in ~/storage/shared blindly with "rm -rf", as this deletes real personal files from your phone device memory.',
      exercise: 'Run "termux-setup-storage", accept the Android system permission prompt, and type "ls ~/storage" to view your mapped directories.',
      tags: ['Storage', 'Android Permission', 'Symlinks']
    },
    4: {
      id: 'termux-4',
      section: 'termux',
      idx: 4,
      title: 'Updating Packages (pkg update)',
      summary: 'Keep packages synchronized with upstream security fixes and library updates.',
      command: 'pkg update && pkg clean',
      explanation: 'The "pkg" wrapper sits on top of "apt" and handles Android-specific architecture mappings and safety checks automatically. "pkg clean" removes downloaded .deb archives to save space.',
      expectedOutput: 'Cleaning downloaded archive caches...\nFreed up 34.2 MB of storage.',
      safetyTip: 'Run pkg update at least once a week if you frequently install new developer tools.',
      exercise: 'Test how much disk space Termux uses by executing "df -h $PREFIX".',
      tags: ['Packages', 'Maintenance', 'Storage']
    },
    5: {
      id: 'termux-5',
      section: 'termux',
      idx: 5,
      title: 'Package Management (pkg / apt)',
      summary: 'Search, install, inspect, and remove developer packages in Termux.',
      command: 'pkg search python && pkg install -y git curl nano',
      explanation: 'Use "pkg search <term>" to locate packages, "pkg install <name>" to install, and "pkg uninstall <name>" to remove packages and free up internal mobile memory.',
      expectedOutput: 'Setting up git (2.44.0)...\nSetting up curl (8.6.0)...\nSetting up nano (7.2)...',
      safetyTip: 'Do not install packages from unknown external PPA repositories unless you trust the maintainer.',
      exercise: 'Install "neofetch" or "fastfetch" using "pkg install fastfetch" and run it to display your system specifications.',
      tags: ['Package Manager', 'CLI', 'Tools']
    },
    6: {
      id: 'termux-6',
      section: 'termux',
      idx: 6,
      title: 'Essential Navigation Commands',
      summary: 'Master pwd, ls, cd, and relative/absolute paths in the terminal.',
      command: 'pwd && ls -la && cd .. && pwd && cd -',
      explanation: '"pwd" displays current directory, "ls -la" lists all files including hidden dotfiles with permissions, and "cd -" returns back to the previous working directory.',
      expectedOutput: '/data/data/com.termux/files/home\ndrwx------ 1 u0_a245 ... .\ndrwx------ 1 u0_a245 ... ..\n/data/data/com.termux/files\n/data/data/com.termux/files/home',
      safetyTip: 'Remember that on Linux/Unix file paths are strictly case-sensitive: "Project" and "project" are distinct directories.',
      exercise: 'Navigate to $PREFIX/bin and run "ls -l | wc -l" to count how many executable commands you have installed.',
      tags: ['Navigation', 'Core Commands', 'Bash']
    },
    7: {
      id: 'termux-7',
      section: 'termux',
      idx: 7,
      title: 'Files & Directories Operations',
      summary: 'Create, move, copy, view, and safely remove files and directories.',
      command: 'mkdir -p ~/projects/lab && touch ~/projects/lab/notes.txt && cp ~/projects/lab/notes.txt ~/projects/lab/notes.bak',
      explanation: 'The "-p" flag makes parent directories as needed without throwing an error if they already exist. "touch" creates an empty file or updates timestamps.',
      expectedOutput: 'File created and duplicated successfully to notes.bak.',
      safetyTip: 'Avoid "rm -rf *" without checking current directory with "pwd" first.',
      exercise: 'Create a practice workspace directory with a subfolder and test copying and renaming files using "mv".',
      tags: ['Filesystem', 'Directories', 'CRUD']
    },
    8: {
      id: 'termux-8',
      section: 'termux',
      idx: 8,
      title: 'Git Installation & Setup',
      summary: 'Install Git, configure your user name/email, and verify cryptographic commits.',
      command: 'git config --global user.name "Your Name" && git config --global user.email "you@example.com"',
      explanation: 'Configuring your name and email ensures your commits are properly attributed to your GitHub profile when pushing.',
      expectedOutput: 'git config --list\nuser.name=Your Name\nuser.email=you@example.com\ncore.autocrlf=input',
      safetyTip: 'Never commit passwords, API keys, or private SSH keys into Git repositories.',
      exercise: 'Initialize a dummy repo with "git init test-repo", create a README.md, and make your first commit.',
      tags: ['Git', 'Config', 'Version Control']
    },
    9: {
      id: 'termux-9',
      section: 'termux',
      idx: 9,
      title: 'Python Setup & Virtualenvs',
      summary: 'Install Python 3, pip, and create isolated virtual environments in Termux.',
      command: 'pkg install -y python && python -m venv ~/myenv && source ~/myenv/bin/activate',
      explanation: 'Python on Termux is a full-featured standard Python distribution with support for pip, virtual environments, and C extensions.',
      expectedOutput: 'Python 3.11.x\n(myenv) student@termforge:~$ which python\n/data/data/com.termux/files/home/myenv/bin/python',
      safetyTip: 'Always use virtual environments ("python -m venv") to prevent dependency conflicts between system packages and pip libraries.',
      exercise: 'Activate your venv, run "pip install requests", and write a one-liner to fetch the current UTC time from an API.',
      tags: ['Python', 'Virtualenv', 'Pip']
    },
    10: {
      id: 'termux-10',
      section: 'termux',
      idx: 10,
      title: 'Node.js & npm Setup',
      summary: 'Install Node.js LTS or current, manage npm packages, and run JavaScript scripts.',
      command: 'pkg install -y nodejs-lts && node -v && npm -v',
      explanation: 'Termux packages both "nodejs-lts" (recommended for stability) and "nodejs" (latest current release) compiled for ARM/x86 Android.',
      expectedOutput: 'v20.x.x\n10.x.x',
      safetyTip: 'Avoid running "sudo npm install -g" (sudo does not exist natively in Termux and is not required).',
      exercise: 'Initialize a quick project: "mkdir node-test && cd node-test && npm init -y" and run a console.log script.',
      tags: ['Node.js', 'JavaScript', 'npm']
    },
    11: {
      id: 'termux-11',
      section: 'termux',
      idx: 11,
      title: 'SSH Client & Server Setup',
      summary: 'Connect to remote Linux VPS servers, or turn Termux into an SSH server you can access from your PC keyboard.',
      command: 'pkg install -y openssh && ssh-keygen -t ed25519 -C "termux-mobile"',
      explanation: 'OpenSSH allows you to manage cloud servers or start "sshd" (default port 8022) to control Termux from your desktop browser or VS Code remote extension.',
      expectedOutput: 'Generating public/private ed25519 key pair...\nYour public key has been saved in /data/data/com.termux/files/home/.ssh/id_ed25519.pub',
      safetyTip: 'If running sshd server on Termux, set a strong password using "passwd" or disable password auth in favor of SSH public keys.',
      exercise: 'Generate your ed25519 SSH keypair and view the public key with "cat ~/.ssh/id_ed25519.pub".',
      tags: ['SSH', 'Remote Access', 'Networking']
    },
    12: {
      id: 'termux-12',
      section: 'termux',
      idx: 12,
      title: 'Networking Basics & curl/ping',
      summary: 'Test connectivity, inspect DNS, and query REST APIs from the mobile command line.',
      command: 'curl -I https://api.github.com && ping -c 3 1.1.1.1',
      explanation: '"curl -I" performs an HTTP HEAD request to inspect HTTP response status and headers without downloading the full body payload.',
      expectedOutput: 'HTTP/2 200\nserver: GitHub.com\n3 packets transmitted, 3 received, 0% packet loss',
      safetyTip: 'Never send plain credentials over unencrypted HTTP ("http://") URLs.',
      exercise: 'Fetch your external IP address from the CLI using "curl -s https://ipinfo.io/json".',
      tags: ['Networking', 'curl', 'HTTP']
    },
    13: {
      id: 'termux-13',
      section: 'termux',
      idx: 13,
      title: 'Bash Scripting in Termux',
      summary: 'Write and execute shell scripts with variables, conditionals, and user input.',
      command: 'cat << "EOF" > greet.sh\n#!/data/data/com.termux/files/usr/bin/bash\necho "Hello $USER, current battery check:"\nEOF\nchmod +x greet.sh && ./greet.sh',
      explanation: 'Note the shebang path in Termux: "#!/data/data/com.termux/files/usr/bin/bash" or use the portable "#!/usr/bin/env bash" with termux-exec.',
      expectedOutput: 'Hello u0_a245, current battery check:\n[Script executed successfully]',
      safetyTip: 'Always use "chmod +x" only on scripts whose contents you have inspected.',
      exercise: 'Install termux-api with "pkg install termux-api" and write a script to display battery status using "termux-battery-status".',
      tags: ['Bash', 'Automation', 'Shebang']
    },
    14: {
      id: 'termux-14',
      section: 'termux',
      idx: 14,
      title: 'Running Background Scripts & cron',
      summary: 'Keep scripts running with nohup, tmux, or cron jobs without keeping the app on screen.',
      command: 'pkg install -y tmux && tmux new -s devsession',
      explanation: 'tmux is a terminal multiplexer that allows your terminal sessions and processes to stay alive even if the Termux app loses focus or the screen turns off.',
      expectedOutput: '[tmux session opened at bottom status bar [0] 0:bash*]',
      safetyTip: 'Enable "Acquire WakeLock" in Termux notifications to prevent Android OS battery manager from killing long background tasks.',
      exercise: 'Start a tmux session, detach using "Ctrl+b then d", and reattach using "tmux attach -t devsession".',
      tags: ['Background', 'tmux', 'Persistence']
    },
    15: {
      id: 'termux-15',
      section: 'termux',
      idx: 15,
      title: 'Useful Productivity Tools',
      summary: 'Essential CLI enhancers: ripgrep, fzf, jq, fastfetch, and zsh.',
      command: 'pkg install -y ripgrep fzf jq bat tree',
      explanation: 'Modern CLI tools like ripgrep (fast search), bat (syntax-highlighted cat), and jq (JSON parser) speed up mobile coding tremendously.',
      expectedOutput: 'Setting up fzf...\nSetting up jq...\nSetting up ripgrep...',
      safetyTip: 'Be mindful of internal storage if installing heavy packages like clang or rust.',
      exercise: 'Pipe an API response through jq: "curl -s https://jsonplaceholder.typicode.com/todos/1 | jq .title".',
      tags: ['Productivity', 'CLI', 'Modern Tools']
    },
    16: {
      id: 'termux-16',
      section: 'termux',
      idx: 16,
      title: 'Common Errors & Mini Projects',
      summary: 'Troubleshooting "permission denied", "command not found", repository 404s, and building your first CLI weather monitor.',
      command: 'termux-wake-lock && curl -s "wttr.in/London?format=3"',
      explanation: 'Understanding error codes (Exit code 127 = command not found, 126 = cannot execute, 1 = general error) makes debugging straightforward.',
      expectedOutput: 'London: ⛅ +14°C',
      safetyTip: 'If a package repository throws 404 errors, rerun "termux-change-repo" to update the mirror list.',
      exercise: 'Build a one-file Python weather notifier script that fetches weather data and logs it with timestamps to a file.',
      tags: ['Troubleshooting', 'Projects', 'Capstone']
    }
  }
};

export const PROGRAMMING_PATHS: ProgrammingPath[] = [
  {
    id: 'python',
    icon: '🐍',
    name: 'Python',
    summary: 'From syntax fundamentals to data structures, APIs, automation bots and full web apps.',
    roadmap: [
      '1. Variables, Data Types & Formatting',
      '2. Logic, Loops & Control Flow',
      '3. Functions, Arguments & Lambda',
      '4. Dictionaries, Lists & Comprehensions',
      '5. File I/O & Error Handling (try/except)',
      '6. Virtual Environments & Pip Packaging',
      '7. HTTP Requests & Consuming REST APIs',
      '8. Web Scraping & CLI Scripting'
    ],
    installCommand: 'pkg install python  # Termux / Linux\n# Windows: winget install Python.Python.3.12',
    starterCode: `import sys\nimport urllib.request\nimport json\n\ndef fetch_status():\n    url = "https://httpbin.org/get"\n    req = urllib.request.Request(url, headers={"User-Agent": "TermForge/1.0"})\n    with urllib.request.urlopen(req) as resp:\n        data = json.loads(resp.read().decode("utf-8"))\n        print(f"Origin IP: {data.get('origin')}")\n\nif __name__ == '__main__':\n    print("Running Python Script via TermForge")\n    fetch_status()`,
    keyUseCases: ['Automation scripts', 'Data science & analytics', 'Backend APIs (FastAPI/Flask)', 'CLI utilities']
  },
  {
    id: 'javascript',
    icon: 'JS',
    name: 'JavaScript',
    summary: 'Core language semantics, modern ES6+, DOM manipulation, asynchronous programming and Node.js.',
    roadmap: [
      '1. Variables (const/let), Types & Scope',
      '2. Array Methods (map, filter, reduce)',
      '3. Objects, Destructuring & Spread Syntax',
      '4. Promises, Async/Await & Fetch API',
      '5. Event Loop & Microtask Queues',
      '6. DOM Event Listeners & State',
      '7. Modules (ESM import/export)',
      '8. Building Interactive Web Apps'
    ],
    installCommand: 'pkg install nodejs-lts  # Termux / Linux\n# or use nvm: curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.7/install.sh | bash',
    starterCode: `// Modern async JavaScript example\nasync function getRepoData(repoName) {\n  try {\n    const res = await fetch(\`https://api.github.com/repos/\${repoName}\`);\n    if (!res.ok) throw new Error(\`Status: \${res.status}\`);\n    const data = await res.json();\n    console.log(\`⭐ Stars: \${data.stargazers_count}\`);\n    console.log(\`🍴 Forks: \${data.forks_count}\`);\n  } catch (err) {\n    console.error("Error fetching repository:", err.message);\n  }\n}\n\ngetRepoData("torvalds/linux");`,
    keyUseCases: ['Frontend web interfaces', 'Full-stack Node.js servers', 'Cross-platform CLI tools', 'Browser extensions']
  },
  {
    id: 'html',
    icon: 'HTML',
    name: 'HTML',
    summary: 'Accessible, semantic markup, document architecture, forms, validation and SEO foundations.',
    roadmap: [
      '1. Document Structure & Doctype',
      '2. Semantic Tags (main, nav, article, section)',
      '3. Accessible Forms & Form Validation',
      '4. Typography & Text Elements',
      '5. Media (img, picture, audio, video)',
      '6. Tables & Structured Data',
      '7. Meta Tags, Open Graph & SEO',
      '8. WCAG Accessibility & ARIA Guidelines'
    ],
    installCommand: '# No compiler needed! Tested in any browser or with Live Server\nnpx serve .',
    starterCode: `<!DOCTYPE html>\n<html lang="en">\n<head>\n  <meta charset="UTF-8">\n  <meta name="viewport" content="width=device-width, initial-scale=1.0">\n  <title>TermForge Semantic Web Page</title>\n</head>\n<body>\n  <header>\n    <h1>Developer Hub</h1>\n  </header>\n  <main>\n    <article>\n      <h2>Semantic HTML Foundations</h2>\n      <p>Clean markup improves accessibility and search rankings.</p>\n    </article>\n  </main>\n</body>\n</html>`,
    keyUseCases: ['Web applications', 'Email templates', 'Documentation pages', 'Accessibility compliance']
  },
  {
    id: 'css',
    icon: '#',
    name: 'CSS',
    summary: 'Modern layouts with Flexbox and CSS Grid, responsive design, animations and design systems.',
    roadmap: [
      '1. The Box Model (content, padding, border, margin)',
      '2. Selectors, Specificity & Cascade',
      '3. Modern Flexbox Layouts',
      '4. CSS Grid for Two-Dimensional Grids',
      '5. Responsive Design & Media Queries',
      '6. CSS Variables & Theme Switching',
      '7. Transforms, Transitions & Keyframes',
      '8. Modern Tailwind & Component Design'
    ],
    installCommand: '# Tailwind CSS setup:\nnpm install -D tailwindcss @tailwindcss/vite',
    starterCode: `:root {\n  --primary: #48a9ff;\n  --surface: #0b1627;\n  --text: #edf5ff;\n}\n\n.card {\n  display: grid;\n  grid-template-columns: 1fr;\n  gap: 1.25rem;\n  padding: 1.5rem;\n  background: var(--surface);\n  border: 1px solid rgba(150, 190, 235, 0.14);\n  border-radius: 1rem;\n  transition: transform 0.2s cubic-bezier(0.16, 1, 0.3, 1);\n}\n\n.card:hover {\n  transform: translateY(-3px);\n}`,
    keyUseCases: ['Responsive user interfaces', 'Design token themes', 'Micro-interactions', 'Design systems']
  },
  {
    id: 'nodejs',
    icon: '⬢',
    name: 'Node.js',
    summary: 'JavaScript outside the browser: file systems, streams, REST APIs, middleware and npm packages.',
    roadmap: [
      '1. The V8 Engine & Node Runtime Architecture',
      '2. CommonJS vs. ES Modules',
      '3. File System (fs/promises) & Path Module',
      '4. HTTP Server Creation & Routing',
      '5. Express.js Fundamentals & Middlewares',
      '6. Environment Variables & Security Config',
      '7. Database Integration (SQLite, PostgreSQL, Mongo)',
      '8. Production Deployment & Process Management'
    ],
    installCommand: 'pkg install nodejs-lts  # Termux / Linux\n# Verify:\nnode -v && npm -v',
    starterCode: `import http from 'node:http';\n\nconst server = http.createServer((req, res) => {\n  res.writeHead(200, { 'Content-Type': 'application/json' });\n  res.end(JSON.stringify({\n    message: "TermForge Microservice Online",\n    uptime: process.uptime(),\n    timestamp: new Date().toISOString()\n  }));\n});\n\nserver.listen(3000, () => {\n  console.log("Server listening on http://localhost:3000");\n});`,
    keyUseCases: ['RESTful backend APIs', 'CLI automation utilities', 'WebSocket microservices', 'Build tooling pipelines']
  }
];

export const OPEN_SOURCE_TOOLS: OpenSourceTool[] = [
  {
    name: 'Git',
    category: 'Version Control',
    website: 'https://git-scm.com/',
    description: 'The world standard distributed version control system designed for speed, integrity, and non-linear workflows.',
    installCommand: 'pkg install git  # Termux\nsudo apt install git  # Ubuntu/Debian'
  },
  {
    name: 'Python',
    category: 'Programming',
    website: 'https://www.python.org/',
    description: 'An approachable, readable programming language with an enormous ecosystem for automation, web backends, and AI.',
    installCommand: 'pkg install python  # Termux\nsudo apt install python3  # Ubuntu/Debian'
  },
  {
    name: 'Node.js',
    category: 'Runtime',
    website: 'https://nodejs.org/',
    description: 'An open-source, cross-platform JavaScript runtime built on Chrome V8 engine for building fast, scalable network applications.',
    installCommand: 'pkg install nodejs-lts  # Termux\nsudo apt install nodejs npm  # Ubuntu/Debian'
  },
  {
    name: 'OpenSSH',
    category: 'Networking',
    website: 'https://www.openssh.com/',
    description: 'The premier connectivity tool for remote login with the SSH protocol, encrypting all traffic to eliminate eavesdropping.',
    installCommand: 'pkg install openssh  # Termux\nsudo apt install openssh-client openssh-server'
  },
  {
    name: 'curl',
    category: 'CLI / APIs',
    website: 'https://curl.se/',
    description: 'Command line tool and library for transferring data with URLs, supporting HTTP, HTTPS, FTP, and thousands of test scenarios.',
    installCommand: 'pkg install curl  # Termux\nsudo apt install curl  # Ubuntu/Debian'
  },
  {
    name: 'Vim / Neovim',
    category: 'Text Editor',
    website: 'https://neovim.io/',
    description: 'A modal, highly extensible terminal text editor designed for developer ergonomics, speed, and terminal productivity.',
    installCommand: 'pkg install neovim  # Termux\nsudo apt install neovim  # Ubuntu/Debian'
  }
];

export const COMMAND_REFERENCES: CommandRef[] = [
  {
    id: 'cmd-1',
    category: 'Termux / Linux',
    command: 'pwd',
    description: 'Print current working directory path to understand your exact filesystem location.',
    example: 'pwd',
    flagNotes: '-P displays physical path resolving all symlinks'
  },
  {
    id: 'cmd-2',
    category: 'Termux / Linux',
    command: 'ls -la',
    description: 'List all files and subdirectories including hidden files with permissions, owner, size, and modification date.',
    example: 'ls -la ~/projects',
    flagNotes: '-l (long format), -a (all including dotfiles), -h (human readable sizes)'
  },
  {
    id: 'cmd-3',
    category: 'Termux / Linux',
    command: 'chmod 755 script.sh',
    description: 'Change file permissions to grant owner read/write/execute, and others read/execute.',
    example: 'chmod +x my_automation.sh',
    flagNotes: '755: rwxr-xr-x; 644: rw-r--r--; 600: rw------- (for private keys)'
  },
  {
    id: 'cmd-4',
    category: 'Bash',
    command: 'grep -rn "pattern" .',
    description: 'Search recursively across all files in the current folder for matching text lines.',
    example: 'grep -rn "API_KEY" src/',
    flagNotes: '-r (recursive), -n (show line numbers), -i (case-insensitive)'
  },
  {
    id: 'cmd-5',
    category: 'PowerShell',
    command: 'Get-Help',
    description: 'Retrieve rich documentation, syntax, parameters and real usage examples for any cmdlet.',
    example: 'Get-Help Get-Process -Examples',
    flagNotes: '-Online opens web documentation; -ShowWindow displays GUI help'
  },
  {
    id: 'cmd-6',
    category: 'PowerShell',
    command: 'Get-Service | Where-Object Status -eq "Running"',
    description: 'Filter active Windows background services using the object pipeline.',
    example: 'Get-Service wuauserv | Restart-Service',
    flagNotes: 'Operates on structured .NET objects rather than plain text'
  },
  {
    id: 'cmd-7',
    category: 'Git',
    command: 'git status',
    description: 'Inspect the state of the working directory and the staging area (added, modified, untracked).',
    example: 'git status -s',
    flagNotes: '-s provides compact short format output'
  },
  {
    id: 'cmd-8',
    category: 'Git',
    command: 'git commit -m "feat: setup project"',
    description: 'Record changes to the repository with an informative commit log message.',
    example: 'git commit -am "fix: resolve path resolution bug"',
    flagNotes: '-a stages all tracked modified files automatically'
  },
  {
    id: 'cmd-9',
    category: 'Git',
    command: 'git clone <url>',
    description: 'Clone a remote repository from GitHub, GitLab or self-hosted Git into a new local directory.',
    example: 'git clone https://github.com/public-apis/public-apis.git',
    flagNotes: '--depth 1 creates a shallow clone with only the latest commit'
  }
];

export const BLOG_POSTS: BlogPost[] = [
  {
    id: 'blog-1',
    icon: '⚡',
    category: 'Termux',
    title: 'How to Build a Safe, Robust First Termux Setup',
    readTime: '4 min read',
    summary: 'A step-by-step blueprint to configure Termux properly on Android, avoid broken Play Store builds, setup mirrors, and configure essential packages.',
    content: [
      'The biggest pitfall for beginners entering the Android terminal ecosystem is downloading Termux from the Google Play Store. Because of changes in Android SDK requirements, the Play Store version has been unmaintained since 2020 and will produce 404 repository errors when running pkg update.',
      'Always install Termux from F-Droid or GitHub Releases. Once installed, immediately execute "termux-change-repo" to pick a geographic mirror with low latency, then execute "pkg update && pkg upgrade -y".',
      'Next, grant storage access using "termux-setup-storage". This mounts /sdcard/Download cleanly into ~/storage/downloads. Finally, install tmux to prevent Android OS from aggressively killing long-running Python or Node processes when the phone screen turns off.'
    ],
    keyTakeaways: [
      'Download only from F-Droid or official GitHub releases',
      'Run termux-change-repo to select reliable mirrors',
      'Use termux-wake-lock or tmux for background tasks',
      'Never paste untrusted shell scripts blindly'
    ],
    recommendedCommand: 'pkg update && pkg install -y git openssh tmux'
  },
  {
    id: 'blog-2',
    icon: '⌘',
    category: 'Linux',
    title: 'The Essential Linux Commands Every Developer Needs First',
    readTime: '5 min read',
    summary: 'Stop memorizing arbitrary cheat sheets. Learn the mental model behind Unix streams, permissions, and directory navigation.',
    content: [
      'Linux treats almost everything as a file stream. When you understand stdin (0), stdout (1), and stderr (2), complex command chaining with pipes (|) and redirects (>, >>, 2>&1) becomes second nature.',
      'Focus on mastering 8 core commands before anything else: pwd, ls -la, cd, mkdir -p, cp -r, mv, rm -i, and grep -rn. Learn to use the man pages ("man ls") or "--help" flags to inspect switches without leaving the terminal.',
      'For file permissions, remember the 3 trios: User, Group, and Others. Read is 4, Write is 2, Execute is 1. Therefore, 755 gives the owner full access (4+2+1=7) while letting others read and execute (4+1=5).'
    ],
    keyTakeaways: [
      'Everything in Unix is represented as a file or byte stream',
      'Pipes (|) send the stdout of one command into the stdin of another',
      '755 permissions allow owner modification while keeping executables safe'
    ],
    recommendedCommand: 'ls -la | grep -E "(drwx|-rwx)"'
  },
  {
    id: 'blog-3',
    icon: '⎇',
    category: 'Git',
    title: "A Beginner's Mental Model for Git (The Three Trees)",
    readTime: '6 min read',
    summary: 'Demystifying Git: Working Directory, Staging Area (Index), and Commit History (HEAD).',
    content: [
      'Most confusion in Git stems from viewing it as a file backup tool rather than a snapshot-based directed acyclic graph (DAG). Git maintains three states for every file: Modified in the Working Directory, Staged in the Index, and Committed in HEAD.',
      'When you run "git add", you are taking a snapshot of files and placing them into the staging staging area. When you run "git commit", Git wraps that staged snapshot into a permanent commit object with a cryptographic hash, author information, and parent pointers.',
      'Branches in Git are remarkably lightweight: a branch is simply a movable pointer to a commit hash. Switching branches with "git switch" simply updates the HEAD pointer and updates your working tree files.'
    ],
    keyTakeaways: [
      'The Staging Area lets you craft clean, atomic commits',
      'Commits are immutable cryptographic snapshots of your project',
      'Branches are simple 41-byte pointer files, making them virtually free'
    ],
    recommendedCommand: 'git status && git log --oneline --graph --decorate'
  },
  {
    id: 'blog-4',
    icon: '◉',
    category: 'APIs',
    title: 'How to Read an API’s Documentation Like an Engineer',
    readTime: '4 min read',
    summary: 'A structured methodology for understanding authentication headers, rate limits, HTTP status codes, and error formats.',
    content: [
      'Before writing a single line of code against a new API, locate three crucial sections in its docs: Authentication (API Key, Bearer Token, OAuth), Rate Limits (requests per minute/day), and Error Response structures.',
      'Always test endpoints using curl or a lightweight tool before implementing them in your application code. This isolates network issues, header mistakes, or CORS restrictions from your application logic.',
      'Remember: Never commit private API keys into Git repositories. Store them in environment variables (.env) and declare sample keys in .env.example.'
    ],
    keyTakeaways: [
      'Always verify whether an endpoint requires an Authorization header',
      'Check rate limit responses (HTTP 429 Too Many Requests)',
      'Keep API keys strictly server-side or in secure environment variables'
    ],
    recommendedCommand: 'curl -i -H "Accept: application/json" https://httpbin.org/get'
  },
  {
    id: 'blog-5',
    icon: '🐍',
    category: 'Python',
    title: 'Build Your First Command-Line Project in 30 Minutes',
    readTime: '5 min read',
    summary: 'How to turn a simple Python script into a reusable CLI utility with argparse, virtual environments, and colored terminal output.',
    content: [
      'Building command-line utilities is one of the fastest ways to understand real programming. Instead of hardcoding values inside your code, use Python standard library module "argparse" to parse flags and arguments passed from the shell.',
      'Add informative exit codes: exit with sys.exit(0) on success, and sys.exit(1) on failure. This ensures your script can be cleanly chained with other tools in shell pipelines (like "python script.py && echo Done").',
      'Package your script with a clean README, virtual environment instructions, and a requirements.txt file so other developers can clone and execute it with zero friction.'
    ],
    keyTakeaways: [
      'Use argparse for clean CLI flag parsing',
      'Return semantic exit codes (0 for success, non-zero for errors)',
      'Document installation steps in a clean README.md'
    ],
    recommendedCommand: 'python3 -m venv .venv && source .venv/bin/activate'
  },
  {
    id: 'blog-6',
    icon: '◈',
    category: 'Open Source',
    title: 'How to Start Exploring GitHub Projects Without Feeling Overwhelmed',
    readTime: '5 min read',
    summary: 'Practical tips to read open-source codebases, clone repositories, inspect pull requests, and contribute your first fix.',
    content: [
      'Large open-source repositories can look daunting with thousands of files. Start by reading the README.md, CONTRIBUTING.md, and package manifest (package.json, pyproject.toml, or Cargo.toml) to identify entry points.',
      'Search for issues with the label "good first issue" or "documentation". These are specifically curated by maintainers to welcome new contributors.',
      'Always fork the repository first, create a feature branch ("git checkout -b fix-typo"), write clear commit messages, and submit a polite Pull Request referencing the related issue number.'
    ],
    keyTakeaways: [
      'Start by inspecting the root README and package configuration',
      'Look for the "good first issue" tag in the repository tracker',
      'Always submit changes via a dedicated feature branch'
    ],
    recommendedCommand: 'git clone https://github.com/user/project.git && cd project'
  }
];

export const FAQS = [
  {
    q: 'What is Termux and is it safe to use?',
    a: 'Termux is an Android terminal emulator and Linux user-space environment application. It does not require rooting your device because it executes inside the standard Android application sandbox. It is very safe when downloaded from official sources like F-Droid or GitHub. Avoid modified or third-party APKs.'
  },
  {
    q: 'Is Linux required to learn programming?',
    a: 'No. Programming can be learned on any operating system including Windows, macOS, and Android. However, most production servers, cloud containers (Docker, Kubernetes), and modern developer workflows run Linux, making command-line fluency an invaluable career skill.'
  },
  {
    q: 'Do I need an API key for every public API?',
    a: 'No. Many community APIs (like Open-Meteo for weather, REST Countries for geography, or JSONPlaceholder for fake testing data) are completely open and require no authentication key. However, commercial APIs typically require a free developer token to track rate limits.'
  },
  {
    q: 'Is the Public APIs repository itself the API provider?',
    a: 'No. It is a community-maintained directory of public APIs created by developers worldwide. The listed endpoints are owned and operated by their respective third-party providers.'
  },
  {
    q: 'Can I track my learning progress?',
    a: 'Yes. Completed lessons and starred APIs are automatically saved in your browser storage (localStorage) so your learning progress is preserved between visits without requiring an account.'
  },
  {
    q: 'What should I do if a command fails or throws an error?',
    a: 'Read the error output carefully: error messages in Linux, Termux, and Git usually describe the exact issue (e.g., missing package, incorrect directory, or permission denied). Always verify your current folder with "pwd" before troubleshooting.'
  }
];

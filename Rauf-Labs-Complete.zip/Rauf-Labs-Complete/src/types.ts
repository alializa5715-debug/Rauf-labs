export interface Course {
  id: string;
  icon: string;
  title: string;
  description: string;
  tags: string[];
  sectionId: string;
  lessonCount: number;
}

export interface LessonDetail {
  id: string;
  section: string;
  idx: number;
  title: string;
  summary: string;
  command: string;
  explanation: string;
  expectedOutput: string;
  safetyTip: string;
  exercise: string;
  tags: string[];
}

export interface ProgrammingPath {
  id: string;
  icon: string;
  name: string;
  summary: string;
  roadmap: string[];
  installCommand: string;
  starterCode: string;
  keyUseCases: string[];
}

export interface OpenSourceTool {
  name: string;
  category: string;
  website: string;
  description: string;
  installCommand: string;
}

export interface CommandRef {
  id: string;
  category: string;
  command: string;
  description: string;
  example: string;
  flagNotes?: string;
}

export interface BlogPost {
  id: string;
  icon: string;
  category: string;
  title: string;
  readTime: string;
  summary: string;
  content: string[];
  keyTakeaways: string[];
  recommendedCommand?: string;
}

export interface PublicApiItem {
  name: string;
  description: string;
  category: string;
  auth: string;
  https: boolean | string;
  cors?: string;
  link: string;
}

export interface SearchResultItem {
  id: string;
  type: string;
  title: string;
  desc: string;
  sectionId?: string;
  action?: () => void;
}
